import boto3 
import json 
import argparse
import time
from os import environ

#IMPORTANT NOTE
# DO NOT ADD Route53SelfService CLOUDFORMATION PARAMETER UPDATE FROM THE PIPELINE AS IT SHOULD USE THE EXISTING VALUES ONLY EVEN IF YOU ARE UPDATING THE STACK
# The Route53SelfService PARAMETER VALUE UPDATE HAPPENS FROM ROUTE53 SELF SERVICE CLOUDNOW JOB SO YOU SHOULD NOT UPDATE THIS VALUE FROM ANY OTHER PIPELINE
 
class IDY:
    def __init__(self, args):
        '''
        '''
        self.IDENTIFIER = args.IDENTIFIER
        self.ACCOUNTNUMBER=args.ACCOUNTNUMBER
        
        self.region=args.aws_region
        self.is_china=False
        if self.region == "cn-north-1":
            self.is_china=True
        self.stack_name=f"NVSGISIDY-IAM-MASTER-{self.IDENTIFIER}-APP-01"
        self.account=args.ACCOUNT
        if self.account == "EXSBX":
            file="exsbx_cloudformation.json"
        else:
            file="eerstd_cloudformation.json"
  

        file_open = open(file, "rt")
        data = file_open.read()

        data=data.replace('$IDENTIFIER', self.IDENTIFIER)
        data=data.replace('$ACCOUNTNUMBER', self.ACCOUNTNUMBER)
        self.data= data
        file_open.close()
        
        
    def main(self):
        file_write=open(f"{self.stack_name.lower()}.json", "wt")
        file_write.write(self.data)
        file_write.close()
        if self.is_china:
            cf=boto3.client("cloudformation", "cn-north-1")
        else:
            cf=boto3.client("cloudformation", "eu-west-1")
        try:
            response = cf.create_stack(
                StackName=self.stack_name,
                TemplateBody=self.data,
                Capabilities=["CAPABILITY_AUTO_EXPAND", "CAPABILITY_NAMED_IAM"],
                DisableRollback=True,
            )
            print(response)
            self.stack_status_check()
        except cf.exceptions.AlreadyExistsException:
            updatestatus = False
            if self.is_china:
                cf=boto3.client("cloudformation", "cn-north-1")
                client = boto3.resource("cloudformation", "cn-north-1")
            else:
                cf=boto3.client("cloudformation", "eu-west-1")
                client = boto3.resource("cloudformation", "eu-west-1")
            stackresponse = client.Stack(self.stack_name)
            if stackresponse.parameters is not None:
                for param in stackresponse.parameters:
                    if param['ParameterKey'] == 'Route53SelfService':
                        response = cf.update_stack(
                            StackName=self.stack_name,
                            TemplateBody=self.data,
                            Parameters=[
                                {
                                    'ParameterKey': 'Route53SelfService',
                                    'UsePreviousValue': True
                                },
                            ],
                            Capabilities=["CAPABILITY_AUTO_EXPAND", "CAPABILITY_NAMED_IAM"],
                            DisableRollback=True
                        )
                        print(response)
                        updatestatus = True
                        self.stack_status_check()
            if not updatestatus:
                response = cf.update_stack(
                    StackName=self.stack_name,
                    TemplateBody=self.data,
                    Capabilities=["CAPABILITY_AUTO_EXPAND", "CAPABILITY_NAMED_IAM"]
                )
                print(response)
                self.stack_status_check()
        except Exception as e:
            print(str(e))
            raise "Stack Operation failed"

    def stack_status_check(self):
        if self.is_china:
            cf = boto3.client("cloudformation", "cn-north-1")
        else:
            cf = boto3.client("cloudformation", "eu-west-1")
        while True:
            response = cf.describe_stacks(StackName=self.stack_name)
            status = response['Stacks'][0]['StackStatus']
            print(f'Stack status: {status}')
            if status in ['CREATE_COMPLETE', 'UPDATE_COMPLETE']:
                break
            if status in ['DELETE_COMPLETE', 'ROLLBACK_COMPLETE', 'UPDATE_ROLLBACK_COMPLETE', 'CREATE_FAILED', 'UPDATE_FAILED']:
                exit(1)
            time.sleep(15)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="IDY CFTs"
    )
    parser.add_argument("--IDENTIFIER", "-ID", help="s", required=True)
    parser.add_argument("--ACCOUNTNUMBER", "-ACC", help="s", required=True)
    parser.add_argument("--ACCOUNT", "-A", help="s", required=True)
    parser.add_argument(
        "--aws_region", "-r", help="us-east-1/cn-north-1", required=True
    )
    args = parser.parse_args()
    IDY(args).main()