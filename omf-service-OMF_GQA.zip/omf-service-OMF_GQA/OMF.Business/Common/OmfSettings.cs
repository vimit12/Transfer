﻿namespace OMF.Business.Common
{
    public class OmfSettings
    {
        public string ExcelFilePricingMatrixFileName { get; set; }

        public string ExcelFilePricingMatrixLeverage { get; set; }

        public string SimulationUrl { get; set; }

        public short SimulationEmailTemplateId { get; set; }

        public short PaymentTermApprovalActionId { get; set; }

        public short PaymentTermDays { get; set; }

        public short MaxHours { get; set; }

        public string LDAPConnectionString { get; set; }

        public string AdditionalDLApprover { get; set; }

        public string AdditionalMLApprover { get; set; }

        public string EmployeeSearchService { get; set; }

        public string ECFReminderEmail { get; set; }

        public string ECFEscalationEmail { get; set; }

        public string ECFReminderAndEscationCCEmail { get; set; }
    }
}
