﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class FinancialWeeklyHoursViewModel
    {
        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public int WeeklyHours { get; set; }

        public decimal LoadingPercentage { get; set; }

        public List<FinancialQuarterViewModel> Quarters { get; set; }
    }
}
