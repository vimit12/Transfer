﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class IssuesViewModel
    {
        public int IssueId { get; set; }

        public int ScreenName { get; set; }

        public string IssueDescription { get; set; }

        public int Priority { get; set; }

        public int Status { get; set; }

        public string ReportedBy { get; set; }

        public DateTime PlannedClosedDate { get; set; }

        public DateTime? ActualClosedDate { get; set; }

        public int IssueType { get; set; }

        public string ActionedBy { get; set; }

        public bool ActionedStatus { get; set; }

        public string Comments { get; set; }

        public string DocumentStream { get; set; }

        public string DocumentExtension { get; set; }

        public string DocumentName { get; set; }

        public int IssueNumber { get; set; }

        public int ApprovedBy { get; set; }

        public int AssignedTo { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public bool IsActive { get; set; }
    }
}
