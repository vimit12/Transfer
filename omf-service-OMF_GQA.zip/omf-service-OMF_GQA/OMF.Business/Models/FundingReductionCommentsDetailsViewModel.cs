﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class FundingReductionCommentsDetailsViewModel
    {
        public int StageId { get; set; }

        public List<FundingReductionEmailCommentsByUserViewModel> Comments { get; set; }
    }
}
