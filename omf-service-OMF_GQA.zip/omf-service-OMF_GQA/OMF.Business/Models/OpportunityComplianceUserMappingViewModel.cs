﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class OpportunityComplianceUserMappingViewModel
    {
        public int OpportunityId { get; set; }

        public int UserRoleId { get; set; }
    }
}
