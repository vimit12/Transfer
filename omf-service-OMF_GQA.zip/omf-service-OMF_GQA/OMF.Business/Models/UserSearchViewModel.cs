﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class UserSearchViewModel
    {
        public string RoleId { get; set; }

        public string Alias { get; set; }

        public string Role { get; set; }

        public string UserId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string UserEmail { get; set; }
        
    }
}
