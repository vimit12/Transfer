﻿namespace OMF.Business.Models
{
    using System;

    public class Comments
    {
        public int CommentId { get; set; }

        public string Comment { get; set; }

        public int ScreenId { get; set; }

        public int Year { get; set; }

        public string Quarter { get; set; }

        public string CurrencyCode { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
