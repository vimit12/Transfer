﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class OpportunityWorkLocationWorkfFlowBasicDetailsViewModel
    {
        public int OpportunityId { get; set; }

        public int WorkLocationId { get; set; }

        public int StatusId { get; set; }

        public int UserCommentId { get; set; }

    }
}
