﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class ORBAttachmentViewModel
    {
        public int OpportunityId { get; set; }

        public string FileName { get; set; }

        public string FileExtension { get; set; }

        public string FileContent { get; set; }

        public byte[] ByteFileContent { get; set; }

        public bool RatingLessThan2 { get; set; }

        public bool IsCategory1 { get; set; }

        public string URL { get; set; }

        public string Comments { get; set; }
    }
}
