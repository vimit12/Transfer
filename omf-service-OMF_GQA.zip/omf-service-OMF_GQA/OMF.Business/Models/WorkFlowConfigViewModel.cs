﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class WorkFlowConfigViewModel : BaseClass
    {
        public int WorkFlowId { get; set; }

        public int RoleId { get; set; }

        public int StatusActionId { get; set; }

        public int CurrentStatusTypeId { get; set; }

        public int StatusTypeId { get; set; }

        public string RoleName { get; set; }

        public string StatusActionName { get; set; }

        public string StatusTypeName { get; set; }

        public string CurrentStatusTypeName { get; set; }

        public string Comments { get; set; }

        public string WorkFlowTemplateMappingNames { get; set; }

        public IEnumerable<WorkFlowTemplateMappingViewModel> WorkFlowTemplateMappingList { get; set; }

        public int RegionId { get; set; }

        public string Countries { get; set; }

        public string Roles { get; set; }

        public IEnumerable<CountryViewModel> CountryViewModels { get; set; }

        public IEnumerable<RoleViewModel> RoleViewModels { get; set; }
    }
}
