﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class ScreenActionsViewModel
    {
        public int ScreenActionId { get; set; }

        public int ScreenId { get; set; }

        public string ActionName { get; set; }
    }
}
