﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class FinancialAnnualMaintenanceCostViewModel : BaseClass
    {
        public int FinancialAnnualMaintenanceCostId { get; set; }

        public int OpportunityId { get; set; }

        public int YearId { get; set; }

        public double Revenue { get; set; }

        public double Cost { get; set; }

        public double GrossServicesMarginValue { get; set; }

        public double GrossProductMarginPercent { get; set; }

        public bool IsDelete { get; set; }

        public bool IsUpdate { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string Description { get; set; }

    }
}
