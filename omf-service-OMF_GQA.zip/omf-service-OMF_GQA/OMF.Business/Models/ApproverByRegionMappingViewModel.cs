﻿namespace OMF.Business.Models
{
    public class ApproverByRegionMappingViewModel
    {
        public int ApproverByRegionMappingId { get; set; }

        public int ApproverByRegionId { get; set; }

        public int UserRoleId { get; set; }
    }
}
