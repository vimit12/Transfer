﻿namespace OMF.Business.Models
{
    public class PaymentTermsViewModel : BaseClass
    {
        public int PaymentTermId { get; set; }

        public string PaymentTermCode { get; set; }

        public short PayTermDays { get; set; }

        public string Comments { get; set; }
    }
}