﻿namespace OMF.Business.Models
{
    public class RateCardByOpportunityViewModel : BaseClass
    {
        public int RateCardByOpportunityId { get; set; }

        public int OpportunityId { get; set; }

        public int YearId { get; set; }

        public int WorkLocationId { get; set; }

        public string WorkLocation { get; set; }

        public int ResourceRoleId { get; set; }

        public string ResourceRoleName { get; set; }

        public double BillingCostValue { get; set; }

        public double ActualBillingCost { get; set; }

        public string DeliveryModelName { get; set; }

        public int DeliveryModelId { get; set; }

        public float TargetPGMPercent { get; set; }

        public double StandardCostValue { get; set; }

        public int PSI { get; set; }
    }
}
