﻿namespace OMF.Business.Models
{
    public class IFRSReferBackOnHoldReasonByOpportunityViewModel
    {
        public int IFRSReferbackOnHoldReasonByOpportunityId { get; set; }

        public int IFRSReferBackOnHoldReasonId { get; set; }

        public string IFRSReferBackOnHoldReasonName { get; set; }

        public int OpportunityId { get; set; }

        public int StatusActionId { get; set; }

        public string StatusActionText { get; set; }
    }
}
