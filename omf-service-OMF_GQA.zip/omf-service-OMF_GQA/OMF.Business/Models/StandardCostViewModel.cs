﻿namespace OMF.Business.Models
{
    public class StandardCostViewModel
    {
        public int RateCardId { get; set; }

        public int YearId { get; set; }

        public int WorkLocationId { get; set; }

        public int ResourceRoleId { get; set; }

        public double StandardCostValue { get; set; }

        public int Psi { get; set; }

        public string Comments { get; set; }
    }
}
