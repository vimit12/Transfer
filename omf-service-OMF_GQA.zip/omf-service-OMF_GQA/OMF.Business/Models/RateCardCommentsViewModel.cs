﻿namespace OMF.Business.Models
{
    public class RateCardCommentsViewModel
    {
        public int Year { get; set; }

        public int CurrencyId { get; set; }
    }
}
