﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class CopyFinancialProposalViewModel
    {
        public int YearId { get; set; }

        public IEnumerable<FinancialEmployeeDetailViewModel> StaffEmpDetails { get; set; }

        public IEnumerable<FinancialContractorDetailViewModel> StaffContractorDetails { get; set; }

        public IQueryable<FinancialSoftwareHardwareDetailViewModel> SoftwareHardwareDetails { get; set; }

        public IEnumerable<FinancialManagedServiceDetailViewModel> ManagedServices { get; set; }

       public FinancialBillableExpenseDetailViewModel BillableExpenseDetails { get; set; }

        public IEnumerable<FinancialNonBillableExpenseDetailViewModel> NonBillableExpenseDetails { get; set; }

        public IEnumerable<FinancialCloudHostingDetailsViewModel> CloudHostingDetails { get; set; }

        public IEnumerable<FinancialsStaffAugmentationViewModel> StaffAugmentationDetails { get; set; }

        public IEnumerable<FinancialsDiscountAndRebateViewModel> DiscountAndRebateDetails { get; set; }

        public IEnumerable<FinancialRoyaltyDetailsViewModel> RoyaltyDetails { get; set; }
    }
}
