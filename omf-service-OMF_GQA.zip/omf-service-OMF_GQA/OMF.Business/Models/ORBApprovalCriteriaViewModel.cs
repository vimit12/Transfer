﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class ORBApprovalCriteriaViewModel : BaseClass
    {
        public int ORBApprovalCriteriaId { get; set; }

        public bool PublicSectorAccount { get; set; }

        public bool PartnerDependent { get; set; }

        public bool NewTechnologyOrSolution { get; set; }

        public bool TotalPGMLessThan30Percentage { get; set; }

        public bool LoadingLessThan80Percentage { get; set; }

        public bool NamedResourcesRequired { get; set; }

        public bool NicheSkillsetRequired { get; set; }

        public bool NonStandardTerms { get; set; }

        public bool RiskFlagged { get; set; }

        public string RiskCriteria { get; set; }

        public string ApproversAsPerRiskCriteria { get; set; }

        public int OpportunityId { get; set; }

        public bool IsNewClient { get; set; }

        public bool AdditionalApprovalRequired { get; set; }
    }
}