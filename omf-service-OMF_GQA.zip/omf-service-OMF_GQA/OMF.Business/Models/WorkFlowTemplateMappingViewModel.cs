﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class WorkFlowTemplateMappingViewModel
    {
        public int WorkFlowTemplateMappingId { get; set; }

        public int WorkFlowId { get; set; }

        public int TemplateId { get; set; }

        public WorkFlowConfigViewModel WorkFlow { get; set; }

        public EmailTemplateViewModel EmailTemplate { get; set; }
    }
}
