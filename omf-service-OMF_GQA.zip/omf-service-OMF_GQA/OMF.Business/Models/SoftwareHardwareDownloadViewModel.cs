﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class SoftwareHardwareDownloadViewModel
    {
        public static string Type = "Type"; // 0
        public static string Product = "Product"; // 1
        public static string Model = "Model"; // 2
        public static string Details = "Details"; // 3
        public static string Qty = "Qty"; // 4
        public static string HitachiProduct = "Hitachi Product"; // 5
        public static string ReasonForNotUsingHitachiProduct = "Reason For Not Using HitachiProduct"; // 6
        public static string PurchaseFrom = "PurchaseFrom"; // 7
        public static string PurchasePricePerUnit = "Purchase Price/Unit"; // 8
        public static string MarkupPercent = "Markup %"; // 9
        public static string TargetMarkupPercent = "Target Markup %"; // 10
        public static string TargetMarkupVariance = "Target Markup Variance"; // 11
        public static string TotalStandardCost = "Total Standard Cost"; // 12
        public static string EndUserCustomerName = "End User Customer Name"; // 13
        public static string SellingPricePerUnit = "Selling Price/Unit"; // 14
        public static string Revenue = "Revenue"; // 15
        public static string TotalPGM = "Total PGM"; // 16
        public static string PGMPercent = "PGM %"; // 17
        public static string WarrantyApplicable = "Warranty Applicable"; // 18
        public static string WarrantyProvider = "Warranty Provider"; // 19
        public static string Vendor = "Vendor"; // 20
        public static string StartDate = "Start Date"; // 21
        public static string EndDate = "End Date"; // 22
        public static string ErrorsDescription = "Errors Description"; // 23
    }
}
