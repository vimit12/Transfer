﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class WorkFlowActionsViewModel
    {
        public int RoleId { get; set; }

        public int OpportunityId { get; set; }

        public string UpdatedBy { get; set; }

        public List<StatusActionViewModel> StatusActionViewModelList { get; set; }

        public int ScreenId { get; set; }
    }
}
