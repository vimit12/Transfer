﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class RateCardViewModel
    {
        public int RateCardId { get; set; }

        public int YearId { get; set; }

        public int WorkLocationId { get; set; }

        public int ResourceRoleId { get; set; }

        public string ResourceRoleName { get; set; }

        public double StandardCostValue { get; set; }

        public bool? IsDiscountMargin { get; set; }

        public bool? IsIncreaseOverCostRate { get; set; }

        public float DiscountPercentage { get; set; }

        public float MarginPercentage { get; set; }

        public float IncreaseOverCostRate { get; set; }

        public int Psi { get; set; }

        public ICollection<StandardCostCurrencyViewModel> StandardCostCurrencyViewModel { get; set; }

        public double ActualStandardCostValue { get; set; }
    }
}