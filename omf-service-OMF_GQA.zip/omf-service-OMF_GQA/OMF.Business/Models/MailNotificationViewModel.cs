﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class MailNotificationViewModel
    {
        public string Subject { get; set; }

        public string MailBody { get; set; }

        public string FromEmailAddress { get; set; }

        public List<string> ToEmailAddress { get; set; }

        public List<string> CcEmailAddress { get; set; }

        public string[] Files { get; set; }
    }
}
