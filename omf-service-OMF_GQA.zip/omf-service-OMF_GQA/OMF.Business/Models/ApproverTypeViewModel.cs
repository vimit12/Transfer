﻿namespace OMF.Business.Models
{
    public class ApproverTypeViewModel
    {
        public int ApproverTypeId { get; set; }

        public string ApproverTypeName { get; set; }

        public bool IsActive { get; set; }
    }
}