﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class HVOUPracticeMappingViewModel : BaseClass
    {
        public int HVOUPracticeMappingId { get; set; }

        public int HVOUId { get; set; }

        public int HVOUPracticeId { get; set; }

        public string HVOUName { get; set; }

        public string HVOUPracticeName { get; set; }

        public string HVOUPracticeNames { get; set; }

        public IEnumerable<HVOUPracticesViewModel> HVOUPractices { get; set; }
    }
}
