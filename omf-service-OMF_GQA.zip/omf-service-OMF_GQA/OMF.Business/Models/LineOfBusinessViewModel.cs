﻿using System;

namespace OMF.Business.Models
{
    public class LineOfBusinessViewModel : BaseClass
    {
        public int LineOfBusinessId { get; set; }

        public string LineOfBusinessName { get; set; }

        public string Comments { get; set; }

        public DateTime? ValidFrom { get; set; }

        public DateTime? ValidTill { get; set; }
    }
}
