﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

   public class FinancialBillableExpenseDetailViewModel : BaseClass
    {
        public int FinancialBillableExpenseDetailId { get; set; }

        public int OpportunityId { get; set; }

        public int YearId { get; set; }

        public double BillableExpense { get; set; }
    }
}
