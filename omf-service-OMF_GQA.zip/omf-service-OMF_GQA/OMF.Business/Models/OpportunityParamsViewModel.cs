﻿namespace OMF.Business.Models
{
    public class OpportunityParamsViewModel
    {
        public int OpportunityId { get; set; }

        public int YearId { get; set; }
    }
}
