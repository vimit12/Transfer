﻿namespace OMF.Business.Models
{
    public class ValidateVarianceDataViewModel
    {
        public int? LeveragePercentageVarianceId { get; set; }

        public int? ProjectOrganization { get; set; }

        public int? LineOfBusiness { get; set; }

        public double? VariancePercentage { get; set; }

        public double? VarianceAmountUSD { get; set; }

        public int? IFRSApprovalType { get; set; }

        public int? OpportunityId { get; set; }
    }
}
