﻿namespace OMF.Business.Models
{
    public class CapabilityViewModel : BaseClass
    {
        public int CapabilityId { get; set; }

        public string CapabilityName { get; set; }

        public string Comments { get; set; }
    }
}