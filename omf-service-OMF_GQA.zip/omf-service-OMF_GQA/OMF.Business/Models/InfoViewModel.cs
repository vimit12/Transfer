﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class InfoViewModel
    {
        public ClientMasterViewModel ClientMaster { get; set; }

        public ClientBillingAddressViewModel ClientBillingAddress { get; set; }

        public OpportunityViewModel Opportunity { get; set; }

        public IEnumerable<OpportunityAccessViewModel> OpportunityAccess { get; set; }

        public OpportunityCRDetailsViewModel OpportunityCRDetailsViewModel { get; set; }

    }
}
