﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class EmployeeFileUploadDetailsViewModel
    {
        public int OpportunityId { get; set; }

        public string FileContent { get; set; }

        public string FileName { get; set; }
    }
}
