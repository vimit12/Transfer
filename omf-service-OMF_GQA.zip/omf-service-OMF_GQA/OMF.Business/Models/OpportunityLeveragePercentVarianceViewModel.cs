﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class OpportunityLeveragePercentVarianceViewModel
    {
        public int OppLeveragePercentVarianceId { get; set; }

        public int OpportunityId { get; set; }

        public double? TotalContractValueSOW { get; set; }

        public double? TotalContractValueOMF { get; set; }

        public int? FXRate { get; set; }

        public DateTime? FXDate { get; set; }

        public double? DifferenceAmount { get; set; }

        public double? DifferenceAmountUSD { get; set; }

        public double? DifferencePercentage { get; set; }

        public string IFRSComments { get; set; }

        public string PCComments { get; set; }

        public string IFRSReReviewComments { get; set; }

        public int? ScreenID { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }
       
        public string UpdatedBy { get; set; }
       
        public DateTime? UpdatedDate { get; set; }
       
        public bool IsActive { get; set; }

        public bool? FullyExecutedSowAvailable { get; set; }

        public string VarianceConclusion { get; set; }

        public bool? IsVarianceExceptionApproved { get; set; }
        public OpportunityProjectSummaryViewModel OpportunityProjectSummaryViewModel { get; set; }
    }
}
