﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class PriceMatrixCalculatorViewModel
    {
        public IEnumerable<PriceCalculatorViewModel> PriceCalculatorViewModel { get; set; }

        public IEnumerable<PricingMatrixViewModel> PricingMatrixViewModel { get; set; }
    }
}
