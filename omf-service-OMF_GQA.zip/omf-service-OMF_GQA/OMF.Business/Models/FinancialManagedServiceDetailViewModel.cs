﻿namespace OMF.Business.Models
{
    public class FinancialManagedServiceDetailViewModel : BaseClass
    {
        public int FinancialManagedServiceDetailId { get; set; }

        public int OpportunityId { get; set; }

        public int YearId { get; set; }

        public double FixedFeeRevenue { get; set; }

        public double FixedFeeCost { get; set; }

        public double FixedFeeMargin { get; set; }

        public float FixedFeePercentage { get; set; }

        public string FixedFeeProjectName { get; set; }

        public double CallOffRevenue { get; set; }

        public double CallOffCost { get; set; }

        public double CallOffMargin { get; set; }

        public float CallOffPercentage { get; set; }

        public string CallOffProjectName { get; set; }

        public double ChangeRequestRevenue { get; set; }

        public double ChangeRequestCost { get; set; }

        public double ChangeRequestMargin { get; set; }

        public float ChangeRequestPercentage { get; set; }

        public string ChangeRequestProjectName { get; set; }

        public double TransitionRevenue { get; set; }

        public double TransitionCost { get; set; }

        public double TransitionMargin { get; set; }

        public float TransitionPercentage { get; set; }

        public string TransitionProjectName { get; set; }
    }
}
