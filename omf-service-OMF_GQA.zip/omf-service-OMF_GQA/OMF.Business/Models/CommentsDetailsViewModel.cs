﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class CommentsDetailsViewModel
    {
        public int ScreenId { get; set; }

        public List<EmailCommentsByUserViewModel> Comments { get; set; }
    }
}
