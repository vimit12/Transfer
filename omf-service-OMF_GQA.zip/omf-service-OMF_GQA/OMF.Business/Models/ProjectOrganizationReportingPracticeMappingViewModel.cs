﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class ProjectOrganizationReportingPracticeMappingViewModel : BaseClass
    {
        public int ProjectOrganizationReportingPracticeMappingId { get; set; }

        public int ProjectOrganizationId { get; set; }

        public int ReportingPracticeId { get; set; }

        public string ProjectOrganizationName { get; set; }

        public string ReportingPracticeNames { get; set; }

        public IEnumerable<ReportingPracticeViewModel> ReportingPractices { get; set; }
    }
}
