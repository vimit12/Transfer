﻿namespace OMF.Business.Models
{
    public class CurrencyViewModel : BaseClass
    {
        public int CurrencyId { get; set; }

        public string CurrencyCode { get; set; }

        public string Comments { get; set; }
    }
}