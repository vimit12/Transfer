﻿namespace OMF.Business.Models
{
    public class OpportunitySectionsViewModel : BaseClass
    {
        public int OpportunitySectionId { get; set; }

        public int OpportunityId { get; set; }

        public int SectionId { get; set; }
    }
}
