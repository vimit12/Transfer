﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class EmailTemplateViewModel : BaseClass
    {
        public int TemplateId { get; set; }

        public string TemplateName { get; set; }

        public string TemplateSubject { get; set; }

        public string TemplateBody { get; set; }

        public List<int> RecipientTypeCC { get; set; }

        public List<int> RecipientTypeTo { get; set; }

        public int RecipientTypeFrom { get; set; }

        public List<int> DocumentType { get; set; }
    }
}
