﻿namespace OMF.Business.Models
{
    using System;

    public class IFRSRevenueTeamCheckListViewModel : BaseClass
    {
        public int IFRS23CheckListId { get; set; }

        public int OpportunityId { get; set; }

        public int Question1 { get; set; }

        public string Question1Description { get; set; }

        public int Question2 { get; set; }

        public string Question2Description { get; set; }

        public int Question3 { get; set; }

        public string Question3Description { get; set; }

        public int Question4 { get; set; }

        public string Question4Description { get; set; }

        public int Question5 { get; set; }

        public string Question5Description { get; set; }

        public int Question6 { get; set; }

        public string Question6Description { get; set; }

        public int Question7 { get; set; }

        public string Question7Description { get; set; }

        public int Question8 { get; set; }

        public string Question8Description { get; set; }

        public int Question9 { get; set; }

        public string Question9Description { get; set; }

        public int Question10 { get; set; }

        public string Question10Description { get; set; }

        public int Question11 { get; set; }

        public string Question11Description { get; set; }

        public int Question12 { get; set; }

        public string Question12Description { get; set; }

        public int Question13 { get; set; }

        public string Question13Description { get; set; }

        public int Question14 { get; set; }

        public string Question14Description { get; set; }

        public int Question15 { get; set; }

        public string Question15Description { get; set; }

        public int Question16 { get; set; }

        public string Question16Description { get; set; }

        public int Question17 { get; set; }

        public string Question17Description { get; set; }

        public int Question18 { get; set; }

        public string Question18Description { get; set; }

        public int Question19 { get; set; }

        public string Question19Description { get; set; }

        public int Question20 { get; set; }

        public string Question20Description { get; set; }

        public int Question21 { get; set; }

        public string Question21Description { get; set; }

        public int Question22 { get; set; }

        public string Question22Description { get; set; }

        public int Question23 { get; set; }

        public string Question23Description { get; set; }

        public int? IFRSApprovalType { get; set; }

        public string IFRSApprovalComments { get; set; }
    }
}