﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

   public class FinancialNonBillableExpenseDetailViewModel : BaseClass
    {
        public int FinancialNonBillableExpenseDetailId { get; set; }

        public int OpportunityId { get; set; }

        public int YearId { get; set; }

        public int EmployeeTypeDeliveryModelId { get; set; }

        public string EmployeeTypeDeliveryModelName { get; set; }

        public double Amount { get; set; }

        public string Description { get; set; }

        public string ReasonNotBillable { get; set; }

        public bool IsDelete { get; set; }

        public bool IsUpdate { get; set; }
    }
}
