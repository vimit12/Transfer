﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class LandingPageDomainViewModel
    {
        public string Domain { get; set; }

        public int Count { get; set; }

        public IEnumerable<LandingPageStatusViewModel> OpportunitiesByStatus { get; set; }
    }
}
