﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class WorkLocationStatusActionViewModel : BaseClass
    {
        public int StatusActionId { get; set; }

        public string Action { get; set; }

        public string StatusActionText { get; set; }

        public int ScreenId { get; set; }

        public string ScreenName { get; set; }

        public string WorkLocationName { get; set; }

        public int WorkLocationId { get; set; }
    }
}
