﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class FinancialContractorDetailViewModel : BaseClass
    {
        public int FinancialContractorDetailId { get; set; }

        public int OpportunityId { get; set; }

        public string Resourcerole { get; set; }

        public string ResourceName { get; set; }

        public string Skills { get; set; }

        public string Company { get; set; }

        public DateTime? ResourceStartDate { get; set; }

        public DateTime? ResourceEndDate { get; set; }

        public float TotalWorkHours { get; set; }

        public double HitachiConsultingBillingRate { get; set; }

        public double ContractorBillingRate { get; set; }

        public double Revenue { get; set; }

        public double TotalContractorCost { get; set; }

        public double ProjectGrossMargin { get; set; }

        public float PgmPercentage { get; set; }

        public int Year { get; set; }

        public int YearId { get; set; }

        public IEnumerable<FinancialQuarterViewModel> FinancialContractorWorkHours { get; set; }

        public int ContractorType { get; set; }
    }
}