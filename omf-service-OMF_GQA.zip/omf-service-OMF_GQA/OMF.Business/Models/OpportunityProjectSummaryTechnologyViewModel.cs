﻿namespace OMF.Business.Models
{
    public class OpportunityProjectSummaryTechnologyViewModel : BaseClass
    {
        public int OpportunityProjectSummaryTechnologyId { get; set; }

        public int OpportunityId { get; set; }

        public int TechnologyId { get; set; }

        public float Percentage { get; set; }

        public bool IsUpdate { get; set; }

        public bool IsDelete { get; set; }

        public string TechnologyName { get; set; }

        public int SubTechnologyId { get; set; }

        public string SubTechnologyName { get; set; }
    }
}
