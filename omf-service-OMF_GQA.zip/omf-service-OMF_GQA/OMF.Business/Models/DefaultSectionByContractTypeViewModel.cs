﻿namespace OMF.Business.Models
{
    public class DefaultSectionByContractTypeViewModel : BaseClass
    {
        public int DefaultSectionByContractTypeId { get; set; }

        public int ContractTypeId { get; set; }

        public int SectionId { get; set; }
    }
}
