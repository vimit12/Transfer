﻿namespace OMF.Business.Models
{
  public class QuarterViewModel
  {
    public int QuarterId { get; set; }

    public string QuarterName { get; set; }
  }
}
