﻿namespace OMF.Business.Models
{
    using System;

    public class ProductScreeningInformationViewModel : BaseClass
    {
        public int ProductScreeningInformationId { get; set; }

        public int OpportunityId { get; set; }

        public string ProductName { get; set; }

        public string ProductNumber { get; set; }

        public string ProductDescription { get; set; }

        public string EccnNumber { get; set; }

        public string CcatsNumber { get; set; }
    }
}
