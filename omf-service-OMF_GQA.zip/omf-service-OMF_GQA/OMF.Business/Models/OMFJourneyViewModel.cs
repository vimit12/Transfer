﻿namespace OMF.Business.Models
{
    public class OMFJourneyViewModel : BaseClass
    {
        public int OMFJourneyId { get; set; }

        public int OpportunityId { get; set; }

        public int StatusId { get; set; }

        public string StatusName { get; set; }

        public string Comments { get; set; }

        public string CreatedByUserName { get; set; }
    }
}
