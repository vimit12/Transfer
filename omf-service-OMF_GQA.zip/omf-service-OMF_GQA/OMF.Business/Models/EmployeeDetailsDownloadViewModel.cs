﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class EmployeeDetailsDownloadViewModel
    {
        public static string WorkLocation = "Resource Location"; // 0
        public static string RoleName = "Role/Level"; // 1
        public static string ResourceId = "Resource ID"; // 2
        public static string ResourceName = "Resource Name"; // 3
        public static string Skills = "Skills"; // 4
        public static string ResourceLoadingPercentage = "Resource Loading"; // 5
        public static string StartDate = "Start Date"; // 6
        public static string EndDate = "End Date"; // 7
        public static string MaxHoursInADay = "Maximum Hours In A Day"; // 8
        public static string TotalWorkHours = "Total Hours"; // 9
        public static string DiscountedHourlyBillingRate = "Disc Hourly Billing Rate"; // 10
        public static string TotalStandardCost = "Total Standard Cost";//11
        public static string StandardCostRate = "Cost Rate";
        public static string RevenueDiscountedRate = "Revenue";
        public static string ProjectGrossMargin = "PGM";
        public static string PgmPercentage = "PGM %";
        public static int count = 12;
        public static string ErrorsDescription = "Errors Description"; // 12
        // Extra fields for Contractor
        public static string Company = "Company"; 
        public static string ContractorBillingRate = "Contractor Billing Rate";
        public static string HitachiConsultingBillingRate = "HV Billing Rate";
        public static string ResourceRole = "Resource Role";
        public static string DiscHourlyBillRate = "Disc Bill Rate"; // 10
        public static string StdCostRate = "Std Cost Rate";
        public static string TotalStdCost = "Cost";//11
        public static string ContactorType = "ContractorType";//11
    }
}
