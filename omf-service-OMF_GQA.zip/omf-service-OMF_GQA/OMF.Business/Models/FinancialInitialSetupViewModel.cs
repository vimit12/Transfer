﻿namespace OMF.Business.Models
{
    public class FinancialInitialSetupViewModel : BaseClass
    {
        public int FinancialInitialSetupId { get; set; }

        public int OpportunityId { get; set; }

        public int YearId { get; set; }

        public int EmployeeCount { get; set; }

        public int ContractorCount { get; set; }

        public double DiscountPercentage { get; set; }

        public int? SwhwCount { get; set; }

        public int? SwhwAmcCount { get; set; }

        public int RateCardType { get; set; }
    }
}
