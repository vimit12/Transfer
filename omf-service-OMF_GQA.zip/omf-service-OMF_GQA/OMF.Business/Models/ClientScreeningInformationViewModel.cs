﻿namespace OMF.Business.Models
{
    using System;

    public class ClientScreeningInformationViewModel : BaseClass
    {
        public int ClientScreeningInformationId { get; set; }

        public int OpportunityId { get; set; }

        public string IsClientOnDeniedPartiesList { get; set; }

        public string SignedNonProliferationCertification { get; set; }

        public string ScreeningConductedBy { get; set; }

        public string Title { get; set; }

        public DateTime? DateOfLegalApproval { get; set; }

        public DateTime? DateOfScreening { get; set; }

        public int? ResultOfScreening { get; set; }

        public string Comments { get; set; }
    }
}
