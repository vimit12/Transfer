﻿namespace OMF.Business.Models
{
    public class IFRSReferBackOnHoldReasonViewModel : BaseClass
    {
        public int IFRSReferBackOnHoldReasonId { get; set; }

        public string IFRSReferBackOnHoldReasonName { get; set; }

        public string Comments { get; set; }

        public int StatusTypeId { get; set; }
    }
}
