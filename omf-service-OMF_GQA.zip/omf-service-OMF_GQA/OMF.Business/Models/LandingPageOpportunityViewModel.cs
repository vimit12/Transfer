﻿using System;

namespace OMF.Business.Models
{
    public  class LandingPageOpportunityViewModel
    {
        public string OpportunityName { get; set; }

        public string CRMId { get; set; }

        public string Customer { get; set; }

        public string LocalizedAccountName { get; set; }

        public string OIC { get; set; }

        public string PM { get; set; }

        public string ContractType { get; set; }

        public string Industry { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }

        public string OpportunityRating { get; set; }

        public string SalesInvolved { get; set; }

        public string TotalMarginPercent { get; set; }

        public string TotalMarginValue { get; set; }

        public string TotalRevenue { get; set; }

        public string CurrencyCode { get; set; }

        public string Status { get; set; }

        public string OpportunityId { get; set; }

        public string ComplianceUserAssignedTo { get; set; }

        public string SentToECFDate { get; set; }

        public string OnShorePM { get; set; }

        public string IFRSUserAssignedTo { get; set; }

        public DateTime? ComplianceUserAssignedDate { get; set; }

        public string ComplianceUserPrevAssignedTo { get; set; }

        public DateTime? ComplianceUserPrevAssignedDate { get; set; }

        public int? ProjectSetupType { get; set; }
    }
}