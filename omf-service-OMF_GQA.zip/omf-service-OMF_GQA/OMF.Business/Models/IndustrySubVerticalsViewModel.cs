﻿using System.Collections;
using System.Collections.Generic;

namespace OMF.Business.Models
{
    public class IndustrySubVerticalsViewModel : BaseClass
    {
        public int IndustrySubVerticalId { get; set; }

        public string IndustrySubVerticalName { get; set; }
    }
}