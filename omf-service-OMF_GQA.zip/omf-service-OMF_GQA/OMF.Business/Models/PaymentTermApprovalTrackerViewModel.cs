﻿namespace OMF.Business.Models
{
    public class PaymentTermApprovalTrackerViewModel : BaseClass
    {
        public int PaymentTermApprovalTrackerId { get; set; }

        public int ClientMasterId { get; set; }

        public string ClientName { get; set; }

        public string PaymentTermCode { get; set; }

        public int PaymentTermId { get; set; }

        public short PayTermDays { get; set; }

        public bool IsApproved { get; set; }

        public bool IsEmailSent { get; set; }
    }
}