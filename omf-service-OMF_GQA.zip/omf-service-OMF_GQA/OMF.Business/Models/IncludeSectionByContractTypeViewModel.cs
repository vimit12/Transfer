﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class IncludeSectionByContractTypeViewModel : BaseClass
    {
        public int IncludeSectionByContractTypeId { get; set; }

        public int ContractTypeId { get; set; }

        public int SectionId { get; set; }

        public string SectionNames { get; set; }

        public string ContractName { get; set; }

        public IEnumerable<OmfFinancialSectionsViewModel> Sections { get; set; }
    }
}
