﻿using System.Collections;
using System.Collections.Generic;

namespace OMF.Business.Models
{
    public class IndustrySegmentViewModel : BaseClass
    {
        public int IndustrySegmentId { get; set; }

        public string IndustrySegmentName { get; set; }

        public string Comments { get; set; }

        public int IndustrySubVerticalId { get; set; }

        public string IndustrySubVerticalName { get; set; }

        public IEnumerable<IndustrySubSegmentViewModel> IndustrySubSegments { get; set; }
    }
}