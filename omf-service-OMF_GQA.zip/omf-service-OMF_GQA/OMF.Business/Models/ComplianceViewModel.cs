﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class ComplianceViewModel
    {
        public DataRiskQuestionnaireViewModel DataRisk { get; set; }

        public ExportControlScreeningViewModel ExportScreening { get; set; }

        public ComplianceScreeningQuestionnaireViewModel ComplianceScreening { get; set; }

        public ProductScreeningInformationViewModel ProductScreening { get; set; }

        public ClientScreeningInformationViewModel ClientScreening { get; set; }

        public double EstimatedRevenueFromFinancials { get; set; }

        public bool IsAdditionalQuestions { get; set; }
    }
}
