﻿namespace OMF.Business.Models
{
    using System;

   public class OpportunityByCRMIdViewModel
    {
        public int OpportunityId { get; set; }

        public string OpportunityName { get; set; }

        public string CrmId { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public int StatusId { get; set; }

        public string CurrentStatus { get; set; }
    }
}
