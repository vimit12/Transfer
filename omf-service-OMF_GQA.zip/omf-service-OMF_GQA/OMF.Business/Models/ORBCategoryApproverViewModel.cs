﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class ORBCategoryApproverViewModel : BaseClass
    {
        public int ORBCategoryUserRoleMappingId { get; set; }

        public IEnumerable<COPViewModel> COPs { get; set; }

        public IEnumerable<CountryViewModel> Countries { get; set; }

        public ApproverTypeViewModel ApproverType { get; set; }

        public int ApproverTypeId { get; set; }

        public int ORBCategory { get; set; }

        //public UserRoleViewModel UserRole { get; set; }

        public int UserRoleId { get; set; }

        public string UserRoleName { get; set; }

        public string COPNames { get; set; }

        public string CountryNames { get; set; }

        public int RegionId { get; set; }

    }
}
