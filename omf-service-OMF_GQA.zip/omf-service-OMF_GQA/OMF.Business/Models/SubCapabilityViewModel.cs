﻿namespace OMF.Business.Models
{
    public class SubCapabilityViewModel : BaseClass
    {
        public int SubCapabilityId { get; set; }

        public int CapabiltyId { get; set; }

        public string SubCapabilityName { get; set; }

        public string Comments { get; set; }
    }
}