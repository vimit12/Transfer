﻿using System.Collections.Generic;

namespace OMF.Business.Models
{
    public class HVOUPracticesViewModel : BaseClass
    {
        public int HVOUPracticeId { get; set; }

        public string HVOUPracticeName { get; set; }
    }
}
