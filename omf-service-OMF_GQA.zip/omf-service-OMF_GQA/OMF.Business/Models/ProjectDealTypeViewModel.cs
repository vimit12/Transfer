﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;
    using System.Linq;

    public class ProjectDealTypeViewModel : BaseClass
    {
        public int ProjectDealTypeId { get; set; }

        public int ProjectDomainId { get; set; }

        public string ProjectDomainName { get; set; }

        public string ProjectDealTypeName { get; set; }

        public float OnShorePercentage { get; set; }

        public float OffShorePercentage { get; set; }

        public string Comments { get; set; }
    }
}