﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class PeriscopeModelOutputViewModel
    {
        public int OpportunityId { get; set; }

        public string PgmPercentageTarget { get; set; }

        public string PgmPercentagePredicted { get; set; }

        public string PositiveFactor3 { get; set; }

        public string PositiveFactor2 { get; set; }

        public string PositiveFactor1 { get; set; }

        public string NegativeFactor3 { get; set; }

        public string NegativeFactor2 { get; set; }

        public string NegativeFactor1 { get; set; }

        public string ProjectNumber { get; set; }

    }
}
