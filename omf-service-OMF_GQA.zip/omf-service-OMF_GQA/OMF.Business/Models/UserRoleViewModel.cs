﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class UserRoleViewModel : BaseClass
    {
        public int UserRoleId { get; set; }

        public int RoleId { get; set; }

        public string RoleName { get; set; }

        public string UserId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string UserEmail { get; set; }

        public string UserFullName { get; set; }

        public string Comments { get; set; }

        public string SecondaryUserEmail { get; set; }
    }
}