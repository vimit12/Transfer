﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class FundingReductionBasicDetailsViewModel
    {
        public int FundingReductionId { get; set; }

        public string ProjectName { get; set; }

        public string ProjectNumber { get; set; }

        public string ClientName { get; set; }

        public double ReductionValue { get; set; }
        public string CurrentStatus { get; set; }

        public int StatusId { get; set; }

        public string AssignedTo { get; set; }
    }
}
