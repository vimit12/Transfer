﻿using System;

namespace OMF.Business.Models
{
    public class COPViewModel : BaseClass
    {
        public int COPId { get; set; }

        public string COPName { get; set; }

        public string Comments { get; set; }

        public DateTime? ValidFrom { get; set; }

        public DateTime? ValidTill { get; set; }
    }
}
