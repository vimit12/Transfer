﻿namespace OMF.Business.Models
{
    public class YearViewModel : BaseClass
    {
        public int YearId { get; set; }

        public int Year { get; set; }

        public string Comments { get; set; }
    }
}
