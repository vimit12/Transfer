﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class ReportingPracticeViewModel
    {
        public int ReportingPracticeId { get; set; }

        public string ReportingPracticeName { get; set; }

        public string LineOfBusinessName { get; set; }

        public string Comments { get; set; }

        public bool IsActive { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public int LineOfBusinessId { get; set; }

        public IEnumerable<COPViewModel> COPs { get; set; }

        public string COPNames { get; set; }

        public DateTime? ValidFrom { get; set; }

        public DateTime? ValidTill { get; set; }
    }
}
