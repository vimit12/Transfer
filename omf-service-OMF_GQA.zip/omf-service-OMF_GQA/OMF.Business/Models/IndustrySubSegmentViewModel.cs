﻿namespace OMF.Business.Models
{
    public class IndustrySubSegmentViewModel : BaseClass
    {
        public int IndustrySubSegmentId { get; set; }

        public string IndustrySubSegmentName { get; set; }

        public string Comments { get; set; }
    }
}