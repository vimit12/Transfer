﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class FxRateViewModelSave
    {
        public int CurrencyId { get; set; }

        public int YearId { get; set; }

        public int QuarterId { get; set; }

        public double ExchangeRate { get; set; }
    }
}