﻿using System.Collections.Generic;

namespace OMF.Business.Models
{
    public class ShareSimulationViewModel
    {
        public int OpportunityId { get; set; }

        public int ActionId { get; set; }

        public PriceCalculatorViewModel PriceCalculatorViewModel { get; set; }

        public List<UserRoleViewModel> UserRoleViewModelList { get; set; }

        public string UpdatedBy { get; set; }
    }
}
