﻿namespace OMF.Business.Models
{
    public class PCReferBackOnHoldReasonByOpportunityViewModel
    {
        public int PCReferbackOnHoldReasonByOpportunityId { get; set; }

        public int PCReferBackOnHoldReasonId { get; set; }

        public string PCReferBackOnHoldReasonName { get; set; }

        public int OpportunityId { get; set; }

        public int StatusActionId { get; set; }

        public string StatusActionText { get; set; }
    }
}
