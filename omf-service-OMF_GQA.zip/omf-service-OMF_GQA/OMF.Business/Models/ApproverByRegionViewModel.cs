﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class ApproverByRegionViewModel : BaseClass
    {
        public int ApproverByRegionId { get; set; }

        public int RegionId { get; set; }

        public int ApproverTypeId { get; set; }

        public string Comments { get; set; }

        public string ApproverNames { get; set; }

        public string RegionName { get; set; }

        public string ApproverTypeName { get; set; }

        public IEnumerable<ApproverByRegionMappingViewModel> Approvers { get; set; }
    }
}
