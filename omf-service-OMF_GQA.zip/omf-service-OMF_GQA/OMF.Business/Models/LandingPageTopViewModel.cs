﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class LandingPageTopViewModel
    {
        public string Region { get; set; }
        public int Count { get; set; }
        public IEnumerable<LandingPageDomainViewModel> OpportunitiesByDomain { get; set; }

    }
}
