﻿using OMF.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class TemporaryModelForLandingPage
    {
        public Opportunity Opportunity { get; set; }
        public LineOfBusiness LineOfBusiness { get; set; }
        public ProjectDomain Domain { get; set; }
        public ProjectOrganization Organization { get; set; }
        public Country Country { get; set; }
        public Region Region { get; set; }
        public OpportunityRating Rating { get; set; }
    }
}
