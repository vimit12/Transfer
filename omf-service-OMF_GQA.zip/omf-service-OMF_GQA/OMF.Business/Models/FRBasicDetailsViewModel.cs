﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class FRBasicDetailsViewModel
    {
        public int FundingReductionId { get; set; }

        public int StatusId { get; set; }

        public int UserCommentId { get; set; }
    }
}
