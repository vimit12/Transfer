﻿namespace OMF.Business.Models
{
    public class RegionViewModel : BaseClass
    {
        public int RegionId { get; set; }

        public string RegionName { get; set; }

        public string Comments { get; set; }
    }
}