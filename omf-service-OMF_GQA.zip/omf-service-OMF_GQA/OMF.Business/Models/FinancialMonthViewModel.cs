﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class FinancialMonthViewModel
    {
        public int MonthId { get; set; }

        public List<FinancialWeekStartDayViewModel> Weeks { get; set; }
    }
}
