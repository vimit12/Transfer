﻿namespace OMF.Business.Models
{
    using System;

    public class ClientDetailsViewModel
    {
        public int ClientMasterId { get; set; }

        public string ClientName { get; set; }
    }
}
