﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class ProjectTemplateMatrixViewModel : BaseClass
    {
        public int ProjectTemplateMatrixId { get; set; }

        public IEnumerable<ReportingPracticeViewModel> ReportingPractices { get; set; }

        public IEnumerable<CapabilityViewModel> Capabilities { get; set; }

        public int CapabilityId { get; set; }

        public IEnumerable<SubCapabilityViewModel> SubCapabilities { get; set; }

        public int ContractTypeId { get; set; }

        public int ProjectTemplateId { get; set; }

        public string ProjectTemplateName { get; set; }

        public int BillingMethod { get; set; } // take Enums

        public string ReportingPracticeNames { get; set; }

        public string CapabilityNames { get; set; }

        public string SubCapabilityNames { get; set; }

        public string ContractTypeName { get; set; }
    }
}
