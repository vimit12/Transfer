﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class ORBWorkFlowViewModel
    {
        public int ORBWorkFlowId { get; set; }

        //public ApproverTypeViewModel ORBApproverType { get; set; }

        public int ApproverTypeId { get; set; }

        public int ORBCategory { get; set; }

        public int CurrentStatusTypeId { get; set; }

        public int StatusActionId { get; set; }

        public int NextStatusTypeId { get; set; }

        public IEnumerable<EmailTemplateViewModel> EmailTemplates { get; set; }

        public string ApproverTypeName { get; set; }

        public string EmailTemplateNames { get; set; }

        public string CurrentStatusName { get; set; }

        public string NextStatusName { get; set; }

        public string StatusActionName { get; set; }

    }
}
