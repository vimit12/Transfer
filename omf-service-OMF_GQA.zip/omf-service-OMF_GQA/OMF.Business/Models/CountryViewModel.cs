namespace OMF.Business.Models
{
    public class CountryViewModel : BaseClass
    {
        public int CountryId { get; set; }

        public string CountryName { get; set; }

        public int CurrencyId { get; set; }

        public string CurrencyCode { get; set; }

        public string Comments { get; set; }

        public bool IsTaxRegistrationNoRequired { get; set; }

        public int RegionId { get; set; }

        public string RegionName { get; set; }

        public bool ExportFriendly { get; set; }

        public bool AdditionalQuestions { get; set; }
    }
}
