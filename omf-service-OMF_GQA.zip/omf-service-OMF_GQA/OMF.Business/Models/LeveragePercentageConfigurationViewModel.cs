﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class LeveragePercentageConfigurationViewModel
    {
        public int LeveragePercentageVarianceId { get; set; }
        
        public int ProjectOrganization { get; set; }

        public int LineOfBusiness { get; set; }

        public double VariancePercentage { get; set; }

        public double VarianceAmountUSD { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }
       
        public string UpdatedBy { get; set; }
       
        public DateTime? UpdatedDate { get; set; }
       
        public bool IsActive { get; set; }
    }
}
