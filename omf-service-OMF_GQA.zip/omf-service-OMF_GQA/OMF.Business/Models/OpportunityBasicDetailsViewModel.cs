﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class OpportunityBasicDetailsViewModel
    {
        public int OpportunityId { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public float? ContingencyFundPercentage { get; set; }

        public short ApplicableRateCard { get; set; }

        public bool IsDefaultRateCard { get; set; }

        public int BaseCurrencyId { get; set; }

        public string BaseCurrencyCode { get; set; }

        public int StatusId { get; set; }

        public int ProjectOrganizationId { get; set; }

        public IList<DeliveryModelViewModel> DeliveryModel { get; set; }

        public int UserCommentId { get; set; }
    }
}
