﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class ApproverViewModel
    {
        public string ApproverName { get; set; }

        public string WorkLocationName { get; set; }

        public string LOBName { get; set; }

        public string COPName { get; set; }

        public string BillingName { get; set; }
    }
}
