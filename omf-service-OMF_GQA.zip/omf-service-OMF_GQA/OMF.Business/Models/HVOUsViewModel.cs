﻿using System.Collections.Generic;

namespace OMF.Business.Models
{
    public class HVOUsViewModel : BaseClass
    {
        public int HVOUId { get; set; }

        public string HVOUName { get; set; }
    }
}
