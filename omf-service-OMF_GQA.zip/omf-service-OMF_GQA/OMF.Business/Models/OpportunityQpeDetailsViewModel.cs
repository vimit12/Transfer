﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace OMF.Business.Models
{
    public class OpportunityQpeDetailsViewModel : BaseClass
    {
        [JsonPropertyName("FirstOfAKind_c")]
        public string FirstOfAKind { get; set; }

        [JsonPropertyName("EstimationModel_c")]
        public string EstimationModel { get; set; }

        [JsonPropertyName("QPEStartRightSupportNeeded_c")]
        public string StartRightSupport { get; set; }

        [JsonPropertyName("QPEPrimaryContact_c")]
        public string QpePrimaryContact { get; set; }

        [JsonPropertyName("QPESecondaryContact_c")]
        public string[] QpeSecondaryContact { get; set; }

        [JsonPropertyName("QPEProposalReviewNotes_c")]
        public string QpeProposalReviewNote { get; set; }

        [JsonPropertyName("QPEContractReviewNotes_c")]
        public string QpeContractReviewNote { get; set; }
    }
}
