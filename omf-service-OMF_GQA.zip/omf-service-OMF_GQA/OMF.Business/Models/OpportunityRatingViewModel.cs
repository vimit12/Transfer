﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class OpportunityRatingViewModel : BaseClass
    {
        public int OpportunityRatingId { get; set; }

        public int OpportunityId { get; set; }

        public float Rating { get; set; }

        public int CreditCheck { get; set; }

        public int PaymentTerm { get; set; }

        public int ClientCompanySize { get; set; }

        public int ClientCompanyOwnership { get; set; }

        public int OpportunitySourced { get; set; }

        public int DeliveryProjectsCompleted { get; set; }

        public bool SalesEnablementInvolved { get; set; }

        public string ApprovedBy { get; set; }

        public DateTime DiscussionDate { get; set; }

        public int MultipleOrSingleCOP { get; set; }

        public string COPNamesCSV { get; set; }

        public bool IsCOELedAccount { get; set; }

        public float ServicesRating { get; set; }

        public float SwHwRating { get; set; }
    }
}
