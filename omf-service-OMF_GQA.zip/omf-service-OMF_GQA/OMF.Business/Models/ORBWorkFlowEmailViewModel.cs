﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class ORBWorkFlowEmailViewModel
    {
        public List<int> UserRoleIdsToSend { get; set; }

        public int OpportunityId { get; set; }

        public int ORBWorkFlowId { get; set; }

        public string UpdatedBy { get; set; }
    }
}
