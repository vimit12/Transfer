﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class BillingAdminByOpportunities
    {
        public string Opportunities { get; set; }

        public string BillingAdmin { get; set; }
    }
}