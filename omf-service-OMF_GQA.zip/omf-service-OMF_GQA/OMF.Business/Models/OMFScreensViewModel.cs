﻿namespace OMF.Business.Models
{
    public class OMFScreensViewModel
    {
        public int ScreenId { get; set; }

        public string ScreenName { get; set; }
    }
}
