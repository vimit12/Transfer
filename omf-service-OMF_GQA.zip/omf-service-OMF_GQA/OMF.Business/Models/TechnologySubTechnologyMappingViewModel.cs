﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;
    using System.Linq;

    public class TechnologySubTechnologyMappingViewModel : BaseClass
    {
        public int TechnologySubTechnologyId { get; set; }

        public int TechnologyAllianceId { get; set; }

        public int SubTechnlogyAllianceId { get; set; }

        public string TechnologyAllianceName { get; set; }

        public string SubTechnologyAllianceNames { get; set; }

        public IEnumerable<SubTechAllianceViewModel> SubTechnologies { get; set; }
    }
}
