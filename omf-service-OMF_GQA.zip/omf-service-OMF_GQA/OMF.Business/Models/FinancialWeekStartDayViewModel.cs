﻿namespace OMF.Business.Models
{
    public class FinancialWeekStartDayViewModel
    {
        public string StartDate { get; set; }

        public decimal Hours { get; set; }

        public int WorkHourEntryId { get; set; }

        public decimal MaxHours { get;set; }

        public int FinancialStaffDetailId { get; set; }
    }
}
