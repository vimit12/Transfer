﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class WorkLocationViewModel : BaseClass
    {
        public int WorkLocationId { get; set; }

        public string WorkLocationName { get; set; }

        public int BaseCurrencyId { get; set; }

        public string CurrencyCode { get; set; }

        public bool IsDiscountMargin { get; set; }

        public bool IsIncreaseOverCostRate { get; set; }

        public float DiscountPercentage { get; set; }

        public float MarginPercentage { get; set; }

        public float IncreaseOverCostRate { get; set; }

        public string Comments { get; set; }

        public int DeliveryModelId { get; set; }

        public string DeliveryModelName { get; set; }

        public IList<ResourceRoleViewModel> ResourceRole { get; set; }
    }
}
