﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class WLRateCardViewModel
    {
        public int WorkLocationId { get; set; }

        public string WorkLocationName { get; set; }

        public ICollection<RateCardViewModel> RateCardViewModel { get; set; }
    }
}
