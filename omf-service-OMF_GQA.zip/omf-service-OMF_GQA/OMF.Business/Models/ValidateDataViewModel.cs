﻿namespace OMF.Business.Models
{
    public class ValidateDataViewModel
    {
        public bool IsValidData { get; set; }

        public string Message { get; set; }
    }
}
