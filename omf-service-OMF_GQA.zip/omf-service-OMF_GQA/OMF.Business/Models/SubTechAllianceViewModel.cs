﻿namespace OMF.Business.Models
{
    public class SubTechAllianceViewModel : BaseClass
    {
        public int SubTechnologyAllianceId { get; set; }

        public string SubTechnologyAllianceName { get; set; }

        public int TechnologyAllianceId { get; set; }
    }
}