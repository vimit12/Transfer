﻿namespace OMF.Business.Models
{
    using System;

    public class OpportunityDatesViewModel
    {
        public int OpportunityId { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public FinancialInitialSetupViewModel FinancialInitialSetup { get; set; }
    }
}
