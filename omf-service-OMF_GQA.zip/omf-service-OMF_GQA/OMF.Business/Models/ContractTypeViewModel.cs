﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class ContractTypeViewModel : BaseClass
    {
        public int ContractTypeId { get; set; }

        public string ContractTypeName { get; set; }

        public string Mapping { get; set; }

        public string Comments { get; set; }

        public bool IsFinanceApprovalRequired { get; set; }

        public int OpportunityTypeId { get; set; }

        public string OpportunityTypeName { get; set; }

        public bool IsContigencyMandatory { get; set; }

        public int? MinimumContingencyPer { get; set; }
    }
}