﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class FinancialCloudHostingDetailsViewModel : BaseClass
    {
        public int FinancialCloudHostingDetailsId { get; set; }

        public int OpportunityId { get; set; }

        public string CloudVendor { get; set; }

        public int CategoryId { get; set; }

        public string Category { get; set; }

        public double TotalStandardRevenue { get; set; }

        public double TotalStandardCost { get; set; }

        public double PgmValue { get; set; }

        public float PgmPercentage { get; set; }

        public string Comments { get; set; }

        public int YearId { get; set; }
    }
}
