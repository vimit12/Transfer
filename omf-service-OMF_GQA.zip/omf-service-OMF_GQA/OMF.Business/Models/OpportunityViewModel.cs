﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class OpportunityViewModel : BaseClass
    {
        public int OpportunityId { get; set; }

        public string OpportunityName { get; set; }

        public int BaseCurrencyId { get; set; }

        public string CurrencyName { get; set; }

        public int ProjectOrganizationId { get; set; }

        public string OpportunityDescription { get; set; }

        public int LineOfBusinessId { get; set; }

        public string LineOfBusinessName { get; set; }

        public int ReportingPracticeId { get; set; }

        public string CrmId { get; set; }

        public int ContractTypeId { get; set; }

        public string DetailedContractType { get; set; }//Detailed Contract Type

        public int OpportunityTypeId { get; set; }

        public string ContractTypeName { get; set; }//Opportunity Type

        public string Mapping { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string OnShoreProjectManager { get; set; }

        public int Oic { get; set; }

        public string PrimaryCapabilityLead { get; set; }

        public string WorkLocation { get; set; }

        public int PaymentTermId { get; set; }

        public string PaymentTermName { get; set; }

        public string PrimaryContactName { get; set; }

        public string WorkLocationPostCode { get; set; }

        public string OffShorePMLocal { get; set; }

        public int ProjectDomainId { get; set; }

        public string ProjectDomainName { get; set; }

        public int ProjectDealTypeId { get; set; }

        public string ProjectDealTypeName { get; set; }

        public int ClientBillingAddressId { get; set; }

        public string ClientExecutiveSponsor { get; set; }

        public string ClientExecutiveSponsorEmail { get; set; }

        public DateTime? ClientSatSurveyPrimaryDate { get; set; }

        public DateTime? ClientSatSurveySecondaryDate { get; set; }

        public int StatusId { get; set; }

        public bool IsPaymentTermEmailSent { get; set; }

        public int WeeklyHours { get; set; }

        public bool IsReferentialArchitectureIncluded { get; set; }

        public float? ContingencyFundPercentage { get; set; }

        public int IsShared { get; set; }

        public ClientBillingAddressViewModel ClientBillingAddress { get; set; }

        public short ApplicableRateCard { get; set; }

        public List<int> WorkLocations { get; set; }

        public string WorkLocationNames { get; set; }

        public List<int> ContractTypeSections { get; set; }

        public string ContractTypeSectionNames { get; set; }

        public int ClientMasterId { get; set; }

        public bool IsThisNewClient { get; set; }

        public string ProjectOrganizationName { get; set; }

        public string ReportingPracticeName { get; set; }

        public string OfficerInCharge { get; set; }

        public bool IsQuickSetup { get; set; }

        public int COPId { get; set; }

        public string COPName { get; set; }

        public bool OICApprovalNeeded { get; set; }

        public string OracleProjectName { get; set; }

        public string OracleProjectCode { get; set; }

        public string CustomerName { get; set; }

        public string ClientEngagementPartner { get; set; }

        public string CurrentStatusName { get; set; }

        public bool IsSentForAudit { get; set; }

        public int ITOSolutionId { get; set; }

        public string ITOSolutionName { get; set; }

        public bool IsProjectCreatedInPending { get; set; }

        public string ClientEngagementPartnerEmail { get; set; }

        public string SalesExecutiveName { get; set; }

        public string SalesExecutiveEmail { get; set; }

        public string AccountManager { get; set; }

        public string AccountManagerEmail { get; set; }

        public string DeliveryPartner { get; set; }

        public string DeliveryPartnerEmail { get; set; }

        public bool IsSalesExecutiveOwned { get; set; }

        public string Synergy { get; set; }

        public bool IsHiQDataIntegrated { get; set; }

        public string BillingAdministrator { get; set; }

        public bool OverridePaymentTerms { get; set; }
    }
}
