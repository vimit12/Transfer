﻿namespace OMF.Business.Models
{
    public class ApproverByCountryMappingViewModel
    {
        public int ApproverByCountryMappingId { get; set; }

        public int ApproverByCountryId { get; set; }

        public int UserRoleId { get; set; }
    }
}
