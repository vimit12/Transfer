﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class LoginViewModel
    {
        string username { get; set; }

        string password { get; set; }
    }
}
