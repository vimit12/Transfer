﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace OMF.Business.Models
{
    public class HiQIntegrationViewModel
    {
        // HiQ field name for ORB Comments
        [JsonPropertyName("Comments")]
        public string Comments { get; set; }

        // HiQ field name for ORB approval
        [JsonPropertyName("ORB_Approved_fcl_c")]
        public string ORB_Approved_fcl_c { get; set; }

        // HiQ field name for Status of the record
        [JsonPropertyName("StatusCode")]
        public string StatusCode { get; set; }

        // HiQ field name for Status of the record
        [JsonPropertyName("OMFStatus_c")]
        public string OMFStatus_c { get; set; }

        [JsonPropertyName("ContractReceived_c")]
        public bool ContractReceived_c { get; set; }

        [JsonPropertyName("AccountPartyNumber")]
        public string AccountPartyNumber { get; set; }

        [JsonPropertyName("PartyName1")]
        public string SalesExecutiveName { get; set; }

        [JsonPropertyName("EmailAddress")]
        public string SalesExecutiveEmail { get; set; }

        [JsonPropertyName("Synergy_c")]
        public string[] Synergy_c { get; set; }

        // HiQ field name for OpportunityType
        [JsonPropertyName("TypeOfOpportunity_c")]
        public string HiQOpportunityType { get; set; }

        // HiQ field name for SFDCID
        [JsonPropertyName("SFDCHVOpportunityID_c")]
        public string SFDCID { get; set; }

        // HiQ field name for OpportunityName
        [JsonPropertyName("Name")]
        public string Name { get; set; }

        // HiQ field name for Delivery Partner
        [JsonPropertyName("DeliveryLeader_c")]
        public string DeliveryPartner { get; set; }

        // HiQ field name for HiQ Revenue
        [JsonPropertyName("Revenue")]
        public float HiQValue { get; set; }

        // HiQ field name for CustomerName
        [JsonPropertyName("TargetPartyName")]
        public string CustomerName { get; set; }
    }
}
