﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class ColaValues
    {
        public int WorkLocationId { get; set; }

        public string WorkLocation { get; set; }

        public float CurrentFYPercentage { get; set; }

        public float PreviousFYPercentage1 { get; set; }

        public float PreviousFYPercentage2 { get; set; }

        public float PreviousFYPercentage3 { get; set; }

        public string UserComment { get; set; }
    }
}
