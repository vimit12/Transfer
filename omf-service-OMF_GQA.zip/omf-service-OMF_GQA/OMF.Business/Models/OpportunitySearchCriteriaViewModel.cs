﻿namespace OMF.Business.Models
{
    public class OpportunitySearchCriteriaViewModel
    {
        public int StatusId { get; set; }

        public bool IsSharedOne { get; set; }

        public string SearchString { get; set; }
    }
}
