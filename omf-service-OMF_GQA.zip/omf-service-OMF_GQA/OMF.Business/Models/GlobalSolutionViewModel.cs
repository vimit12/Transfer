﻿namespace OMF.Business.Models
{
    public class GlobalSolutionViewModel : BaseClass
    {
        public int GlobalSolutionId { get; set; }

        public string GlobalSolutionName { get; set; }

        public string Comments { get; set; }
    }
}