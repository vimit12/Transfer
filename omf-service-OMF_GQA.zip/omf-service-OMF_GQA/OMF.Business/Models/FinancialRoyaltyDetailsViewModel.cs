﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class FinancialRoyaltyDetailsViewModel : BaseClass
    {
        public int FinancialRoyaltyDetailsId { get; set; }

        public int OpportunityId { get; set; }

        public string RoyaltyPayeeOrPayer { get; set; }

        public double TotalStandardRevenue { get; set; }

        public double TotalStandardCost { get; set; }

        public double PgmValue { get; set; }

        public float PgmPercentage { get; set; }

        public string Comments { get; set; }

        public int YearId { get; set; }
    }
}