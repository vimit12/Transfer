﻿namespace OMF.Business.Models
{
    public class OmfFinancialSectionsViewModel : BaseClass
    {
        public int SectionId { get; set; }

        public string SectionName { get; set; }
    }
}
