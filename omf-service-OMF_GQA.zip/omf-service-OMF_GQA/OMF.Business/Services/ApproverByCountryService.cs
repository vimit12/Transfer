﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class ApproverByCountryService : IApproverByCountryService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public ApproverByCountryService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<ApproverByCountryViewModel> GetApproversByCountry()
        {
            var approversByCountry = uow.Repository<ApproverByCountry>().GetAll(aByC => aByC.ApproverType.IsActive, "ApproverType").OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));

            List<ApproverByCountryViewModel> approversByCountryVMList = new List<ApproverByCountryViewModel>();

            foreach (var approver in approversByCountry)
            {
                var approverMapping = from approverMappings in uow.Repository<ApproverByCountryMapping>().GetAll()
                                      join approverByCountry in uow.Repository<ApproverByCountry>().GetAll() on approverMappings.ApproverByCountryId equals approverByCountry.ApproverByCountryId
                                      join userRole in uow.Repository<UserRole>().GetAll() on approverMappings.UserRoleId equals userRole.UserRoleId
                                      where approverByCountry.ApproverByCountryId == approver.ApproverByCountryId
                                      select new
                                      {
                                          approverByCountryId = approverByCountry.ApproverByCountryId,
                                          approverTypeId = approver.ApproverTypeId,
                                          name = userRole.FirstName + " " + userRole.LastName + " - " + userRole.UserId,
                                          isActive = userRole.IsActive
                                      };

                if (approverMapping.Any())
                {
                    var countryDetails = (from approverByCountry in uow.Repository<ApproverByCountry>().GetAll()
                                          join country in uow.Repository<Country>().GetAll() on approverByCountry.CountryId equals country.CountryId
                                          join approverType in uow.Repository<ApproverType>().GetAll() on approverByCountry.ApproverTypeId equals approverType.ApproverTypeId
                                          where approverByCountry.ApproverByCountryId == approver.ApproverByCountryId && country.IsActive && approverType.IsActive
                        select new
                                          {
                                              country.CountryName,
                                              approverType.ApproverTypeName
                                          }).FirstOrDefault();

                    if (countryDetails != null)
                    {
                        var approverByCountryModel = new ApproverByCountry
                        {
                            ApproverByCountryId = approver.ApproverByCountryId,
                            ApproverTypeId = approver.ApproverTypeId,
                            CountryId = approver.CountryId,
                            Comments = approver.Comments,
                            IsActive = approver.IsActive,
                            CreatedBy = approver.CreatedBy,
                            CreatedDate = approver.CreatedDate,
                            UpdatedBy = approver.UpdatedBy,
                            UpdatedDate = approver.UpdatedDate
                        };

                        var approverVM = mapper.Map<ApproverByCountry, ApproverByCountryViewModel>(approverByCountryModel);
                        approverVM.ApproverNames = string.Join((char)44 + " ", approverMapping.Where(y => y.isActive).Select(x => x.name));
                        approverVM.CountryName = countryDetails.CountryName;
                        approverVM.ApproverTypeName = countryDetails.ApproverTypeName;
                        approversByCountryVMList.Add(approverVM);
                    }
                }
            }

            return approversByCountryVMList;
        }

        public void AddApproverByCountry(ApproverByCountryViewModel model)
        {
            if (model != null)
            {
                var approverByCountry = mapper.Map<ApproverByCountryViewModel, ApproverByCountry>(model);

                // Created by should get from claims
                approverByCountry.CreatedBy = model.CreatedBy;
                approverByCountry.IsActive = true;
                approverByCountry.CreatedDate = DateTime.Now;
                uow.Repository<ApproverByCountry>().Add(approverByCountry);

                if (model.Approvers != null && model.Approvers.Any())
                {
                    var approverMappingsByCountry = mapper.Map<IEnumerable<ApproverByCountryMappingViewModel>, IEnumerable<ApproverByCountryMapping>>(model.Approvers);

                    foreach (var approverMapping in approverMappingsByCountry)
                    {
                        approverMapping.ApproverByCountryId = approverByCountry.ApproverByCountryId;
                    }

                    uow.Repository<ApproverByCountryMapping>().AddRange(approverMappingsByCountry);
                }

                uow.SaveChanges();
            }
        }

        public void UpdateApproverByCountry(ApproverByCountryViewModel model)
        {
            var approverByCountryModel = mapper.Map<ApproverByCountryViewModel, ApproverByCountry>(model);
            var approverByCountry = uow.Repository<ApproverByCountry>().GetById(approverByCountryModel.ApproverByCountryId);
            if (model.Approvers != null && model.Approvers.Any())
            {
                var approverByCountryMapping = uow.Repository<ApproverByCountryMapping>().GetAll(apprMap => apprMap.ApproverByCountryId == approverByCountryModel.ApproverByCountryId);
                uow.Repository<ApproverByCountryMapping>().DeleteRange(uow.Repository<ApproverByCountryMapping>().GetAll(apprMap => apprMap.ApproverByCountryId == approverByCountryModel.ApproverByCountryId));
                var approverMappingsByCountry = mapper.Map<IEnumerable<ApproverByCountryMappingViewModel>, IEnumerable<ApproverByCountryMapping>>(model.Approvers);
                foreach (var approverMapping in approverMappingsByCountry)
                {
                    approverMapping.ApproverByCountryId = approverByCountry.ApproverByCountryId;
                }

                uow.Repository<ApproverByCountryMapping>().AddRange(approverMappingsByCountry);
            }

            approverByCountry.ApproverTypeId = approverByCountryModel.ApproverTypeId;
            approverByCountry.CountryId = approverByCountryModel.CountryId;
            approverByCountry.Comments = approverByCountryModel.Comments;
            approverByCountry.IsActive = approverByCountryModel.IsActive;
            approverByCountry.CreatedDate = approverByCountry.CreatedDate;
            approverByCountry.CreatedBy = approverByCountry.CreatedBy;

            // Created by should get from claims
            approverByCountry.UpdatedBy = model.UpdatedBy;
            approverByCountry.UpdatedDate = DateTime.Now;
            uow.Repository<ApproverByCountry>().Update(approverByCountry);
            uow.SaveChanges();
        }
    }
}
