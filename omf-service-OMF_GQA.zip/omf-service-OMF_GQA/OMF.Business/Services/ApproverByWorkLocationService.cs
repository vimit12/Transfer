﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;


    public class ApproverByWorkLocationService : IApproverByWorkLocationService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public ApproverByWorkLocationService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<ApproverByWorkLocationViewModel> GetApproversByWorkLocationLOB()
        {
            var approversByWorkLocation = uow.Repository<ApproverByWorkLocation>().GetAll(aByC => aByC.ApproverType.IsActive, "ApproverType").OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));

            List<ApproverByWorkLocationViewModel> approversByWorkLocationVMList = new List<ApproverByWorkLocationViewModel>();

            foreach (var approver in approversByWorkLocation)
            {
                var approverMapping = from approverMappings in uow.Repository<ApproverByWorkLocationLineOfBusinessMapping>().GetAll(null, "LineOfBusiness")
                                      join approverByWorkLocation in uow.Repository<ApproverByWorkLocation>().GetAll() on approverMappings.ApproverByWorkLocationId equals approverByWorkLocation.ApproverByWorkLocationId
                                      join userRole in uow.Repository<UserRole>().GetAll() on approverMappings.UserRoleId equals userRole.UserRoleId
                                      where approverByWorkLocation.ApproverByWorkLocationId == approver.ApproverByWorkLocationId
                                      select new
                                      {
                                          approverByWorkLocationId = approverByWorkLocation.ApproverByWorkLocationId,
                                          approverTypeId = approver.ApproverTypeId,
                                          name = userRole.FirstName + " " + userRole.LastName + " - " + userRole.UserId,
                                          isActive = userRole.IsActive,
                                          LOBId = approverMappings.LineOfBusinessId,
                                          LOBName = approverMappings.LineOfBusiness.LineOfBusinessName
                                      };

                if (approverMapping.Any())
                {
                    var WorkLocationDetails = (from approverByWorkLocation in uow.Repository<ApproverByWorkLocation>().GetAll()
                                               join WorkLocation in uow.Repository<WorkLocation>().GetAll() on approverByWorkLocation.WorkLocationId equals WorkLocation.WorkLocationId
                                               join approverType in uow.Repository<ApproverType>().GetAll() on approverByWorkLocation.ApproverTypeId equals approverType.ApproverTypeId
                                               where approverByWorkLocation.ApproverByWorkLocationId == approver.ApproverByWorkLocationId && WorkLocation.IsActive && approverType.IsActive
                                               select new
                                               {
                                                   WorkLocation.WorkLocationName,
                                                   approverType.ApproverTypeName
                                               }).FirstOrDefault();

                    if (WorkLocationDetails != null)
                    {
                        var approverByWorkLocationModel = new ApproverByWorkLocation
                        {
                            ApproverByWorkLocationId = approver.ApproverByWorkLocationId,
                            ApproverTypeId = approver.ApproverTypeId,
                            WorkLocationId = approver.WorkLocationId,
                            Comments = approver.Comments,
                            IsActive = approver.IsActive,
                            CreatedBy = approver.CreatedBy,
                            CreatedDate = approver.CreatedDate,
                            UpdatedBy = approver.UpdatedBy,
                            UpdatedDate = approver.UpdatedDate
                        };

                        var approverVM = mapper.Map<ApproverByWorkLocation, ApproverByWorkLocationViewModel>(approverByWorkLocationModel);
                        approverVM.ApproverNames = string.Join((char)44 + " ", approverMapping.Where(y => y.isActive).Select(x => x.name));
                        approverVM.WorkLocationName = WorkLocationDetails.WorkLocationName;
                        approverVM.ApproverTypeName = WorkLocationDetails.ApproverTypeName;


                        var listOfLOBS = new List<LineOfBusinessViewModel>();
                        var wlLOBs = approverMapping.Where(x => x.approverByWorkLocationId == approver.ApproverByWorkLocationId).Select(x => new LineOfBusinessViewModel
                        {
                            LineOfBusinessId = x.LOBId,
                            LineOfBusinessName = x.LOBName
                        }
                        ).ToList();

                        approverVM.LinesOfBusinesses = wlLOBs;
                        approverVM.LinesOfBusinessesNames = string.Join((char)44 + " ", wlLOBs.Select(x => x.LineOfBusinessName));

                        approversByWorkLocationVMList.Add(approverVM);
                    }
                }
            }

            return approversByWorkLocationVMList;
        }

        public IEnumerable<ApproverByWorkLocationViewModel> GetApproversByWorkLocationCOP()
        {
            var approversByWorkLocation = uow.Repository<ApproverByWorkLocation>().GetAll(aByC => aByC.ApproverType.IsActive, "ApproverType").OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));

            List<ApproverByWorkLocationViewModel> approversByWorkLocationVMList = new List<ApproverByWorkLocationViewModel>();

            foreach (var approver in approversByWorkLocation)
            {
                var approverMapping = from approverMappings in uow.Repository<ApproverByWorkLocationCOPMapping>().GetAll(null, "LineOfBusiness")
                                      join approverByWorkLocation in uow.Repository<ApproverByWorkLocation>().GetAll() on approverMappings.ApproverByWorkLocationId equals approverByWorkLocation.ApproverByWorkLocationId
                                      join userRole in uow.Repository<UserRole>().GetAll() on approverMappings.UserRoleId equals userRole.UserRoleId
                                      where approverByWorkLocation.ApproverByWorkLocationId == approver.ApproverByWorkLocationId
                                      select new
                                      {
                                          approverByWorkLocationId = approverByWorkLocation.ApproverByWorkLocationId,
                                          approverTypeId = approver.ApproverTypeId,
                                          name = userRole.FirstName + " " + userRole.LastName + " - " + userRole.UserId,
                                          isActive = userRole.IsActive,
                                          COPId = approverMappings.COPId,
                                          COPName = approverMappings.COP.COPName
                                      };

                if (approverMapping.Any())
                {
                    var WorkLocationDetails = (from approverByWorkLocation in uow.Repository<ApproverByWorkLocation>().GetAll()
                                               join WorkLocation in uow.Repository<WorkLocation>().GetAll() on approverByWorkLocation.WorkLocationId equals WorkLocation.WorkLocationId
                                               join approverType in uow.Repository<ApproverType>().GetAll() on approverByWorkLocation.ApproverTypeId equals approverType.ApproverTypeId
                                               where approverByWorkLocation.ApproverByWorkLocationId == approver.ApproverByWorkLocationId && WorkLocation.IsActive && approverType.IsActive
                                               select new
                                               {
                                                   WorkLocation.WorkLocationName,
                                                   approverType.ApproverTypeName
                                               }).FirstOrDefault();

                    if (WorkLocationDetails != null)
                    {
                        var approverByWorkLocationModel = new ApproverByWorkLocation
                        {
                            ApproverByWorkLocationId = approver.ApproverByWorkLocationId,
                            ApproverTypeId = approver.ApproverTypeId,
                            WorkLocationId = approver.WorkLocationId,
                            Comments = approver.Comments,
                            IsActive = approver.IsActive,
                            CreatedBy = approver.CreatedBy,
                            CreatedDate = approver.CreatedDate,
                            UpdatedBy = approver.UpdatedBy,
                            UpdatedDate = approver.UpdatedDate
                        };

                        var approverVM = mapper.Map<ApproverByWorkLocation, ApproverByWorkLocationViewModel>(approverByWorkLocationModel);
                        approverVM.ApproverNames = string.Join((char)44 + " ", approverMapping.Where(y => y.isActive).Select(x => x.name));
                        approverVM.WorkLocationName = WorkLocationDetails.WorkLocationName;
                        approverVM.ApproverTypeName = WorkLocationDetails.ApproverTypeName;


                        var listOfLOBS = new List<LineOfBusinessViewModel>();
                        var wlLOBs = approverMapping.Where(x => x.approverByWorkLocationId == approver.ApproverByWorkLocationId).Select(x => new COPViewModel
                        {
                            COPId = x.COPId,
                            COPName = x.COPName
                        }
                        ).ToList();

                        approverVM.COPs = wlLOBs;
                        approverVM.COPNames = string.Join((char)44 + " ", wlLOBs.Select(x => x.COPName));

                        approversByWorkLocationVMList.Add(approverVM);
                    }
                }
            }

            return approversByWorkLocationVMList;
        }


        public void AddApproverByWorkLocation(ApproverByWorkLocationViewModel model)
        {
            if (model != null)
            {
                var approverByWorkLocation = mapper.Map<ApproverByWorkLocationViewModel, ApproverByWorkLocation>(model);

                // Created by should get from claims
                approverByWorkLocation.CreatedBy = model.CreatedBy;
                approverByWorkLocation.IsActive = true;
                approverByWorkLocation.CreatedDate = DateTime.Now;
                uow.Repository<ApproverByWorkLocation>().Add(approverByWorkLocation);

                if (model.Approvers != null && model.Approvers.Any())
                {
                    //var approverMappingsByWorkLocation = mapper.Map<IEnumerable<ApproverByWorkLocationMappingViewModel>, IEnumerable<ApproverByWorkLocationMapping>>(model.Approvers);

                    //foreach (var approverMapping in approverMappingsByWorkLocation)
                    //{
                    //    approverMapping.ApproverByWorkLocationId = approverByWorkLocation.ApproverByWorkLocationId;
                    //    foreach(var location in )
                    //}

                    //uow.Repository<ApproverByWorkLocationMapping>().AddRange(approverMappingsByWorkLocation);

                    foreach (var approverModel in model.Approvers)
                    {
                        if (model.ApproverTypeId == (int)Enums.ApproverType.LOB)
                        {
                            var approver = mapper.Map<ApproverByWorkLocationMappingViewModel, ApproverByWorkLocationLineOfBusinessMapping>(approverModel);
                            approver.ApproverByWorkLocationId = approverByWorkLocation.ApproverByWorkLocationId;

                            foreach (var location in model.LinesOfBusinesses)
                            {
                                approver.LineOfBusinessId = location.LineOfBusinessId;
                                uow.Repository<ApproverByWorkLocationLineOfBusinessMapping>().Add(approver);
                            }
                        }
                        else if (model.ApproverTypeId == (int)Enums.ApproverType.COP)
                        {
                            var approver = mapper.Map<ApproverByWorkLocationMappingViewModel, ApproverByWorkLocationCOPMapping>(approverModel);
                            approver.ApproverByWorkLocationId = approverByWorkLocation.ApproverByWorkLocationId;

                            foreach (var cop in model.COPs)
                            {
                                approver.COPId = cop.COPId;
                                uow.Repository<ApproverByWorkLocationCOPMapping>().Add(approver);
                            }
                        }
                        else
                        {
                            var approver = mapper.Map<ApproverByWorkLocationMappingViewModel, ApproverByWorkLocationMapping>(approverModel);
                            approver.ApproverByWorkLocationId = approverByWorkLocation.ApproverByWorkLocationId;

                            uow.Repository<ApproverByWorkLocationMapping>().Add(approver);
                        }
                    }
                }

                uow.SaveChanges();
            }
        }

        public void UpdateApproverByWorkLocation(ApproverByWorkLocationViewModel model)
        {
            var approverByWorkLocationModel = mapper.Map<ApproverByWorkLocationViewModel, ApproverByWorkLocation>(model);
            var approverByWorkLocation = uow.Repository<ApproverByWorkLocation>().GetById(approverByWorkLocationModel.ApproverByWorkLocationId);
            if (model.Approvers != null && model.Approvers.Any())
            {
                var approverByWorkLocationMapping = uow.Repository<ApproverByWorkLocationLineOfBusinessMapping>().GetAll(apprMap => apprMap.ApproverByWorkLocationId == approverByWorkLocationModel.ApproverByWorkLocationId);
                uow.Repository<ApproverByWorkLocationLineOfBusinessMapping>().DeleteRange(uow.Repository<ApproverByWorkLocationLineOfBusinessMapping>().GetAll(apprMap => apprMap.ApproverByWorkLocationId == approverByWorkLocationModel.ApproverByWorkLocationId));
                if (model.ApproverTypeId == (int)Enums.ApproverType.LOB)
                {
                    var approverMappingsByWorkLocation = mapper.Map<IEnumerable<ApproverByWorkLocationMappingViewModel>, IEnumerable<ApproverByWorkLocationLineOfBusinessMapping>>(model.Approvers);
                    foreach (var approverMapping in approverMappingsByWorkLocation)
                    {
                        approverMapping.ApproverByWorkLocationId = approverByWorkLocation.ApproverByWorkLocationId;

                        foreach (var location in model.LinesOfBusinesses)
                        {
                            approverMapping.LineOfBusinessId = location.LineOfBusinessId;
                            uow.Repository<ApproverByWorkLocationLineOfBusinessMapping>().Add(approverMapping);
                        }
                    }
                }
                else if (model.ApproverTypeId == (int)Enums.ApproverType.COP)
                {
                    var approverMappingsByWorkLocation = mapper.Map<IEnumerable<ApproverByWorkLocationMappingViewModel>, IEnumerable<ApproverByWorkLocationCOPMapping>>(model.Approvers);
                    foreach (var approverMapping in approverMappingsByWorkLocation)
                    {
                        approverMapping.ApproverByWorkLocationId = approverByWorkLocation.ApproverByWorkLocationId;

                        foreach (var location in model.COPs)
                        {
                            approverMapping.COPId = location.COPId;
                            uow.Repository<ApproverByWorkLocationCOPMapping>().Add(approverMapping);
                        }
                    }
                }
                else
                {
                    var approverMappingsByWorkLocation = mapper.Map<IEnumerable<ApproverByWorkLocationMappingViewModel>, IEnumerable<ApproverByWorkLocationMapping>>(model.Approvers);
                    foreach (var app in approverMappingsByWorkLocation)
                    {
                        uow.Repository<ApproverByWorkLocationMapping>().Add(app);
                    }
                }
            }

            //uow.Repository<ApproverByWorkLocationLineOfBusinessMapping>().AddRange(approverMappingsByWorkLocation);


            approverByWorkLocation.ApproverTypeId = approverByWorkLocationModel.ApproverTypeId;
            approverByWorkLocation.WorkLocationId = approverByWorkLocationModel.WorkLocationId;
            approverByWorkLocation.Comments = approverByWorkLocationModel.Comments;
            approverByWorkLocation.IsActive = approverByWorkLocationModel.IsActive;
            approverByWorkLocation.CreatedDate = approverByWorkLocation.CreatedDate;
            approverByWorkLocation.CreatedBy = approverByWorkLocation.CreatedBy;

            // Created by should get from claims
            approverByWorkLocation.UpdatedBy = model.UpdatedBy;
            approverByWorkLocation.UpdatedDate = DateTime.Now;
            uow.Repository<ApproverByWorkLocation>().Update(approverByWorkLocation);
            uow.SaveChanges();
        }

        public IEnumerable<ApproverByWorkLocationViewModel> GetApproversByWorkLocation()
        {
            var approversByWorkLocation = uow.Repository<ApproverByWorkLocation>().GetAll(aByC => aByC.ApproverType.IsActive, "ApproverType").OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));

            List<ApproverByWorkLocationViewModel> approversByWorkLocationVMList = new List<ApproverByWorkLocationViewModel>();

            foreach (var approver in approversByWorkLocation)
            {
                var approverMapping = from approverMappings in uow.Repository<ApproverByWorkLocationMapping>().GetAll()
                                      join approverByWorkLocation in uow.Repository<ApproverByWorkLocation>().GetAll() on approverMappings.ApproverByWorkLocationId equals approverByWorkLocation.ApproverByWorkLocationId
                                      join userRole in uow.Repository<UserRole>().GetAll() on approverMappings.UserRoleId equals userRole.UserRoleId
                                      where approverByWorkLocation.ApproverByWorkLocationId == approver.ApproverByWorkLocationId
                                      select new
                                      {
                                          approverByWorkLocationId = approverByWorkLocation.ApproverByWorkLocationId,
                                          approverTypeId = approver.ApproverTypeId,
                                          name = userRole.FirstName + " " + userRole.LastName + " - " + userRole.UserId,
                                          isActive = userRole.IsActive
                                      };

                if (approverMapping.Any())
                {
                    var WorkLocationDetails = (from approverByWorkLocation in uow.Repository<ApproverByWorkLocation>().GetAll()
                                               join WorkLocation in uow.Repository<WorkLocation>().GetAll() on approverByWorkLocation.WorkLocationId equals WorkLocation.WorkLocationId
                                               join approverType in uow.Repository<ApproverType>().GetAll() on approverByWorkLocation.ApproverTypeId equals approverType.ApproverTypeId
                                               where approverByWorkLocation.ApproverByWorkLocationId == approver.ApproverByWorkLocationId && WorkLocation.IsActive && approverType.IsActive
                                               select new
                                               {
                                                   WorkLocation.WorkLocationName,
                                                   approverType.ApproverTypeName
                                               }).FirstOrDefault();

                    if (WorkLocationDetails != null)
                    {
                        var approverByWorkLocationModel = new ApproverByWorkLocation
                        {
                            ApproverByWorkLocationId = approver.ApproverByWorkLocationId,
                            ApproverTypeId = approver.ApproverTypeId,
                            WorkLocationId = approver.WorkLocationId,
                            Comments = approver.Comments,
                            IsActive = approver.IsActive,
                            CreatedBy = approver.CreatedBy,
                            CreatedDate = approver.CreatedDate,
                            UpdatedBy = approver.UpdatedBy,
                            UpdatedDate = approver.UpdatedDate
                        };

                        var approverVM = mapper.Map<ApproverByWorkLocation, ApproverByWorkLocationViewModel>(approverByWorkLocationModel);
                        approverVM.ApproverNames = string.Join((char)44 + " ", approverMapping.Where(y => y.isActive).Select(x => x.name));
                        approverVM.WorkLocationName = WorkLocationDetails.WorkLocationName;
                        approverVM.ApproverTypeName = WorkLocationDetails.ApproverTypeName;

                        approversByWorkLocationVMList.Add(approverVM);
                    }
                }
            }

            return approversByWorkLocationVMList;
        }

    }
}
