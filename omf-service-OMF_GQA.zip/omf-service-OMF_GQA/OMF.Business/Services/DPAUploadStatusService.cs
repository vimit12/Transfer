﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using AutoMapper;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class DPAUploadStatusService : IDPAUploadStatusService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public DPAUploadStatusService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<DPAUploadStatusViewModel> GetActiveDPAUploadStatuses()
        {
            var dpaUploadStatus = uow.Repository<DPAUploadStatus>().GetAll(x => x.IsActive);
            return mapper.Map<IEnumerable<DPAUploadStatus>, IEnumerable<DPAUploadStatusViewModel>>(dpaUploadStatus);
        }
    }
}
