﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using Microsoft.AspNetCore.Http;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class ApproverTypeService : IApproverTypeService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;
        private readonly IHttpContextAccessor httpContextAccessor;
        public ApproverTypeService(IUow uow, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            this.uow = uow;
            this.mapper = mapper;
            this.httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// Get all the ApproverTypes
        /// </summary>
        /// <returns>Return the list of all ApproverTypes</returns>
        public IEnumerable<ApproverTypeViewModel> GetApproverTypes()
        {
            var approverTypes = uow.Repository<ApproverType>().GetAll().OrderBy(x => x.ApproverTypeName);
            return mapper.Map<IEnumerable<ApproverType>, IEnumerable<ApproverTypeViewModel>>(approverTypes);
        }

        public IEnumerable<ApproverTypeViewModel> GetActiveApproverTypes()
        {
            var approverTypes = uow.Repository<ApproverType>().GetAll(x => x.IsActive).OrderBy(x => x.ApproverTypeName);
            return mapper.Map<IEnumerable<ApproverType>, IEnumerable<ApproverTypeViewModel>>(approverTypes);
        }

        /// <summary>
        /// Gets the ApproverType
        /// </summary>
        /// <param name="id">ApproverType Id</param>
        /// <returns>Currency Object based on the id</returns>
        public ApproverTypeViewModel GetApproverTypeById(int id)
        {
            var approverType = uow.Repository<ApproverType>().GetById(id);
            return mapper.Map<ApproverType, ApproverTypeViewModel>(approverType);
        }

        /// <summary>
        /// Adds the ApproverType object to the DB
        /// </summary>
        /// <param name="model">The ApproverType object that is to be inserted in to the DB</param>
        public void AddApproverType(ApproverTypeViewModel model)
        {
            if (model != null)
            {
                var approverType = mapper.Map<ApproverTypeViewModel, ApproverType>(model);
                approverType.ApproverTypeName = model.ApproverTypeName;
                approverType.IsActive = true;
                uow.Repository<ApproverType>().Add(approverType);
                uow.SaveChanges();
            }
        }

        /// <summary>
        /// Updates the ApproverType object to the DB
        /// </summary>
        /// <param name="model">ApproverType Model Object</param>
        public void UpdateApproverType(ApproverTypeViewModel model)
        {
            var approverType = uow.Repository<ApproverType>().GetById(model.ApproverTypeId);
            approverType.ApproverTypeName = model.ApproverTypeName;
            approverType.IsActive = model.IsActive;
            uow.Repository<ApproverType>().Update(approverType);
            uow.SaveChanges();
        }

        public string GetFRApproverType()
        {
            List<int> frRole = new List<int>();
            string frApprover = string.Empty;
            try
            {
                var userName = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                var userRole = uow.Repository<UserRole>().GetAll(x => x.UserId.ToLower() == userName.ToLower()).FirstOrDefault();
                //var fundingReduction = uow.Repository<FundingReduction>().GetAll(fr => GetOICDetails(fr.OfficerInCharge).ToLower().Trim() == userName.ToLower().Trim()).FirstOrDefault();
                // commented for .Net 6 upgrade
                //var fundingReduction = uow.Repository<FundingReduction>().GetAll(fr => GetOICDetails(fr.OfficerInCharge).ToLower() == userName.ToLower()).FirstOrDefault();
                var GetAfundingReduction = uow.Repository<FundingReduction>().GetAll().ToList();
                var fundingReduction = GetAfundingReduction.Where(x => GetOICDetails(x.OfficerInCharge).ToLower() == userName.ToLower()).FirstOrDefault();
                if (fundingReduction != null)
                {
                    var oicUserName = GetOICDetails(fundingReduction.OfficerInCharge);
                    if (userName == oicUserName)
                    {
                        frRole.Add((int)Enums.RoleType.OIC);
                    }
                }
                if (userRole.RoleId == (int)Enums.RoleType.Compliance)
                {
                    frRole.Add((int)Enums.RoleType.Compliance);
                }
                var frLOBApprovers = (from categoryUser in uow.Repository<ORBCategoryUserRoleMapping>().GetAll(x => x.ORBApproverTypeId == (int)Enums.ApproverType.FRLOBApprover, "UserRole").ToList()
                                      join userCOPMap in uow.Repository<ORBCategoryUserRoleReportingPracticeMapping>().GetAll().ToList()
                                      on categoryUser.ORBCategoryUserRoleMappingId equals userCOPMap.ORBCategoryUserRoleMappingId
                                      join userCOPCountryMap in uow.Repository<ORBCategoryUserRoleReportingPracticeCountryMapping>().GetAll().ToList()
                                      on userCOPMap.ORBCategoryUserRoleReportingPracticeMappingId equals userCOPCountryMap.ORBCategoryUserRoleReportingPracticeMappingId
                                      where categoryUser.ORBCategory == 2 && categoryUser.UserRole.UserId.ToLower().Trim() == userName.ToLower().Trim()
                                      select new
                                      {
                                          ApproverTypeId = (int)Enums.ApproverType.FRLOBApprover,
                                          UserName = categoryUser.UserRole.UserId,
                                      }).ToList();
                if (frLOBApprovers.Count > 0)
                {
                    frRole.Add((int)Enums.ApproverType.FRLOBApprover);
                }

                var frQAApprovers = (from categoryUser in uow.Repository<ORBCategoryUserRoleMapping>().GetAll(x => x.ORBApproverTypeId == (int)Enums.ApproverType.FRQAApprover, "UserRole").ToList()
                                     join userCOPMap in uow.Repository<ORBCategoryUserRoleReportingPracticeMapping>().GetAll().ToList()
                                     on categoryUser.ORBCategoryUserRoleMappingId equals userCOPMap.ORBCategoryUserRoleMappingId
                                     join userCOPCountryMap in uow.Repository<ORBCategoryUserRoleReportingPracticeCountryMapping>().GetAll().ToList()
                                     on userCOPMap.ORBCategoryUserRoleReportingPracticeMappingId equals userCOPCountryMap.ORBCategoryUserRoleReportingPracticeMappingId
                                     where categoryUser.ORBCategory == 2  && categoryUser.UserRole.UserId.ToLower().Trim() == userName.ToLower().Trim()
                                     select new
                                     {
                                         ApproverTypeId = (int)Enums.ApproverType.FRQAApprover,
                                         UserName = categoryUser.UserRole.UserId,
                                     }).ToList();
                if (frQAApprovers.Count > 0)
                {
                    frRole.Add((int)Enums.ApproverType.FRQAApprover);
                }

                var countryApprovers = uow.Repository<ApproverByCountry>().GetAll(x => x.ApproverTypeId == (int)Enums.ApproverType.FRFinanceApprover).ToList();
                foreach (var ra in countryApprovers)
                {
                    var appMapping = uow.Repository<ApproverByCountryMapping>().GetAll(m => m.ApproverByCountryId == ra.ApproverByCountryId, "UserRole").ToList();
                    if (appMapping.Any(a => a.UserRole.UserId.ToLower() == userName.ToLower()))
                    {
                        frRole.Add((int)Enums.RoleType.FinanceExecutive);
                    }
                }

                if (!frRole.Any(x => x == (int)Enums.RoleType.FinanceExecutive))
                {
                    var regionApprovers = uow.Repository<ApproverByRegion>().GetAll(x => x.ApproverTypeId == (int)Enums.ApproverType.FRFinanceApprover).ToList();
                    foreach (var ra in regionApprovers)
                    {
                        var appMapping = uow.Repository<ApproverByRegionMapping>().GetAll(m => m.ApproverByRegionId == ra.ApproverByRegionId, "UserRole").ToList();
                        if (appMapping.Any(a => a.UserRole.UserId == userName))
                        {
                            frRole.Add((int)Enums.RoleType.FinanceExecutive);
                        }
                    }
                }

                if (frRole.Count > 0)
                {
                    frApprover = Constants.User.FRApprover;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return frApprover;
        }

        private string GetOICDetails(string officerInCharge)
        {
            string empId = string.Empty;
            try
            {
                UserRole userRoles = new UserRole();
                if (officerInCharge != null)
                {
                    var empDetails = officerInCharge.Split("-");
                    empId = empDetails[empDetails.Length - 1];
                }
                return empId;
            }
            catch (Exception exception)
            {
                return empId;
            }
        }
    }
}