﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class ContractTypeService : IContractTypeService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public ContractTypeService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<ContractTypeViewModel> GetAllContractTypes()
        {
            var contractTypes = uow.Repository<ContractType>().GetAll(null, "OpportunityType").OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));

            List<ContractTypeViewModel> contractTypeVMList = new List<ContractTypeViewModel>();

            foreach (var contract in contractTypes)
            {
                var contractTypeRow = mapper.Map<ContractType, ContractTypeViewModel>(contract);
                contractTypeRow.OpportunityTypeName = contract.OpportunityType.OpportunityTypeName;
                contractTypeVMList.Add(contractTypeRow);
            }

            return contractTypeVMList; // mapper.Map<IEnumerable<ContractType>, IEnumerable<ContractTypeViewModel>>(contractTypes);
        }

        public void AddContractType(ContractTypeViewModel model)
        {
            if (model != null)
            {
                var contractType = mapper.Map<ContractTypeViewModel, ContractType>(model);
                contractType.CreatedBy = model.CreatedBy;
                contractType.IsActive = true;
                contractType.CreatedDate = DateTime.Now;
                uow.Repository<ContractType>().Add(contractType);
                uow.SaveChanges();
            }
        }

        public ContractTypeViewModel GetContractTypeById(int id)
        {
            var contractType = uow.Repository<ContractType>().GetById(id);
            return mapper.Map<ContractType, ContractTypeViewModel>(contractType);
        }

        public void UpdateContractType(ContractTypeViewModel model)
        {
            var contractType = uow.Repository<ContractType>().GetById(model.ContractTypeId);
            contractType.ContractTypeName = model.ContractTypeName;
            contractType.IsActive = model.IsActive;
            contractType.CreatedDate = contractType.CreatedDate;
            contractType.UpdatedBy = model.UpdatedBy;
            contractType.UpdatedDate = DateTime.Now;
            contractType.Mapping = model.Mapping;
            contractType.Comments = model.Comments;
            contractType.IsFinanceApprovalRequired = model.IsFinanceApprovalRequired;
            contractType.OpportunityTypeId = model.OpportunityTypeId;
            contractType.IsContigencyMandatory = model.IsContigencyMandatory;
            contractType.MinimumContingencyPer = model.MinimumContingencyPer;
            uow.Repository<ContractType>().Update(contractType);
            uow.SaveChanges();
            model = mapper.Map<ContractType, ContractTypeViewModel>(contractType);
        }

        public IEnumerable<ContractTypeViewModel> GetActiveContractTypes()
        {
            var contractTypes = uow.Repository<ContractType>().GetAll(x => x.IsActive == true).OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            return mapper.Map<IEnumerable<ContractType>, IEnumerable<ContractTypeViewModel>>(contractTypes);
        }
    }
}
