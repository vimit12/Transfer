﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class COPService : ICOPService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public COPService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public void AddCOP(COPViewModel model)
        {
            if (model != null)
            {
                var cop = mapper.Map<COPViewModel, COP>(model);
                cop.CreatedBy = model.CreatedBy;
                cop.IsActive = true;
                cop.CreatedDate = DateTime.Now;
                uow.Repository<COP>().Add(cop);
                uow.SaveChanges();
            }
        }

        public IEnumerable<COPViewModel> GetActiveCOPs(int oppId)
        {
            //var cop = uow.Repository<COP>().GetAll(etype => etype.IsActive).OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            var opportunity = uow.Repository<Opportunity>().GetAll(x => x.OpportunityId == oppId).FirstOrDefault();
            var oppCreatedDate = opportunity != null ? opportunity.CreatedDate : DateTime.Now;
            var cop = uow.Repository<COP>().GetAll(item => item.ValidFrom <= oppCreatedDate && item.ValidTill >= oppCreatedDate).OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            return mapper.Map<IEnumerable<COP>, IEnumerable<COPViewModel>>(cop);
        }

        public COPViewModel GetCOPById(int id)
        {
            var cop = uow.Repository<COP>().GetById(id);
            return mapper.Map<COP, COPViewModel>(cop);
        }

        public IEnumerable<COPViewModel> GetAllCOPs()
        {
            var cops = uow.Repository<COP>().GetAll().OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            return mapper.Map<IEnumerable<COP>, IEnumerable<COPViewModel>>(cops);
        }

        public void UpdateCOP(COPViewModel model)
        {
            var cop = uow.Repository<COP>().GetById(model.COPId);
            cop.COPName = model.COPName;
            cop.IsActive = model.IsActive;
            cop.CreatedDate = cop.CreatedDate;
            cop.UpdatedBy = model.UpdatedBy;
            cop.UpdatedDate = DateTime.Now;
            cop.Comments = model.Comments;
            cop.ValidFrom = model.ValidFrom;
            cop.ValidTill = model.ValidTill;
            uow.Repository<COP>().Update(cop);
            uow.SaveChanges();
            model = mapper.Map<COP, COPViewModel>(cop);
        }

        public IEnumerable<COPViewModel> GetActiveCOPs()
        {
            var cop = uow.Repository<COP>().GetAll(etype => etype.IsActive).OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            return mapper.Map<IEnumerable<COP>, IEnumerable<COPViewModel>>(cop);
        }
    }
}
