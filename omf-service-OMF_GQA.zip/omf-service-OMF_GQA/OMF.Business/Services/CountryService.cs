namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class CountryService : ICountryService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public CountryService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<CountryViewModel> GetCountries()
        {
            var countries = uow.Repository<Country>().GetAll(country => country.Region.IsActive && country.Currency.IsActive, "Region,Currency").ToList().OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            List<CountryViewModel> countryViews = new List<CountryViewModel>();
            foreach (var country in countries)
            {
                var countryVM = mapper.Map<Country, CountryViewModel>(country);
                countryVM.RegionName = country.Region.RegionName;
                countryVM.CurrencyCode = country.Currency.CurrencyCode;

                countryViews.Add(countryVM);
            }

            return countryViews;
        }

    public IEnumerable<CountryViewModel> GetActiveCountries()
    {
      var countries = uow.Repository<Country>().GetAll(country => country.IsActive).OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            return mapper.Map<IEnumerable<Country>, IEnumerable<CountryViewModel>>(countries);
    }

        public CountryViewModel GetCountryById(int id)
        {
            var country = uow.Repository<Country>().GetAll(x => x.CountryId == id, "Region").FirstOrDefault();
            var countryViewModel = mapper.Map<Country, CountryViewModel>(country);
            countryViewModel.RegionName = country.Region.RegionName;
            return countryViewModel;
        }

        public void AddCountry(CountryViewModel model)
        {
            if (model != null)
            {
                var country = mapper.Map<CountryViewModel, Country>(model);

                // Created by should get from claims
                country.CreatedBy = model.CreatedBy;
                country.IsActive = true;
                country.CreatedDate = DateTime.Now;
                uow.Repository<Country>().Add(country);
                uow.SaveChanges();
            }
        }

        public void UpdateCountry(CountryViewModel model)
        {
            var country = uow.Repository<Country>().GetById(model.CountryId);
            country.CountryName = model.CountryName;
            country.CurrencyId = model.CurrencyId;
            country.Comments = model.Comments;
            country.IsActive = model.IsActive;
            country.IsTaxRegistrationNoRequired = model.IsTaxRegistrationNoRequired;
            country.RegionId = model.RegionId;
            country.ExportFriendly = model.ExportFriendly;
            country.CreatedDate = country.CreatedDate;
            country.AdditionalQuestions = model.AdditionalQuestions;

            // Created by should get from claims
            country.UpdatedBy = model.UpdatedBy;
            country.UpdatedDate = DateTime.Now;
            uow.Repository<Country>().Update(country);
            uow.SaveChanges();
            model = mapper.Map<Country, CountryViewModel>(country);
        }
    }
}
