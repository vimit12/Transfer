﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class CurrencyService : ICurrencyService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public CurrencyService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<CurrencyViewModel> GetAllCurrencies()
        {
            var currencies = uow.Repository<Currency>().GetAll().OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            return mapper.Map<IEnumerable<Currency>, IEnumerable<CurrencyViewModel>>(currencies);
        }

        /// <summary>
        /// Get all the active currencies
        /// </summary>
        /// <returns>Return the list of all currencies</returns>
        public IEnumerable<CurrencyViewModel> GetActiveCurrencies()
        {
            // commented for .Net 6.0 upgrade
            //var currencies = uow.Repository<Currency>().GetAll(currency => currency.IsActive).OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            var currencies = uow.Repository<Currency>().GetAll(currency => currency.IsActive).ToList().OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            return mapper.Map<IEnumerable<Currency>, IEnumerable<CurrencyViewModel>>(currencies);
        }

        /// <summary>
        /// Gets the currency given the if
        /// </summary>
        /// <param name="id">Currency Id</param>
        /// <returns>Currency Object based on the id</returns>
        public CurrencyViewModel GetCurrencyById(int id)
        {
            var currency = uow.Repository<Currency>().GetById(id);
            return mapper.Map<Currency, CurrencyViewModel>(currency);
        }

        /// <summary>
        /// Adds the currency object to the DB
        /// </summary>
        /// <param name="model">The currency object that is to be inserted in to the DB</param>
        public void AddCurrency(CurrencyViewModel model)
        {
            if (model != null)
            {
                var currency = mapper.Map<CurrencyViewModel, Currency>(model);

                // Created by should get from claims
                currency.CurrencyCode = model.CurrencyCode;
                currency.Comments = model.Comments;
                currency.CreatedBy = model.CreatedBy;
                currency.IsActive = true;
                currency.CreatedDate = DateTime.Now;
                uow.Repository<Currency>().Add(currency);
                uow.SaveChanges();
            }
        }

        /// <summary>
        /// Updates the currency object to the DB
        /// </summary>
        /// <param name="model">Currency Model Object</param>
        public void UpdateCurrency(CurrencyViewModel model)
        {
            var currency = uow.Repository<Currency>().GetById(model.CurrencyId);
            currency.CurrencyCode = model.CurrencyCode;
            currency.Comments = model.Comments;
            currency.IsActive = model.IsActive;
            currency.CreatedDate = currency.CreatedDate;

            // Created by should get from claims
            currency.UpdatedBy = model.UpdatedBy;
            currency.UpdatedDate = DateTime.Now;
            uow.Repository<Currency>().Update(currency);
            uow.SaveChanges();
        }
    }
}