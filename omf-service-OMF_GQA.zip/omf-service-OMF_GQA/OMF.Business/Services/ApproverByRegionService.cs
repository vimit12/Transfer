﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class ApproverByRegionService : IApproverByRegionService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public ApproverByRegionService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<ApproverByRegionViewModel> GetApproversByRegion()
        {
            var approversByRegion = uow.Repository<ApproverByRegion>().GetAll(aByR => aByR.ApproverType.IsActive, "ApproverType").OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));

            List<ApproverByRegionViewModel> approversByRegionVMList = new List<ApproverByRegionViewModel>();

            foreach (var approver in approversByRegion)
            {
                var approverMapping = from approverMappings in uow.Repository<ApproverByRegionMapping>().GetAll()
                                      join approverByRegion in uow.Repository<ApproverByRegion>().GetAll() on approverMappings.ApproverByRegionId equals approverByRegion.ApproverByRegionId
                                      join userRole in uow.Repository<UserRole>().GetAll() on approverMappings.UserRoleId equals userRole.UserRoleId
                                      where approverByRegion.ApproverByRegionId == approver.ApproverByRegionId
                                      select new
                                      {
                                          approverByRegionId = approverByRegion.ApproverByRegionId,
                                          approverTypeId = approver.ApproverTypeId,
                                          name = userRole.FirstName + " " + userRole.LastName + " - " + userRole.UserId,
                                          isActive = userRole.IsActive
                                      };

                if (approverMapping.Any())
                {
                    var regionDetails = (from approverByRegion in uow.Repository<ApproverByRegion>().GetAll()
                                 join region in uow.Repository<Region>().GetAll() on approverByRegion.RegionId equals region.RegionId
                                 join approverType in uow.Repository<ApproverType>().GetAll() on approverByRegion.ApproverTypeId equals approverType.ApproverTypeId
                                 where approverByRegion.ApproverByRegionId == approver.ApproverByRegionId && region.IsActive
                                 select new
                                 {
                                     region.RegionName,
                                     approverType.ApproverTypeName
                                 }).FirstOrDefault();

                    if (regionDetails != null)
                    {
                        var approverByRegionModel = new ApproverByRegion
                        {
                            ApproverByRegionId = approver.ApproverByRegionId,
                            ApproverTypeId = approver.ApproverTypeId,
                            RegionId = approver.RegionId,
                            Comments = approver.Comments,
                            IsActive = approver.IsActive,
                            CreatedBy = approver.CreatedBy,
                            CreatedDate = approver.CreatedDate,
                            UpdatedBy = approver.UpdatedBy,
                            UpdatedDate = approver.UpdatedDate
                        };

                        var approverVM = mapper.Map<ApproverByRegion, ApproverByRegionViewModel>(approverByRegionModel);
                        approverVM.ApproverNames = string.Join((char)44 + " ", approverMapping.Where(y => y.isActive).Select(x => x.name));
                        approverVM.RegionName = regionDetails.RegionName;
                        approverVM.ApproverTypeName = regionDetails.ApproverTypeName;
                        approversByRegionVMList.Add(approverVM);
                    }
                }
            }

            return approversByRegionVMList;
        }

        public void AddApproverByRegion(ApproverByRegionViewModel model)
        {
            if (model != null)
            {
                var approverByRegion = mapper.Map<ApproverByRegionViewModel, ApproverByRegion>(model);

                // Created by should get from claims
                approverByRegion.CreatedBy = model.CreatedBy;
                approverByRegion.IsActive = true;
                approverByRegion.CreatedDate = DateTime.Now;
                uow.Repository<ApproverByRegion>().Add(approverByRegion);
                uow.SaveChanges();

                if (model.Approvers != null && model.Approvers.Any())
                {
                    var approverMappingsByRegion = mapper.Map<IEnumerable<ApproverByRegionMappingViewModel>, IEnumerable<ApproverByRegionMapping>>(model.Approvers);

                    foreach (var approverMapping in approverMappingsByRegion)
                    {
                        approverMapping.ApproverByRegionId = approverByRegion.ApproverByRegionId;
                    }

                    uow.Repository<ApproverByRegionMapping>().AddRange(approverMappingsByRegion);
                }

                uow.SaveChanges();
            }
        }

        public void UpdateApproverByRegion(ApproverByRegionViewModel model)
        {
            var approverByRegionModel = mapper.Map<ApproverByRegionViewModel, ApproverByRegion>(model);
            var approverByRegion = uow.Repository<ApproverByRegion>().GetById(approverByRegionModel.ApproverByRegionId);
            if (model.Approvers != null && model.Approvers.Any())
            {
                var approverByRegionMapping = uow.Repository<ApproverByRegionMapping>().GetAll(apprMap => apprMap.ApproverByRegionId == approverByRegionModel.ApproverByRegionId);
                uow.Repository<ApproverByRegionMapping>().DeleteRange(uow.Repository<ApproverByRegionMapping>().GetAll(apprMap => apprMap.ApproverByRegionId == approverByRegionModel.ApproverByRegionId));
                var approverMappingsByRegion = mapper.Map<IEnumerable<ApproverByRegionMappingViewModel>, IEnumerable<ApproverByRegionMapping>>(model.Approvers);
                foreach (var approverMapping in approverMappingsByRegion)
                {
                    approverMapping.ApproverByRegionId = approverByRegion.ApproverByRegionId;
                }

                uow.Repository<ApproverByRegionMapping>().AddRange(approverMappingsByRegion);
            }

            approverByRegion.ApproverTypeId = approverByRegionModel.ApproverTypeId;
            approverByRegion.RegionId = approverByRegionModel.RegionId;
            approverByRegion.Comments = approverByRegionModel.Comments;
            approverByRegion.IsActive = approverByRegionModel.IsActive;
            approverByRegion.CreatedDate = approverByRegion.CreatedDate;
            approverByRegion.CreatedBy = approverByRegion.CreatedBy;

            // Created by should get from claims
            approverByRegion.UpdatedBy = model.UpdatedBy;
            approverByRegion.UpdatedDate = DateTime.Now;
            uow.Repository<ApproverByRegion>().Update(approverByRegion);
            uow.SaveChanges();
        }
    }
}