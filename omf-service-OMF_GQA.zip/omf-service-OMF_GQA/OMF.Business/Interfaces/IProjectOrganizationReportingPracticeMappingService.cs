﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IProjectOrganizationReportingPracticeMappingService
    {
        IEnumerable<ProjectOrganizationReportingPracticeMappingViewModel> GetAllProjectOrganizationReportingPracticeMappings();

        void AddProjectOrganizationReportingPracticeMapping(ProjectOrganizationReportingPracticeMappingViewModel model);
    }
}
