﻿namespace OMF.Business.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using OMF.Business.Models;

    public interface IOpportunityService
    {
        IEnumerable<OpportunitySectionFilterViewModel> GetOpportunitySections(int opportunityId, int contractTypeId);

        IEnumerable<OpportunitySectionFilterViewModel> GetAllSectionsForOpportunity(int opportunityId);

        IEnumerable<OpportunityViewModel> GetAllOpportunities();

        IEnumerable<OmfFinancialSectionsViewModel> GetOmfFinancialSections();

        IEnumerable<OpportunitiesViewModel> GetOpportunities();

        Task<InfoViewModel> GetOpportunityById(int opprtunityId);

        Task<OpportunityQpeDetailsViewModel> GetOpportunityQpeDetails(int opportunityId);

        OpportunityBasicDetailsViewModel SaveInfoCompliance(InfoViewModel infoComp);

        bool ValidateInfoCompliance(InfoViewModel opporValidate, out string errorMessage);

        OpportunityBasicDetailsViewModel GetOpportunityMasterDetails(int opportunityId);

        IEnumerable<ClientMasterViewModel> GetAllClients();

        // Compliance Section Declarations
        ComplianceViewModel ComplianceDetailsByOpportunity(int opportunityId);

        void SaveCompliance(ComplianceViewModel compl);

        // Project Summary Code
        IEnumerable<OpportunityProjectSummaryCapabilityViewModel> GetProjectSummaryCapabilities(int opportunityId);

        void SaveProjectSummaryCapabilities(IEnumerable<OpportunityProjectSummaryCapabilityViewModel> prjCapabilities);

        IEnumerable<OpportunityProjectSummaryTechnologyViewModel> GetProjectSummaryTechnologies(int opportunityId);

        void SaveProjectTechnologies(IEnumerable<OpportunityProjectSummaryTechnologyViewModel> prjTechnologies);

        IEnumerable<OpportunityProjectSummaryGlobalSolutionViewModel> GetProjectGlobalSolutions(int opportunityId);

        void SaveProjectGlobalSolutions(IEnumerable<OpportunityProjectSummaryGlobalSolutionViewModel> prjGlobalSolutions);

        OpportunityProjectSummaryViewModel GetMainProjectSummary(int opportunityId);

        void SaveProjectSummary(OpportunityProjectSummaryViewModel prjSummary);

        // Get Weekly Hours By Date Range
        IEnumerable<FinancialQuarterViewModel> GetFinancialWeeklyHoursByQuarters(FinancialWeeklyHoursViewModel financialWeeklyHoursViewModel);

        IEnumerable<FinancialQuarterViewModel> GetOMFCurrentFinancialWeeklyHours(int omfId, int year, decimal loadingPercentage = 0);

        InfoFinancialSummaryViewModel GetProposalFinancialSummaryDetails(int opportunityId, int yearId);

        OpportunityAccessViewModel GetAccessDetailsByOpportunityId(int opportunityId, string userId);

        void DeleteOpportunity(int opportunityId);

        bool CheckOpportunityAccess(int opportunityId, string userId);

        OpportunityOverviewViewModel GetOpportunityOverview(int opportunityId);

        void SaveOpportunityOverview(OpportunityOverviewViewModel oppOverview);

        IEnumerable<OpportunityRisksViewModel> GetOpportunityRisks(int opportunityId);

        void SaveOrUpdateOpportunityRisks(List<OpportunityRisksViewModel> oppRisks);

        InfoFinancialSummaryViewModel GetProposalFinancialOverviewSummaryDetails(int opportunityId, int yearId);

        OpportunityProjectDetailsViewModel GetOpportunityProjectDetails(int opportunityId);

        void SaveOrUpdateOpportunityProjectDetail(OpportunityProjectDetailsViewModel oppProjectDetail);

        double GetRevenueEstimate(int opportunityId);

        IList<ComplianceScreeningInstructionsViewModel> GetComplianceScreeningInstructions();

        void DeleteOpportunityRisks(List<OpportunityRisksViewModel> oppRisks);

        CountryViewModel GetCountryDetailsByContractingOrganization(OpportunityBasicDetailsViewModel opportunityBasicDetailsView);

        void SaveCROpportunity(CROpportunityViewModel crOpportunity);

        OpportunityRatingViewModel GetOpportunityRating(int opportunityId);

        void SaveOrUpdateOpportunityRating(OpportunityRatingViewModel oppRating);

        ProjectDealTypeViewModel GetProjectDealPercentage(int opportunityId);

        IEnumerable<OpportunityViewModel> GetOpportunitiesByUser();

        void SaveNewVersion(int opportunityId);

        Task SaveORBAttachments(ORBAttachmentViewModel viewModel);

        ORBAttachmentViewModel GetORBAttachmentsForOpportunity(int opportunityId);

        IEnumerable<OpportunitiesViewModel> GetOpportunitiesForHistoryPage(DateTime startDate, DateTime endDate);

        //IEnumerable<string> GetStatusesForLandingPage(DateTime startDate, DateTime endDate);

        IEnumerable<dynamic> GetOpportunitiesForLandingPage(int options);

        StatusTypeViewModel GetCurrentStatusForOpportunity(int oppId);

        IEnumerable<OpportunitiesViewModel> GetCompletedOpportunitiesForCRList();

        Task SaveDocuments(OpportunityDocumentDetailsViewModel model);

        Task<OpportunityDocumentDetailsViewModel> GetOpportunityDocumentDetails(int opportunityDocumentDetailsId);

        List<OpportunityDocumentMetaDataViewModel> GetOpportunityDocumentMetaData(int opportunityId);

        Task<bool> DeleteDocument(int opportunityDocumentDetailId);

        void UpdateProjectDiscountPercentages();

        void InsertDataToRevenueTableForMissingOpportunity(int opportunityId);

        Task<bool> MoveCommentsFromOrb();

        void SetOpportunityForAudit(int opportunityId, int approverType);

        void SetOpportunityForAuditAsComplete(int opportunityId, int approverType);

        void SaveOpportunityComplianceUserMapping(OpportunityComplianceUserMappingViewModel model);

        void UpdateOICMissingUserIds();

        PeriscopeModelOutputViewModel GetPeriscopeModelForOpportunity(int oppId);

        int CopyOpportunityInfo(int oppId, bool isPendingStatus);

        void PendingStatus(PendingStatusViewModel pendingStatusViewModel);

        List<RevenueCostViewModel> GetOpportunityEmployeeRevenueCost(int opportunityId);

        List<RevenueCostViewModel> GetOpportunityContractRevenueCost(int opportunityId);

        IEnumerable<OpportunityProjectDetailsViewModel> GetProjectCodesAccessWise();

        IEnumerable<OpportunityViewModel> GetOpportunitiesByProjectCodeOrCrmIdOrClientId(string projectCode, string crmId, int clientId);

        IEnumerable<OpportunityAccessViewModel> GetOpportunitiyAccessUsers(int opportunityId);

        void SaveOrUpdateOpportunitiyAccessUsers(IEnumerable<OpportunityAccessViewModel> oppAccessUsers);

        OpportunityAuditAccessViewModel GetOpportunitiyAuditAccess(int opportunityId);

        void SaveOpportunityIFRSUserMapping(OpportunityComplianceUserMappingViewModel model);

        IEnumerable<OpportunityByCRMIdViewModel> GetOpportunitiesByCrmId(string crmid);
        
        string UpdateBillingAdministratorByOpportunityIds(BillingAdminByOpportunities billingAdminViewModel);

        ValidateDataViewModel ValidateReportingPracticeAndCOPByOppId(InfoViewModel infoComp);

        void InsertIntoOpportunityAccessBasedonCreatedBy(int opportunityId, string pcreatedBy, string loggedInUser, int parentOppId);
    }
}
