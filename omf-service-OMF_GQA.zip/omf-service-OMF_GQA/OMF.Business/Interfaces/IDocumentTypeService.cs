﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IDocumentTypeService
    {
        IEnumerable<DocumentTypeViewModel> GetActiveDocumentTypes();
    }
}
