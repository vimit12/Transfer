﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IOmfJourney
    {
        IEnumerable<OMFJourneyViewModel> GetOmfJourneyByOpportunityId(int opportunityId);

        IEnumerable<OMFJourneyViewModel> GetDefaultJourney();

        IEnumerable<OMFJourneyViewModel> GetDefaultJourneyByOpportunityId(int opportunityId);

        IEnumerable<OMFWorkLocationWorkFlowJourneyViewModel> GetDefaultWorkLocationJourney(int oppId);

        IEnumerable<OMFWorkLocationWorkFlowJourneyViewModel> GetWorkLocationJourney(int oppId);

        IEnumerable<ORBJourneyViewModel> GetORBWorkFlowJourneyForOpportunity(int oppId);

        IEnumerable<ORBJourneyViewModel> GetDefaultORBJourneyForOpportunity(int opportunityId);

        IEnumerable<FundingReductionJourneyViewModel> GetDefaultFundingReductionJourney();

        IEnumerable<FundingReductionJourneyViewModel> GetFRJourneyByFundingReductionId(int fundingReductionId);
    }
}
