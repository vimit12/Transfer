﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IApproverByCountryService
    {
        IEnumerable<ApproverByCountryViewModel> GetApproversByCountry();

        void AddApproverByCountry(ApproverByCountryViewModel model);

        void UpdateApproverByCountry(ApproverByCountryViewModel model);
    }
}
