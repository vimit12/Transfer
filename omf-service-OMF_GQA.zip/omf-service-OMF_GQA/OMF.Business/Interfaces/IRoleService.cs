﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IRoleService
    {
        IEnumerable<RoleViewModel> GetRoles();

        IEnumerable<RoleViewModel> GetActiveRoles();

        void AddRole(RoleViewModel model);

        void UpdateRole(RoleViewModel model);
    }
}
