﻿using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Interfaces
{
    public interface IApproverByWorkLocationService
    {
        IEnumerable<ApproverByWorkLocationViewModel> GetApproversByWorkLocationLOB();

        void AddApproverByWorkLocation(ApproverByWorkLocationViewModel model);

        void UpdateApproverByWorkLocation(ApproverByWorkLocationViewModel model);

        IEnumerable<ApproverByWorkLocationViewModel> GetApproversByWorkLocationCOP();

        IEnumerable<ApproverByWorkLocationViewModel> GetApproversByWorkLocation();

    }
}
