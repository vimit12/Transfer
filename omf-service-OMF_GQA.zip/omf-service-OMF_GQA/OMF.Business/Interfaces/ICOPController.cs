﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ICOPService
    {
        IEnumerable<COPViewModel> GetAllCOPs();

        IEnumerable<COPViewModel> GetActiveCOPs(int oppId);

        COPViewModel GetCOPById(int id);

        void AddCOP(COPViewModel model);

        void UpdateCOP(COPViewModel model);

        IEnumerable<COPViewModel> GetActiveCOPs();
    }
}