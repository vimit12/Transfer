﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IWorkLocationResourceRoleMappingService
    {
        IEnumerable<WorkLocationResourceRoleMappingViewModel> GetWorkLocationResourceRoleMappings();

        IEnumerable<WorkLocationResourceRoleMappingViewModel> GetActiveWorkLocationResourceRoleMappings();

        WorkLocationResourceRoleMappingViewModel GetWorkLocationResourceRoleMappingById(int id);

        void AddWorkLocationResourceRoleMapping(WorkLocationResourceRoleMappingViewModel model);

        void UpdateWorkLocationResourceRoleMapping(WorkLocationResourceRoleMappingViewModel model);
    }
}
