﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IFxRateService
    {
        IEnumerable<FxRateViewModel> GetFxRatesByYear(int yearId);

        IEnumerable<CommentsSummaryViewModel> GetFxRatesSummary(int year, string quarter);

        void SaveFxRates(IEnumerable<FxRateViewModel> models);

        Dictionary<string, double> GetFxCurrencyForCurrentQtr();
    }
}