﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using System.Net.Mail;
    using System.Threading.Tasks;
    using OMF.Business.Models;

    public interface IEmailService
    {
        Task<string> SendMailAsync(MailNotificationViewModel mailNotificationViewModel, MailMessage mailMessage = null);

        string GetApprovalLink(IEnumerable<WorkLocationStatusActionViewModel> workLocationStatusAction, WorkFlowActionViewModel workFlowActionView, string approval, int templateId);

        string GetOICApprovalLink(IEnumerable<StatusActionViewModel> workLocationStatusAction, WorkFlowActionViewModel workFlowActionView, string approval, int templateId);

        string GetReferBackLink(int wlApprovalType, IEnumerable<StatusActionViewModel> statusAction, WorkFlowActionViewModel workFlowActionView, int templateId);
    }
}
