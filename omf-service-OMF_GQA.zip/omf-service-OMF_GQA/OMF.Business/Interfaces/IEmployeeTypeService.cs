﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IEmployeeTypeService
    {
        IEnumerable<EmployeeTypeViewModel> GetEmployeeTypes();

        IEnumerable<EmployeeTypeViewModel> GetActiveEmployeeTypes();

        EmployeeTypeViewModel GetEmployeeTypeById(int id);

        void AddEmployeeType(EmployeeTypeViewModel model);

        void UpdateEmployeeType(EmployeeTypeViewModel model);
    }
}
