﻿using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Interfaces
{
    public interface IFinancialsStaffAugmentationService
    {
        IEnumerable<FinancialsStaffAugmentationViewModel> GetFinancialsStaffAugmentations(int opportunityId, int yearId);
        IEnumerable<FinancialsStaffAugmentationViewModel> GetFinancialsStaffAugmentations();

        void SaveFinancialsStaffAugmentations(IEnumerable<FinancialsStaffAugmentationViewModel> financialsStaffAugmentations);

        void DeleteFinancialsStaffAugmentation(FinancialsStaffAugmentationViewModel financialsStaffAugmentations);
    }
}
