﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IIFRS15CheckListService
    {
        IFRS15CheckListViewModel GetIFRS15CheckListByOpportunityId(int opportunityId);

        void SaveIFRS15CheckList(IFRS15CheckListViewModel ifrs);

        void SaveIFRSRevenueTeamCheckList(IFRSRevenueTeamCheckListViewModel ifrs);

        IFRSRevenueTeamCheckListViewModel GetIFRSRevenueTeamCheckListByOppId(int opportunityId);

        OpportunityProjectTemplateMatrixViewModel GetProjectMatrixTemplateByOppId(int opportunityId);
    }
}