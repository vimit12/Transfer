﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using Microsoft.AspNetCore.Http;
    using OMF.Business.Models;

    public interface IFinancialRoyaltyService
    {
        IEnumerable<FinancialRoyaltyDetailsViewModel> GetFinancialRoyaltyDetails(int opportunityId, int yearId);

        void AddNewOrUpdateRoyaltyDetails(List<FinancialRoyaltyDetailsViewModel> royaltyViewModel, string userId);

        void DeleteRoyaltyDetails(List<FinancialRoyaltyDetailsViewModel> financialRoyalty, ref string errorMessage);
    }
}