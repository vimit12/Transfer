﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IOpportunityTypeService
    {
        IEnumerable<OpportunityTypeViewModel> GetOpportunityTypes();
    }
}
