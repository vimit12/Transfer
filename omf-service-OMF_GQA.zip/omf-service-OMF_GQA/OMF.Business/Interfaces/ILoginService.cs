﻿using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace OMF.Business.Interfaces
{
    public interface ILoginService
    {
        Task<string> Login(LoginViewModel model);

        Task<HttpResponseMessage> GetEmployees(string searchString);

    }
}
