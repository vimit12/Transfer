﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IContractTypeService
    {
        IEnumerable<ContractTypeViewModel> GetAllContractTypes();

        void AddContractType(ContractTypeViewModel model);

        ContractTypeViewModel GetContractTypeById(int id);

        void UpdateContractType(ContractTypeViewModel model);

        IEnumerable<ContractTypeViewModel> GetActiveContractTypes();
    }
}
