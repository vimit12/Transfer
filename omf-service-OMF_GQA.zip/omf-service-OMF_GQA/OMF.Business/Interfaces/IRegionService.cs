﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IRegionService
    {
        IEnumerable<RegionViewModel> GetAllRegions();

        IEnumerable<RegionViewModel> GetActiveRegions();

        RegionViewModel GetRegionById(int id);

        void AddRegion(RegionViewModel model);

        void UpdateRegion(RegionViewModel model);
    }
}