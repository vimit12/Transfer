﻿using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace OMF.Business.Interfaces
{
    public interface IHiQService
    {
        Task<HttpResponseMessage> MakeHttpCall(string url, int method, HttpContent content = null);

        Task<bool> UpdateORBComments(WorkFlowActionViewModel wfModel, bool orbHeldToday = false);

        Task<bool> CheckHiQRecordStatus(int opportunityId);

        Task<bool> GetOpportunityQpeDetailsFromHiq(int opportunityId);

        Task<bool> UpdateOMFDetailsToHiQ(WorkFlowActionViewModel wfModel, bool updateOMFStatus = false);

        string GetORBApprovedPGM(int opportunityId);

        Task<HiQOMFIntegrationViewModel> HiQOMFIntegration(int opportunityId);
    }
}
