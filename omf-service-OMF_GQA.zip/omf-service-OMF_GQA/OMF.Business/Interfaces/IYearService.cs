﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using System.Linq;
    using OMF.Business.Models;
    using System;

    public interface IYearService
    {
        IEnumerable<YearViewModel> GetAllYears();

        IEnumerable<YearViewModel> GetYearByOrder(string operatr, string order);

        void AddYear(YearViewModel model);

        YearViewModel GetYearById(int id);

        void UpdateYear(YearViewModel model);

        IEnumerable<YearViewModel> GetAllYearsByOrder(string operatr, string order);

        IQueryable<YearViewModel> GetFinancialYears(int opportunityId, ref string message);

        IQueryable<YearViewModel> GetFinancialYearsWithDates(DateTime startDate, DateTime endDate);
    }
}
