﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IIFRSReferbackOnHoldReasonService
    {
        IEnumerable<IFRSReferBackOnHoldReasonViewModel> GetAllIFRSReferBackOnHoldReason();

        IEnumerable<IFRSReferBackOnHoldReasonViewModel> GetActiveIFRSReferBackOnHoldReason();

        IFRSReferBackOnHoldReasonViewModel GetIFRSReferBackOnHoldReasonById(int id);

        void AddIFRSReferBackOnHoldReason(IFRSReferBackOnHoldReasonViewModel model);

        void UpdateIFRSReferBackOnHoldReason(IFRSReferBackOnHoldReasonViewModel model);

        void AddIFRSReferBackOnHoldReasonByOpportunity(IFRSReferBackOnHoldReasonByOpportunityViewModel model);

        List<IFRSReferBackOnHoldReasonByOpportunityViewModel> GetIFRSReferBackOnHoldReasonByOpportunityId(int id);
    }
}