﻿using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Interfaces
{

    public interface IUserRegistrationRequestService
    {
        void CreateUserRegistrationRequest(UserRegistrationRequestViewModel model);

        bool CheckExistingEmailorUsername(UserRegistrationRequestViewModel userRegModel, out string errorMessage);

        bool CheckDuplicateUsernameorEmail(string username, string email, out string errorMessage);
    }
}
