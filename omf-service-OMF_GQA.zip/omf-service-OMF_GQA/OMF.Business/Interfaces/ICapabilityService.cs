﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ICapabilityService
    {
        IEnumerable<CapabilityViewModel> GetCapabilities();

        IEnumerable<CapabilityViewModel> GetActiveCapabilities();

        CapabilityViewModel GetCapabilitiesById(int id);

        void AddCapability(CapabilityViewModel model);

        void UpdateCapability(CapabilityViewModel model);
    }
}