﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using Microsoft.AspNetCore.Http;
    using OMF.Business.Models;

    public interface IFinancialProposalService
    {
        // Expense Detail Interface
        IEnumerable<FinancialNonBillableExpenseDetailViewModel> GetNonBillableExpenseDetails(int opportunityId, int yearId);

        void SaveNonBillableExpenseDetails(IEnumerable<FinancialNonBillableExpenseDetailViewModel> expense);

        // Managed Service Interface
        IEnumerable<FinancialManagedServiceDetailViewModel> GetManagedServicesDetail(int opportunityId, int yearId);

        void SaveManagedServiceDetail(FinancialManagedServiceDetailViewModel mgdServiceDetail);

        // Billable Section Details
        FinancialBillableExpenseDetailViewModel GetBillableExpenseDetails(int opportunityId, int yearId);

        void SaveBillableExpenseDetails(FinancialBillableExpenseDetailViewModel billableExpense);

        // Project-Staffing employees
        IEnumerable<FinancialEmployeeDetailViewModel> GetProjectStaffDetails();

        IEnumerable<FinancialEmployeeDetailViewModel> GetProjectStaffDetailsByYear(int opportunityId, int financialyear);

        IEnumerable<FinancialQuarterViewModel> GetProjectStaffWorkHours(int financialEmployeeDetailId);

        void AddOrModifyStaffDetails(List<FinancialEmployeeDetailViewModel> model, ref string errorMessage);

        void DeleteEmployeeDetails(List<FinancialEmployeeDetailViewModel> model, ref string errorMessage);

        // Project-ContractorDetails
        IEnumerable<FinancialContractorDetailViewModel> GetProjectContractorDetails();

        IEnumerable<FinancialContractorDetailViewModel> GetProjectContractorDetailsByYear(int opportunityId, int financialYear);

        IEnumerable<FinancialQuarterViewModel> GetProjectContractorWorkHours(int financialContractorDetailId);

        void AddOrModifyContractorDetails(List<FinancialContractorDetailViewModel> model, ref string errorMessage);

        void DeleteFinancialContractor(List<FinancialContractorDetailViewModel> model, ref string errorMessage);

        CopyFinancialProposalViewModel CopyFinancialProposal(CopyFinancialProposalInputViewModel model, ref string errorMessage);

        byte[] ExtractEmployeeDetailsTemplate(int opportunityId, out string fileName);

        byte[] ExtractEmployeeStaffingDetailsWithMargins(int opportunityId, out string fileName);

        //void UploadStaffingDetails(IFormFile file, int opportunityId);
        byte[] UploadEmployeeDetails(EmployeeFileUploadDetailsViewModel employeeFileUploadDetails, out string messages, out string fileName);

        byte[] ExtractContractorDetailsTemplate(int opportunityId, out string fileName);

        byte[] ExtractContractorDetailsTemplateWithMargins(int opportunityId, out string fileName);

        byte[] UploadContractorDetails(EmployeeFileUploadDetailsViewModel employeeFileUploadDetails, out string messages, out string fileName);

        void SaveBillableExpensesWithDetails(List<FinancialBillableExpensesWithDetailsViewModel> billableExpenses);

        IList<FinancialAnnualMaintenanceCostViewModel> GetFinancialAnnualMaintenanceCosts(int opportunityId, int yearId);

        void SaveAnnualMaintenanceCosts(IEnumerable<FinancialAnnualMaintenanceCostViewModel> expense);

        IList<FinancialBillableExpensesWithDetailsViewModel> GetBillableExpensesWithDetails(int opportunityId, int yearId);

        void DeleteBillableExpensesWithDetails(IList<FinancialBillableExpensesWithDetailsViewModel> financialBillableExpensesWithDetailsViewModels);

        IEnumerable<FinancialsDiscountAndRebateViewModel> GetFinancialsDiscountAndRebates(int opportunityId, int yearId);

        void SaveFinancialsDiscountAndRebates(IEnumerable<FinancialsDiscountAndRebateViewModel> discountsAndRebates);

        void DeleteFinancialsDiscountAndRebates(FinancialsDiscountAndRebateViewModel discountsAndRebates);

    }
}
