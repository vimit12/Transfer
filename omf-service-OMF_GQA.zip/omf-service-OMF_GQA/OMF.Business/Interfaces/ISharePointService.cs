﻿using OMF.Business.Models;
using OMF.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OMF.Business.Interfaces
{
    public interface ISharePointService
    {
        Task<string> GetSharePointAccessToken();

        Task<SharePointSuccessfulUploadModel> SaveDocument(OpportunityDocumentDetailsViewModel model);

        Task<byte[]> GetDocument(OpportunityDocumentDetails details);

        Task<bool> DeleteDocument(OpportunityDocumentDetails model);

        Task<SharePointSuccessfulUploadModel> CreatedFolder(int opporutnityId);

        Task<SharePointSuccessfulUploadModel> SaveFundingReductionDocument(FundingReductionDocumentDetailsViewModel model);

        Task<SharePointSuccessfulUploadModel> CreatedFolderFundingReduction(int fundingReductionId);

        Task<byte[]> GetFundingReductionDocument(FundingReductionDocumentDetails details);

    }
}
