﻿namespace OMF.Business.Interfaces
{
    using System.Net.Mail;
    using System.Threading.Tasks;
    using OMF.Business.Models;

    public interface IReadOutlookMailService
    {
        void ReadMails();
    }
}
