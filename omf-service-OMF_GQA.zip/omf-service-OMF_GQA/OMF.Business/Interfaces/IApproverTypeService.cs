﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IApproverTypeService
    {
        IEnumerable<ApproverTypeViewModel> GetApproverTypes();

        IEnumerable<ApproverTypeViewModel> GetActiveApproverTypes();

        ApproverTypeViewModel GetApproverTypeById(int id);

        void AddApproverType(ApproverTypeViewModel model);

        void UpdateApproverType(ApproverTypeViewModel model);

        string GetFRApproverType();
    }
}