﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IReasonForFundingReductionService
    {
        IEnumerable<ReasonForFundingReductionViewModel> GetAllReasonForFundingReductions();

        IEnumerable<ReasonForFundingReductionViewModel> GetActiveReasonForFundingReductions();

        ReasonForFundingReductionViewModel GetReasonForFundingReductionById(int id);

        void AddReasonForFundingReduction(ReasonForFundingReductionViewModel model);

        void UpdateReasonForFundingReduction(ReasonForFundingReductionViewModel model);
    }
}