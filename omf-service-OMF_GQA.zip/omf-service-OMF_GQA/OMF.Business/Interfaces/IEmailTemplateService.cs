﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IEmailTemplateService
    {
        EmailTemplateViewModel GetEmailTemplatesDetails(int templateId);

        void AddEmailTemplate(EmailTemplateViewModel emailTemplate);

        void UpdateEmailTemplate(EmailTemplateViewModel emailTemplate);

        IEnumerable<EmailTemplateViewModel> GetEmailTemplates();
    }
}
