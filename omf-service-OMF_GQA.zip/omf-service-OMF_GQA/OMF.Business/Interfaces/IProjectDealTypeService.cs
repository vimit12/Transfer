﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IProjectDealTypeService
    {
        IEnumerable<ProjectDealTypeViewModel> GetAllProjectDealTypes();

        void AddProjectDealType(ProjectDealTypeViewModel model);

        ProjectDealTypeViewModel GetProjectDealTypeById(int id);

        void UpdateProjectDealType(ProjectDealTypeViewModel model);

        IEnumerable<ProjectDealTypeViewModel> GetActiveProjectDealTypes();
    }
}