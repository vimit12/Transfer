﻿
namespace OMF.Business.Interfaces
{
    using OMF.Business.Models;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public interface IOppLeveragePercentVarianceService
    {
        void SaveOppLeverageVariance(OpportunityLeveragePercentVarianceViewModel oppLeveragePercentVarianceAssessmentViewModel);
        OpportunityLeveragePercentVarianceViewModel GetOppLeverageVarianceDetails(int opportunityId);
        ValidateVarianceDataViewModel GetLeverageConfigDetailsForOpp(int opportunityId);


    }
}
