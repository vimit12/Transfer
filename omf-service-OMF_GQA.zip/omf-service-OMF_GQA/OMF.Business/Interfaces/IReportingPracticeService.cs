﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IReportingPracticeService
    {
        IEnumerable<ReportingPracticeViewModel> GetReportingPractices();

        IEnumerable<ReportingPracticeViewModel> GetActiveReportingPractices();

        ReportingPracticeViewModel GetReportingPracticeById(int id);

        void AddReportingPractice(ReportingPracticeViewModel model);

        void UpdateReportingPractice(ReportingPracticeViewModel model);

        IEnumerable<ReportingPracticeDetailsViewModel> GetReportingPracticeDetails();
    }
}
