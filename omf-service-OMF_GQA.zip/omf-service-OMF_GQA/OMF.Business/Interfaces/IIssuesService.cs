﻿using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Interfaces
{
    public interface IIssuesService
    {
        IEnumerable<IssuesViewModel> GetAllIssues();

        IEnumerable<IssuesViewModel> GetIssueById(int issueId);

        IEnumerable<OMFSupportViewModel> GetOMFSupport();

        IEnumerable<OMFScreensViewModel> GetOMFScreens();

        string AddIssue(IssuesViewModel issuesViewModel, UserViewModel userClaims);

        string UpdateIssue(IssuesViewModel issuesViewModel, UserViewModel userClaims);

        string DeleteIssue(int issueId);

        IEnumerable<OMFSupportViewModel> GetOMFSupportForUser();

    }
}
