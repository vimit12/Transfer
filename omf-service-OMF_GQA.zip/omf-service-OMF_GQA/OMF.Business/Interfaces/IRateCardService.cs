﻿namespace OMF.Business.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using OMF.Business.Models;

    public interface IRateCardService
    {
        List<WLRateCardViewModel> GetBillRate(CurrencyRateViewModel currencyRate);

        List<WLRateCardViewModel> GetWLRateCard(CurrencyRateViewModel currencyRate);

        void UpdateStandardCost(IEnumerable<StandardCostViewModel> rateCardViews);

        IEnumerable<CommentsSummaryViewModel> GetCommentsSummary(RateCardCommentsViewModel comments);

        List<RateCardByOpportunityViewModel> GetRateCardByOpportunity(DefaultRateCardInputViewModel currencyRate);

        void AddRateCardByOpportunity(RateCardForWorkLocationsViewModel rateCardForWork);

        void UpdateRateCardByOpportunity(List<RateCardByOpportunityViewModel> rateCardForWork);

        RateCardViewModel GetActualBillingCost(int resourceRoleId, int workLocationId, int baseCurrencyId, int yearId);

        byte[] ExtractRateCardByYear(int yearId);

        List<FinancialOpportunityPGMTargetPercentByYearViewModel> GetPGMTargetPercentagesForOpportunityAndYear(int opportunityId, int yearId);

        void SaveOrUpdatePGMTargetPercentages(IList<FinancialOpportunityPGMTargetPercentByYearViewModel> financialOpportunityPGMTargetPercentByYearViewModels);

    }
}
