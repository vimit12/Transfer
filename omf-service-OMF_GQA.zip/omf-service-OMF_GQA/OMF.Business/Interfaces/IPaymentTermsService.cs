﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IPaymentTermsService
    {
        IEnumerable<PaymentTermsViewModel> GetAllPaymentTerms();

        PaymentTermsViewModel GetPaymentTermById(int id);

        void AddPaymentTerms(PaymentTermsViewModel model);

        void UpdatePaymentTerms(PaymentTermsViewModel model);

        IEnumerable<PaymentTermsViewModel> GetActivePaymentTerms();
    }
}