﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;
    using OMF.Data.Models;

    public interface IWorkflowService
    {
        OpportunityBasicDetailsViewModel UpdateNextStatus(WorkFlowActionViewModel workFlowActionViewModel);

        IEnumerable<StatusActionViewModel> GetWorkFlowActionsByStatus(WorkFlowActionsViewModel workFlowActionsViewModel);

        int AddCommentsByUser(EmailCommentsByUserViewModel emailComments);

        void ShareSimulation(ShareSimulationViewModel shareSimulationView);

        void AddJourney(int id, int statusId, string createdBy);

        void SendPaymentTermNotification(WorkFlowActionViewModel workFlowActionViewModel);

        void SetOpportunityAsLost(int oppId);

        void SetNoSaleOpportunity(int oppId);

        int SendORBCategory1Notification(WorkFlowActionViewModel workFlowActionViewModel);

        List<CommentsDetailsViewModel> GetCommentsForOpportunity(int opportunityId, int screenId);

        void SetDuplicateOpportunity(int oppId);

        List<ApproverViewModel> GetApproversForWorkLocations(int opportunityId);

        WorkFlow CheckWorkFlowAutoProgressPossibility(int opportunityId);

        OpportunityBasicDetailsViewModel WorkFlowAutoProgress(int opportunityId);

        IEnumerable<OpportunityWorkLocationWorkfFlowBasicDetailsViewModel> GetStatusOfWL(int opportunityId);

        InfoFinancialSummaryViewModel GetProposalFinancialSummaryDetails(int opportunityId, int yearId);

        void SendIFRSUserAssignedNotification(OpportunityComplianceUserMappingViewModel model);

        void SendMailFromSmtp(int opportunityId, int statusId, int reminderOrEscalation);

        IEnumerable<StatusActionViewModel> GetFRWorkFlowActionsByStatus(FRWorkFlowActionsViewModel workFlowActionsViewModel);

        FRBasicDetailsViewModel UpdateFRNextStatus(FRWorkFlowActionViewModel workFlowActionViewModel);

        List<FundingReductionCommentsDetailsViewModel> GetCommentsForFundingReduction(int fundingReductionId);

        ValidateRourceLocationViewModel ValidateResourceWorkLocation(int opportunityId);

        ValidateDataViewModel ValidateOICAndPMForOpportunity(int opportunityId);

        ValidateDataViewModel ValidateOpportunityPaymentTerms(int opportunityId);
    }
}
