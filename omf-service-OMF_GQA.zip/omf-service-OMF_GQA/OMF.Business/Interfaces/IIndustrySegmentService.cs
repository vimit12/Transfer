﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IIndustrySegmentService
    {
        IEnumerable<IndustrySegmentViewModel> GetAllIndustrySegments();

        void AddIndustrySegment(IndustrySegmentViewModel model);

        IndustrySegmentViewModel GetIndustrySegmentById(int id);

        void UpdateIndustrySegment(IndustrySegmentViewModel model);

        IEnumerable<IndustrySegmentViewModel> GetActiveIndustrySegments();

        IEnumerable<IndustrySegmentViewModel> GetAllIndustrySegmentsWithSubSegments();
    }
}
