﻿
namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;
    public interface ILeveragePercentageConfigurationService
    {
        void SaveLeverageVariance(LeveragePercentageConfigurationViewModel leveragePercentConfigurationAssessmentViewModel);
        IEnumerable<LeveragePercentageConfigurationViewModel> GetLeverageVarianceConfigDetails();

        ValidateDataViewModel ValidateVariancePercentageByOppId(int opportunityId,int screenId);
    }
}
