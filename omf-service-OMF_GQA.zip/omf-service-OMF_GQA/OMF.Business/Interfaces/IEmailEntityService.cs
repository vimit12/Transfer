﻿namespace OMF.Business.Interfaces
{
    using System;
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IEmailEntityService
    {
        IEnumerable<EmailEntityViewModel> GetAllEmailEntities();

        IEnumerable<EmailEntityViewModel> GetActiveEmailEntities();

        EmailEntityViewModel GetEmailEntityById(int id);

        void AddEmailEntity(EmailEntityViewModel model);

        void UpdateEmailEntity(EmailEntityViewModel model);

        void UpdateDatesRemovingWeekEnds();
    }
}