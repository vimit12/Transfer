﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface INextStatusActionByStatusTypeMappingService
    {
        IEnumerable<NextStatusActionByStatusTypeMappingViewModel> GetAllNextStatusActions();

        IEnumerable<NextStatusActionByStatusTypeMappingViewModel> GetActiveNextStatusActions(int opportunityId);

        void AddNextStatusAction(NextStatusActionByStatusTypeMappingViewModel model);
    }
}
