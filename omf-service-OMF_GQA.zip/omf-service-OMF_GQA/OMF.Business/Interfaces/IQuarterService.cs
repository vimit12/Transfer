﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IQuarterService
    {
        IEnumerable<QuarterViewModel> GetAllQuarters();

        QuarterViewModel GetQuarterById(int id);

        int GetCurrentQuarter();
    }
}