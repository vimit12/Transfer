﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IScreenActionsByRoleService
    {
        IEnumerable<RoleScreenActionsViewModel> GetAllScreenActionsByRole();

        IEnumerable<OMFScreensViewModel> GetActionOMFScreens();

        IEnumerable<ScreenActionsViewModel> GetActiveScreenActions();

        RoleScreenActionsViewModel GetScreenActionsByScreenIdRoleId(RoleScreenActionsViewModel roleScreenActionsView);

        void ModifyRoleScreenActions(RoleScreenActionsViewModel roleScreenActionsView);

        bool ValidateRoleScreen(RoleScreenActionsViewModel roleScreenActionsView, out string errorMessage);
    }
}
