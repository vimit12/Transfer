﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class CurrencyAPITests : UnitTestBase
    {
        private static CurrencyController currencyController;
        private static CurrencyService countryService;
        private static CurrencyViewModel currencyViewModel;
        private static Mock<ILogger<CurrencyController>> logger;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            countryService = new CurrencyService(Repository, Mapper);
            logger = new Mock<ILogger<CurrencyController>>();
            currencyController = new CurrencyController(countryService, logger.Object);
            currencyController = new CurrencyController(countryService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
            PrepareTestDataForUpdate();
        }

        /// <summary>
        /// Unit Test for getting all currencies
        /// </summary>
        [TestMethod]
        public void GetActiveCurrencies()
        {
            var getCurrencies = currencyController.GetActiveCurrencies();
            Assert.IsNotNull(getCurrencies);

            var result = (OkObjectResult)getCurrencies;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        /// <summary>
        /// Unit Test Method to Add the currency
        /// </summary>
        [TestMethod]
        public void AddCurrency()
        {
            currencyViewModel = new CurrencyViewModel
            {
                CurrencyCode = "AUS",
                IsActive = true,
                Comments = "Comments for Asutralia",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                CurrencyId = 3
            };

            var createdCurrency = currencyController.AddCurrency(currencyViewModel);
            Assert.IsNotNull(createdCurrency);

            var result = (OkObjectResult)createdCurrency;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getCurrencies = currencyController.GetActiveCurrencies();
            Assert.IsNotNull(getCurrencies);

            var getResult = (OkObjectResult)getCurrencies;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var currencyList = (List<CurrencyViewModel>)getResponse.Result;
            Assert.IsTrue(currencyList.Any(e => e.CurrencyCode == currencyViewModel.CurrencyCode));
        }

        /// <summary>
        /// Unit Test Method for Updating Currency
        /// </summary>
        [TestMethod]
        public void UpdateCurrency()
        {
            var currencyUpdate = Repository.Repository<Currency>().GetAll().FirstOrDefault();
            CurrencyViewModel currencyModel =  Mapper.Map<Currency, CurrencyViewModel>(currencyUpdate);

            currencyModel.CurrencyCode = "BNG";
            var editCurrency = currencyController.UpdateCurrency(currencyModel);
            Assert.IsNotNull(editCurrency);

            var result = (OkObjectResult)editCurrency;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getCurrency = currencyController.GetCurrencyById(currencyUpdate.CurrencyId);
            Assert.IsNotNull(getCurrency);

            var getResult = (OkObjectResult)getCurrency;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var currency = (CurrencyViewModel)getResponse.Result;
            Assert.IsTrue(currency.CurrencyCode == currency.CurrencyCode);
        }

        [TestMethod]
        public void GetAllCurrencies()
        {
            var getCurrencies = currencyController.GetAllCurrencies();
            Assert.IsNotNull(getCurrencies);

            var result = (OkObjectResult)getCurrencies;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetCurrencyById()
        {
            var getCurrencies = currencyController.GetCurrencyById(1);
            Assert.IsNotNull(getCurrencies);

            var result = (OkObjectResult)getCurrencies;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        /// <summary>
        /// Procedure to create test data
        /// </summary>
        private static void PrepareTestDataForUpdate()
        {
            Repository.Repository<Currency>().DeleteRange(Repository.Repository<Currency>().GetAll());
            Repository.SaveChanges();

            var currencyList = new List<Currency>()
            {
                new Currency() { CurrencyId = 1, CurrencyCode = "USD", Comments = "USD Comments", CreatedBy = "nbhat", CreatedDate = DateTime.Now },
                new Currency() { CurrencyId = 2, CurrencyCode = "INR", Comments = "INR Comments", CreatedBy = "nbhat", CreatedDate = DateTime.Now }
            };
            Repository.Repository<Currency>().AddRange(currencyList);
            Repository.SaveChanges();
        }

    }
}
