﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class ApproverByRegionServiceAPITest : UnitTestBase
    {
        private static ApproverByRegionController ApproverByRegionController;
        private static ApproverByRegionService ApproverByRegionService;
        private static ApproverByRegionViewModel ApproverByRegionViewModel;
        private static ApproverByRegionAndLineOfBusinessService ApproverByRegionAndLineOfBusinessService;
        private static Mock<ILogger<ApproverByRegionController>> Logger;
        private List<ApproverByRegionViewModel> approverByRegionViewModelList = new List<ApproverByRegionViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            ApproverByRegionService = new ApproverByRegionService(Repository, Mapper);
            ApproverByRegionAndLineOfBusinessService = new ApproverByRegionAndLineOfBusinessService(Repository, Mapper);
            Logger = new Mock<ILogger<ApproverByRegionController>>();
            ApproverByRegionController = new ApproverByRegionController(ApproverByRegionService, Logger.Object, ApproverByRegionAndLineOfBusinessService);
            Repository.Repository<ApproverByRegion>().DeleteRange(Repository.Repository<ApproverByRegion>().GetAll());

            ApproverByRegionController = new ApproverByRegionController(ApproverByRegionService, Logger.Object, ApproverByRegionAndLineOfBusinessService)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            ApproverByRegionViewModel = new ApproverByRegionViewModel
            {
                ApproverByRegionId = new Random().Next(1, randomInterval),
                RegionId = 1,
                IsActive = true,
                Comments = "Service Test",
                ApproverTypeId = 1
            };

            ApproverByRegionViewModel.Approvers = new List<ApproverByRegionMappingViewModel>() { new ApproverByRegionMappingViewModel { UserRoleId = 1 } };

            var result = ApproverByRegionController.AddApproverByRegion(ApproverByRegionViewModel);
            approverByRegionViewModelList.Add(ApproverByRegionViewModel);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            ApproverByRegionViewModel = null;
            approverByRegionViewModelList = null;
        }

        [TestMethod]
        public void GetCapabilitySubCapabilities()
        {
            var approversByRegion = ApproverByRegionController.GetApproversByRegion();
            Assert.IsNotNull(approversByRegion);

            var result = (OkObjectResult)approversByRegion;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddApproverByRegion()
        {
            ApproverByRegionViewModel = new ApproverByRegionViewModel
            {
                ApproverByRegionId = new Random().Next(1, randomInterval),
                RegionId = 1,
                IsActive = true,
                Comments = "Service Test",
                ApproverTypeId = 1
            };

            ApproverByRegionViewModel.Approvers = new List<ApproverByRegionMappingViewModel>() { new ApproverByRegionMappingViewModel { UserRoleId = 1 } };

            var createdApprByRegion = ApproverByRegionController.AddApproverByRegion(ApproverByRegionViewModel);
            Assert.IsNotNull(createdApprByRegion);

            var result = (OkObjectResult)createdApprByRegion;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void UpdateApproverByRegion()
        {
            var approverByRegion = approverByRegionViewModelList.FirstOrDefault();
            approverByRegion.Comments = "Update Test";
            approverByRegion.RegionId = 2;

            var editApprByRegion = ApproverByRegionController.UpdateApproverByRegion(approverByRegion);
            Assert.IsNotNull(editApprByRegion);

            var result = (OkObjectResult)editApprByRegion;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}