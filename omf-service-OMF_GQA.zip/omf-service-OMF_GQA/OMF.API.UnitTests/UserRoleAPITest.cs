﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class UserRoleAPITest : UnitTestBase
    {
        public static UserRoleController UserRoleController;
        public static UserRoleService UserRoleService;
        public static Mock<ILogger<UserRoleController>> logger;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            UserRoleService = new UserRoleService(Repository, Mapper, HttpContextAccessor);
            logger = new Mock<ILogger<UserRoleController>>();
            UserRoleController = new UserRoleController(UserRoleService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            prepareData();
        }

        [TestMethod]
        public void GetStatusActions()
        {
            var getStatusActions = UserRoleController.GetUserRoles();
            Assert.IsNotNull(getStatusActions);

            var result = (OkObjectResult)getStatusActions;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var viewModel = (IEnumerable<UserRoleViewModel>)response.Result;
            Assert.IsTrue(viewModel.Any(x => x.RoleId == 1));
        }

        private void prepareData()
        {
            var roleModel = new Role
            {
                RoleId = 1,
                RoleName = "Test Role",
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
            };

            Repository.Repository<Role>().DeleteRange(Repository.Repository<Role>().GetAll());
            Repository.Repository<Role>().Add(roleModel);
            Repository.SaveChanges();

            var userRoleModel = new UserRole
            {
                UserRoleId = 1,
                RoleId = 1,
                FirstName = "TFName",
                LastName = "TLName",
                UserEmail = "test@test.com",
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                UserId = "Test User",

            };

            Repository.Repository<UserRole>().DeleteRange(Repository.Repository<UserRole>().GetAll());
            Repository.Repository<UserRole>().Add(userRoleModel);
            Repository.SaveChanges();
        }
    }
}
