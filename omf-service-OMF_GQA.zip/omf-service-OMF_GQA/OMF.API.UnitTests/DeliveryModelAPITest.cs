﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class DeliveryModelAPITest : UnitTestBase
    {
        private static DeliveryModelController deliveryModelController;
        private static DeliveryModelService deliveryModelService;
        private static DeliveryModelViewModel deliveryModelViewModel;
        private static Mock<ILogger<DeliveryModelController>> logger;
        private List<DeliveryModelViewModel> deliveryModelList = new List<DeliveryModelViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            deliveryModelService = new DeliveryModelService(Repository, Mapper);
            logger = new Mock<ILogger<DeliveryModelController>>();
            deliveryModelController = new DeliveryModelController(deliveryModelService, logger.Object);
            Repository.Repository<DeliveryModel>().DeleteRange(Repository.Repository<DeliveryModel>().GetAll());

            deliveryModelController = new DeliveryModelController(deliveryModelService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getDeliveryModel = deliveryModelController.GetAllDeliveryModels();
            Assert.IsNotNull(getDeliveryModel);

            var result = (OkObjectResult)getDeliveryModel;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<DeliveryModelViewModel>)response.Result;

            if (getData.Count > 0)
            {
                deliveryModelList = getData;
            }
            else
            {
                deliveryModelViewModel = new DeliveryModelViewModel
                {
                    DeliveryModelId = new Random().Next(1, randomInterval),
                    DeliveryModelName = "TESTAPI",
                    IsActive = true,
                    Comments = "TestComment"
                };

                var deliveryModel = deliveryModelController.AddDeliveryModel(deliveryModelViewModel);
                deliveryModelList.Add(deliveryModelViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            deliveryModelViewModel = null;
            deliveryModelList = null;
        }

        [TestMethod]
        public void GetAllDeliveryModel()
        {
            var getDeliveryModel = deliveryModelController.GetAllDeliveryModels();
            Assert.IsNotNull(getDeliveryModel);

            var result = (OkObjectResult)getDeliveryModel;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetDeliveryModelById()
        {
            var getDeliveryModel = deliveryModelController.GetDeliveryModelById(deliveryModelList.FirstOrDefault().DeliveryModelId);
            Assert.IsNotNull(getDeliveryModel);

            var result = (OkObjectResult)getDeliveryModel;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddDeliveryModel()
        {
            deliveryModelViewModel = new DeliveryModelViewModel
            {
                DeliveryModelId = new Random().Next(1, randomInterval),
                DeliveryModelName = "TESTAPI",
                TargetMargin = 10,
                IsActive = true,
                Comments = "TestComment"
            };

            var createdDeliveryModel = deliveryModelController.AddDeliveryModel(deliveryModelViewModel);
            Assert.IsNotNull(createdDeliveryModel);

            var result = (OkObjectResult)createdDeliveryModel;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getDeliveryModel = deliveryModelController.GetAllDeliveryModels();
            Assert.IsNotNull(getDeliveryModel);

            var getResult = (OkObjectResult)getDeliveryModel;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var deliveryModelList = (List<DeliveryModelViewModel>)getResponse.Result;
            Assert.IsTrue(deliveryModelList.Any(e => e.DeliveryModelName == deliveryModelViewModel.DeliveryModelName));
        }

        [TestMethod]
        public void UpdateDeliveryModel()
        {
            var deliveryModelUpdate = deliveryModelList.FirstOrDefault();
            deliveryModelUpdate.DeliveryModelName = "TESTAPI";

            var editDeliveryModel = deliveryModelController.UpdateDeliveryModel(deliveryModelUpdate);
            Assert.IsNotNull(editDeliveryModel);

            var result = (OkObjectResult)editDeliveryModel;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getDeliveryModel = deliveryModelController.GetDeliveryModelById(deliveryModelUpdate.DeliveryModelId);
            Assert.IsNotNull(getDeliveryModel);

            var getResult = (OkObjectResult)getDeliveryModel;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var deliveryModel = (DeliveryModelViewModel)getResponse.Result;
            Assert.IsTrue(deliveryModelUpdate.DeliveryModelName == deliveryModel.DeliveryModelName);
        }


        [TestMethod]
        public void GetActiveDeliveryModels()
        {
            var getDeliveryModel = deliveryModelController.GetActiveDeliveryModels();
            Assert.IsNotNull(getDeliveryModel);

            var result = (OkObjectResult)getDeliveryModel;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}