﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class YearAPITest : UnitTestBase
    {
        private static YearController yearController;
        private static YearService yearService;
        private static YearViewModel yearViewModel;
        private static Mock<ILogger<YearController>> logger;
        private List<YearViewModel> yearList = new List<YearViewModel>();
        private int randomInterval = 100000;
        private static OpportunityAPITest oppTest;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            yearService = new YearService(Repository, Mapper);
            logger = new Mock<ILogger<YearController>>();
            yearController = new YearController(yearService, logger.Object);
            Repository.Repository<CAYear>().DeleteRange(Repository.Repository<CAYear>().GetAll());

            yearController = new YearController(yearService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };

            oppTest = new OpportunityAPITest();
            OpportunityAPITest.ClassInitialize(context);
        }

        [TestInitialize]
        public void TestInitialize()
        {
            oppTest.TestInitialize();
            var getYears = yearController.GetAllYears();
            Assert.IsNotNull(getYears);

            var result = (OkObjectResult)getYears;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<YearViewModel>)response.Result;

            if (getData.Count > 0)
            {
                yearList = getData;
            }
            else
            {
                yearViewModel = new YearViewModel
                {
                    YearId= new Random().Next(1, randomInterval),
                    Year = 2035,
                    IsActive = true,
                    Comments= "TestComment"
                };

                var year = yearController.AddYear(yearViewModel);
                yearList.Add(yearViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            yearViewModel = null;
            yearList = null;
        }

       [TestMethod]
        public void GetAllYears()
        {
            var getYears = yearController.GetAllYears();
            Assert.IsNotNull(getYears);

            var result = (OkObjectResult)getYears;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetYearById()
        {
            var getYear = yearController.GetYearById(yearList.FirstOrDefault().YearId);
            Assert.IsNotNull(getYear);

            var result = (OkObjectResult)getYear;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetYearByOrder()
        {
            string operatr = "GTOET";
            string order = "Asc";
            var getYear = yearController.GetYearByOrder(operatr , order);
            Assert.IsNotNull(getYear);

            var result = (OkObjectResult)getYear;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddYear()
        {
            yearViewModel = new YearViewModel
            {
                YearId = new Random().Next(1, randomInterval),
                Year = 2050,
                IsActive = true,
                Comments = "TestComment"
            };

            var createdYear = yearController.AddYear(yearViewModel);
            Assert.IsNotNull(createdYear);

            var result = (OkObjectResult)createdYear;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getYears = yearController.GetAllYears();
            Assert.IsNotNull(getYears);

            var getResult = (OkObjectResult)getYears;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var yearList = (List<YearViewModel>)getResponse.Result;
            Assert.IsTrue(yearList.Any(e => e.Year == yearViewModel.Year));
        }

        [TestMethod]
        public void UpdateYear()
        {
            var yearUpdate = yearList.FirstOrDefault();
            yearUpdate.Year = 2050;

            var editYear = yearController.UpdateYear(yearUpdate);
            Assert.IsNotNull(editYear);

            var result = (OkObjectResult)editYear;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getYear = yearController.GetYearById(yearUpdate.YearId);
            Assert.IsNotNull(getYear);

            var getResult = (OkObjectResult)getYear;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var year = (YearViewModel)getResponse.Result;
            Assert.IsTrue(yearUpdate.Year== year.Year);
        }

        [TestMethod]
        public void GetAllYearByOrder()
        {
            string operatr = "GTOET";
            string order = "Asc";
            var getYear = yearController.GetAllYearsByOrder(operatr, order);
            Assert.IsNotNull(getYear);

            var result = (OkObjectResult)getYear;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetFinancialYearsByopprtunityId()
        {
            oppTest.SaveInfoCompliance();
            var opp = Repository.Repository<Opportunity>().GetAll().FirstOrDefault().OpportunityId;
            var result = yearController.GetFinancialYearsByopprtunityId(opp);
            Assert.IsNotNull(result);

            var year = (OkObjectResult)result;
            Assert.AreEqual(200, year.StatusCode);

            var response = (ApiOkResponse)year.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}