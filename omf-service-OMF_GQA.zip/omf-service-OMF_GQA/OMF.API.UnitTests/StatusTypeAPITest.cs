﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class StatusTypeAPITest : UnitTestBase
    {
        private static StatusTypeController statusTypeController;
        private static StatusTypeService statusTypeService;
        private static StatusTypeViewModel statusTypeViewModel;
        private static Mock<ILogger<StatusTypeController>> logger;
        private List<StatusTypeViewModel> statusTypeList = new List<StatusTypeViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            statusTypeService = new StatusTypeService(Repository, Mapper);
            logger = new Mock<ILogger<StatusTypeController>>();
            statusTypeController = new StatusTypeController(statusTypeService, logger.Object);
            Repository.Repository<StatusType>().DeleteRange(Repository.Repository<StatusType>().GetAll());

            statusTypeController = new StatusTypeController(statusTypeService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getStatusTypes = statusTypeController.GetAllStatusTypes();
            Assert.IsNotNull(getStatusTypes);

            var result = (OkObjectResult)getStatusTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<StatusTypeViewModel>)response.Result;

            if (getData.Count > 0)
            {
                statusTypeList = getData;
            }
            else
            {
                statusTypeViewModel = new StatusTypeViewModel
                {
                    StatusId = new Random().Next(1, randomInterval),
                    Status = "TESTAPI",
                    IsActive = true,
                    Comments = "TestComment",
                };

                var statusType = statusTypeController.AddStatusType(statusTypeViewModel);
                statusTypeList.Add(statusTypeViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            statusTypeViewModel = null;
            statusTypeList = null;
        }

        [TestMethod]
        public void GetAllStatusTypes()
        {
            var getStatusTypes = statusTypeController.GetAllStatusTypes();
            Assert.IsNotNull(getStatusTypes);

            var result = (OkObjectResult)getStatusTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetStatusTypeById()
        {
            var getStatusType = statusTypeController.GetStatusTypeById(statusTypeList.FirstOrDefault().StatusId);
            Assert.IsNotNull(getStatusType);

            var result = (OkObjectResult)getStatusType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddStatusType()
        {
            statusTypeViewModel = new StatusTypeViewModel
            {
                StatusId = new Random().Next(1, randomInterval),
                Status = "TESTAPI",
                IsActive = true,
                Comments = "TestComment",
            };

            var createdStatusType = statusTypeController.AddStatusType(statusTypeViewModel);
            Assert.IsNotNull(createdStatusType);

            var result = (OkObjectResult)createdStatusType;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getStatusTypes = statusTypeController.GetAllStatusTypes();
            Assert.IsNotNull(getStatusTypes);

            var getResult = (OkObjectResult)getStatusTypes;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var statusTypeList = (List<StatusTypeViewModel>)getResponse.Result;
            Assert.IsTrue(statusTypeList.Any(e => e.Status == statusTypeViewModel.Status));
        }

        [TestMethod]
        public void UpdateStatusType()
        {
            var statusTypeUpdate = statusTypeList.FirstOrDefault();
            statusTypeUpdate.Status = "TESTAPI";

            var editStatusType = statusTypeController.UpdateStatusType(statusTypeUpdate);
            Assert.IsNotNull(editStatusType);

            var result = (OkObjectResult)editStatusType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getStatusType = statusTypeController.GetStatusTypeById(statusTypeUpdate.StatusId);
            Assert.IsNotNull(getStatusType);

            var getResult = (OkObjectResult)getStatusType;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var statusType = (StatusTypeViewModel)getResponse.Result;
            Assert.IsTrue(statusTypeUpdate.Status == statusType.Status);
        }

        [TestMethod]
        public void GetActiveStatusTypes()
        {
            var getStatusTypes = statusTypeController.GetActiveStatusTypes();
            Assert.IsNotNull(getStatusTypes);

            var result = (OkObjectResult)getStatusTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}
