﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class ContractFinancialSectionsMappingAPITest : UnitTestBase
    {
        private static ContractFinancialSectionsMappingController contractFinancialSectionsMappingController;
        private static ContractFinancialSectionsMappingService contractFinancialSectionsMappingService;
        private static Mock<ILogger<ContractFinancialSectionsMappingController>> logger;
        private static IncludeSectionByContractTypeViewModel viewModel;

        [ClassInitialize]
        public static void ClassInitiailize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            contractFinancialSectionsMappingService = new ContractFinancialSectionsMappingService(Repository, Mapper);
            logger = new Mock<ILogger<ContractFinancialSectionsMappingController>>();
            contractFinancialSectionsMappingController = new ContractFinancialSectionsMappingController(contractFinancialSectionsMappingService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            prepareData();
        }

        [TestMethod]
        public void GetAllContractFinancialSections()
        {
            var getAllContractFinancialSections = contractFinancialSectionsMappingController.GetAllContractFinancialSections();
            Assert.IsNotNull(getAllContractFinancialSections);

            var result = (OkObjectResult)getAllContractFinancialSections;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var model = (List<IncludeSectionByContractTypeViewModel>)response.Result;
            Assert.IsTrue(model.Any(x => x.IncludeSectionByContractTypeId == 1));
        }

        [TestMethod]
        public void AddContractFinancialSection()
        {
            var getAllContractFinancialSections = contractFinancialSectionsMappingController.GetAllContractFinancialSections();
            Assert.IsNotNull(getAllContractFinancialSections);

            var result = (OkObjectResult)getAllContractFinancialSections;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var model = (List<IncludeSectionByContractTypeViewModel>)response.Result;
            Assert.IsTrue(model.Any(x => x.IncludeSectionByContractTypeId == 1));

            var viewModel = model.First();
            viewModel.IncludeSectionByContractTypeId = 0;
            viewModel.SectionId = 2;
            var temp = new OmfFinancialSections()
            {
                SectionId = 2,
                SectionName = "Test Section 2",
                CreatedDate = DateTime.Now,
                CreatedBy = "nbhat",
                IsActive = true
            };
            //viewModel.Sections = Mapper.Map<OmfFinancialSections, OmfFinancialSectionsViewModel>(temp) as IEnumerable<OmfFinancialSectionsViewModel>;
            var tempMap = Mapper.Map<OmfFinancialSections, OmfFinancialSectionsViewModel>(temp);
            IEnumerable<OmfFinancialSectionsViewModel> sections = new List<OmfFinancialSectionsViewModel>().ToList();
            sections.Append(tempMap);
            viewModel.Sections = sections;



            var add = contractFinancialSectionsMappingController.AddContractFinancialSection(viewModel);
            Assert.IsNotNull(add);

            var addResult = (OkObjectResult)add;
            var addResponse = (ApiOkResponse)addResult.Value;
            Assert.IsNotNull(addResponse);

            var addModel = (IncludeSectionByContractTypeViewModel)addResponse.Result;
            Assert.AreEqual(2, addModel.SectionId);
        }

        private void prepareData()
        {
            var contractModel = new ContractType
            {
                ContractTypeId = 1,
                ContractTypeName = "Test contract",
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                
            };
            Repository.Repository<ContractType>().DeleteRange(Repository.Repository<ContractType>().GetAll());
            Repository.Repository<ContractType>().Add(contractModel);
            Repository.SaveChanges();

            var sectionModel = new List<OmfFinancialSections>
            {
                new OmfFinancialSections(){
                SectionId = 1,
                SectionName = "Test Section",
                CreatedDate = DateTime.Now,
                CreatedBy = "nbhat",
                IsActive = true
                },
                new OmfFinancialSections()
                {
                    SectionId = 2,
                SectionName = "Test Section 2",
                CreatedDate = DateTime.Now,
                CreatedBy = "nbhat",
                IsActive = true
                }
            };
            Repository.Repository<OmfFinancialSections>().DeleteRange(Repository.Repository<OmfFinancialSections>().GetAll());
            Repository.Repository<OmfFinancialSections>().AddRange(sectionModel);
            Repository.SaveChanges();

            var mappingModel = new IncludeSectionByContractType
            {
                ContractTypeId = 1,
                SectionId = 1,
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IncludeSectionByContractTypeId = 1,

            };
            Repository.Repository<IncludeSectionByContractType>().DeleteRange(Repository.Repository<IncludeSectionByContractType>().GetAll());
            Repository.Repository<IncludeSectionByContractType>().Add(mappingModel);
            Repository.SaveChanges();
        }
    }
}
