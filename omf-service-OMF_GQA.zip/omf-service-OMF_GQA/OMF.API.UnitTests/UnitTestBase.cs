﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using OMF.Business.Interfaces;
using OMF.Business.Models;
using OMF.Data.Models;
using OMF.Data.Repository;

namespace OMF.API.UnitTests
{
    public class UnitTestBase
    {
        public static OMFContext OmfContext;

        public static Uow Repository;

        public static IMapper Mapper;

        public static ICountryService CountryService;

        public static ClaimsPrincipal User;

        public static IHttpContextAccessor HttpContextAccessor;

        public Opportunity opportunity;

        private static int randomInterval = 100000;

        public UnitTestBase()
        {
            var builder = new DbContextOptionsBuilder<OMFContext>();
            builder.UseInMemoryDatabase("OMFTestDataBase");

            OmfContext = new OMFContext(builder.Options);

            Repository = new Uow(OmfContext);

            HttpContextAccessor = new HttpContextAccessor();

            User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
             {
                 new Claim("Alias", "AliasUser"),
                 new Claim ("Role", "Test Role")
             }));

            //HttpContextAccessor.HttpContext.User = User;
            

            var config = new MapperConfiguration(e =>

            {
                // Country
                e.CreateMap<Country, CountryViewModel>();
                e.CreateMap<CountryViewModel, Country>();

                // Capability
                e.CreateMap<Capability, CapabilityViewModel>();
                e.CreateMap<CapabilityViewModel, Capability>();

                // Sub Capability
                e.CreateMap<SubCapability, SubCapabilityViewModel>();
                e.CreateMap<SubCapabilityViewModel, SubCapability>();

                // Approver By Region
                e.CreateMap<ApproverByRegion, ApproverByRegionViewModel>();
                e.CreateMap<ApproverByRegionViewModel, ApproverByRegion>();

                // Approver By Region Mapping
                e.CreateMap<ApproverByRegionMapping, ApproverByRegionMappingViewModel>();
                e.CreateMap<ApproverByRegionMappingViewModel, ApproverByRegionMapping>();

                // Approver By Country
                e.CreateMap<ApproverByCountry, ApproverByCountryViewModel>();
                e.CreateMap<ApproverByCountryViewModel, ApproverByCountry>();

                // Approver By Country Mapping
                e.CreateMap<ApproverByCountryMapping, ApproverByCountryMappingViewModel>();
                e.CreateMap<ApproverByCountryMappingViewModel, ApproverByCountryMapping>();

                // CapabilitySubCapability Mapping
                e.CreateMap<CapabilitySubCapabilityMapping, CapabilitySubCapabilityMappingViewModel>();
                e.CreateMap<CapabilitySubCapabilityMappingViewModel, CapabilitySubCapabilityMapping>();

                // Year
                e.CreateMap<CAYear, YearViewModel>();
                e.CreateMap<YearViewModel, CAYear>();

                // Contract Type
                e.CreateMap<ContractType, ContractTypeViewModel>();
                e.CreateMap<ContractTypeViewModel, ContractType>();

                // TaxRate
                e.CreateMap<TaxRate, TaxRateViewModel>();
                e.CreateMap<TaxRateViewModel, TaxRate>();

                // Currency
                e.CreateMap<Currency, CurrencyViewModel>();
                e.CreateMap<CurrencyViewModel, Currency>();

                // Quarter
                e.CreateMap<Quarter, QuarterViewModel>();
                e.CreateMap<QuarterViewModel, Quarter>();

                // Employee type
                e.CreateMap<EmployeeType, EmployeeTypeViewModel>();
                e.CreateMap<EmployeeTypeViewModel, EmployeeType>();

                // Industry Segment
                e.CreateMap<IndustrySegment, IndustrySegmentViewModel>();
                e.CreateMap<IndustrySegmentViewModel, IndustrySegment>();

                // Industry Sub Segment
                e.CreateMap<IndustrySubSegment, IndustrySubSegmentViewModel>();
                e.CreateMap<IndustrySubSegmentViewModel, IndustrySubSegment>();

                // Rate Card StandardCostViewModel
                e.CreateMap<RateCard, StandardCostViewModel>();
                e.CreateMap<StandardCostViewModel, RateCard>();

                // FxRate
                e.CreateMap<FxRate, FxRateViewModel>();
                e.CreateMap<FxRateViewModel, FxRate>();

                // Industry Segment Sub Segment Mapping
                e.CreateMap<IndustrySegmentSubSegmentMapping, IndustrySegmentSubSegmentMappingViewModel>();
                e.CreateMap<IndustrySegmentSubSegmentMappingViewModel, IndustrySegmentSubSegmentMapping>();

                // Project Organization
                e.CreateMap<ProjectOrganization, ProjectOrganizationViewModel>();
                e.CreateMap<ProjectOrganizationViewModel, ProjectOrganization>();

                // WorkLocation
                e.CreateMap<WorkLocation, WorkLocationViewModel>();
                e.CreateMap<WorkLocationViewModel, WorkLocation>();

                // WorkLocationResourceRoleMapping
                e.CreateMap<WorkLocationResourceRoleMapping, WorkLocationResourceRoleMappingViewModel>();
                e.CreateMap<WorkLocationResourceRoleMappingViewModel, WorkLocationResourceRoleMapping>();

                // Reporting Practice
                e.CreateMap<ReportingPractice, ReportingPracticeViewModel>();
                e.CreateMap<ReportingPracticeViewModel, ReportingPractice>();

                // ProjectOrganizationReportingPractice Mapping
                e.CreateMap<ProjectOrganizationReportingPracticeMapping, ProjectOrganizationReportingPracticeMappingViewModel>();
                e.CreateMap<ProjectOrganizationReportingPracticeMappingViewModel, ProjectOrganizationReportingPracticeMapping>();

                // Region
                e.CreateMap<Region, RegionViewModel>();
                e.CreateMap<RegionViewModel, Region>();

                // Global Solution
                e.CreateMap<GlobalSolution, GlobalSolutionViewModel>();
                e.CreateMap<GlobalSolutionViewModel, GlobalSolution>();

                // Delivery Model
                e.CreateMap<DeliveryModel, DeliveryModelViewModel>();
                e.CreateMap<DeliveryModelViewModel, DeliveryModel>();

                // Project Domain
                e.CreateMap<ProjectDomain, ProjectDomainViewModel>();
                e.CreateMap<ProjectDomainViewModel, ProjectDomain>();

                // Payment Terms
                e.CreateMap<PaymentTerms, PaymentTermsViewModel>();
                e.CreateMap<PaymentTermsViewModel, PaymentTerms>();

                // Role
                e.CreateMap<Role, RoleViewModel>();
                e.CreateMap<RoleViewModel, Role>();

                // User Role
                e.CreateMap<UserRole, UserRoleViewModel>();
                e.CreateMap<UserRoleViewModel, UserRole>();

                // Project Deal Type
                e.CreateMap<ProjectDealType, ProjectDealTypeViewModel>();
                e.CreateMap<ProjectDealTypeViewModel, ProjectDealType>();

                // Omf Approver
                //e.CreateMap<OmfApprover, OmfApproverViewModel>();
                //e.CreateMap<OmfApproverViewModel, OmfApprover>();

                // ApproverTypes
                e.CreateMap<ApproverType, ApproverTypeViewModel>();
                e.CreateMap<ApproverTypeViewModel, ApproverType>();

                // StatusActions
                e.CreateMap<StatusAction, StatusActionViewModel>();
                e.CreateMap<StatusActionViewModel, StatusAction>();

                // Email Entity
                e.CreateMap<EmailEntity, EmailEntityViewModel>();
                e.CreateMap<EmailEntityViewModel, EmailEntity>();

                // StatusType
                e.CreateMap<StatusType, StatusTypeViewModel>();
                e.CreateMap<StatusTypeViewModel, StatusType>();

                // Client Master
                e.CreateMap<ClientMaster, ClientMasterViewModel>();
                e.CreateMap<ClientMasterViewModel, ClientMaster>();

                // Client Billing Address
                e.CreateMap<ClientBillingAddress, ClientBillingAddressViewModel>();
                e.CreateMap<ClientBillingAddressViewModel, ClientBillingAddress>();

                // Opportunity
                e.CreateMap<Opportunity, OpportunityViewModel>();
                e.CreateMap<OpportunityViewModel, Opportunity>();

                // Opportunity Access
                e.CreateMap<OpportunityAccess, OpportunityAccessViewModel>();
                e.CreateMap<OpportunityAccessViewModel, OpportunityAccess>();

                // DocumentType
                e.CreateMap<DocumentType, DocumentTypeViewModel>();
                e.CreateMap<DocumentTypeViewModel, DocumentType>();

                // Place Holders
                e.CreateMap<EmailTemplatePlaceHolder, EmailTemplatePlaceHolderViewModel>();
                e.CreateMap<EmailTemplatePlaceHolderViewModel, EmailTemplatePlaceHolder>();

                // Financial Expense Detail
                e.CreateMap<FinancialNonBillableExpenseDetail, FinancialNonBillableExpenseDetailViewModel>();
                e.CreateMap<FinancialNonBillableExpenseDetailViewModel, FinancialNonBillableExpenseDetail>();

                // Financial Managed Services
                e.CreateMap<FinancialManagedServiceDetail, FinancialManagedServiceDetailViewModel>();
                e.CreateMap<FinancialManagedServiceDetailViewModel, FinancialManagedServiceDetail>();

                // Financial Billable Exxpense Detail
                e.CreateMap<FinancialBillableExpenseDetail, FinancialBillableExpenseDetailViewModel>();
                e.CreateMap<FinancialBillableExpenseDetailViewModel, FinancialBillableExpenseDetail>();

                // PaymentTermApprovalTracker
                e.CreateMap<PaymentTermApprovalTracker, PaymentTermApprovalTrackerViewModel>();
                e.CreateMap<PaymentTermApprovalTrackerViewModel, PaymentTermApprovalTracker>();

                // EmailCommentsByUser
                e.CreateMap<EmailCommentsByUser, EmailCommentsByUserViewModel>();
                e.CreateMap<EmailCommentsByUserViewModel, EmailCommentsByUser>();

                // OpportunityType
                e.CreateMap<OpportunityType, OpportunityTypeViewModel>();
                e.CreateMap<OpportunityTypeViewModel, OpportunityType>();

                // Finance Employee Detail
                e.CreateMap<FinancialEmployeeDetail, FinancialEmployeeDetailViewModel>();
                e.CreateMap<FinancialEmployeeDetailViewModel, FinancialEmployeeDetail>();

                // Finance Contractor Detail
                e.CreateMap<FinancialContractorDetail, FinancialContractorDetailViewModel>();
                e.CreateMap<FinancialContractorDetailViewModel, FinancialContractorDetail>();

                // Finance Employer Work Hour Entry
                e.CreateMap<FinancialEmployeeWorkHourEntry, FinancialEmployeeWorkHourEntryViewModel>();
                e.CreateMap<FinancialEmployeeWorkHourEntryViewModel, FinancialEmployeeWorkHourEntry>();

                // Finance Contractor Work Hour Entry
                e.CreateMap<FinancialContractorWorkHourEntry, FinancialContractorWorkHourEntryViewModel>();
                e.CreateMap<FinancialContractorWorkHourEntryViewModel, FinancialContractorWorkHourEntry>();

                // NextStatusActionByStatusTypeMappingService
                e.CreateMap<NextStatusActionByStatusTypeMapping, NextStatusActionByStatusTypeMappingViewModel>();
                e.CreateMap<NextStatusActionByStatusTypeMappingViewModel, NextStatusActionByStatusTypeMapping>();

                // OpportunityProjectSummary
                e.CreateMap<OpportunityProjectSummary, OpportunityProjectSummaryViewModel>();
                e.CreateMap<OpportunityProjectSummaryViewModel, OpportunityProjectSummary>();

                // OpportunityProjectSummary
                e.CreateMap<OpportunityProjectSummaryCapability, OpportunityProjectSummaryCapabilityViewModel>();
                e.CreateMap<OpportunityProjectSummaryCapabilityViewModel, OpportunityProjectSummaryCapability>();

                // OpportunityProjectSummaryGlobalSolution
                e.CreateMap<OpportunityProjectSummaryGlobalSolution, OpportunityProjectSummaryGlobalSolutionViewModel>();
                e.CreateMap<OpportunityProjectSummaryGlobalSolutionViewModel, OpportunityProjectSummaryGlobalSolution>();

                // OpportunityProjectSummaryTechnology
                e.CreateMap<OpportunityProjectSummaryTechnology, OpportunityProjectSummaryTechnologyViewModel>();
                e.CreateMap<OpportunityProjectSummaryTechnologyViewModel, OpportunityProjectSummaryTechnology>();

                // OpportunityWorkLocation
                e.CreateMap<OpportunityWorkLocation, OpportunityWorkLocationViewModel>();
                e.CreateMap<OpportunityWorkLocationViewModel, OpportunityWorkLocation>();

                // FinancialInitialSetup
                e.CreateMap<FinancialInitialSetup, FinancialInitialSetupViewModel>();
                e.CreateMap<FinancialInitialSetupViewModel, FinancialInitialSetup>();

                // RateCardByOpportunity
                e.CreateMap<RateCardByOpportunity, RateCardByOpportunityViewModel>();
                e.CreateMap<RateCardByOpportunityViewModel, RateCardByOpportunity>();

                // OmfFinancialSections
                e.CreateMap<OmfFinancialSections, OmfFinancialSectionsViewModel>();
                e.CreateMap<OmfFinancialSectionsViewModel, OmfFinancialSections>();

                // DefaultSectionByContractType
                e.CreateMap<DefaultSectionByContractType, DefaultSectionByContractTypeViewModel>();
                e.CreateMap<DefaultSectionByContractTypeViewModel, DefaultSectionByContractType>();

                // IncludeSectionByContractType
                e.CreateMap<IncludeSectionByContractType, IncludeSectionByContractTypeViewModel>();
                e.CreateMap<IncludeSectionByContractTypeViewModel, IncludeSectionByContractType>();

                // OpportunitySections
                e.CreateMap<OpportunitySections, OpportunitySectionsViewModel>();
                e.CreateMap<OpportunitySectionsViewModel, OpportunitySections>();

                // Work flow config
                e.CreateMap<WorkFlow, WorkFlowConfigViewModel>();
                e.CreateMap<WorkFlowConfigViewModel, WorkFlow>();

                // work flow templates
                e.CreateMap<WorkFlowTemplateMapping, WorkFlowTemplateMappingViewModel>();
                e.CreateMap<WorkFlowTemplateMappingViewModel, WorkFlowTemplateMapping>();

                // ResourceRole
                e.CreateMap<ResourceRole, ResourceRoleViewModel>();
                e.CreateMap<ResourceRoleViewModel, ResourceRole>();

                // OMFScreens
                e.CreateMap<OMFScreens, OMFScreensViewModel>();
                e.CreateMap<OMFScreensViewModel, OMFScreens>();

                // ScreenActions
                e.CreateMap<ScreenActions, ScreenActionsViewModel>();
                e.CreateMap<ScreenActionsViewModel, ScreenActions>();

                e.CreateMap<OMFJourney, OMFJourneyViewModel>();
                e.CreateMap<OMFJourneyViewModel, OMFJourney>();

                e.CreateMap<OpportunityRisks, OpportunityRisksViewModel>();
                e.CreateMap<OpportunityRisksViewModel, OpportunityRisks>();

                e.CreateMap<OpportunityOverview, OpportunityOverviewViewModel>();
                e.CreateMap<OpportunityOverviewViewModel, OpportunityOverview>();

                e.CreateMap<OpportunityProjectDetails, OpportunityProjectDetailsViewModel>();
                e.CreateMap<OpportunityProjectDetailsViewModel, OpportunityProjectDetails>();
            });

            Mapper = config.CreateMapper();

            InsertInfoViewModel();
        }

        
        protected static List<Currency> CreateCurrency()
        {
            //Repository.Repository<Currency>().DeleteRange(Repository.Repository<Currency>().GetAll());
            //Repository.SaveChanges();
            

            var currencyList = new List<Currency>()
            {
                new Currency() { CurrencyId = 1, CurrencyCode = "USD", Comments = "USD Comments", CreatedBy = "nbhat", CreatedDate = DateTime.Now, IsActive=true },
                new Currency() { CurrencyId = 2, CurrencyCode = "INR", Comments = "INR Comments", CreatedBy = "nbhat", CreatedDate = DateTime.Now, IsActive=true }
            };

            return currencyList;
            //Repository.Repository<Currency>().AddRange(currencyList);
            //Repository.SaveChanges();
        }

        private static ContractType CreateContractType()
        {
            var contractTypeViewModel = new ContractTypeViewModel
            {
                ContractTypeId = new Random().Next(1, randomInterval),
                ContractTypeName = "TESTAPI",
                IsActive = true,
                Comments = "TestComment",
                IsFinanceApprovalRequired = false
            };

            var contract = new ContractType
            {
                ContractTypeId = 1,
                ContractTypeName = "TestContract",
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now
            };

            return contract;
            //var contractType = contractTypeController.AddContractType(contractTypeViewModel);
            //contractTypeList.Add(contractTypeViewModel);
        }

        private static PaymentTerms CreatePaymentTerm()
        {
            var paymentTermsViewModel = new PaymentTermsViewModel
            {
                PaymentTermId = new Random().Next(1, randomInterval),
                PaymentTermCode = "TESTAPI",
                PayTermDays = 10,
                IsActive = true,
                Comments = "TestComment"
            };

            var paymentTerm = new PaymentTerms
            {
                PaymentTermId = 1,
                PaymentTermCode = "TestPaymentTerm",
                PayTermDays = 10,
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now
            };

            return paymentTerm;

            //var paymentTerms = paymentTermsController.AddPaymentTerms(paymentTermsViewModel);
            //paymentTermsList.Add(paymentTermsViewModel);
        }

        private static ProjectDealType CreateProjectDealType()
        {
            var projectDealTypeViewModel = new ProjectDealTypeViewModel
            {
                ProjectDealTypeId = new Random().Next(1, randomInterval),
                ProjectDealTypeName = "TESTAPI",
                ProjectDomainId = new Random().Next(1, randomInterval),
                OnShorePercentage = 22,
                OffShorePercentage = 23,
                IsActive = true,
                Comments = "TestComment",
            };

            var projectDealType = new ProjectDealType
            {
                ProjectDealTypeId = 1,
                ProjectDealTypeName = "TestProjectDealType",
                ProjectDomainId = 1,
                OnShorePercentage = 22,
                OffShorePercentage = 23,
                IsActive = true,
                Comments = "Test",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now
            };

            return projectDealType;
            //var projectDealType = projectDealTypeController.AddProjectDealType(projectDealTypeViewModel);
            //projectDealTypeList.Add(projectDealTypeViewModel);
        }

        private static ProjectDomain CreateProjectDomain()
        {
            var projectDomainViewModel = new ProjectDomainViewModel
            {
                ProjectDomainId = new Random().Next(1, randomInterval),
                ProjectDomainName = "Domain 1",
                IsActive = true

            };

            var projectDomain = new ProjectDomain
            {
                ProjectDomainId = 1,
                ProjectDomainName = "Test Project Domain",
                IsActive = true,
                CreatedDate = DateTime.Now,
                CreatedBy = "nbhat"
            };

            return projectDomain;
            //var projectDomain = projectDomainController.AddProjectDomain(projectDomainViewModel);
            //projectDomainList.Add(projectDomainViewModel);
        }

        private static ProjectOrganization CreateProjectOrganization()
        {
            var projectOrganizationViewModel = new ProjectOrganizationViewModel
            {
                ProjectOrganizationId = new Random().Next(1, randomInterval),
                ProjectOrganizationName = "TESTAPI",
                IsActive = true,
                Comments = "TestComment"
            };

            var projectOrganization = new ProjectOrganization
            {
                ProjectOrganizationId = 1,
                ProjectOrganizationName = "Test Org",
                IsActive = true,
                Comments = "Test",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now
            };

            return projectOrganization;
            //var projectOrganization = projectOrganizationController.AddProjectOrganization(projectOrganizationViewModel);
            //projectOrganizationList.Add(projectOrganizationViewModel);
        }

        private static ReportingPractice CreateReportingPractice()
        {
            var reportingPracticeViewModel = new ReportingPracticeViewModel
            {
                ReportingPracticeId = new Random().Next(1, randomInterval),
                ReportingPracticeName = "Full Time",
                IsActive = true

            };

            var reportingPractive = new ReportingPractice
            {
                ReportingPracticeId = 1,
                ReportingPracticeName = "Test Practice",
                IsActive = true,
                CreatedDate = DateTime.Now,
                CreatedBy = "nbhat"
            };

            return reportingPractive;
            //var reportingPractice = reportingPracticeController.AddReportingPractice(reportingPracticeViewModel);
            //reportingPracticeList.Add(reportingPracticeViewModel);
        }

        protected static StatusType CreateStatusType()
        {
            var statusTypeViewModel = new StatusTypeViewModel
            {
                StatusId = 1,
                Status = "TESTAPI",
                IsActive = true,
                Comments = "TestComment",
            };

            var statusType = new StatusType
            {
                StatusId = 1,
                Status = "TESTAPI",
                IsActive = true,
                Comments = "TestComment"
            };

            return statusType;
            //var statusType = statusTypeController.AddStatusType(statusTypeViewModel);
            //statusTypeList.Add(statusTypeViewModel);
        }

        private static IndustrySubSegment CreateSubSegment()
        {
            var model = new IndustrySubSegmentViewModel
            {
                IndustrySubSegmentId = 1,
                IndustrySubSegmentName = "Test Sub Segment",
                Comments = "Test",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            var susbsegment = new IndustrySubSegment
            {
                IndustrySubSegmentId = 1,
                IndustrySubSegmentName = "Test Sub Segment",
                Comments = "Test",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            return susbsegment;
        }

        private static IndustrySegment CreateIndustrySegment()
        {
            var model = new IndustrySegmentViewModel
            {
                IndustrySegmentId = 1,
                IndustrySegmentName = "Test Segment",
                Comments = "Test",
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now
            };

            var segment = new IndustrySegment
            {
                IndustrySegmentId = 1,
                IndustrySegmentName = "Test Segment",
                Comments = "Test",
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now
            };

            return segment;
        }

        private static Region CreateRegion()
        {
            var model = new RegionViewModel
            {
                RegionId = 1,
                RegionName = "Test Region",
                Comments = "Test",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            var region = new Region
            {
                RegionId = 1,
                RegionName = "Test Region",
                Comments = "Test",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            return region;
        }

        private static Country CreateBillingCountry()
        {
            var model = new CountryViewModel
            {
                CountryId = 1,
                CountryName = "Test Country",
                CurrencyId = 1,
                CurrencyCode = "USD",
                Comments = "Test",
                IsTaxRegistrationNoRequired = false,
                RegionId = 1,
                RegionName = "Test Region",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            var country = new Country
            {
                CountryId = 1,
                CountryName = "Test Country",
                CurrencyId = 1,
                Comments = "Test",
                IsTaxRegistrationNoRequired = false,
                RegionId = 1,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            return country;
        }

        private static OpportunityType CreateOpportunityType()
        {
            var oppType = new OpportunityType
            {
                OpportunityTypeId = 1,
                OpportunityTypeName = "Test Type"
            };

            return oppType;
        }

        public InfoViewModel CreateOpportunityForTest()
        {
            var clientBillingAddress = CreateClientBillingAddressViewModel();
            var clientMaster = CreateClientMasterViewModel();
            var opportunityViewModel = new OpportunityViewModel
            {
                OpportunityId = 0,
                OpportunityName = "Test Opportunity",
                BaseCurrencyId = 1,
                ProjectOrganizationId = 1,
                OpportunityDescription = "This is a test opportunity",
                ReportingPracticeId = 1,
                CrmId = "123123",
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddYears(1),
                OnShoreProjectManager = "OPM",
                Oic = 1,
                PrimaryCapabilityLead = "Tester",
                WorkLocation = "Test location",
                PaymentTermId = 1,
                PrimaryContactName = "Test contact",
                WorkLocationPostCode = "500032",
                OffShorePMLocal = "Madhu",
                ProjectDomainId = 1,
                ContractTypeId = 1,
                ClientBillingAddressId = 1,
                ClientExecutiveSponsor = String.Empty,
                ClientExecutiveSponsorEmail = String.Empty,
                StatusId = 1,
                IsPaymentTermEmailSent = false,
                WeeklyHours = 40,
                IsReferentialArchitectureIncluded = false,
                IsShared = 1,
                ClientBillingAddress = clientBillingAddress,
                ApplicableRateCard = 1,
                ClientMasterId = 1,
                IsThisNewClient = true,
                ProjectOrganizationName = String.Empty,
                ReportingPracticeName = String.Empty,
                OfficerInCharge = String.Empty,
                IsQuickSetup = false
            };
            opportunityViewModel.WorkLocations = new List<int>();
            opportunityViewModel.ContractTypeSections = new List<int>();

            opportunityViewModel.WorkLocations.Add(1);
            opportunityViewModel.ContractTypeSections.Add(1);


            InfoViewModel infoViewModel = new InfoViewModel
            {
                ClientMaster = clientMaster,
                ClientBillingAddress = clientBillingAddress,
                Opportunity = opportunityViewModel,
                OpportunityAccess = CreateOpportunityAccess()
            };

            //InsertInfoViewModel();

            return infoViewModel;
        }

        
        public ResourceRole CreateResourceRole()
        {
            var model = new ResourceRole
            {
                ResourceRoleId = 1,
                ResourceRoleName = "Test Resource",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            return model;
        }

        private void InsertInfoViewModel()
        {
            // delete and add all the foreign keys
            // Currency
            Repository.Repository<Currency>().DeleteRange(Repository.Repository<Currency>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<Currency>().AddRange(CreateCurrency());
            Repository.SaveChanges();

            // 
            Repository.Repository<OpportunityType>().DeleteRange(Repository.Repository<OpportunityType>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<OpportunityType>().Add(CreateOpportunityType());
            Repository.SaveChanges();


            // 
            Repository.Repository<ContractType>().DeleteRange(Repository.Repository<ContractType>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<ContractType>().Add(CreateContractType());
            Repository.SaveChanges();

            // 
            Repository.Repository<PaymentTerms>().DeleteRange(Repository.Repository<PaymentTerms>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<PaymentTerms>().Add(CreatePaymentTerm());
            Repository.SaveChanges();

            //
            Repository.Repository<ProjectDealType>().DeleteRange(Repository.Repository<ProjectDealType>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<ProjectDealType>().Add(CreateProjectDealType());
            Repository.SaveChanges();

            //
            Repository.Repository<ProjectDomain>().DeleteRange(Repository.Repository<ProjectDomain>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<ProjectDomain>().Add(CreateProjectDomain());
            Repository.SaveChanges();

            //
            Repository.Repository<ProjectOrganization>().DeleteRange(Repository.Repository<ProjectOrganization>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<ProjectOrganization>().Add(CreateProjectOrganization());
            Repository.SaveChanges();

            //
            Repository.Repository<ReportingPractice>().DeleteRange(Repository.Repository<ReportingPractice>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<ReportingPractice>().Add(CreateReportingPractice());
            Repository.SaveChanges();

            //
            Repository.Repository<Region>().DeleteRange(Repository.Repository<Region>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<Region>().Add(CreateRegion());
            Repository.SaveChanges();

            //
            Repository.Repository<Country>().DeleteRange(Repository.Repository<Country>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<Country>().Add(CreateBillingCountry());
            Repository.SaveChanges();

            //
            Repository.Repository<UserRole>().DeleteRange(Repository.Repository<UserRole>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<UserRole>().Add(CreateUserRole());
            Repository.SaveChanges();

            //
            Repository.Repository<Country>().DeleteRange(Repository.Repository<Country>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<Country>().Add(CreateBillingCountry());
            Repository.SaveChanges();

            //
            Repository.Repository<OmfFinancialSections>().DeleteRange(Repository.Repository<OmfFinancialSections>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<OmfFinancialSections>().Add(CreateOmfFinancialSections());
            Repository.SaveChanges();

            //
            Repository.Repository<DeliveryModel>().DeleteRange(Repository.Repository<DeliveryModel>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<DeliveryModel>().Add(CreateDeliveryModel());
            Repository.SaveChanges();

            //
            Repository.Repository<WorkLocation>().DeleteRange(Repository.Repository<WorkLocation>().GetAll());
            Repository.SaveChanges();
            Repository.Repository<WorkLocation>().Add(CreateWorkLocation());
            Repository.SaveChanges();

            //
            Repository.Repository<Role>().DeleteRange(Repository.Repository<Role>().GetAll());
            Repository.Repository<Role>().Add(CreateRole());
            Repository.SaveChanges();

            //
            Repository.Repository<StatusAction>().DeleteRange(Repository.Repository<StatusAction>().GetAll());
            Repository.Repository<StatusAction>().Add(CreateStatusAction());
            Repository.SaveChanges();

            //
            Repository.Repository<WorkFlow>().DeleteRange(Repository.Repository<WorkFlow>().GetAll());
            Repository.Repository<WorkFlow>().Add(CreateWorkFlow());
            Repository.SaveChanges();

            // 
            Repository.Repository<CAYear>().DeleteRange(Repository.Repository<CAYear>().GetAll());
            var cAYears = new List<CAYear>()
            {
                new CAYear() { YearId = 1, Year = 2019, Comments = "" , IsActive=true},
                new CAYear() { YearId = 2, Year = 2020, Comments = ""},
                new CAYear() { YearId = 3, Year = 2021, Comments = ""},
            };
            Repository.Repository<CAYear>().AddRange(cAYears);
            Repository.SaveChanges();

            //
            Repository.Repository<OMFJourney>().DeleteRange(Repository.Repository<OMFJourney>().GetAll());
            Repository.Repository<OMFJourney>().Add(CreateJourney());
            Repository.SaveChanges();

            var omfScreen = new OMFScreens
            {
                ScreenId = 1,
                ScreenName = "Test Screen"
            };
            Repository.Repository<OMFScreens>().DeleteRange(Repository.Repository<OMFScreens>().GetAll());
            Repository.Repository<OMFScreens>().Add(omfScreen);
            Repository.SaveChanges();

            var screenAction = new ScreenActions
            {
                ScreenActionId = 1,
                ScreenId = 1,
                ActionName = "Test Action",

            };
            Repository.Repository<ScreenActions>().DeleteRange(Repository.Repository<ScreenActions>().GetAll());
            Repository.Repository<ScreenActions>().Add(screenAction);
            Repository.SaveChanges();

            var role = new Role
            {
                RoleId = 1,
                RoleName = "Test",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };
            Repository.Repository<Role>().DeleteRange(Repository.Repository<Role>().GetAll());
            Repository.Repository<Role>().Add(role);
            Repository.SaveChanges();

            var screenByRole = new ScreenAccessByRole
            {
                RoleId = 1,
                ScreenId = 1,
                IsActive = true,
                ScreenAccessByRoleId = 1,
                CreatedDate = DateTime.Now,
                CreatedBy = "nbhat"
            };
            Repository.Repository<ScreenAccessByRole>().DeleteRange(Repository.Repository<ScreenAccessByRole>().GetAll());
            Repository.Repository<ScreenAccessByRole>().Add(screenByRole);
            Repository.SaveChanges();

        }

        private ClientBillingAddressViewModel CreateClientBillingAddressViewModel()
        {
            var clientBillAddress = Repository.Repository<ClientBillingAddress>().GetById(1);
            
            if (clientBillAddress != null)
            {
                return Mapper.Map<ClientBillingAddress, ClientBillingAddressViewModel>(clientBillAddress);
            }

            ClientBillingAddressViewModel model = new ClientBillingAddressViewModel
            {
                ClientBillingAddressId = 1,
                ClientMasterId = 1,
                BillingCountryId = 1,
                BillingAddress = "123 Test",
                BillingState = "Test",
                BillingCity = "Test",
                BillingPostCode = "123123",
                BranchOrClientOffice = 1,
                ClientContactPerson = String.Empty,
                TaxRegistrationNumber = String.Empty,
                FaxNumber = String.Empty,
                PhoneNumber = String.Empty
            };

            return model;

        }

        private ClientMasterViewModel CreateClientMasterViewModel()
        {
            var clientMasters = Repository.Repository<ClientMaster>().GetById(1);
            if (clientMasters != null)
            {
                return Mapper.Map<ClientMaster, ClientMasterViewModel>(clientMasters);
            }

            ClientMasterViewModel model = new ClientMasterViewModel
            {
                ClientMasterId = 1,
                ClientName = "Test client",
                IndustrySegmentId = 1,
                IndustrySubSegmentId = 1,
                PaymentTermId = 1,
                HitachiCompany = false,
                JapaneseCompany = false,
                Url = "www.test.com",
                PrimaryContactName = String.Empty,
                Comments = String.Empty
            };

            return model;
        }

        private List<OpportunityAccessViewModel> CreateOpportunityAccess()
        {
            var model = new OpportunityAccess
            {
                OpportunityId = 0,
                UserRoleId = 1,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true,
                DeleteAccess = true,
                EditAccess = true,
                ViewOnlyAccess = false,
            };

            List<OpportunityAccessViewModel> result = new List<OpportunityAccessViewModel>();
            result.Add(Mapper.Map<OpportunityAccess, OpportunityAccessViewModel>(model));

            return result;
        }

        private UserRole CreateUserRole()
        {
            var model = new UserRole
            {
                UserRoleId = 1,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                FirstName = "Test",
                LastName = "Test",
                RoleId = 1,
                UserId = "Test Id",
                IsActive = true,
                UserEmail = "test@email.com",
                Comments = "Test comments",
            };

            return model;
        }

        private OmfFinancialSections CreateOmfFinancialSections()
        {
            var model = new OmfFinancialSections
            {
                SectionId = 1,
                SectionName = "Test Section",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            return model;
        }

        // no need to add to repository
        private OpportunitySectionsViewModel CreateContractTypeSections()
        {
            var model = new OpportunitySectionsViewModel
            {
                SectionId = 1,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            return model;
        }


        private DeliveryModel CreateDeliveryModel()
        {
            var model = new DeliveryModel
            {
                DeliveryModelId = 1,
                DeliveryModelName = "Test Delivery Model",
                TargetMargin = 10,
                Comments = "Test Comments",
                IsActive = true
            };

            return model;
        }

        protected static WorkLocation CreateWorkLocation()
        {
            var model = new WorkLocation
            {
                WorkLocationId = 1,
                WorkLocationName = "Test Work Location",
                BaseCurrencyId = 1,
                DeliveryModelId = 1,
                DiscountPercentage = 10,
                MarginPercentage = 30,
                IncreaseOverCostRate = 5,
                Comments = "Test Comments",
                IsActive = true
            };

            return model;
        }

        protected static List<CAYear> CreateYears()
        {
            var cAYears = new List<CAYear>()
            {
                new CAYear() { YearId = 1, Year = 2019, Comments = ""},
                new CAYear() { YearId = 2, Year = 2020, Comments = ""},
                new CAYear() { YearId = 3, Year = 2021, Comments = ""},
            };

            return cAYears;
        }

        protected static List<Quarter> CreateQuarters()
        {
            var quarter = new List<Quarter>()
            {
                new Quarter(){QuarterId=1,QuarterName="Q1"},
                new Quarter(){QuarterId=2,QuarterName="Q2"},
                new Quarter(){QuarterId=3,QuarterName="Q3"},
                new Quarter(){QuarterId=4,QuarterName="Q4"}
            };

            return quarter;
        }

        protected static Role CreateRole()
        {
            var model = new Role
            {
                RoleId = 1,
                RoleName = "Test Role",
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
            };

            return model;
        }

        protected static StatusAction CreateStatusAction()
        {
            var model = new StatusAction
            {
                StatusActionId = 1,
                Action = "Test Action",
                StatusActionText = "Test Text",
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now
            };

            return model;
        }

        protected static WorkFlow CreateWorkFlow()
        {
            var model = new WorkFlow
            {
                WorkFlowId = 1,
                StatusTypeId = 1,
                StatusActionId = 1,
                IsActive = true,
                CurrentStatusTypeId = 14,
                //RoleId = 1,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,

            };

            return model;
        }

        protected static OMFJourney CreateJourney()
        {
            var journeyModel = new OMFJourney
            {
                OMFJourneyId = 0,
                StatusId = 1,
                OpportunityId = 1,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true,

            };

            return journeyModel;
        }

    }
}