﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class CapabilitySubCapabilityMappingAPITest : UnitTestBase
    {
        private static CapabilitySubCapabilityMappingController CapabilitySubCapabilityMappingController;
        private static CapabilitySubCapabilityMappingService CapabilitySubCapabilityMappingService;
        private static CapabilitySubCapabilityMappingViewModel CapabilitySubCapabilityMappingViewModel;
        private static Mock<ILogger<CapabilitySubCapabilityMappingController>> Logger;
        private List<CapabilitySubCapabilityMappingViewModel> capabilitySubCapabilityMappingList = new List<CapabilitySubCapabilityMappingViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            CapabilitySubCapabilityMappingService = new CapabilitySubCapabilityMappingService(Repository, Mapper);
            Logger = new Mock<ILogger<CapabilitySubCapabilityMappingController>>();
            CapabilitySubCapabilityMappingController = new CapabilitySubCapabilityMappingController(CapabilitySubCapabilityMappingService, Logger.Object);
            Repository.Repository<CapabilitySubCapabilityMapping>().DeleteRange(Repository.Repository<CapabilitySubCapabilityMapping>().GetAll());

            CapabilitySubCapabilityMappingController = new CapabilitySubCapabilityMappingController(CapabilitySubCapabilityMappingService, Logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
                CapabilitySubCapabilityMappingViewModel = new CapabilitySubCapabilityMappingViewModel
                {
                    CapabilityId = new Random().Next(1, randomInterval),
                    SubCapabilities = new List<SubCapabilityViewModel> { new SubCapabilityViewModel { SubCapabilityId = 1000001, SubCapabilityName = "Sub Capability" } },
                    IsActive = true
                };

                var capability = CapabilitySubCapabilityMappingController.AddCapabilitySubCapability(CapabilitySubCapabilityMappingViewModel);
                capabilitySubCapabilityMappingList.Add(CapabilitySubCapabilityMappingViewModel);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            CapabilitySubCapabilityMappingViewModel = null;
            capabilitySubCapabilityMappingList = null;
        }

        [TestMethod]
        public void GetCapabilitySubCapabilities()
        {
            var capabilitySubCapabilityMappings = CapabilitySubCapabilityMappingController.GetAllCapabilitySubCapabilities();
            Assert.IsNotNull(capabilitySubCapabilityMappings);

            var result = (OkObjectResult)capabilitySubCapabilityMappings;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddCapabilitySubCapabilityMapping()
        {
            CapabilitySubCapabilityMappingViewModel = new CapabilitySubCapabilityMappingViewModel
            {
                CapabilityId = new Random().Next(1, randomInterval),
                SubCapabilities = new List<SubCapabilityViewModel> { new SubCapabilityViewModel { SubCapabilityId = 1001001, SubCapabilityName = "Sub Capability" } },
                IsActive = true
            };

            var createdCapability = CapabilitySubCapabilityMappingController.AddCapabilitySubCapability(CapabilitySubCapabilityMappingViewModel);
            Assert.IsNotNull(createdCapability);

            var result = (OkObjectResult)createdCapability;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getCapabilities = CapabilitySubCapabilityMappingController.GetAllCapabilitySubCapabilities();
            Assert.IsNotNull(getCapabilities);

            var getResult = (OkObjectResult)getCapabilities;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}
