﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class FinancialInitialSetupAPITest : UnitTestBase
    {
        private static FinancialInitialSetupController FinancialInitialSetupController;
        private static FinancialInitialSetupService FinancialInitialSetupService;
        private static Mock<ILogger<FinancialInitialSetupController>> logger;
        private static OpportunityAPITest oppTest;


        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            FinancialInitialSetupService = new FinancialInitialSetupService(Repository, Mapper);
            logger = new Mock<ILogger<FinancialInitialSetupController>>();
            FinancialInitialSetupController = new FinancialInitialSetupController(FinancialInitialSetupService, logger.Object)
            {
                ControllerContext = new ControllerContext(){
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };

            oppTest = new OpportunityAPITest();
            OpportunityAPITest.ClassInitialize(context);
        }

        [TestInitialize]
        public void TestInitialize()
        {
            oppTest.TestInitialize();
            prepareData();
            
        }

        [TestMethod]
        public void AddInitialSetup()
        {
            var viewModel = new FinancialInitialSetupViewModel
            {
                OpportunityId = 2,
                EmployeeCount = 2,
                ContractorCount = 2,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                DiscountPercentage = 5,
                FinancialInitialSetupId = 1,
                IsActive = true,
                YearId = 0,
                RateCardType = 1
            };

            var addInitial = FinancialInitialSetupController.AddInitialSetup(viewModel);
            Assert.IsNotNull(addInitial);

            var result = (OkObjectResult)addInitial;
            Assert.AreEqual(200, result.StatusCode);


        }

        //[TestMethod]
        //public void GetInitialSetupById()
        //{
        //    var viewModel = new FinancialInitialSetupViewModel
        //    {
        //        OpportunityId = 1,
        //        EmployeeCount = 2,
        //        ContractorCount = 2,
        //        CreatedBy = "nbhat",
        //        CreatedDate = DateTime.Now,
        //        DiscountPercentage = 5,
        //        FinancialInitialSetupId = 1,
        //        IsActive = true,
        //        YearId = 0,
        //        RateCardType = 1
        //    };

        //    var addInitial = FinancialInitialSetupController.AddInitialSetup(viewModel);

        //    var getInitialSetupId = FinancialInitialSetupController.GetInitialSetupById(1);
        //    Assert.IsNotNull(getInitialSetupId);

        //    var result = (OkObjectResult)getInitialSetupId;
        //    Assert.AreEqual(200, result.StatusCode);

        //    var response = (ApiOkResponse)result.Value;
        //    Assert.IsNotNull(response);

        //    var model = (IEnumerable<FinancialInitialSetupViewModel>)response.Result;
        //    Assert.IsTrue(model.Any(x => x.OpportunityId == 2));
        //}

        //[TestMethod]
        //public void GetAllFinancialsInitialSetup()
        //{
        //    var getInitialSetupId = FinancialInitialSetupController.GetAllFinancialsInitialSetup();
        //    Assert.IsNotNull(getInitialSetupId);

        //    var result = (OkObjectResult)getInitialSetupId;
        //    Assert.AreEqual(200, result.StatusCode);

        //    var response = (ApiOkResponse)result.Value;
        //    Assert.IsNotNull(response);

        //    var model = (IEnumerable<FinancialInitialSetupViewModel>)response.Result;
        //    Assert.IsTrue(model.Any(x => x.OpportunityId == 1));
        //}

        //[TestMethod]
        //public void GetInitialSetupByOppourtunityID()
        //{
        //    var getInitialSetupId = FinancialInitialSetupController.GetInitialSetupByOppourtunityID(1);
        //    Assert.IsNotNull(getInitialSetupId);

        //    var result = (OkObjectResult)getInitialSetupId;
        //    Assert.AreEqual(200, result.StatusCode);

        //    var response = (ApiOkResponse)result.Value;
        //    Assert.IsNotNull(response);

        //    var model = (IEnumerable<FinancialInitialSetupViewModel>)response.Result;
        //    Assert.IsTrue(model.Any(x => x.OpportunityId == 1));
        //}

        //[TestMethod]
        //public void UpdateInitialSetup()
        //{
        //    var getInitialSetupId = FinancialInitialSetupController.GetInitialSetupById(1);
        //    Assert.IsNotNull(getInitialSetupId);

        //    var result = (OkObjectResult)getInitialSetupId;
        //    Assert.AreEqual(200, result.StatusCode);

        //    var response = (ApiOkResponse)result.Value;
        //    Assert.IsNotNull(response);

        //    var model = (IEnumerable<FinancialInitialSetupViewModel>)response.Result;
        //    Assert.IsTrue(model.Any(x => x.OpportunityId == 1));

        //    var viewModel = model.FirstOrDefault();
        //    viewModel.DiscountPercentage = 10;

        //    var addInitial = FinancialInitialSetupController.UpdateInitialSetup(viewModel);
        //    Assert.IsNotNull(addInitial);

        //    var updateResult = (OkObjectResult)addInitial;
        //    Assert.AreEqual(200, result.StatusCode);


        //}

        private void prepareData()
        {
            oppTest.SaveInfoCompliance();
            Repository.Repository<CAYear>().DeleteRange(Repository.Repository<CAYear>().GetAll());
            var cAYears = new List<CAYear>()
            {
                new CAYear() { YearId = 1, Year = 2019, Comments = ""},
                new CAYear() { YearId = 2, Year = 2020, Comments = ""},
                new CAYear() { YearId = 3, Year = 2021, Comments = ""},
            };
            Repository.Repository<CAYear>().AddRange(cAYears);
            Repository.SaveChanges();
        }
    }
}
