﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class ContractTypeAPITest : UnitTestBase
    {
        private static ContractTypeController contractTypeController;
        private static ContractTypeService contractTypeService;
        private static ContractTypeViewModel contractTypeViewModel;
        private static Mock<ILogger<ContractTypeController>> logger;
        private List<ContractTypeViewModel> contractTypeList = new List<ContractTypeViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            contractTypeService = new ContractTypeService(Repository, Mapper);
            logger = new Mock<ILogger<ContractTypeController>>();
            contractTypeController = new ContractTypeController(contractTypeService, logger.Object);
            Repository.Repository<ContractType>().DeleteRange(Repository.Repository<ContractType>().GetAll());

            contractTypeController = new ContractTypeController(contractTypeService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getContractTypes = contractTypeController.GetAllContractTypes();
            Assert.IsNotNull(getContractTypes);

            var result = (OkObjectResult)getContractTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<ContractTypeViewModel>)response.Result;

            if (getData.Count > 0)
            {
                contractTypeList = getData;
            }
            else
            {
                contractTypeViewModel = new ContractTypeViewModel
                {
                    ContractTypeId = new Random().Next(1, randomInterval),
                    ContractTypeName = "TESTAPI",
                    IsActive = true,
                    Comments = "TestComment",
                    IsFinanceApprovalRequired = false
                };

                var contractType = contractTypeController.AddContractType(contractTypeViewModel);
                contractTypeList.Add(contractTypeViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            contractTypeViewModel = null;
            contractTypeList = null;
        }

        [TestMethod]
        public void GetAllContractTypes()
        {
            var getContractTypes = contractTypeController.GetAllContractTypes();
            Assert.IsNotNull(getContractTypes);

            var result = (OkObjectResult)getContractTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetContractTypeById()
        {
            var getContractType = contractTypeController.GetContractTypeById(contractTypeList.FirstOrDefault().ContractTypeId);
            Assert.IsNotNull(getContractType);

            var result = (OkObjectResult)getContractType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddContractType()
        {
            contractTypeViewModel = new ContractTypeViewModel
            {
                ContractTypeId = new Random().Next(1, randomInterval),
                ContractTypeName = "TESTAPI",
                IsActive = true,
                Comments = "TestComment",
                IsFinanceApprovalRequired = false,
                OpportunityTypeId = 1
            };

            var createdContractType = contractTypeController.AddContractType(contractTypeViewModel);
            Assert.IsNotNull(createdContractType);

            var result = (OkObjectResult)createdContractType;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getContractTypes = contractTypeController.GetAllContractTypes();
            Assert.IsNotNull(getContractTypes);

            var getResult = (OkObjectResult)getContractTypes;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var contractTypeList = (List<ContractTypeViewModel>)getResponse.Result;
            Assert.IsTrue(contractTypeList.Any(e => e.ContractTypeName == contractTypeViewModel.ContractTypeName));
        }

        [TestMethod]
        public void UpdateContractType()
        {
            var contractTypeUpdate = contractTypeList.FirstOrDefault();
            contractTypeUpdate.ContractTypeName = "TESTAPI";

            var editContractType = contractTypeController.UpdateContractType(contractTypeUpdate);
            Assert.IsNotNull(editContractType);

            var result = (OkObjectResult)editContractType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getContractType = contractTypeController.GetContractTypeById(contractTypeUpdate.ContractTypeId);
            Assert.IsNotNull(getContractType);

            var getResult = (OkObjectResult)getContractType;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var contractType = (ContractTypeViewModel)getResponse.Result;
            Assert.IsTrue(contractTypeUpdate.ContractTypeName == contractType.ContractTypeName);
        }

        [TestMethod]
        public void GetActiveContractTypes()
        {
            var getContractTypes = contractTypeController.GetActiveContractTypes();
            Assert.IsNotNull(getContractTypes);

            var result = (OkObjectResult)getContractTypes;
            Assert.AreEqual(200, result.StatusCode);
            
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var message = (IEnumerable<ContractTypeViewModel>)response.Result;
            Assert.IsNotNull(message);
        }
    }
}