﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class RegionAPITest : UnitTestBase
    {
        private static RegionController regionController;
        private static RegionService regionService;
        private static RegionViewModel regionViewModel;
        private static Mock<ILogger<RegionController>> logger;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            regionService = new RegionService(Repository, Mapper);
            logger = new Mock<ILogger<RegionController>>();
            regionController = new RegionController(regionService, logger.Object);
            regionController = new RegionController(regionService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
            PrepareTestDataForUpdate();
        }

        /// <summary>
        /// Unit Test for getting all regions
        /// </summary>
        [TestMethod]
        public void GetActiveRegions()
        {
            var getRegions = regionController.GetActiveRegions();
            Assert.IsNotNull(getRegions);

            var result = (OkObjectResult)getRegions;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        /// <summary>
        /// Unit Test Method to Add the region
        /// </summary>
        [TestMethod]
        public void AddRegion()
        {
            regionViewModel = new RegionViewModel
            {
                RegionId = 11,
                RegionName = "APacific",
                IsActive = true,
                Comments = "Comments for Asia Pacific",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
            };

            var createdRegion = regionController.AddRegion(regionViewModel);
            Assert.IsNotNull(createdRegion);

            var result = (OkObjectResult)createdRegion;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getRegions = regionController.GetActiveRegions();
            Assert.IsNotNull(getRegions);

            var getResult = (OkObjectResult)getRegions;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var regionList = (List<RegionViewModel>)getResponse.Result;
            Assert.IsTrue(regionList.Any(e => e.RegionName == regionViewModel.RegionName));
        }

        /// <summary>
        /// Unit Test Method for Updating Region
        /// </summary>
        [TestMethod]
        public void UpdateRegion()
        {
            var regionUpdate = Repository.Repository<Region>().GetAll().FirstOrDefault();
            RegionViewModel regionModel =  Mapper.Map<Region, RegionViewModel>(regionUpdate);

            regionModel.RegionName = "AMEA";
            var editRegion = regionController.UpdateRegion(regionModel);
            Assert.IsNotNull(editRegion);

            var result = (OkObjectResult)editRegion;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getRegion = regionController.GetRegionById(regionUpdate.RegionId);
            Assert.IsNotNull(getRegion);

            var getResult = (OkObjectResult)getRegion;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var region = (RegionViewModel)getResponse.Result;
            Assert.IsTrue(region.RegionName == region.RegionName);
        }

        [TestMethod]
        public void GetAllRegions()
        {
            var getRegions = regionController.GetAllRegions();
            Assert.IsNotNull(getRegions);

            var result = (OkObjectResult)getRegions;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }


        [TestMethod]
        public void GetRegionById()
        {
            var id = Repository.Repository<Region>().GetAll().Where(x => x.RegionId == 1).FirstOrDefault().RegionId;
            var getRegions = regionController.GetRegionById(id);
            Assert.IsNotNull(getRegions);

            var result = (OkObjectResult)getRegions;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        /// <summary>
        /// Procedure to create test data
        /// </summary>
        private static void PrepareTestDataForUpdate()
        {
            Repository.Repository<Region>().DeleteRange(Repository.Repository<Region>().GetAll());
            Repository.SaveChanges();

            var regionList = new List<Region>()
            {
                new Region() { RegionId = 1, RegionName = "Asia", Comments = "Asia Comments", CreatedBy = "nbhat", CreatedDate = DateTime.Now, IsActive=true },
                new Region() { RegionId = 2, RegionName = "EMEA", Comments = "EMEA Comments", CreatedBy = "nbhat", CreatedDate = DateTime.Now, IsActive=true }
            };
            Repository.Repository<Region>().AddRange(regionList);
            Repository.SaveChanges();
        }

    }
}
