﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class StatusActionAPITest : UnitTestBase
    {
        private static StatusActionController StatusActionController;
        private static StatusActionService StatusActionService;
        private static Mock<ILogger<ColaController>> logger;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            logger = new Mock<ILogger<ColaController>>();
            StatusActionService = new StatusActionService(Repository, Mapper);
            StatusActionController = new StatusActionController(StatusActionService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };

        }

        [TestInitialize]
        public void TestInitialize()
        {
            prepareData();
        }

        [TestMethod]
        public void GetStatusActions()
        {
            var getStatusActions = StatusActionController.GetStatusActions();
            Assert.IsNotNull(getStatusActions);

            var result = (OkObjectResult)getStatusActions;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var viewModel = (IQueryable<StatusAction>)response.Result;
            Assert.IsTrue(viewModel.Any(x => x.StatusActionText == "Test Text"));
        }

        [TestMethod]
        public void GetActiveStatusActions()
        {
            var getStatusActions = StatusActionController.GetActiveStatusActions();
            Assert.IsNotNull(getStatusActions);

            var result = (OkObjectResult)getStatusActions;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var viewModel = (List<StatusActionViewModel>)response.Result;
            Assert.IsTrue(viewModel.Any(x => x.StatusActionText == "Test Text"));
        }

        private void prepareData()
        {
            var model = new StatusAction
            {
                StatusActionId = 1,
                Action = "Test Action",
                StatusActionText = "Test Text",
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now
            };

            Repository.Repository<StatusAction>().DeleteRange(Repository.Repository<StatusAction>().GetAll());
            Repository.Repository<StatusAction>().Add(model);
            Repository.SaveChanges();
        }
    }
}
