﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class IndustrySegmentSubSegmentMappingAPITest : UnitTestBase
    {
        private static IndustrySegmentSubSegmentMappingController IndustrySegmentSubSegmentMappingController;
        private static IndustrySegmentSubSegmentMappingService IndustrySegmentSubSegmentMappingService;
        private static IndustrySegmentSubSegmentMappingViewModel IndustrySegmentSubSegmentMappingViewModel;
        private static Mock<ILogger<IndustrySegmentSubSegmentMappingController>> Logger;
        private List<IndustrySegmentSubSegmentMappingViewModel> industrySegmentSubSegmentMappingList = new List<IndustrySegmentSubSegmentMappingViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            IndustrySegmentSubSegmentMappingService = new IndustrySegmentSubSegmentMappingService(Repository, Mapper);
            Logger = new Mock<ILogger<IndustrySegmentSubSegmentMappingController>>();
            IndustrySegmentSubSegmentMappingController = new IndustrySegmentSubSegmentMappingController(IndustrySegmentSubSegmentMappingService, Logger.Object);
            Repository.Repository<IndustrySegmentSubSegmentMapping>().DeleteRange(Repository.Repository<IndustrySegmentSubSegmentMapping>().GetAll());

            IndustrySegmentSubSegmentMappingController = new IndustrySegmentSubSegmentMappingController(IndustrySegmentSubSegmentMappingService, Logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            IndustrySegmentSubSegmentMappingViewModel = new IndustrySegmentSubSegmentMappingViewModel
            {
                IndustrySegmentId = new Random().Next(1, randomInterval),
                IndustrySubSegments = new List<IndustrySubSegmentViewModel> { new IndustrySubSegmentViewModel { IndustrySubSegmentId = 1000001, IndustrySubSegmentName = "Industry SubSegment Name" } },
                IsActive = true
            };

            var industrySegment = IndustrySegmentSubSegmentMappingController.AddIndustrySegmentSubSegment(IndustrySegmentSubSegmentMappingViewModel);
            industrySegmentSubSegmentMappingList.Add(IndustrySegmentSubSegmentMappingViewModel);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            IndustrySegmentSubSegmentMappingViewModel = null;
            industrySegmentSubSegmentMappingList = null;
        }

        [TestMethod]
        public void GetIndustrySegmentSubSegments()
        {
            var industrySegmentSubSegmentMappings = IndustrySegmentSubSegmentMappingController.GetAllIndustrySegmentSubSegments();
            Assert.IsNotNull(industrySegmentSubSegmentMappings);

            var result = (OkObjectResult)industrySegmentSubSegmentMappings;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddIndustrySegmentSubSegmentMapping()
        {
            IndustrySegmentSubSegmentMappingViewModel = new IndustrySegmentSubSegmentMappingViewModel
            {
                IndustrySegmentId = new Random().Next(1, randomInterval),
                IndustrySubSegments = new List<IndustrySubSegmentViewModel> { new IndustrySubSegmentViewModel { IndustrySubSegmentId = 1010001, IndustrySubSegmentName = "Industry SubSegment" } },
                IsActive = true
            };

            var createdIndustrySegment = IndustrySegmentSubSegmentMappingController.AddIndustrySegmentSubSegment(IndustrySegmentSubSegmentMappingViewModel);
            Assert.IsNotNull(createdIndustrySegment);

            var result = (OkObjectResult)createdIndustrySegment;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getCapabilities = IndustrySegmentSubSegmentMappingController.GetAllIndustrySegmentSubSegments();
            Assert.IsNotNull(getCapabilities);

            var getResult = (OkObjectResult)getCapabilities;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}
