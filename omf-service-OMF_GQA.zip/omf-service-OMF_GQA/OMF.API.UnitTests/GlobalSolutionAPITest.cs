﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class GlobalSolutionAPITest : UnitTestBase
    {
        private static GlobalSolutionController globalSolutionController;
        private static GlobalSolutionService globalSolutionService;
        private static GlobalSolutionViewModel globalSolutionViewModel;
        private static Mock<ILogger<GlobalSolutionController>> logger;
        private List<GlobalSolutionViewModel> globalSolutionList = new List<GlobalSolutionViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            globalSolutionService = new GlobalSolutionService(Repository, Mapper);
            logger = new Mock<ILogger<GlobalSolutionController>>();
            globalSolutionController = new GlobalSolutionController(globalSolutionService, logger.Object);
            Repository.Repository<GlobalSolution>().DeleteRange(Repository.Repository<GlobalSolution>().GetAll());

            globalSolutionController = new GlobalSolutionController(globalSolutionService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getGlobalSolution = globalSolutionController.GetAllGlobalSolutions();
            Assert.IsNotNull(getGlobalSolution);

            var result = (OkObjectResult)getGlobalSolution;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<GlobalSolutionViewModel>)response.Result;

            if (getData.Count > 0)
            {
                globalSolutionList = getData;
            }
            else
            {
                globalSolutionViewModel = new GlobalSolutionViewModel
                {
                    GlobalSolutionId = new Random().Next(1, randomInterval),
                    GlobalSolutionName = "TESTAPI",
                    IsActive = true,
                    Comments = "TestComment"
                };

                var globalSolution = globalSolutionController.AddGlobalSolution(globalSolutionViewModel);
                globalSolutionList.Add(globalSolutionViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            globalSolutionViewModel = null;
            globalSolutionList = null;
        }

        [TestMethod]
        public void GetAllGlobalSolution()
        {
            var getGlobalSolution = globalSolutionController.GetAllGlobalSolutions();
            Assert.IsNotNull(getGlobalSolution);

            var result = (OkObjectResult)getGlobalSolution;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetGlobalSolutionById()
        {
            var getGlobalSolution = globalSolutionController.GetGlobalSolutionById(globalSolutionList.FirstOrDefault().GlobalSolutionId);
            Assert.IsNotNull(getGlobalSolution);

            var result = (OkObjectResult)getGlobalSolution;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddGlobalSolution()
        {
            globalSolutionViewModel = new GlobalSolutionViewModel
            {
                GlobalSolutionId = new Random().Next(1, randomInterval),
                GlobalSolutionName = "TESTAPI",
                IsActive = true,
                Comments = "TestComment"
            };

            var createdGlobalSolution = globalSolutionController.AddGlobalSolution(globalSolutionViewModel);
            Assert.IsNotNull(createdGlobalSolution);

            var result = (OkObjectResult)createdGlobalSolution;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getGlobalSolution = globalSolutionController.GetAllGlobalSolutions();
            Assert.IsNotNull(getGlobalSolution);

            var getResult = (OkObjectResult)getGlobalSolution;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var globalSolutionList = (List<GlobalSolutionViewModel>)getResponse.Result;
            Assert.IsTrue(globalSolutionList.Any(e => e.GlobalSolutionName == globalSolutionViewModel.GlobalSolutionName));
        }

        [TestMethod]
        public void UpdateGlobalSolution()
        {
            var globalSolutionUpdate = globalSolutionList.FirstOrDefault();
            globalSolutionUpdate.GlobalSolutionName = "TESTAPI";

            var editGlobalSolution = globalSolutionController.UpdateGlobalSolution(globalSolutionUpdate);
            Assert.IsNotNull(editGlobalSolution);

            var result = (OkObjectResult)editGlobalSolution;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getGlobalSolution = globalSolutionController.GetGlobalSolutionById(globalSolutionUpdate.GlobalSolutionId);
            Assert.IsNotNull(getGlobalSolution);

            var getResult = (OkObjectResult)getGlobalSolution;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var globalSolution = (GlobalSolutionViewModel)getResponse.Result;
            Assert.IsTrue(globalSolutionUpdate.GlobalSolutionName == globalSolution.GlobalSolutionName);
        }
    }
}