﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class ApproverTypesAPITest : UnitTestBase
    {
        private static ApproverTypeController approverTypeController;
        private static ApproverTypeService approveTypeService;
        private static ApproverTypeViewModel approverTypeViewModel;
        private static Mock<ILogger<ApproverTypeController>> logger;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            approveTypeService = new ApproverTypeService(Repository, Mapper, HttpContextAccessor);
            logger = new Mock<ILogger<ApproverTypeController>>();
            approverTypeController = new ApproverTypeController(approveTypeService, logger.Object);
            approverTypeController = new ApproverTypeController(approveTypeService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
            PrepareTestDataForUpdate();
        }

        /// <summary>
        /// Unit Test for getting all ApproverType
        /// </summary>
        [TestMethod]
        public void GetActiveApproverTypes()
        {
            var getApproverTypes = approverTypeController.GetApproverTypes();
            Assert.IsNotNull(getApproverTypes);

            var result = (OkObjectResult)getApproverTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        /// <summary>
        /// Unit Test Method to Add the ApproverType
        /// </summary>
        [TestMethod]
        public void AddApproverType()
        {
            approverTypeViewModel = new ApproverTypeViewModel
            {
                ApproverTypeName = "Approver44",
                ApproverTypeId = 3
            };

            var createdApproverType = approverTypeController.AddApproverType(approverTypeViewModel);
            Assert.IsNotNull(createdApproverType);

            var result = (OkObjectResult)createdApproverType;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getApproverTypes = approverTypeController.GetApproverTypes();
            Assert.IsNotNull(getApproverTypes);

            var getResult = (OkObjectResult)getApproverTypes;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var approverTypesList = (List<ApproverTypeViewModel>)getResponse.Result;
            Assert.IsTrue(approverTypesList.Any(e => e.ApproverTypeName == approverTypeViewModel.ApproverTypeName));
        }

        /// <summary>
        /// Unit Test Method for Updating ApproverType
        /// </summary>
        [TestMethod]
        public void UpdateApproverType()
        {
            var approverTypeUpdate = Repository.Repository<ApproverType>().GetAll().FirstOrDefault();
            ApproverTypeViewModel approverTypeModel =  Mapper.Map<ApproverType, ApproverTypeViewModel>(approverTypeUpdate);

            approverTypeModel.ApproverTypeName = "Approver444";
            var editApproverType = approverTypeController.UpdateApproverType(approverTypeModel);
            Assert.IsNotNull(editApproverType);

            var result = (OkObjectResult)editApproverType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getCurrency = approverTypeController.GetApproverById(approverTypeUpdate.ApproverTypeId);
            Assert.IsNotNull(getCurrency);

            var getResult = (OkObjectResult)getCurrency;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var currency = (ApproverTypeViewModel)getResponse.Result;
            Assert.IsTrue(currency.ApproverTypeName == currency.ApproverTypeName);
        }

        [TestMethod]
        public void GetApproverTypes()
        {
            var getApproverTypes = approverTypeController.GetApproverTypes();
            Assert.IsNotNull(getApproverTypes);

            var result = (OkObjectResult)getApproverTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetAproverById()
        {
            var testApproverId = Repository.Repository<ApproverType>().GetAll().Where(x => x.ApproverTypeName == "Sample1").FirstOrDefault();
            var getApproverTypes = approverTypeController.GetApproverById(testApproverId.ApproverTypeId);
            Assert.IsNotNull(getApproverTypes);

            var result = (OkObjectResult)getApproverTypes;
            Assert.AreEqual(200, result.StatusCode);
            
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        /// <summary>
        /// Procedure to create test data
        /// </summary>
        private static void PrepareTestDataForUpdate()
        {
            Repository.Repository<ApproverType>().DeleteRange(Repository.Repository<ApproverType>().GetAll());
            Repository.SaveChanges();

            var approverTypesList = new List<ApproverType>()
            {
                new ApproverType() { ApproverTypeId = 1, ApproverTypeName = "Sample1", IsActive = true},
                new ApproverType() { ApproverTypeId = 2, ApproverTypeName = "Sample2", IsActive = true}
            };
            Repository.Repository<ApproverType>().AddRange(approverTypesList);
            Repository.SaveChanges();
        }

    }
}
