﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class OmfJourneyAPITest : UnitTestBase
    {
        private static OmfJourneyController OmfJourneyController;
        private static OmfJourneyService OmfJourneyService;
        private static Mock<ILogger<OmfJourneyController>> logger;
        private static OpportunityAPITest oppTest;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            logger = new Mock<ILogger<OmfJourneyController>>();
            OmfJourneyService = new OmfJourneyService(Repository, Mapper);
            OmfJourneyController = new OmfJourneyController(OmfJourneyService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
            OpportunityAPITest.ClassInitialize(context);
            oppTest = new OpportunityAPITest();
        }

        [TestInitialize]
        public void TestInitialize()
        {
            prepareData();
        }

        [TestMethod]
        public void GetOmfJourneyByOpportunityId()
        {
            var getOmfJourneyByOpportunityId = OmfJourneyController.GetOmfJourneyByOpportunityId(1);
            Assert.IsNotNull(getOmfJourneyByOpportunityId);
        }

        private void prepareData()
        {
            oppTest.TestInitialize();
            //var model = new StatusAction
            //{
            //    StatusActionId = 1,
            //    Action = "Test Action",
            //    StatusActionText = "Test Text",
            //    IsActive = true,
            //    CreatedBy = "nbhat",
            //    CreatedDate = DateTime.Now
            //};

            //Repository.Repository<StatusAction>().DeleteRange(Repository.Repository<StatusAction>().GetAll());
            //Repository.Repository<StatusAction>().Add(model);
            //Repository.SaveChanges();

            //var journeyModel = new OMFJourney
            //{
            //    OMFJourneyId = 1,
            //    StatusId = 1,
            //    OpportunityId = 1,
            //    CreatedBy = "nbhat",
            //    CreatedDate = DateTime.Now,
            //    IsActive = true,

            //};

            //Repository.Repository<OMFJourney>().DeleteRange(Repository.Repository<OMFJourney>().GetAll());
            //Repository.Repository<OMFJourney>().Add(journeyModel);
            //Repository.SaveChanges();
        }
    }
}
