﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using OMF.API.Controllers;
using OMF.Business.Common;
using OMF.Business.Interfaces;
using OMF.Business.Models;
using OMF.Business.Services;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.CodeAnalysis.Options;
using OMF.API.Common;

namespace OMF.API.UnitTests
{
    [TestClass]
    public class OpportunityAPITest : UnitTestBase
    {
        protected static OpportunityController opportunityController;
        protected static OpportunityService opportunityService;
        private static InfoViewModel infoViewModel;
        private static Mock<ILogger<OpportunityController>> logger;
        private static Mock<IHiQService> hiQService;
        private static IOptions<OmfSettings> options;
        private static IOptions<HiQSettings> hiqOptions;
        //private static List<InfoViewModel> infoViewModels;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            options = new OmfSettings() as IOptions<OmfSettings>;
            hiqOptions = new HiQSettings() as IOptions<HiQSettings>;
            UnitTestBase baseObject = new UnitTestBase();
            HttpContextAccessor.HttpContext = new DefaultHttpContext() { User = User };
            IUserRoleService userRoleService = new UserRoleService(Repository, Mapper, HttpContextAccessor);
            IYearService yearService = new YearService(Repository, Mapper);
            IQuarterService quarterService = new QuarterService(Repository,Mapper);
            ICurrencyService currencyService = new CurrencyService(Repository, Mapper);
            IFxRateService fxRateService = new FxRateService(Repository, Mapper, quarterService, HttpContextAccessor);
            IHiQService hiQService = new HiQService(Repository, hiqOptions,fxRateService, Mapper);
            IORBWorkFlowService orbWorkFlowService = new ORBWorkFlowService(Repository, Mapper, HttpContextAccessor, userRoleService, hiQService, fxRateService, options);
            IORBApprovalCriteriaService approvalCriteriaService = new ORBApprovalCriteriaService(Repository, Mapper, HttpContextAccessor);
            IWorkflowService workflowService = new WorkflowService(Repository, Mapper, userRoleService, options, HttpContextAccessor, fxRateService, orbWorkFlowService, approvalCriteriaService);
            IRateCardService rateCardService = new RateCardService(Repository,Mapper, quarterService, yearService,currencyService, HttpContextAccessor);
            ISharePointService sharePointService = new SharePointService(Repository, new SharePointSettings() as IOptions<SharePointSettings>);
            IOpportunityCRDetailsService opportunityCRDetailsService = new OpportunityCRDetailsService(Repository, Mapper, HttpContextAccessor);
            //IYearService yearService = new YearService(Repository, Mapper);
            

            opportunityService = new OpportunityService(Repository, Mapper,HttpContextAccessor,rateCardService,workflowService, options, yearService, sharePointService, opportunityCRDetailsService, hiQService);
            logger = new Mock<ILogger<OpportunityController>>();
            opportunityController = new OpportunityController(opportunityService, logger.Object, hiQService)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
            
        }

        [TestInitialize]
        public async void TestInitialize()
        {
            var getOpportunities = await opportunityController.GetOpportunityById(1);
            Assert.IsNotNull(getOpportunities);

            var result = (OkObjectResult)getOpportunities;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var getData = (InfoViewModel)response.Result;

            if (getData.Opportunity != null)
            {
                infoViewModel = getData;
            }
            else
            {
                InfoViewModel model = CreateOpportunityForTest();
                var viewModel = opportunityController.SaveInfoCompliance(model);
                //infoViewModels.Add(model);
            }
        }

        [TestMethod]
        public void SaveInfoCompliance()
        {
            var testOpp = CreateOpportunityForTest();
            testOpp.Opportunity.OpportunityName = "Test Opp 2";
            var saveInfoCompliance = opportunityController.SaveInfoCompliance(testOpp);
            Assert.IsNotNull(saveInfoCompliance);

            var result = (OkObjectResult)saveInfoCompliance;
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            //OpportunityBasicDetailsViewModel

            var opportunity = (OpportunityBasicDetailsViewModel)response.Result;
            Assert.AreEqual((int)Enums.StatusType.New, opportunity.StatusId);
        }

        //[TestMethod]
        //public void GetOpportunities()
        //{
        //    var getOppotunities = opportunityController.GetOpportunities();
        //    Assert.IsNotNull(getOppotunities);

        //    var result = (OkObjectResult)getOppotunities;
        //    Assert.IsNotNull(result);
        //    Assert.AreEqual(200, result.StatusCode);

        //    var response = (ApiOkResponse)result.Value;
        //    Assert.IsNotNull(response);

        //    var opportunity = (List<OpportunityViewModel>)response.Result;
        //    //Assert.AreEqual(infoViewModel.Opportunity.OpportunityId, opportunity.);
        //}
    }
}
