﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class ApproverByCountryAPITest : UnitTestBase
    {
        private static ApproverByCountryController ApproverByCountryController;
        private static ApproverByCountryService ApproverByCountryService;
        private static ApproverByCountryViewModel ApproverByCountryViewModel;
        private static Mock<ILogger<ApproverByCountryController>> Logger;
        private List<ApproverByCountryViewModel> approverByCountryViewModelList = new List<ApproverByCountryViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            ApproverByCountryService = new ApproverByCountryService(Repository, Mapper);
            Logger = new Mock<ILogger<ApproverByCountryController>>();
            ApproverByCountryController = new ApproverByCountryController(ApproverByCountryService, Logger.Object);
            Repository.Repository<ApproverByCountry>().DeleteRange(Repository.Repository<ApproverByCountry>().GetAll());

            ApproverByCountryController = new ApproverByCountryController(ApproverByCountryService, Logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            ApproverByCountryViewModel = new ApproverByCountryViewModel
            {
                ApproverByCountryId = new Random().Next(1, randomInterval),
                CountryId = 1,
                IsActive = true,
                Comments = "Service Test",
                ApproverTypeId = 1
            };

            ApproverByCountryViewModel.Approvers = new List<ApproverByCountryMappingViewModel>() { new ApproverByCountryMappingViewModel { UserRoleId = 1 } };

            var result = ApproverByCountryController.AddApproverByCountry(ApproverByCountryViewModel);
            approverByCountryViewModelList.Add(ApproverByCountryViewModel);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            ApproverByCountryViewModel = null;
            approverByCountryViewModelList = null;
        }

        [TestMethod]
        public void GetCapabilitySubCapabilities()
        {
            var approversByCountry = ApproverByCountryController.GetApproversByCountry();
            Assert.IsNotNull(approversByCountry);

            var result = (OkObjectResult)approversByCountry;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddApproverByCountry()
        {
            ApproverByCountryViewModel = new ApproverByCountryViewModel
            {
                ApproverByCountryId = new Random().Next(1, randomInterval),
                CountryId = 1,
                IsActive = true,
                Comments = "Service Test",
                ApproverTypeId = 1
            };

            ApproverByCountryViewModel.Approvers = new List<ApproverByCountryMappingViewModel>() { new ApproverByCountryMappingViewModel { UserRoleId = 1 } };

            var createdApprByCountry = ApproverByCountryController.AddApproverByCountry(ApproverByCountryViewModel);
            Assert.IsNotNull(createdApprByCountry);

            var result = (OkObjectResult)createdApprByCountry;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void UpdateApproverByCountry()
        {
            var approverByCountry = approverByCountryViewModelList.FirstOrDefault();
            approverByCountry.Comments = "Update Test";
            approverByCountry.CountryId = 2;

            var editApprByCountry = ApproverByCountryController.UpdateApproverByCountry(approverByCountry);
            Assert.IsNotNull(editApprByCountry);

            var result = (OkObjectResult)editApprByCountry;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}