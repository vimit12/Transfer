﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class ScreenActionsByRoleAPITest : UnitTestBase
    {
        private static ScreenActionsByRoleController ScreenActionsByRoleController;
        private static ScreenActionsByRoleService ScreenActionsByRoleService;
        private static Mock<ILogger<ScreenActionsByRoleController>> logger;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            logger = new Mock<ILogger<ScreenActionsByRoleController>>();
            HttpContextAccessor.HttpContext = new DefaultHttpContext() { User = User };
            ScreenActionsByRoleService = new ScreenActionsByRoleService(Repository, Mapper, HttpContextAccessor);
            ScreenActionsByRoleController = new ScreenActionsByRoleController(ScreenActionsByRoleService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };

        }

        [TestInitialize]
        public void TestInitialize()
        {
            prepareData();
        }

        [TestMethod]
        public void GetActionOMFScreens()
        {
            var getActionOMFScreens = ScreenActionsByRoleController.GetActionOMFScreens();
            Assert.IsNotNull(getActionOMFScreens);

            var result = (OkObjectResult)getActionOMFScreens;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var model = (List<OMFScreensViewModel>)response.Result;
            Assert.IsTrue(model.Any(x => x.ScreenId == 1));
        }

        [TestMethod]
        public void GetActiveScreenActions()
        {
            var getActionOMFScreens = ScreenActionsByRoleController.GetActiveScreenActions();
            Assert.IsNotNull(getActionOMFScreens);

            var result = (OkObjectResult)getActionOMFScreens;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var model = (List<ScreenActionsViewModel>)response.Result;
            Assert.IsTrue(model.Any(x => x.ScreenId == 1));
        }

        //[TestMethod]
        //public void GetAllScreenActionsByRole()
        //{
        //    var getActionOMFScreens = ScreenActionsByRoleController.GetAllScreenActionsByRole();
        //    Assert.IsNotNull(getActionOMFScreens);

        //    var result = (OkObjectResult)getActionOMFScreens;
        //    Assert.AreEqual(200, result.StatusCode);

        //    var response = (ApiOkResponse)result.Value;
        //    Assert.IsNotNull(response);

        //    var model = (List<RoleScreenActionsViewModel>)response.Result;
        //    Assert.IsTrue(model.Any(x => x.ScreenId == 1));
        //}

        //[TestMethod]
        //public void GetScreenActionsByScreenIdRoleId()
        //{
        //    var viewModel = new RoleScreenActionsViewModel
        //    {
        //        RoleId = 1,
        //        ScreenId = 1
        //    };
        //    var getActionOMFScreens = ScreenActionsByRoleController.GetScreenActionsByScreenIdRoleId(viewModel);
        //    Assert.IsNotNull(getActionOMFScreens);

        //    var result = (OkObjectResult)getActionOMFScreens;
        //    Assert.AreEqual(200, result.StatusCode);

        //    var response = (ApiOkResponse)result.Value;
        //    Assert.IsNotNull(response);

        //    var model = (RoleScreenActionsViewModel)response.Result;
        //    Assert.IsTrue(model.RoleScreenActionsId == 1);
        //}

        private void prepareData()
        {
            var omfScreen = new OMFScreens
            {
                ScreenId = 1,
                ScreenName = "Test Screen"
            };
            Repository.Repository<OMFScreens>().DeleteRange(Repository.Repository<OMFScreens>().GetAll());
            Repository.Repository<OMFScreens>().Add(omfScreen);
            Repository.SaveChanges();

            var screenAction = new ScreenActions
            {
                ScreenActionId = 1,
                ScreenId = 1,
                ActionName = "Test Action",

            };
            Repository.Repository<ScreenActions>().DeleteRange(Repository.Repository<ScreenActions>().GetAll());
            Repository.Repository<ScreenActions>().Add(screenAction);
            Repository.SaveChanges();

            var role = new Role
            {
                RoleId = 1,
                RoleName = "Test",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true
            };
            Repository.Repository<Role>().DeleteRange(Repository.Repository<Role>().GetAll());
            Repository.Repository<Role>().Add(role);
            Repository.SaveChanges();

            var screenByRole = new ScreenAccessByRole
            {
                RoleId = 1,
                ScreenId = 1,
                IsActive = true,
                ScreenAccessByRoleId = 1,
                CreatedDate = DateTime.Now,
                CreatedBy = "nbhat"
            };
            Repository.Repository<ScreenAccessByRole>().DeleteRange(Repository.Repository<ScreenAccessByRole>().GetAll());
            Repository.Repository<ScreenAccessByRole>().Add(screenByRole);
            Repository.SaveChanges();

        }
    }
}
