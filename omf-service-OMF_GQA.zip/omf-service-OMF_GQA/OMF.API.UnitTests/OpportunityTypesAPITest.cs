﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class OpportunityTypesAPITest : UnitTestBase
    {
        private static OpportunityTypeController OpportunityTypeController;
        private static OpportunityTypeService OpportunityTypeService;
        private static Mock<ILogger<OpportunityTypeController>> logger;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            IUserRoleService userRoleService = new UserRoleService(Repository, Mapper, HttpContextAccessor);
            OpportunityTypeService = new OpportunityTypeService(Repository, Mapper, userRoleService);
            logger = new Mock<ILogger<OpportunityTypeController>>();
            OpportunityTypeController = new OpportunityTypeController(OpportunityTypeService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            prepareData();
        }

        [TestMethod]
        public void GetOpportunityTypes()
        {
            var getOpportunityTypes = OpportunityTypeController.GetOpportunityTypes();
            Assert.IsNotNull(getOpportunityTypes);

            var result = (OkObjectResult)getOpportunityTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var model = (IEnumerable<OpportunityTypeViewModel>)response.Result;
            Assert.IsTrue(model.Any(x => x.OpportunityTypeId == 1));
        }

        private void prepareData()
        {
            var model = new OpportunityType
            {
                OpportunityTypeId = 1,
                OpportunityTypeName = "Test Type"
            };

            Repository.Repository<OpportunityType>().DeleteRange(Repository.Repository<OpportunityType>().GetAll());
            Repository.Repository<OpportunityType>().Add(model);
            Repository.SaveChanges();
        }
    }
}
