﻿
namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class EmployeeTypeAPITest : UnitTestBase
    {
        private static EmployeeTypeController employeeTypeController;
        private static EmployeeTypeService employeeTypeService;
        private static EmployeeTypeViewModel employeeTypeViewModel;
        private static Mock<ILogger<EmployeeTypeController>> logger;
        private List<EmployeeTypeViewModel> employeeTypeList = new List<EmployeeTypeViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            employeeTypeService = new EmployeeTypeService(Repository, Mapper);
            logger = new Mock<ILogger<EmployeeTypeController>>();
            employeeTypeController = new EmployeeTypeController(employeeTypeService, logger.Object);
            Repository.Repository<EmployeeType>().DeleteRange(Repository.Repository<EmployeeType>().GetAll());

            employeeTypeController = new EmployeeTypeController(employeeTypeService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getEmployeeType = employeeTypeController.GetEmployeeTypes();
            Assert.IsNotNull(getEmployeeType);

            var result = (OkObjectResult)getEmployeeType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<EmployeeTypeViewModel>)response.Result;

            if (getData.Count > 0)
            {
                employeeTypeList = getData;
            }
            else
            {
                employeeTypeViewModel = new EmployeeTypeViewModel
                {
                    EmployeeTypeId = new Random().Next(1, randomInterval),
                    EmployeeTypeName = "Full Time",
                    IsActive = true
                   
                };

                var employeetype = employeeTypeController.AddEmployeeType(employeeTypeViewModel);
                employeeTypeList.Add(employeeTypeViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            employeeTypeViewModel = null;
            employeeTypeList = null;
        }

        [TestMethod]
        public void GetActiveEmployeeTypes()
        {
            var getEmployeeType = employeeTypeController.GetActiveEmployeeTypes();
            Assert.IsNotNull(getEmployeeType);

            var result = (OkObjectResult)getEmployeeType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetAllEmployeeTypes()
        {
            var getEmployeeType = employeeTypeController.GetEmployeeTypes();
            Assert.IsNotNull(getEmployeeType);

            var result = (OkObjectResult)getEmployeeType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetEmployeeTypeById()
        {
            var getEmployeeType = employeeTypeController.GetEmployeeTypeById(employeeTypeList.FirstOrDefault().EmployeeTypeId);
            Assert.IsNotNull(getEmployeeType);

            var result = (OkObjectResult)getEmployeeType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddEmployeeType()
        {
            employeeTypeViewModel = new EmployeeTypeViewModel
            {
                EmployeeTypeId = new Random().Next(1, randomInterval),
                EmployeeTypeName = "Full Time",
                IsActive = true
            };

            var createdEmployeeType = employeeTypeController.AddEmployeeType(employeeTypeViewModel);
            Assert.IsNotNull(createdEmployeeType);

            var result = (OkObjectResult)createdEmployeeType;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getEmployeeType = employeeTypeController.GetEmployeeTypes();
            Assert.IsNotNull(getEmployeeType);

            var getResult = (OkObjectResult)getEmployeeType;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var employeeTypeList = (List<EmployeeTypeViewModel>)getResponse.Result;
            Assert.IsTrue(employeeTypeList.Any(e => e.EmployeeTypeName == employeeTypeViewModel.EmployeeTypeName));
        }

        [TestMethod]
        public void UpdateEmployeeType()
        {
            var employeetypeUpdate = employeeTypeList.FirstOrDefault();
            employeetypeUpdate.EmployeeTypeName = "Full Time Employee";

            var editEmployeeType = employeeTypeController.UpdateEmployeeType(employeetypeUpdate);
            Assert.IsNotNull(editEmployeeType);

            var result = (OkObjectResult)editEmployeeType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getEmployeeType = employeeTypeController.GetEmployeeTypeById(employeetypeUpdate.EmployeeTypeId);
            Assert.IsNotNull(getEmployeeType);

            var getResult = (OkObjectResult)getEmployeeType;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var employeetype = (EmployeeTypeViewModel)getResponse.Result;
            Assert.IsTrue(employeetypeUpdate.EmployeeTypeName == employeetype.EmployeeTypeName);
        }


    }
}
