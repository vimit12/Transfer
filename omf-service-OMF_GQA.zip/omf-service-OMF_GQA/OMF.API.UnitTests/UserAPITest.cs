﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Common;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class UserAPITest : UnitTestBase
    {
        public static UserController UserController;
        public static UserService UserService;
        public static Mock<ILogger<UserController>> logger;
        private static IOptions<AuthenticationSettings> options;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            var temp = new AuthenticationSettings
            {
                CheckTokenUrl = "http://192.168.150.82:9014",
                CheckTokenAppId = "ideaapp",
                CheckTokenAppSecret = "password",
                CheckTokenRelativeUrl = "hcc-oauth-server/oauth/check_token?token=",
                ConnectionString = "Server=192.168.150.82;Database=omf;Port=5432;User Id=OMFDB;Password=omfdb;"
            };
            options = temp as IOptions<AuthenticationSettings>;
            logger = new Mock<ILogger<UserController>>();
            HttpContextAccessor.HttpContext = new DefaultHttpContext() { User = User };
            UserService = new UserService(HttpContextAccessor, Repository);
            UserController = new UserController(UserService, options, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
            
        }

        //[TestMethod]
        //public void GetUserDetails()
        //{
        //    var getUserDetails = UserController.GetUserDetails();
        //    Assert.IsNotNull(getUserDetails);

        //    var result = (OkObjectResult)getUserDetails;
        //    Assert.AreEqual(200, result.StatusCode);

        //    var response = (ApiOkResponse)result.Value;
        //    Assert.IsNotNull(response);

        //    var model = (UserViewModel)response.Result;
        //    Assert.IsTrue(model.Role == "Test Role");
        //}
    }
}
