﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class ProjectOrganizationAPITest : UnitTestBase
    {
        private static ProjectOrganizationController projectOrganizationController;
        private static ProjectOrganizationService projectOrganizationService;
        private static ProjectOrganizationViewModel projectOrganizationViewModel;
        private static Mock<ILogger<ProjectOrganizationController>> logger;
        private List<ProjectOrganizationViewModel> projectOrganizationList = new List<ProjectOrganizationViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            projectOrganizationService = new ProjectOrganizationService(Repository, Mapper);
            logger = new Mock<ILogger<ProjectOrganizationController>>();
            projectOrganizationController = new ProjectOrganizationController(projectOrganizationService, logger.Object);
            Repository.Repository<ProjectOrganization>().DeleteRange(Repository.Repository<ProjectOrganization>().GetAll());

            projectOrganizationController = new ProjectOrganizationController(projectOrganizationService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getProjectOrganization = projectOrganizationController.GetAllProjectOrganizations();
            Assert.IsNotNull(getProjectOrganization);

            var result = (OkObjectResult)getProjectOrganization;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<ProjectOrganizationViewModel>)response.Result;

            if (getData.Count > 0)
            {
                projectOrganizationList = getData;
            }
            else
            {
                projectOrganizationViewModel = new ProjectOrganizationViewModel
                {
                    ProjectOrganizationId = new Random().Next(1, randomInterval),
                    ProjectOrganizationName = "TESTAPI",
                    IsActive = true,
                    Comments = "TestComment"
                };

                var projectOrganization = projectOrganizationController.AddProjectOrganization(projectOrganizationViewModel);
                projectOrganizationList.Add(projectOrganizationViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            projectOrganizationViewModel = null;
            projectOrganizationList = null;
        }

        [TestMethod]
        public void GetAllProjectOrganization()
        {
            var getProjectOrganization = projectOrganizationController.GetAllProjectOrganizations();
            Assert.IsNotNull(getProjectOrganization);

            var result = (OkObjectResult)getProjectOrganization;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetProjectOrganizationById()
        {
            var getProjectOrganization = projectOrganizationController.GetProjectOrganizationById(projectOrganizationList.FirstOrDefault().ProjectOrganizationId);
            Assert.IsNotNull(getProjectOrganization);

            var result = (OkObjectResult)getProjectOrganization;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddProjectOrganization()
        {
            projectOrganizationViewModel = new ProjectOrganizationViewModel
            {
                ProjectOrganizationId = new Random().Next(1, randomInterval),
                ProjectOrganizationName = "TESTAPI",
                IsActive = true,
                Comments = "TestComment"
            };

            var createdProjectOrganization = projectOrganizationController.AddProjectOrganization(projectOrganizationViewModel);
            Assert.IsNotNull(createdProjectOrganization);

            var result = (OkObjectResult)createdProjectOrganization;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getProjectOrganization = projectOrganizationController.GetAllProjectOrganizations();
            Assert.IsNotNull(getProjectOrganization);

            var getResult = (OkObjectResult)getProjectOrganization;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var projectOrganizationList = (List<ProjectOrganizationViewModel>)getResponse.Result;
            Assert.IsTrue(projectOrganizationList.Any(e => e.ProjectOrganizationName == projectOrganizationViewModel.ProjectOrganizationName));
        }

        [TestMethod]
        public void UpdateProjectOrganization()
        {
            var projectOrganizationUpdate = projectOrganizationList.FirstOrDefault();
            projectOrganizationUpdate.ProjectOrganizationName = "TESTAPI";

            var editProjectOrganization = projectOrganizationController.UpdateProjectOrganization(projectOrganizationUpdate);
            Assert.IsNotNull(editProjectOrganization);

            var result = (OkObjectResult)editProjectOrganization;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getProjectOrganization = projectOrganizationController.GetProjectOrganizationById(projectOrganizationUpdate.ProjectOrganizationId);
            Assert.IsNotNull(getProjectOrganization);

            var getResult = (OkObjectResult)getProjectOrganization;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var projectOrganization = (ProjectOrganizationViewModel)getResponse.Result;
            Assert.IsTrue(projectOrganizationUpdate.ProjectOrganizationName == projectOrganization.ProjectOrganizationName);
        }

        [TestMethod]
        public void GetActiveProjectOrganization()
        {
            var activeWorkLocations = projectOrganizationController.GetActiveProjectOrganizations();
            Assert.IsNotNull(activeWorkLocations);

            var result = (OkObjectResult)activeWorkLocations;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}