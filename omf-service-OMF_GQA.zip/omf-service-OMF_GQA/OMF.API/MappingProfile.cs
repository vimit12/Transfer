﻿namespace OMF.API
{
    using AutoMapper;
    using OMF.Business.Models;
    using OMF.Data.Models;

    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // Country
            CreateMap<Country, CountryViewModel>();
            CreateMap<CountryViewModel, Country>();

            // Capability
            CreateMap<Capability, CapabilityViewModel>();
            CreateMap<CapabilityViewModel, Capability>();

            // Sub Capability
            CreateMap<SubCapability, SubCapabilityViewModel>();
            CreateMap<SubCapabilityViewModel, SubCapability>();

            // Approver By Region
            CreateMap<ApproverByRegion, ApproverByRegionViewModel>();
            CreateMap<ApproverByRegionViewModel, ApproverByRegion>();

            // Approver By Region Mapping
            CreateMap<ApproverByRegionMapping, ApproverByRegionMappingViewModel>();
            CreateMap<ApproverByRegionMappingViewModel, ApproverByRegionMapping>();

            // Approver By Country
            CreateMap<ApproverByCountry, ApproverByCountryViewModel>();
            CreateMap<ApproverByCountryViewModel, ApproverByCountry>();

            // Approver By Country Mapping
            CreateMap<ApproverByCountryMapping, ApproverByCountryMappingViewModel>();
            CreateMap<ApproverByCountryMappingViewModel, ApproverByCountryMapping>();

            // CapabilitySubCapability Mapping
            CreateMap<CapabilitySubCapabilityMapping, CapabilitySubCapabilityMappingViewModel>();
            CreateMap<CapabilitySubCapabilityMappingViewModel, CapabilitySubCapabilityMapping>();

            // Capability
            CreateMap<Capability, CapabilityViewModel>();
            CreateMap<CapabilityViewModel, Capability>();

            // TechnologySubTechnology Mapping
            CreateMap<TechnologySubTechnologyMapping, TechnologySubTechnologyMappingViewModel>();
            CreateMap<TechnologySubTechnologyMappingViewModel, TechnologySubTechnologyMapping>();

            // Year
            CreateMap<CAYear, YearViewModel>();
            CreateMap<YearViewModel, CAYear>();

            // Contract Type
            CreateMap<ContractType, ContractTypeViewModel>();
            CreateMap<ContractTypeViewModel, ContractType>();

            // TaxRate
            CreateMap<TaxRate, TaxRateViewModel>();
            CreateMap<TaxRateViewModel, TaxRate>();

            // Currency
            CreateMap<Currency, CurrencyViewModel>();
            CreateMap<CurrencyViewModel, Currency>();

            // Quarter
            CreateMap<Quarter, QuarterViewModel>();
            CreateMap<QuarterViewModel, Quarter>();

            // Employee type
            CreateMap<EmployeeType, EmployeeTypeViewModel>();
            CreateMap<EmployeeTypeViewModel, EmployeeType>();

            // Industry Segment
            CreateMap<IndustrySegment, IndustrySegmentViewModel>();
            CreateMap<IndustrySegmentViewModel, IndustrySegment>();

            // Industry Sub Segment
            CreateMap<IndustrySubSegment, IndustrySubSegmentViewModel>();
            CreateMap<IndustrySubSegmentViewModel, IndustrySubSegment>();

            // Rate Card StandardCostViewModel
            CreateMap<RateCard, StandardCostViewModel>();
            CreateMap<StandardCostViewModel, RateCard>();

            // FxRate
            CreateMap<FxRate, FxRateViewModel>();
            CreateMap<FxRateViewModel, FxRate>();

            // Industry Segment Sub Segment Mapping
            CreateMap<IndustrySegmentSubSegmentMapping, IndustrySegmentSubSegmentMappingViewModel>();
            CreateMap<IndustrySegmentSubSegmentMappingViewModel, IndustrySegmentSubSegmentMapping>();

            // Project Organization
            CreateMap<ProjectOrganization, ProjectOrganizationViewModel>();
            CreateMap<ProjectOrganizationViewModel, ProjectOrganization>();

            // WorkLocation
            CreateMap<WorkLocation, WorkLocationViewModel>();
            CreateMap<WorkLocationViewModel, WorkLocation>();

            // WorkLocationResourceRoleMapping
            CreateMap<WorkLocationResourceRoleMapping, WorkLocationResourceRoleMappingViewModel>();
            CreateMap<WorkLocationResourceRoleMappingViewModel, WorkLocationResourceRoleMapping>();

            // Reporting Practice
            CreateMap<ReportingPractice, ReportingPracticeViewModel>();
            CreateMap<ReportingPracticeViewModel, ReportingPractice>();

            // ProjectOrganizationReportingPractice Mapping
            CreateMap<ProjectOrganizationReportingPracticeMapping, ProjectOrganizationReportingPracticeMappingViewModel>();
            CreateMap<ProjectOrganizationReportingPracticeMappingViewModel, ProjectOrganizationReportingPracticeMapping>();

            // Region
            CreateMap<Region, RegionViewModel>();
            CreateMap<RegionViewModel, Region>();

            // Global Solution
            CreateMap<GlobalSolution, GlobalSolutionViewModel>();
            CreateMap<GlobalSolutionViewModel, GlobalSolution>();

            // Delivery Model
            CreateMap<DeliveryModel, DeliveryModelViewModel>();
            CreateMap<DeliveryModelViewModel, DeliveryModel>();

            // Project Domain
            CreateMap<ProjectDomain, ProjectDomainViewModel>();
            CreateMap<ProjectDomainViewModel, ProjectDomain>();

            // Payment Terms
            CreateMap<PaymentTerms, PaymentTermsViewModel>();
            CreateMap<PaymentTermsViewModel, PaymentTerms>();

            // Role
            CreateMap<Role, RoleViewModel>();
            CreateMap<RoleViewModel, Role>();

            // User Role
            CreateMap<UserRole, UserRoleViewModel>();
            CreateMap<UserRoleViewModel, UserRole>();

            // Project Deal Type
            CreateMap<ProjectDealType, ProjectDealTypeViewModel>();
            CreateMap<ProjectDealTypeViewModel, ProjectDealType>();

            // ApproverTypes
            CreateMap<ApproverType, ApproverTypeViewModel>();
            CreateMap<ApproverTypeViewModel, ApproverType>();

            // StatusActions
            CreateMap<StatusAction, StatusActionViewModel>();
            CreateMap<StatusActionViewModel, StatusAction>();

            // Email Entity
            CreateMap<EmailEntity, EmailEntityViewModel>();
            CreateMap<EmailEntityViewModel, EmailEntity>();

            // StatusType
            CreateMap<StatusType, StatusTypeViewModel>();
            CreateMap<StatusTypeViewModel, StatusType>();

            // Client Master
            CreateMap<ClientMaster, ClientMasterViewModel>();
            CreateMap<ClientMasterViewModel, ClientMaster>();

            // Client Billing Address
            CreateMap<ClientBillingAddress, ClientBillingAddressViewModel>();
            CreateMap<ClientBillingAddressViewModel, ClientBillingAddress>();

            // Opportunity
            CreateMap<Opportunity, OpportunityViewModel>();
            CreateMap<OpportunityViewModel, Opportunity>();

            // Opportunity Access
            CreateMap<OpportunityAccess, OpportunityAccessViewModel>();
            CreateMap<OpportunityAccessViewModel, OpportunityAccess>();

            // DocumentType
            CreateMap<DocumentType, DocumentTypeViewModel>();
            CreateMap<DocumentTypeViewModel, DocumentType>();

            // Place Holders
            CreateMap<EmailTemplatePlaceHolder, EmailTemplatePlaceHolderViewModel>();
            CreateMap<EmailTemplatePlaceHolderViewModel, EmailTemplatePlaceHolder>();

            // Financial Expense Detail
            CreateMap<FinancialNonBillableExpenseDetail, FinancialNonBillableExpenseDetailViewModel>();
            CreateMap<FinancialNonBillableExpenseDetailViewModel, FinancialNonBillableExpenseDetail>();

            // Financial Managed Services
            CreateMap<FinancialManagedServiceDetail, FinancialManagedServiceDetailViewModel>();
            CreateMap<FinancialManagedServiceDetailViewModel, FinancialManagedServiceDetail>();

            // Financial Billable Exxpense Detail
            CreateMap<FinancialBillableExpenseDetail, FinancialBillableExpenseDetailViewModel>();
            CreateMap<FinancialBillableExpenseDetailViewModel, FinancialBillableExpenseDetail>();

            // PaymentTermApprovalTracker
            CreateMap<PaymentTermApprovalTracker, PaymentTermApprovalTrackerViewModel>();
            CreateMap<PaymentTermApprovalTrackerViewModel, PaymentTermApprovalTracker>();

            // EmailCommentsByUser
            CreateMap<EmailCommentsByUser, EmailCommentsByUserViewModel>();
            CreateMap<EmailCommentsByUserViewModel, EmailCommentsByUser>();

            // OpportunityType
            CreateMap<OpportunityType, OpportunityTypeViewModel>();
            CreateMap<OpportunityTypeViewModel, OpportunityType>();

            // Finance Employee Detail
            CreateMap<FinancialEmployeeDetail, FinancialEmployeeDetailViewModel>();
            CreateMap<FinancialEmployeeDetailViewModel, FinancialEmployeeDetail>();

            // Finance Contractor Detail
            CreateMap<FinancialContractorDetail, FinancialContractorDetailViewModel>();
            CreateMap<FinancialContractorDetailViewModel, FinancialContractorDetail>();

            // Finance Employer Work Hour Entry
            CreateMap<FinancialEmployeeWorkHourEntry, FinancialEmployeeWorkHourEntryViewModel>();
            CreateMap<FinancialEmployeeWorkHourEntryViewModel, FinancialEmployeeWorkHourEntry>();

            // Finance Contractor Work Hour Entry
            CreateMap<FinancialContractorWorkHourEntry, FinancialContractorWorkHourEntryViewModel>();
            CreateMap<FinancialContractorWorkHourEntryViewModel, FinancialContractorWorkHourEntry>();

            // NextStatusActionByStatusTypeMappingService
            CreateMap<NextStatusActionByStatusTypeMapping, NextStatusActionByStatusTypeMappingViewModel>();
            CreateMap<NextStatusActionByStatusTypeMappingViewModel, NextStatusActionByStatusTypeMapping>();

            // OpportunityProjectSummary
            CreateMap<OpportunityProjectSummary, OpportunityProjectSummaryViewModel>();
            CreateMap<OpportunityProjectSummaryViewModel, OpportunityProjectSummary>();

            // OpportunityProjectSummary
            CreateMap<OpportunityProjectSummaryCapability, OpportunityProjectSummaryCapabilityViewModel>();
            CreateMap<OpportunityProjectSummaryCapabilityViewModel, OpportunityProjectSummaryCapability>();

            // OpportunityProjectSummaryGlobalSolution
            CreateMap<OpportunityProjectSummaryGlobalSolution, OpportunityProjectSummaryGlobalSolutionViewModel>();
            CreateMap<OpportunityProjectSummaryGlobalSolutionViewModel, OpportunityProjectSummaryGlobalSolution>();

            // OpportunityProjectSummaryTechnology
            CreateMap<OpportunityProjectSummaryTechnology, OpportunityProjectSummaryTechnologyViewModel>();
            CreateMap<OpportunityProjectSummaryTechnologyViewModel, OpportunityProjectSummaryTechnology>();

            // OpportunityWorkLocation
            CreateMap<OpportunityWorkLocation, OpportunityWorkLocationViewModel>();
            CreateMap<OpportunityWorkLocationViewModel, OpportunityWorkLocation>();

            // FinancialInitialSetup
            CreateMap<FinancialInitialSetup, FinancialInitialSetupViewModel>();
            CreateMap<FinancialInitialSetupViewModel, FinancialInitialSetup>();

            // RateCardByOpportunity
            CreateMap<RateCardByOpportunity, RateCardByOpportunityViewModel>();
            CreateMap<RateCardByOpportunityViewModel, RateCardByOpportunity>();

            // OmfFinancialSections
            CreateMap<OmfFinancialSections, OmfFinancialSectionsViewModel>();
            CreateMap<OmfFinancialSectionsViewModel, OmfFinancialSections>();

            // DefaultSectionByContractType
            CreateMap<DefaultSectionByContractType, DefaultSectionByContractTypeViewModel>();
            CreateMap<DefaultSectionByContractTypeViewModel, DefaultSectionByContractType>();

            // IncludeSectionByContractType
            CreateMap<IncludeSectionByContractType, IncludeSectionByContractTypeViewModel>();
            CreateMap<IncludeSectionByContractTypeViewModel, IncludeSectionByContractType>();

            // OpportunitySections
            CreateMap<OpportunitySections, OpportunitySectionsViewModel>();
            CreateMap<OpportunitySectionsViewModel, OpportunitySections>();

            // Work flow config
            CreateMap<WorkFlow, WorkFlowConfigViewModel>();
            CreateMap<WorkFlowConfigViewModel, WorkFlow>();

            // work flow templates
            CreateMap<WorkFlowTemplateMapping, WorkFlowTemplateMappingViewModel>();
            CreateMap<WorkFlowTemplateMappingViewModel, WorkFlowTemplateMapping>();

            // ResourceRole
            CreateMap<ResourceRole, ResourceRoleViewModel>();
            CreateMap<ResourceRoleViewModel, ResourceRole>();

            // OMFScreens
            CreateMap<OMFScreens, OMFScreensViewModel>();
            CreateMap<OMFScreensViewModel, OMFScreens>();

            // ScreenActions
            CreateMap<ScreenActions, ScreenActionsViewModel>();
            CreateMap<ScreenActionsViewModel, ScreenActions>();

            CreateMap<OMFJourney, OMFJourneyViewModel>();
            CreateMap<OMFJourneyViewModel, OMFJourney>();

            CreateMap<OpportunityRisks, OpportunityRisksViewModel>();
            CreateMap<OpportunityRisksViewModel, OpportunityRisks>();

            CreateMap<OpportunityOverview, OpportunityOverviewViewModel>();
            CreateMap<OpportunityOverviewViewModel, OpportunityOverview>();

            CreateMap<OpportunityProjectDetails, OpportunityProjectDetailsViewModel>();
            CreateMap<OpportunityProjectDetailsViewModel, OpportunityProjectDetails>();

            CreateMap<CROpportunity, CROpportunityViewModel>();
            CreateMap<CROpportunityViewModel, CROpportunity>();

            CreateMap<OpportunityRating, OpportunityRatingViewModel>();
            CreateMap<OpportunityRatingViewModel, OpportunityRating>();

            CreateMap<LineOfBusiness, LineOfBusinessViewModel>();
            CreateMap<LineOfBusinessViewModel, LineOfBusiness>();

            //CreateMap<ClientScreeningInformation, ClientScreeningInformationViewModel>().ForSourceMember(source => source.Question1Comments, opt => opt.Ignore()).ForSourceMember(source => source.Question13Comments, opt => opt.Ignore()).ForSourceMember(source => source.Question15Comments, opt => opt.Ignore()).ForSourceMember(source => source.Question1UploadContent, opt => opt.Ignore()).ForSourceMember(source => source.Question1UploadFileExtension, opt => opt.Ignore()).ForSourceMember(source => source.Question1UploadFileName, opt => opt.Ignore());

            CreateMap<ComplianceScreeningQuestionnaire, ComplianceScreeningQuestionnaireViewModel>().ForMember(dest => dest.Question1Comments, opt => opt.Ignore()).ForMember(dest => dest.Question13Comments, opt => opt.Ignore()).ForMember(dest => dest.Question15Comments, opt => opt.Ignore()).ForMember(dest => dest.Question1UploadContent, opt => opt.Ignore()).ForMember(dest => dest.Question1UploadFileExtension, opt => opt.Ignore()).ForMember(dest => dest.Question1UploadFileName, opt => opt.Ignore());

            //CreateMap<InfoFinancialSummaryViewModel, OpportunityTotalPlannedRevenue>().ForSourceMember(source => source.ProjectEndDate, opt => opt.Ignore()).ForSourceMember(source => source.ProjectStartDate, opt => opt.Ignore()).ForSourceMember(source => source.OracleProjectName, opt => opt.Ignore()).ForSourceMember(source => source.ProjectCode, opt => opt.Ignore()).ForSourceMember(source => source.ClientName, opt => opt.Ignore()).ForSourceMember(source => source.ProjectName, opt => opt.Ignore()).ForSourceMember(source => source.ReportingPracticeName, opt => opt.Ignore());

            CreateMap<SubTechnologyAlliance, SubTechAllianceViewModel>();
            CreateMap<SubTechAllianceViewModel, SubTechnologyAlliance>();

            CreateMap<COP, COPViewModel>();
            CreateMap<COPViewModel, COP>();

            CreateMap<ApproverByWorkLocationMappingViewModel, ApproverByWorkLocationLineOfBusinessMapping>();
            CreateMap<ApproverByWorkLocationMappingViewModel, ApproverByWorkLocationCOPMapping>();

            CreateMap<ApproverByWorkLocation, ApproverByWorkLocationViewModel>();
            CreateMap<ApproverByWorkLocationViewModel, ApproverByWorkLocation>();

            CreateMap<WorkLocationWorkFlowConfigViewModel, WorkLocationWorkFlow>();
            CreateMap<WorkLocationWorkFlow, WorkLocationWorkFlowConfigViewModel>();

            CreateMap<WorkLocationWorkFlowTemplateMapping, WorkLocationWorkFlowTemplateMappingViewModel>();
            CreateMap<WorkLocationWorkFlowTemplateMappingViewModel, WorkLocationWorkFlowTemplateMapping>();

            CreateMap<Issues, IssuesViewModel>();
            CreateMap<IssuesViewModel, Issues>();

            CreateMap<OMFSupport, OMFSupportViewModel>();
            CreateMap<OMFSupportViewModel, OMFSupport>();

            CreateMap<ApproverByWorkLocationMappingViewModel, ApproverByWorkLocationMapping>();
            CreateMap<ApproverByWorkLocationMapping, ApproverByWorkLocationMappingViewModel>();

            CreateMap<ORBApprovalCriteria, ORBApprovalCriteriaViewModel>();
            CreateMap<ORBApprovalCriteriaViewModel, ORBApprovalCriteria>();

            CreateMap<OpportunityCRDetails, OpportunityCRDetailsViewModel>();
            CreateMap<OpportunityCRDetailsViewModel, OpportunityCRDetails>();

            CreateMap<FinancialBillableExpensesWithDetails, FinancialBillableExpensesWithDetailsViewModel>();
            CreateMap<FinancialBillableExpensesWithDetailsViewModel, FinancialBillableExpensesWithDetails>();

            CreateMap<FinancialAnnualMaintenanceCost, FinancialAnnualMaintenanceCostViewModel>();
            CreateMap<FinancialAnnualMaintenanceCostViewModel, FinancialAnnualMaintenanceCost>();

            CreateMap<ExportControlScreening, ExportControlScreeningViewModel>();
            CreateMap<ExportControlScreeningViewModel, ExportControlScreening>();

            CreateMap<ApproverByRegionAndLineOfBusiness, ApproverByRegionAndLineOfBusinessViewModel>();
            CreateMap<ApproverByRegionAndLineOfBusinessViewModel, ApproverByRegionAndLineOfBusiness>();

            CreateMap<ApproverByRegionAndLineOfBusinessMapping, ApproverByRegionAndLineOfBusinessMappingViewModel>();
            CreateMap<ApproverByRegionAndLineOfBusinessMappingViewModel, ApproverByRegionAndLineOfBusinessMapping>();

            CreateMap<FinancialOpportunityPGMTargetPercentByYear, FinancialOpportunityPGMTargetPercentByYearViewModel>();
            CreateMap<FinancialOpportunityPGMTargetPercentByYearViewModel, FinancialOpportunityPGMTargetPercentByYear>();

            CreateMap<OpportunityComplianceUserAssignedToMapping, OpportunityComplianceUserMappingViewModel>();
            CreateMap<OpportunityComplianceUserMappingViewModel, OpportunityComplianceUserAssignedToMapping>();

            CreateMap<OpportunityComplianceUserMappingViewModel, OpportunityComplianceUserAssignedToMapping_History>();
            CreateMap<ORBCategoryApproverViewModel, ORBCategoryUserRoleMapping>();
            CreateMap<ORBCategoryUserRoleMapping, ORBCategoryApproverViewModel>();

            CreateMap<ORBWorkFlowViewModel, ORBWorkFlow>();
            CreateMap<ORBWorkFlow, ORBWorkFlowViewModel>();

            CreateMap<PeriscopeModelOutput, PeriscopeModelOutputViewModel>();

            CreateMap<FinancialsDiscountAndRebate, FinancialsDiscountAndRebateViewModel>();
            CreateMap<FinancialsDiscountAndRebateViewModel, FinancialsDiscountAndRebate>();

            CreateMap<FinancialsStaffAugmentation, FinancialsStaffAugmentationViewModel>();
            CreateMap<FinancialsStaffAugmentationViewModel, FinancialsStaffAugmentation>();

            CreateMap<HVContractingEntity, HVContractingEntityViewModel>();
            CreateMap<HVContractingEntityViewModel, HVContractingEntity>();

            CreateMap<ORBMarketApproverViewModel, ORBMarketUserRoleMapping>();
            CreateMap<ORBMarketUserRoleMapping, ORBMarketApproverViewModel>();

            CreateMap<ORBSalesLeadApproverViewModel, ORBSalesLeadUserRoleMapping>();
            CreateMap<ORBSalesLeadUserRoleMapping, ORBSalesLeadApproverViewModel>();

            CreateMap<Opportunity, OpportunitiesViewModel>();
            CreateMap<OpportunitiesViewModel, Opportunity>();

            CreateMap<FinancialRoyaltyDetails, FinancialRoyaltyDetailsViewModel>();
            CreateMap<FinancialRoyaltyDetailsViewModel, FinancialRoyaltyDetails>();

            CreateMap<IFRS15CheckList, IFRS15CheckListViewModel>();
            CreateMap<IFRS15CheckListViewModel, IFRS15CheckList>();

            CreateMap<IFRS23CheckList, IFRSRevenueTeamCheckListViewModel>();
            CreateMap<IFRSRevenueTeamCheckListViewModel, IFRS23CheckList>();

            CreateMap<OpportunityIFRSUserAssignedToMapping, OpportunityComplianceUserMappingViewModel>();
            CreateMap<OpportunityComplianceUserMappingViewModel, OpportunityIFRSUserAssignedToMapping>();

            CreateMap<DPAUploadStatus, DPAUploadStatusViewModel>();
            CreateMap<DPAUploadStatusViewModel, DPAUploadStatus>();

            CreateMap<ReasonForFundingReduction, ReasonForFundingReductionViewModel>();
            CreateMap<ReasonForFundingReductionViewModel, ReasonForFundingReduction>();

            CreateMap<IFRSReferBackOnHoldReason, IFRSReferBackOnHoldReasonViewModel>();
            CreateMap<IFRSReferBackOnHoldReasonViewModel, IFRSReferBackOnHoldReason>();

            CreateMap<FundingReduction, FundingReductionViewModel>();
            CreateMap<FundingReductionViewModel, FundingReduction>();

            CreateMap<IFRSReferBackOnHoldReasonByOpportunity, IFRSReferBackOnHoldReasonByOpportunityViewModel>();
            CreateMap<IFRSReferBackOnHoldReasonByOpportunityViewModel, IFRSReferBackOnHoldReasonByOpportunity>();

            CreateMap<PCReferBackOnHoldReason, PCReferBackOnHoldReasonViewModel>();
            CreateMap<PCReferBackOnHoldReasonViewModel, PCReferBackOnHoldReason>();

            CreateMap<PCReferBackOnHoldReasonByOpportunity, PCReferBackOnHoldReasonByOpportunityViewModel>();
            CreateMap<PCReferBackOnHoldReasonByOpportunityViewModel, PCReferBackOnHoldReasonByOpportunity>();

            CreateMap<FundingReductionJourney, FundingReductionJourneyViewModel>();
            CreateMap<FundingReductionJourneyViewModel, FundingReductionJourney>();

            CreateMap<FundingReduction, FundingReductionBasicDetailsViewModel>();
            CreateMap<FundingReductionBasicDetailsViewModel, FundingReduction>();

            CreateMap<FundingReductionEmailCommentsByUserViewModel, FundingReductionEmailCommentsByUser>();
            CreateMap<FundingReductionEmailCommentsByUser, FundingReductionEmailCommentsByUserViewModel>();

            CreateMap<OpportunityQpeDetails, OpportunityQpeDetailsViewModel>();
            CreateMap<OpportunityQpeDetailsViewModel, OpportunityQpeDetails>();

            CreateMap<UserRegistrationRequest, UserRegistrationRequestViewModel>();
            CreateMap<UserRegistrationRequestViewModel, UserRegistrationRequest>();

            CreateMap<OpportunityLeveragePercentVariance, OpportunityLeveragePercentVarianceViewModel>();
            CreateMap<OpportunityLeveragePercentVarianceViewModel, OpportunityLeveragePercentVariance>();

            CreateMap<LeveragePercentageConfiguration, LeveragePercentageConfigurationViewModel>();
            CreateMap<LeveragePercentageConfigurationViewModel, LeveragePercentageConfiguration>();
        }
    }
}
