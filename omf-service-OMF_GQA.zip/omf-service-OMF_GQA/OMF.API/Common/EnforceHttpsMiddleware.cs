﻿namespace OMF.API.Common
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;

    public class EnforceHttpsMiddleware
    {
        private readonly RequestDelegate next;

        public EnforceHttpsMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            HttpRequest req = context.Request;
            if (req.IsHttps == false)
            {
                //string url = "https://" + req.Host + req.Path + req.QueryString;
                //context.Response.Redirect(url, permanent: true);
            }
            else
            {
                await next(context);
            }
            await next(context);
        }
    }
}
