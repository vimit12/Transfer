﻿namespace OMF.API.Common
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Net.Http.Json;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.WebUtilities;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Caching.Memory;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Options;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using OMF.Business.Common;
    using OMF.Data.Models;

    public class TokenAuthenticationMiddleware
    {
        private readonly RequestDelegate next;
        private readonly IHttpClientFactory httpClientFactory;

        private IMemoryCache memoryCache;

        private string cacheKey = "UserRoles";
        private string roleEntity = "Role";

        public TokenAuthenticationMiddleware(RequestDelegate requestDelegate, IOptions<AuthenticationSettings> myOptions, IMemoryCache cache, IHttpClientFactory httpClientFactory)
        {
            next = requestDelegate;
            memoryCache = cache;
            this.httpClientFactory = httpClientFactory;
        }

        private OMFContext DatabaseContext { get; set; }

        public async Task Invoke(HttpContext context, IOptions<AuthenticationSettings> myOptions)
        {
            AuthenticationSettings authenticationOptions;
            authenticationOptions = myOptions.Value;

            if (context.Request.Path.Value.Contains("Login") || context.Request.Path.Value.Contains("Register"))
            {
                try
                {

                    string body;
                    using (var streamReader = new HttpRequestStreamReader(context.Request.Body, System.Text.Encoding.UTF8))
                    using (var jsonReader = new JsonTextReader(streamReader))
                    {

                        var json = await JObject.LoadAsync(jsonReader);

                        var client = httpClientFactory.CreateClient("login");
                        client.BaseAddress = new Uri(authenticationOptions.AuthenticationUrl + authenticationOptions.AuthenticationRelativeUrl);
                        HttpContent httpcontent = new StringContent(json.ToString());
                        httpcontent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        var response = await client.PostAsync(client.BaseAddress, httpcontent);
                        var result = await response.Content.ReadAsStringAsync();
                        await context.Response.WriteAsync(result);
                        return;
                    }
                }
                catch (Exception e)
                {
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsync("Un-authorized");
                    return;
                }

            }

            // Check whether request contains authorization header
            if (context.Request.Headers.Keys.Contains("Authorization"))
            {
                string tokenHeader = context.Request.Headers["Authorization"];
                string[] tokens = tokenHeader.Split(" ");
                string basicAuthenticationCode = authenticationOptions.CheckTokenAppId + ":" + authenticationOptions.CheckTokenAppSecret; // authenticationCode;
                byte[] encodedAuthenticationCodeBytes = System.Text.Encoding.UTF8.GetBytes(basicAuthenticationCode);
                string encodedAuthenticationCode = Convert.ToBase64String(encodedAuthenticationCodeBytes);

                HttpResponseMessage response = GetUserDetails(encodedAuthenticationCode, tokens[1], authenticationOptions);

                if (response.IsSuccessStatusCode)
                {
                    var data = response.Content.ReadAsStringAsync().Result;
                    var userIdentity = JsonConvert.DeserializeObject<UserIdentity>(data);

                    var optionsBuilder = new DbContextOptionsBuilder<OMFContext>();

                    // optionsBuilder.UseNpgsql(connectionString);
                    optionsBuilder.UseNpgsql(authenticationOptions.ConnectionString);
                    DatabaseContext = new OMFContext(optionsBuilder.Options);

                    context.User = GetClaimsPrincipal(userIdentity, tokenHeader, authenticationOptions);

                    if (string.IsNullOrEmpty(context.User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.Role).Value))
                    {
                        context.Response.StatusCode = 401;
                        await context.Response.WriteAsync("Un-authorized");
                        return;
                    }
                }
                else if (context.Request.Path.Value.Contains("login"))
                {

                }
                else if (context.Request.Path.Value.Contains("CreateUserRegistrationRequest") ||
                   context.Request.Path.Value.Contains("CheckDuplicateUsernameorEmail"))
                {

                }
                else
                {
                    // return unauthorized status
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsync("Un-authorized");
                    return;
                }
            }

            await next.Invoke(context);
        }

        private ClaimsPrincipal GetClaimsPrincipal(UserIdentity userIdentity, string token, AuthenticationSettings authenticationOptions)
        {
            if (userIdentity == null)
            {
                return null;
            }

            ICollection<UserRole> userRoles = null;

            // Get All User Roles
            userRoles = GetUserRoles();

            // build claims from employee data
            var claims = BuildClaims(userIdentity, userRoles);

            // Create Claims Principal
            var userClaimIdentity = new ClaimsIdentity(claims, "Token");
            var userPrincipal = new ClaimsPrincipal(userClaimIdentity);

            return userPrincipal;
        }

        private ICollection<UserRole> GetUserRoles()
        {
            // Get application level user roles
            if (!memoryCache.TryGetValue(cacheKey, out ICollection<UserRole> userRoles))
            {
                userRoles = DatabaseContext.Set<UserRole>().Include(roleEntity).ToList();

                var cacheEntryOptions = new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(5));

                memoryCache.Set(cacheKey, userRoles, cacheEntryOptions);
            }

            return userRoles;
        }

        private HttpResponseMessage GetUserDetails(string encodedAuthenticationCode, string token, AuthenticationSettings authenticationOptions)
        {
            // Validate token and get user details
            var client = new HttpClient
            {
                // BaseAddress = new Uri(authenticationServiceBaseUrl)
                BaseAddress = new Uri(authenticationOptions.CheckTokenUrl)
            };
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("Authorization", "Basic " + encodedAuthenticationCode);

            // var urlRelative = authenticationServiceRelativeUrl + token;
            var urlRelative = authenticationOptions.CheckTokenRelativeUrl + token;

            HttpResponseMessage response = client.PostAsync(urlRelative, null).Result;
            return response;
        }

        private ICollection<Claim> BuildClaims(UserIdentity userIdentity, ICollection<UserRole> userRoles)
        {
            string userEmail = string.Empty;
            string role = string.Empty;
            int roleId = 0;
            string firstName = string.Empty;
            string lastName = string.Empty;
            string userId = string.Empty;

            var user = userRoles.Where(row => row.UserId.Equals(userIdentity.user_name, StringComparison.OrdinalIgnoreCase) && row.IsActive && row.Role.IsActive).FirstOrDefault();

            if (user != null && user.Role != null && !string.IsNullOrEmpty(user.Role.RoleName))
            {
                roleId = user.RoleId;
                role = user.Role.RoleName;
                userEmail = user.UserEmail;
                firstName = user.FirstName;
                lastName = user.LastName;
                userId = user.UserId;
            }

            // Generate Claims
            var claims = new List<Claim>
                        {
                            new Claim(ClaimTypes.Role, role, ClaimValueTypes.String),
                            new Claim(Constants.User.Alias, userIdentity.user_name, ClaimValueTypes.String),
                            new Claim(Constants.User.RoleId, roleId.ToString(), ClaimValueTypes.Integer32),
                            new Claim(Constants.User.UserId, userId, ClaimValueTypes.String),
                            new Claim(Constants.User.FirstName, firstName, ClaimValueTypes.String),
                            new Claim(Constants.User.LastName, lastName, ClaimValueTypes.String),
                            new Claim(Constants.User.UserEmail, userEmail, ClaimValueTypes.String),
                        };

            return claims;
        }
    }
}