﻿namespace OMF.API.Common
{
    public class Error
    {
        public string Message { get; set; }

        public string Stacktrace { get; set; }
    }
}
