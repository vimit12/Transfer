﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class TechnologySubTechnologyMappingController : Controller
    {
        private readonly ITechnologySubTechnologyMappingService technologySubTechnologyMappingService;

        private readonly ILogger<TechnologySubTechnologyMappingController> logger;

        public TechnologySubTechnologyMappingController(ITechnologySubTechnologyMappingService service, ILogger<TechnologySubTechnologyMappingController> logger)
        {
            this.technologySubTechnologyMappingService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllTechnologySubTechnologies")]
        public IActionResult GetAllTechnologySubTechnologies()
        {
            logger.LogInformation("GetAllCapabilitySubCapabilities");
            try
            {
                var capabilitySubCapabilityMappings = technologySubTechnologyMappingService.GetAllTechnologySubTechnologies();
                return Ok(new ApiOkResponse(capabilitySubCapabilityMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllCapabilitySubCapabilities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddTechnologySubTechnology")]
        public IActionResult AddTechnologySubTechnology([FromBody]TechnologySubTechnologyMappingViewModel technologySubTechnologyMappingViewModel)
        {
            logger.LogInformation("AddTechnologySubTechnology");
            try
            {
                technologySubTechnologyMappingViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                technologySubTechnologyMappingService.AddTechnologySubTechnology(technologySubTechnologyMappingViewModel);
                return Ok(new ApiOkResponse(technologySubTechnologyMappingViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddTechnologySubTechnology() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}