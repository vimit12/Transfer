﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class FinancialSoftwareHardwareDetailController : Controller
    {
        private readonly IFinancialSoftwareHardwareDetailService fshdService;
        private readonly ILogger<ColaController> logger;

        public FinancialSoftwareHardwareDetailController(IFinancialSoftwareHardwareDetailService service, ILogger<ColaController> logger)
        {
            this.fshdService = service;
            this.logger = logger;
        }

        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetFinancialSoftwareHardwareDetail")]
        public IActionResult GetFinancialSoftwareHardwareDetail(int opportunityId, int yearId)
        {
            logger.LogInformation("GetFinancialSoftwareHardwareDetail");
            try
            {
                var financialSoftwareHardwareDetails = fshdService.GetFSHD(opportunityId, yearId);
                return Ok(new ApiOkResponse(financialSoftwareHardwareDetails));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetFinancialSoftwareHardwareDetail() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetFinancialSoftwareHardwareDetailsByOpportunityId")]
        public IActionResult GetFinancialSoftwareHardwareDetailsByOpportunityId(int opportunityId, int yearId)
        {
            logger.LogInformation("GetFinancialSoftwareHardwareDetailsByOpportunityId");
            try
            {
                var financialSoftwareHardwareDetails = fshdService.GetFSHDByOpportunityId(opportunityId, yearId);
                return Ok(new ApiOkResponse(financialSoftwareHardwareDetails));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetFinancialSoftwareHardwareDetailsByOpportunityId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateFinancialSoftwareHardwareDetails")]
        public IActionResult UpdateFinancialSoftwareHardwareDetails([FromBody]List<FinancialSoftwareHardwareDetailViewModel> model)
        {
            logger.LogInformation("UpdateFinancialSoftwareHardwareDetails", model);
            try
            {
                fshdService.UpdateFSHD(model);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateFinancialSoftwareHardwareDetails() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }


        [HttpGet("{oppId}")]
        [ActionName("ExtractSoftwareHardwareDetailsTemplate")]
        public IActionResult ExtractSoftwareHardwareDetailsTemplate(int oppId)
        {
            logger.LogInformation("ExtractSoftwareHardwareDetailsTemplate");
            try
            {
                var template = fshdService.ExtractSoftwareHardwareDetailsTemplate(oppId, out string fileName);
                fileName = fileName.Replace(" ", "_");
                return Ok(new ApiOkResponse(new
                {
                    FileName = fileName,
                    Excel = template
                }));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ExtractContractorDetailsTemplate()");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("UploadSoftwareHardwareDetails")]
        public IActionResult UploadSoftwareHardwareDetails([FromBody]EmployeeFileUploadDetailsViewModel fileUploadDetails)
        {
            logger.LogInformation("UploadSoftwareHardwareDetails");
            try
            {
                string message = string.Empty;
                var uploadResult = fshdService.UploadSoftwareHardwareDetails(fileUploadDetails, out message, out string newFile);
                if (uploadResult.Length == 0)
                {
                    return Ok(new ApiOkResponse(new
                    {
                        Message = "Upload successful",
                        Excel = uploadResult,
                        FileName = newFile
                    }));
                }
                else
                {
                    return Ok(new ApiOkResponse(new
                    {
                        Message = "Please check the excel for issues - fix the issues and try uploading again - " + message,
                        Excel = uploadResult,
                        FileName = newFile
                    }));
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UploadSoftwareHardwareDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
