﻿namespace OMF.API.Controllers
{
    using System;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;

    [EnableCors("CorsPolicy")]
    [Route("api/omf/[controller]")]
    public class UserController : Controller
    {
        private readonly IUserService userService;

        private readonly AuthenticationSettings authenticationSettings;
        private readonly ILogger<UserController> logger;

        public UserController(IUserService service, IOptions<AuthenticationSettings> options, ILogger<UserController> logger)
        {
            userService = service;
            authenticationSettings = options.Value;
            this.logger = logger;
        }

        [HttpGet]
        public IActionResult GetUserDetails()
        {
            logger.LogInformation("GetUserDetails");
            try
            {
                UserViewModel userViewModel = userService.GetUserDetails();
                return Ok(new ApiOkResponse(userViewModel));
            }
            catch (Exception e)
            {
                logger.LogError(e, "GetUserDetails - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
