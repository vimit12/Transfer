﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ColaController : Controller
    {
        private readonly IColaService colaService;
        private readonly ILogger<ColaController> logger;

    public ColaController(IColaService service, ILogger<ColaController> logger)
        {
            this.colaService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetColaByFYear")]
        public IActionResult GetColaByFYear()
        {
            logger.LogInformation("GetAllCola");
            try
            {
               var currentFYColaValues = colaService.GetCurrentFinancialYearCola();
                return Ok(new ApiOkResponse(currentFYColaValues));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllCola() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("ModifyColaByFYear")]
        public IActionResult SaveColaByFYear([FromBody]IEnumerable<ColaValues> colaValues)
        {
            logger.LogInformation("SaveColaByFYear");
            try
            {
                colaService.SaveColaValues(colaValues);
                return Ok(new ApiOkResponse(string.Empty));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveColaByFYear() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
    }