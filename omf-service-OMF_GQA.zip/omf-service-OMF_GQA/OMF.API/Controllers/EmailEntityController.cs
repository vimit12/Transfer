﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class EmailEntityController : Controller
    {
        private readonly IEmailEntityService emailEntityService;

        private readonly ILogger<EmailEntityController> logger;

        public EmailEntityController(IEmailEntityService service, ILogger<EmailEntityController> logger)
        {
            this.emailEntityService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllEmailEntities")]
        public IActionResult GetAllEmailEntities()
        {
            logger.LogInformation("GetAllEmailEntities");
            try
            {
                var emailEntity = emailEntityService.GetAllEmailEntities();
                return Ok(new ApiOkResponse(emailEntity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllEmailEntities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveEmailEntities")]
        public IActionResult GetActiveEmailEntities()
        {
            logger.LogInformation("GetActiveEmailEntities");
            try
            {
                var emailEntity = emailEntityService.GetActiveEmailEntities();
                return Ok(new ApiOkResponse(emailEntity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveEmailEntities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetEmailEntityById")]
        public IActionResult GetEmailEntityById(int id)
        {
            try
            {
                logger.LogInformation("GetEmailEntityById");
                var emailEntity = emailEntityService.GetEmailEntityById(id);
                return Ok(new ApiOkResponse(emailEntity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetEmailEntityById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddEmailEntity")]
        public IActionResult AddEmailEntity([FromBody]EmailEntityViewModel emailEntity)
        {
            logger.LogInformation("AddEmailEntity");
            try
            {
                emailEntity.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                emailEntityService.AddEmailEntity(emailEntity);
                return Ok(new ApiOkResponse(emailEntity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddEmailEntity() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateEmailEntity")]
        public IActionResult UpdateEmailEntity([FromBody]EmailEntityViewModel emailEntity)
        {
            logger.LogInformation("UpdateEmailEntity", emailEntity);
            try
            {
                var getemailEntity = emailEntityService.GetEmailEntityById(emailEntity.EmailEntityId);
                if (getemailEntity == null)
                {
                    return NotFound("Payment Term not found.");
                }
                else
                {
                    emailEntity.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    emailEntityService.UpdateEmailEntity(emailEntity);
                    return Ok(new ApiOkResponse(emailEntity));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateEmailEntity() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateDatesRemovingWeekEnds")]
        public IActionResult UpdateDatesRemovingWeekEnds()
        {
            logger.LogInformation("UpdateDatesRemovingWeekEnds");
            try
            {
                emailEntityService.UpdateDatesRemovingWeekEnds();
                return Ok(new ApiOkResponse(Constants.NotificationSent));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateDatesRemovingWeekEnds() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
