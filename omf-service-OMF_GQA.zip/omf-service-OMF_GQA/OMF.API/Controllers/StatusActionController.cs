﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]

    public class StatusActionController : Controller
    {
        private readonly IStatusActionService statusActionService;
        private readonly ILogger<ColaController> logger;

        public StatusActionController(IStatusActionService service, ILogger<ColaController> logger)
        {
            this.statusActionService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetStatusActions")]
        public IActionResult GetStatusActions()
        {
            logger.LogInformation("GetStatusActions");
            try
            {
                var statusActions = statusActionService.GetStatusActions();
                return Ok(new ApiOkResponse(statusActions));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetStatusActions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveStatusActions")]
        public IActionResult GetActiveStatusActions()
        {
            logger.LogInformation("GetActiveStatusActions");
            try
            {
                var statusActions = statusActionService.GetActiveStatusActions();
                return Ok(new ApiOkResponse(statusActions));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveStatusActions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddStausAction")]
        public IActionResult AddStausAction([FromBody] StatusActionViewModel model)
        {
            logger.LogInformation("AddStausAction");
            try
            {
                model.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                statusActionService.AddStausAction(model);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddStausAction() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateStatusAction")]
        public IActionResult UpdateStatusAction([FromBody]StatusActionViewModel statusActionViewModel)
        {
            logger.LogInformation("UpdateStatusAction", statusActionViewModel);
            try
            {
                if (statusActionViewModel != null)
                {
                    var statusAction = statusActionService.GetStatusActionById(statusActionViewModel.StatusActionId);
                    if (statusAction == null)
                    {
                        return NotFound(" UpdateStatusAction not found.");
                    }
                    else
                    {
                        statusActionViewModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                        statusActionService.UpdateStatusAction(statusActionViewModel);
                        return Ok(new ApiOkResponse(statusActionViewModel));
                    }
                }
                else
                {
                    return NotFound(" UpdateStatusAction is null.");
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateStatusAction() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetOmfScreens")]
        public IActionResult GetOmfScreens()
        {
            logger.LogInformation("GetOmfScreens");
            try
            {
                var omfScreens = statusActionService.GetOmfScreens();
                return Ok(new ApiOkResponse(omfScreens));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOmfScreens() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}