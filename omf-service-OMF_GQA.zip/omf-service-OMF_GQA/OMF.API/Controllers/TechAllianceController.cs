﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]

    public class TechAllianceController : Controller
    {
        private readonly ITechAllianceService techAllianceService;

        private readonly ILogger<TechAllianceController> logger;

        public TechAllianceController(ITechAllianceService service, ILogger<TechAllianceController> logger)
        {
            this.techAllianceService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllTechAlliance")]
        public IActionResult GetTechAlliance()
        {
            logger.LogInformation("GetAllTechAlliance");
            try
            {
                var techAlliance = techAllianceService.GetTechAlliance();
                return Ok(new ApiOkResponse(techAlliance));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllTechAlliance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetTechAllianceById")]
        public IActionResult GetTechAllianceById(int id)
        {
            try
            {
                logger.LogInformation("GetTechAllianceById");
                var tech = techAllianceService.GetTechAllianceById(id);
                return Ok(new ApiOkResponse(tech));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetTechAllianceById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveTechnologies")]
        public IActionResult GetActiveTechnologies()
        {
            logger.LogInformation("GetActiveTechnologies");
            try
            {
                var technologies = techAllianceService.GetActiveTechnologies();
                return Ok(new ApiOkResponse(technologies));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveTechnologies() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }


        [HttpPost]
        [ActionName("AddTechAlliance")]
        public IActionResult AddTechAlliance([FromBody]TechAllianceViewModel tech)
        {
            logger.LogInformation("AddTechAlliance");
            try
            {
                tech.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                techAllianceService.AddTechAlliance(tech);
                return Ok(new ApiOkResponse(tech));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddTechAlliance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateTechAlliance")]
        public IActionResult UpdateTechAlliance([FromBody]TechAllianceViewModel tech)
        {
            logger.LogInformation("UpdateTechAlliance", tech);
            try
            {
                var gettechnology = techAllianceService.GetTechAllianceById(tech.TechnologyId);
                if (gettechnology == null)
                {
                    // logger.LogWarning("country is null", country);
                    return NotFound("Technology is not found.");
                }
                else
                {
                    tech.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    techAllianceService.UpdateTechAlliance(tech);
                    return Ok(new ApiOkResponse(tech));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateTechAlliance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
