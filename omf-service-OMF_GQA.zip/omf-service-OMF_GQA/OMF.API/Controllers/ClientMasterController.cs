﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ClientMasterController : ControllerBase
    {
        private readonly IClientMasterService clientMasterService;

        private readonly ILogger<ClientMasterController> logger;

        public ClientMasterController(IClientMasterService service, ILogger<ClientMasterController> logger)
        {
            this.clientMasterService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllClients")]
        public IActionResult GetClientMasters()
        {
            logger.LogInformation("GetAllClients");
            try
            {
                var clients = clientMasterService.GetClientMasters();
                return Ok(new ApiOkResponse(clients));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllClients() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveClients")]
        public IActionResult GetActiveCountries()
        {
            logger.LogInformation("GetActiveClients");
            try
            {
                var clients = clientMasterService.GetActiveClientMasters();
                return Ok(new ApiOkResponse(clients));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveClients() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveClientDetails")]
        public IActionResult GetActiveClientDetails()
        {
            logger.LogInformation("GetActiveClientDetails");
            try
            {
                var clients = clientMasterService.GetActiveClientDetails();
                return Ok(new ApiOkResponse(clients));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveClientDetails() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddClientMaster")]
        public IActionResult AddClientMaster([FromBody]ClientMasterViewModel clientMaster)
        {
            this.logger.LogInformation("AddClientMaster");
            try
            {
                clientMaster.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.clientMasterService.AddClientMaster(clientMaster);
                return this.Ok(new ApiOkResponse(clientMaster));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddClientMaster() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateClientMaster")]
        public IActionResult UpdateClientMaster([FromBody]ClientMasterViewModel clientMaster)
        {
            this.logger.LogInformation("UpdateClientMaster", clientMaster);
            try
            {
                var getprojectDomain = this.clientMasterService.GetClientMasterById(clientMaster.ClientMasterId);
                if (getprojectDomain == null)
                {
                    return this.NotFound("Client Not Found.");
                }
                else
                {
                    clientMaster.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.clientMasterService.UpdateClientMaster(clientMaster);
                    return this.Ok(new ApiOkResponse(clientMaster));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateClientMaster() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetClientDetailsById")]
        public IActionResult GetClientDetailsById(int id)
        {
            logger.LogInformation("GetActiveClientDetails");
            try
            {
                var clients = clientMasterService.GetClientDetailsById(id);
                return Ok(new ApiOkResponse(clients));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetClientDetailsById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}