﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ProjectOrganizationReportingPracticeMappingController : Controller
    {
        private readonly IProjectOrganizationReportingPracticeMappingService poRPMappingService;

        private readonly ILogger<ProjectOrganizationReportingPracticeMappingController> logger;

        public ProjectOrganizationReportingPracticeMappingController(IProjectOrganizationReportingPracticeMappingService service, ILogger<ProjectOrganizationReportingPracticeMappingController> logger)
        {
            this.poRPMappingService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllProjectOrganizationReportingPracticeMappings")]
        public IActionResult GetAllProjectOrganizationReportingPracticeMappings()
        {
            this.logger.LogInformation("GetAllPOReportingPracticeMappings");
            try
            {
                var poRPMappings = this.poRPMappingService.GetAllProjectOrganizationReportingPracticeMappings();
                return this.Ok(new ApiOkResponse(poRPMappings));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllPOReportingPracticeMappings() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddProjectOrganizationReportingPracticeMapping")]
        public IActionResult AddProjectOrganizationReportingPracticeMapping([FromBody]ProjectOrganizationReportingPracticeMappingViewModel poReportingPracticeMappingViewModel)
        {
            logger.LogInformation("AddProjectOrganizationReportingPracticeMapping");
            try
            {
                poReportingPracticeMappingViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                poRPMappingService.AddProjectOrganizationReportingPracticeMapping(poReportingPracticeMappingViewModel);
                return Ok(new ApiOkResponse(poReportingPracticeMappingViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddProjectOrganizationReportingPracticeMapping() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}