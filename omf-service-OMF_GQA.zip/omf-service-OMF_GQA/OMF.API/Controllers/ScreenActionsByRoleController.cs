﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ScreenActionsByRoleController : Controller
    {
        private readonly IScreenActionsByRoleService screenActionsByRoleService;

        private readonly ILogger<ScreenActionsByRoleController> logger;

        public ScreenActionsByRoleController(IScreenActionsByRoleService service, ILogger<ScreenActionsByRoleController> logger)
        {
            this.screenActionsByRoleService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllScreenActionsByRole")]
        public IActionResult GetAllScreenActionsByRole()
        {
            logger.LogInformation("GetAllScreenActionsByRole");
            try
            {
                var result = screenActionsByRoleService.GetAllScreenActionsByRole();
                return Ok(new ApiOkResponse(result));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllScreenActionsByRole() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActionOMFScreens")]
        public IActionResult GetActionOMFScreens()
        {
            logger.LogInformation("GetActionOMFScreens");
            try
            {
                var result = screenActionsByRoleService.GetActionOMFScreens();
                return Ok(new ApiOkResponse(result));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActionOMFScreens() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveScreenActions")]
        public IActionResult GetActiveScreenActions()
        {
            logger.LogInformation("GetActiveScreenActions");
            try
            {
                var result = screenActionsByRoleService.GetActiveScreenActions();
                return Ok(new ApiOkResponse(result));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveScreenActions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("GetScreenActionsByScreenIdRoleId")]
        public IActionResult GetScreenActionsByScreenIdRoleId([FromBody]RoleScreenActionsViewModel model)
        {
            logger.LogInformation("GetScreenActionsByScreenIdRoleId");
            try
            {
                var result = screenActionsByRoleService.GetScreenActionsByScreenIdRoleId(model);
                return Ok(new ApiOkResponse(result));
            }
            catch (Exception exception)
            {
                logger.LogInformation(exception, "GetScreenActionsByScreenIdRoleId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("ModifyRoleScreenActions")]
        public IActionResult ModifyRoleScreenActions([FromBody]RoleScreenActionsViewModel model)
        {
            logger.LogInformation("ModifyRoleScreenActions");
            try
            {
                var validate = screenActionsByRoleService.ValidateRoleScreen(model, out string errorMessage);
                if (!validate)
                {
                    return BadRequest(errorMessage);
                }

                screenActionsByRoleService.ModifyRoleScreenActions(model);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "ModifyRoleScreenActions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
