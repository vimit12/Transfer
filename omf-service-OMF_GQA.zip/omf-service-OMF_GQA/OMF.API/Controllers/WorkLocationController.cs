﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class WorkLocationController : Controller
    {
        private readonly IWorkLocationService workLocationService;

        private readonly ILogger<WorkLocationController> logger;

        public WorkLocationController(IWorkLocationService service, ILogger<WorkLocationController> logger)
        {
            this.workLocationService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllWorkLocations")]
        public IActionResult GetAllWorkLocations()
        {
            logger.LogInformation("GetAllWorkLocations");
            try
            {
                var workLocations = workLocationService.GetWorkLocations();
                return Ok(new ApiOkResponse(workLocations));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllWorkLocations() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveWorkLocations")]
        public IActionResult GetActiveWorkLocations()
        {
            logger.LogInformation("GetActiveWorkLocations");
            try
            {
                var workLocations = workLocationService.GetActiveWorkLocations();
                return Ok(new ApiOkResponse(workLocations));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveWorkLocations() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetWorkLocationResourceMapping")]
        public IActionResult GetWorkLocationResourceMapping(DefaultRateCardInputViewModel defaultRateCardInput)
        {
            logger.LogInformation("GetWorkLocationResourceMapping");
            try
            {
                var workLocationResourceRoleMappings = workLocationService.GetWorkLocationResourceMapping(defaultRateCardInput.Id, defaultRateCardInput.YearId, defaultRateCardInput.OppourtunityBaseCurrencyId);
                return Ok(new ApiOkResponse(workLocationResourceRoleMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetWorkLocationResourceMapping() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetWorkLocationResourceByOpportunity")]
        public IActionResult GetWorkLocationResourceByOpportunity(DefaultRateCardInputViewModel defaultRate)
        {
            logger.LogInformation("GetWorkLocationResourceMapping");
            try
            {
                var workLocationResourceRoleMappings = workLocationService.GetWorkLocationResourceByOpportunity(defaultRate);
                return Ok(new ApiOkResponse(workLocationResourceRoleMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetWorkLocationResourceMapping() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetWorkLocationDeliveryModel")]
        public IActionResult GetWorkLocationDeliveryModel(int id)
        {
            try
            {
                logger.LogInformation("GetWorkLocationDeliveryModel");
                var workLocation = workLocationService.GetWorkLocationDeliveryModel(id);
                return Ok(new ApiOkResponse(workLocation));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetWorkLocationDeliveryModel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetWorkLocationById")]
        public IActionResult GetWorkLocationById(int id)
        {
            try
            {
                logger.LogInformation("GetWorkLocationById");
                var workLocation = workLocationService.GetWorkLocationById(id);
                return Ok(new ApiOkResponse(workLocation));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetWorkLocationById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetCurrencyList")]
        public IActionResult GetCurrencyList()
        {
            logger.LogInformation("GetCurrencyList");
            try
            {
                var currencies = workLocationService.GetCurrencyList();
                return Ok(new ApiOkResponse(currencies));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetCurrencyList() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddWorkLocation")]
        public IActionResult AddWorkLocation([FromBody]WorkLocationViewModel workLocationViewModel)
        {
            logger.LogInformation("AddWorkLocation");
            try
            {
                workLocationViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                workLocationService.AddWorkLocation(workLocationViewModel);
                return Ok(new ApiOkResponse(workLocationViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddWorkLocation() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateWorkLocation")]
        public IActionResult UpdateWorkLocation([FromBody]WorkLocationViewModel workLocationViewModel)
        {
            logger.LogInformation("UpdateWorkLocation", workLocationViewModel);
            try
            {
                var workLocation = workLocationService.GetWorkLocationById(workLocationViewModel.WorkLocationId);
                if (workLocation == null)
                {
                    return NotFound("WorkLocation not found.");
                }
                else
                {
                    workLocationViewModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    workLocationService.UpdateWorkLocation(workLocationViewModel);
                    return Ok(new ApiOkResponse(workLocationViewModel));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateWorkLocation() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
