﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class IndustrySegmentSubSegmentMappingController : Controller
    {
        private readonly IIndustrySegmentSubSegmentMappingService industrySegmentSubSegmentMappingService;

        private readonly ILogger<IndustrySegmentSubSegmentMappingController> logger;

        public IndustrySegmentSubSegmentMappingController(IIndustrySegmentSubSegmentMappingService service, ILogger<IndustrySegmentSubSegmentMappingController> logger)
        {
            this.industrySegmentSubSegmentMappingService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllIndustrySegmentSubSegments")]
        public IActionResult GetAllIndustrySegmentSubSegments()
        {
            logger.LogInformation("GetAllIndustrySegmentSubSegments");
            try
            {
                var industrySegmentSubSegmentMappings = industrySegmentSubSegmentMappingService.GetAllIndustrySegmentSubSegments();
                return Ok(new ApiOkResponse(industrySegmentSubSegmentMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllIndustrySegmentSubSegments() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddIndustrySegmentSubSegment")]
        public IActionResult AddIndustrySegmentSubSegment([FromBody]IndustrySegmentSubSegmentMappingViewModel industrySegmentSubSegmentMappingViewModel)
        {
            logger.LogInformation("AddIndustrySegmentSubSegment");
            try
            {
                industrySegmentSubSegmentMappingViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                industrySegmentSubSegmentMappingService.AddIndustrySegmentSubSegment(industrySegmentSubSegmentMappingViewModel);
                return Ok(new ApiOkResponse(industrySegmentSubSegmentMappingViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddIndustrySegmentSubSegment() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{segmentId}")]
        [ActionName("GetSubSegmentsBySegmentId")]
        public IActionResult GetSubSegmentsBySegmentId(int segmentId)
        {
            logger.LogInformation("GetSubSegmentsBySegmentId");
            try
            {
                var industrySegmentSubSegmentMappings = industrySegmentSubSegmentMappingService.GetSubSegmnetsBySegmentId(segmentId);
                return Ok(new ApiOkResponse(industrySegmentSubSegmentMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetSubSegmentsBySegmentId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}