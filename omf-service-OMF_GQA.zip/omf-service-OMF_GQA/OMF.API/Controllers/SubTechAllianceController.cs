﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]

    public class SubTechAllianceController : Controller
    {
        private readonly ISubTechAllianceService subTechAllianceService;

        private readonly ILogger<TechAllianceController> logger;

        public SubTechAllianceController(ISubTechAllianceService service, ILogger<TechAllianceController> logger)
        {
            this.subTechAllianceService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetSubTechAlliance")]
        public IActionResult GetSubTechAlliance()
        {
            logger.LogInformation("GetAllTechAlliance");
            try
            {
                var techAlliance = subTechAllianceService.GetSubTechAlliance();
                return Ok(new ApiOkResponse(techAlliance));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllTechAlliance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveSubTechnologies")]
        public IActionResult GetActiveSubTechnologies()
        {
            logger.LogInformation("GetActiveSubTechnologies");
            try
            {
                var subTechnologies = subTechAllianceService.GetActiveSubTechnologies();
                return Ok(new ApiOkResponse(subTechnologies));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveSubTechnologies() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveSubTechnologiesWithTechnologyId")]
        public IActionResult GetActiveSubTechnologiesWithTechnologyId()
        {
            logger.LogInformation("GetActiveSubTechnologies");
            try
            {
                var subTechnologies = subTechAllianceService.GetActiveSubTechnologiesWithTechnologyId();
                return Ok(new ApiOkResponse(subTechnologies));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveSubTechnologiesWithTechnologyId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetSubTechAllianceById")]
        public IActionResult GetSubTechAllianceById(int id)
        {
            try
            {
                logger.LogInformation("GetTechAllianceById");
                var tech = subTechAllianceService.GetSubTechAllianceById(id);
                return Ok(new ApiOkResponse(tech));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetTechAllianceById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddSubTechAlliance")]
        public IActionResult AddSubTechAlliance([FromBody]SubTechAllianceViewModel tech)
        {
            logger.LogInformation("AddTechAlliance");
            try
            {
                tech.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                subTechAllianceService.AddSubTechAlliance(tech);
                return Ok(new ApiOkResponse(tech));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddTechAlliance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateSubTechAlliance")]
        public IActionResult UpdateSubTechAlliance([FromBody]SubTechAllianceViewModel tech)
        {
            logger.LogInformation("UpdateTechAlliance", tech);
            try
            {
                var gettechnology = subTechAllianceService.GetSubTechAllianceById(tech.SubTechnologyAllianceId);
                if (gettechnology == null)
                {
                    // logger.LogWarning("country is null", country);
                    return NotFound("Technology is not found.");
                }
                else
                {
                    tech.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    subTechAllianceService.UpdateSubTechAlliance(tech);
                    return Ok(new ApiOkResponse(tech));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateTechAlliance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
