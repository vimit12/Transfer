﻿namespace OMF.API.Controllers
{
    using System;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class DocumentTypeController : Controller
    {
        private readonly IDocumentTypeService documentTypeService;

        private readonly ILogger<DocumentTypeController> logger;

        public DocumentTypeController(IDocumentTypeService service, ILogger<DocumentTypeController> logger)
        {
            this.documentTypeService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetActiveDocumentTypes")]
        public IActionResult GetActiveDocumentTypes()
        {
            logger.LogInformation("GetActiveDocumentTypes");
            try
            {
                var documentTypes = documentTypeService.GetActiveDocumentTypes();
                return Ok(new ApiOkResponse(documentTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveDocumentTypes() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
