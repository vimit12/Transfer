﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class RateCardController : Controller
    {
        private readonly IRateCardService rateCardService;

        private readonly ILogger<RateCardController> logger;

        public RateCardController(IRateCardService service, ILogger<RateCardController> logger)
        {
            this.rateCardService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetBillRate")]
        public IActionResult GetBillRate(CurrencyRateViewModel currencyRate)
        {
            logger.LogInformation("GetBillRate");
            try
            {
                var rateCard = rateCardService.GetBillRate(currencyRate);
                return Ok(new ApiOkResponse(rateCard));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetBillRate() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetWLRateCard")]
        public IActionResult GetWLRateCard(CurrencyRateViewModel currencyRate)
        {
            logger.LogInformation("GetWLRateCard");
            try
            {
                var rateCard = rateCardService.GetWLRateCard(currencyRate);
                return Ok(new ApiOkResponse(rateCard));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetWLRateCard() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetRateCardByOpportunity")]
        public IActionResult GetRateCardByOpportunity(DefaultRateCardInputViewModel inputRate)
        {
            logger.LogInformation("GetRateCardByOpportunity");
            try
            {
                var rateCard = rateCardService.GetRateCardByOpportunity(inputRate);
                return Ok(new ApiOkResponse(rateCard));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetRateCardByOpportunity() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateRateCard")]
        public IActionResult UpdateRateCard([FromBody]IEnumerable<StandardCostViewModel> standardCost)
        {
            logger.LogInformation("UpdateRateCard", standardCost);
            try
            {
                rateCardService.UpdateStandardCost(standardCost);
                return Ok(new ApiOkResponse(standardCost));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateRateCard() - Exception", standardCost);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddRateCardByOpportunity")]
        public IActionResult AddRateCardByOpportunity([FromBody]RateCardForWorkLocationsViewModel rateCardForWork)
        {
            logger.LogInformation("AddRateCardByOpportunity", rateCardForWork);
            try
            {
                rateCardForWork.CreatedBy = string.Empty;
                rateCardService.AddRateCardByOpportunity(rateCardForWork);
                return Ok(new ApiOkResponse(rateCardForWork));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddRateCardByOpportunity() - Exception", rateCardForWork);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateRateCardByOpportunity")]
        public IActionResult UpdateRateCardByOpportunity([FromBody]List<RateCardByOpportunityViewModel> rateCardForWork)
        {
            logger.LogInformation("UpdateRateCardByOpportunity", rateCardForWork);
            try
            {
                rateCardService.UpdateRateCardByOpportunity(rateCardForWork);
                return Ok(new ApiOkResponse(rateCardForWork));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateRateCardByOpportunity() - Exception", rateCardForWork);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetCommentsSummary")]
        public IActionResult GetCommentsSummary(RateCardCommentsViewModel comments)
        {
            logger.LogInformation("GetCommentsSummary", comments);
            try
            {
                var commentsSummary = rateCardService.GetCommentsSummary(comments);
                return Ok(new ApiOkResponse(commentsSummary));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetCommentsSummary() - Exception", comments);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{yearId}")]
        [ActionName("ExtractRateCardByYear")]
        public IActionResult ExtractRateCardByYear(int yearId)
        {
            logger.LogInformation("ExtractRateCardByYear");
            try
            {
                var rateCard = rateCardService.ExtractRateCardByYear(yearId);
                return Ok(new ApiOkResponse(rateCard));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "ExtractRateCardByYear() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetPGMTargetPercentagesForOpportunityAndYear")]
        public IActionResult GetPGMTargetPercentagesForOpportunityAndYear(int opportunityId, int yearId)
        {
            logger.LogInformation("GetPGMTargetPercentagesForOpportunityAndYear");
            try
            {
                var rateCard = rateCardService.GetPGMTargetPercentagesForOpportunityAndYear(opportunityId, yearId);
                return Ok(new ApiOkResponse(rateCard));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetPGMTargetPercentagesForOpportunityAndYear() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveOrUpdatePGMTargetPercentages")]
        public IActionResult SaveOrUpdatePGMTargetPercentages([FromBody]IList<FinancialOpportunityPGMTargetPercentByYearViewModel> modelList)
        {
            logger.LogInformation("SaveOrUpdatePGMTargetPercentages", modelList);
            try
            {
                rateCardService.SaveOrUpdatePGMTargetPercentages(modelList);
                return Ok(new ApiOkResponse(modelList));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveOrUpdatePGMTargetPercentages() - Exception", modelList);
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
