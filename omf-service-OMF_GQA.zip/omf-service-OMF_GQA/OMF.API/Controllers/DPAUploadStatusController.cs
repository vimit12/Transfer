﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class DPAUploadStatusController : Controller
    {
        private readonly IDPAUploadStatusService dpaUploadStatusService;
        private readonly ILogger<DPAUploadStatusController> logger;

        public DPAUploadStatusController(IDPAUploadStatusService service, ILogger<DPAUploadStatusController> logger)
        {
            this.dpaUploadStatusService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetActiveDPAUploadStatuses")]
        public IActionResult GetDPAUploadStatuses()
        {
            logger.LogInformation("GetDPAUploadStatuses");
            try
            {
               var currentFYColaValues = dpaUploadStatusService.GetActiveDPAUploadStatuses();
                return Ok(new ApiOkResponse(currentFYColaValues));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveDPAUploadStatuses() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}