﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class CurrencyController : Controller
    {
        private readonly ICurrencyService currencyService;

        private readonly ILogger<CurrencyController> logger;

        public CurrencyController(ICurrencyService service, ILogger<CurrencyController> logger)
        {
            this.currencyService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllCurrencies")]
        public IActionResult GetAllCurrencies()
        {
            logger.LogInformation("GetAllCurrencies");
            try
            {
                var currencies = currencyService.GetAllCurrencies();
                return Ok(new ApiOkResponse(currencies));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllCurrencies() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetCurrencies")]
        public IActionResult GetActiveCurrencies()
        {
            logger.LogInformation("GetCurrencies");
            try
            {
                var currencies = currencyService.GetActiveCurrencies();
                return Ok(new ApiOkResponse(currencies));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetCurrencies() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetCurrencyById")]
        public IActionResult GetCurrencyById(int id)
        {
            try
            {
                logger.LogInformation("GetCurrencyById");
                var currency = currencyService.GetCurrencyById(id);
                return Ok(new ApiOkResponse(currency));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetCurrencyById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddCurrency")]
        public IActionResult AddCurrency([FromBody]CurrencyViewModel currency)
        {
            logger.LogInformation("AddCurrency");
            try
            {
                currency.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                currencyService.AddCurrency(currency);
                return Ok(new ApiOkResponse(currency));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddCurrency() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateCurrency")]
        public IActionResult UpdateCurrency([FromBody]CurrencyViewModel currency)
        {
            logger.LogInformation("UpdateCurrency", currency);
            try
            {
                var currencyObj = currencyService.GetCurrencyById(currency.CurrencyId);
                if (currencyObj == null)
                {
                    return NotFound("Currency not found.");
                }
                else
                {
                    currency.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    currencyService.UpdateCurrency(currency);
                    return Ok(new ApiOkResponse(currency));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateCurrency() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}