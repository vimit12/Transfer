﻿// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class WorkLocationWorkFlowController : Controller
    {
        private readonly IWorkLocationWorkFlowService workLocationWorkFlowService;

        private readonly IWorkflowService workFlowService;

        private readonly ILogger<WorkLocationWorkFlowController> logger;

        public WorkLocationWorkFlowController(IWorkLocationWorkFlowService service, ILogger<WorkLocationWorkFlowController> logger, IWorkflowService workflowService)
        {
            this.workLocationWorkFlowService = service;
            this.workFlowService = workflowService;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetWorkLocationWorkFlowActionsByStatus")]
        public IActionResult GetWorkLocationWorkFlowActionsByStatus(WorkFlowActionsViewModel workFlowActionsViewModel)
        {
            logger.LogInformation("GetWorkLocationWorkFlowActionsByStatus()");
            try
            {
                var actions = workLocationWorkFlowService.GetWorkLocationWorkFlowActionsByStatus(workFlowActionsViewModel);
                return Ok(new ApiOkResponse(actions));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetWorkLocationWorkFlowActionsByStatus");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateNextWorkLocationStatus")]
        public IActionResult UpdateNextWorkLocationStatus([FromBody]WorkLocationWorkFlowActionViewModel workFlowActionViewModel)
        {
            logger.LogInformation("UpdateNextWorkLocationStatus()");
            try
            {
                    var currentWLStatuses = workLocationWorkFlowService.UpdateNextWorkLocationStatus(workFlowActionViewModel);

                if (currentWLStatuses.All(x => x.StatusId == (int)Enums.StatusType.Completed))
                {
                    workLocationWorkFlowService.EndChildWorkFlows(workFlowActionViewModel);
                }

                var autoFlowCheck = CheckWorkFlowAutoProgressPossibility(workFlowActionViewModel.OpportunityId);

                if (autoFlowCheck)
                {
                    WorkFlowAutoProgress(workFlowActionViewModel.OpportunityId);
                }

                return Ok(new ApiOkResponse(currentWLStatuses));

            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateNextWorkLocationStatus");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        private OpportunityBasicDetailsViewModel WorkFlowAutoProgress(int opportunityId)
        {
            return workFlowService.WorkFlowAutoProgress(opportunityId);
        }

        private bool CheckWorkFlowAutoProgressPossibility(int opportunityId)
        {
            var autoActions = workFlowService.CheckWorkFlowAutoProgressPossibility(opportunityId);
            return autoActions == null ? false : true;
        }
    }
}
