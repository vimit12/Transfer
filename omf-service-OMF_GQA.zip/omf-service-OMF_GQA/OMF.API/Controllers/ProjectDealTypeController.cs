﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ProjectDealTypeController : Controller
    {
        private readonly IProjectDealTypeService projectDealTypeService;

        private readonly ILogger<ProjectDealTypeController> logger;

        public ProjectDealTypeController(IProjectDealTypeService service, ILogger<ProjectDealTypeController> logger)
        {
            this.projectDealTypeService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllProjectDealTypes")]
        public IActionResult GetAllProjectDealTypes()
        {
            logger.LogInformation("GetAllProjectDealTypes");
            try
            {
                var projectDealTypes = projectDealTypeService.GetAllProjectDealTypes();
                return Ok(new ApiOkResponse(projectDealTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllProjectDealTypes() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddProjectDealType")]
        public IActionResult AddProjectDealType([FromBody]ProjectDealTypeViewModel projectDealType)
        {
            logger.LogInformation("AddProjectDealType");
            try
            {
                projectDealType.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                projectDealTypeService.AddProjectDealType(projectDealType);
                return Ok(new ApiOkResponse(projectDealType));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddProjectDealType() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetProjectDealTypeById")]
        public IActionResult GetContractTypeById(int id)
        {
            try
            {
                logger.LogInformation("GetProjectDealTypeById");
                var projectDealType = projectDealTypeService.GetProjectDealTypeById(id);
                return Ok(new ApiOkResponse(projectDealType));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetProjectDealTypeById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateProjectDealType")]
        public IActionResult UpdateProjectDealType([FromBody]ProjectDealTypeViewModel projectDealType)
        {
            logger.LogInformation("UpdateProjectDealType", projectDealType);
            try
            {
                var getProjectDealType = projectDealTypeService.GetProjectDealTypeById(projectDealType.ProjectDealTypeId);
                if (getProjectDealType == null)
                {
                    return NotFound("ProjectDealType not found.");
                }
                else
                {
                    projectDealType.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    projectDealTypeService.UpdateProjectDealType(projectDealType);
                    return Ok(new ApiOkResponse(projectDealType));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateProjectDealType() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveProjectDealTypes")]
        public IActionResult GetActiveProjectDealTypes()
        {
            logger.LogInformation("GetActiveProjectDealTypes");
            try
            {
                var projectDealTypes = projectDealTypeService.GetActiveProjectDealTypes();
                return Ok(new ApiOkResponse(projectDealTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveProjectDealTypes() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}