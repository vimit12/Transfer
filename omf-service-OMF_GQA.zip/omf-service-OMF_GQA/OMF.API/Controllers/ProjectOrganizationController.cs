﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ProjectOrganizationController : Controller
    {
        private readonly IProjectOrganizationService projectOrganizationService;

        private readonly ILogger<ProjectOrganizationController> logger;

        public ProjectOrganizationController(IProjectOrganizationService service, ILogger<ProjectOrganizationController> logger)
        {
            this.projectOrganizationService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllProjectOrganizations")]
        public IActionResult GetAllProjectOrganizations()
        {
            logger.LogInformation("GetAllProjectOrganizations");
            try
            {
                var projectOrganization = projectOrganizationService.GetAllProjectOrganizations();
                return Ok(new ApiOkResponse(projectOrganization));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllProjectOrganizations() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetProjectOrganizationById")]
        public IActionResult GetProjectOrganizationById(int id)
        {
            try
            {
                logger.LogInformation("GetProjectOrganizationById");
                var projectOrganization = projectOrganizationService.GetProjectOrganizationById(id);
                return Ok(new ApiOkResponse(projectOrganization));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetProjectOrganizationById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddProjectOrganization")]
        public IActionResult AddProjectOrganization([FromBody]ProjectOrganizationViewModel projectOrganization)
        {
            logger.LogInformation("AddProjectOrganization");
            try
            {
                projectOrganization.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                projectOrganizationService.AddProjectOrganization(projectOrganization);
                return Ok(new ApiOkResponse(projectOrganization));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddProjectOrganization() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateProjectOrganization")]
        public IActionResult UpdateProjectOrganization([FromBody]ProjectOrganizationViewModel projectOrganization)
        {
            logger.LogInformation("UpdateProjectOrganization", projectOrganization);
            try
            {
                var getprojectOrganization = projectOrganizationService.GetProjectOrganizationById(projectOrganization.ProjectOrganizationId);
                if (getprojectOrganization == null)
                {
                    return NotFound("Project Organization not found.");
                }
                else
                {
                    projectOrganization.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    projectOrganizationService.UpdateProjectOrganization(projectOrganization);
                    return Ok(new ApiOkResponse(projectOrganization));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateProjectOrganization() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveProjectOrganizations")]
        public IActionResult GetActiveProjectOrganizations()
        {
            logger.LogInformation("GetActiveProjectOrganizations");
            try
            {
                var projectOrganization = projectOrganizationService.GetActiveProjectOrganizations();
                return Ok(new ApiOkResponse(projectOrganization));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveProjectOrganizations() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetProjectOrganizationDetails")]
        public IActionResult GetProjectOrganizationDetails(int opportunityId)
        {
            logger.LogInformation("GetProjectOrganizationDetails");
            try
            {
                var projectOrganization = projectOrganizationService.GetProjectOrganizationDetails(opportunityId);
                return Ok(new ApiOkResponse(projectOrganization));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetProjectOrganizationDetails() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
        [HttpGet("{id}")]
        [ActionName("ValidateReportingPracticeAndCOPByOppId")]
        public IActionResult ValidateReportingPracticeAndCOPByOppId(int id)
        {
            this.logger.LogInformation("ValidateReportingPracticeAndCOPByOppId");
            try
            {
                var cops = this.projectOrganizationService.ValidateReportingPracticeAndCOPByOppId(id);
                return this.Ok(new ApiOkResponse(cops));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "ValidateReportingPracticeAndCOPByOppId() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
