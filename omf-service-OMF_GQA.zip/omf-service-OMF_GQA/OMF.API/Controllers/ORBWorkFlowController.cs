﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OMF.API.Common;
using OMF.Business.Interfaces;
using OMF.Business.Common;
using OMF.Business.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OMF.API.Controllers
{
    [Route("api/omf/[controller]/[action]")]
    public class ORBWorkFlowController : Controller
    {
        private readonly IORBWorkFlowService orbWorkFlowService;

        private readonly ILogger<ORBWorkFlowController> logger;

        private readonly IHiQService hiQService;

        public ORBWorkFlowController(IORBWorkFlowService workFlowService, ILogger<ORBWorkFlowController> logger, IHiQService hiQService)
        {
            this.orbWorkFlowService = workFlowService;
            this.logger = logger;
            this.hiQService = hiQService;
        }

        [HttpGet]
        [ActionName("GetORBWorkFlows")]
        public IActionResult GetORBWorkFlows()
        {
            logger.LogInformation("GetORBWorkFlows");
            if (!this.ModelState.IsValid)
            {
                return BadRequest(this.ModelState);
            }

            try
            {
                var orbWFs = orbWorkFlowService.GetORBWorkFlows();
                return Ok(new ApiOkResponse(orbWFs));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetORBWorkFlows() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveORBWorkFlows")]
        public IActionResult SaveORBWorkFlows([FromBody]ORBWorkFlowViewModel model)
        {

            try
            {
                logger.LogInformation("SaveORBWorkFlows");
                orbWorkFlowService.SaveORBWorkFlows(model);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "SaveORBWorkFlows() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateORBWorkFlow")]
        public IActionResult UpdateORBWorkFlow([FromBody] ORBWorkFlowViewModel oRBWorkFlowView)
        {
            try
            {
                logger.LogInformation("UpdateORBWorkFlow");
                orbWorkFlowService.UpdateORBWorkFlow(oRBWorkFlowView);
                return this.Ok(new ApiOkResponse(oRBWorkFlowView));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateORBWorkFlow() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetORBWorkFlowActions")]
        public IActionResult GetORBWorkFlowActions(WorkFlowActionsViewModel workFlowViewModel)
        {
            try
            {
                var orbWFs = orbWorkFlowService.GetORBWorkFlowActions(workFlowViewModel);
                return Ok(new ApiOkResponse(orbWFs));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetORBWorkFlowActions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateORBNextStatus")]
        public async Task<IActionResult> UpdateORBNextStatus([FromBody] WorkFlowActionViewModel oRBWorkFlowView)
        {
            try
            {
                logger.LogInformation("UpdateORBNextStatus");
                var result = await orbWorkFlowService.UpdateORBNextStatus(oRBWorkFlowView);
                return this.Ok(new ApiOkResponse(result));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateORBNextStatus() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetORBApprovers")]
        public IActionResult GetORBApprovers(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetORBApprovers", opportunityId);
                return Ok(new ApiOkResponse(orbWorkFlowService.GetORBApprovers(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetORBApprovers", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateORBComments")]
        public IActionResult UpdateORBComments(WorkFlowActionViewModel workFlowViewModel, bool orbHeldToday)
        {
            try
            {
                var orbWFs = hiQService.UpdateORBComments(workFlowViewModel, orbHeldToday);
                return Ok(new ApiOkResponse(orbWFs));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateORBComments() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateOMFDetailsToHiQ")]
        public IActionResult UpdateOMFDetailsToHiQ(WorkFlowActionViewModel workFlowViewModel, bool updateOMFStatus)
        {
            try
            {
                var orbWFs = hiQService.UpdateOMFDetailsToHiQ(workFlowViewModel, updateOMFStatus);
                return Ok(new ApiOkResponse(orbWFs));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateOMFDetailsToHiQ() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
