﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class DeliveryModelController : Controller
    {
        private readonly IDeliveryModelService deliveryModelService;

        private readonly ILogger<DeliveryModelController> logger;

        public DeliveryModelController(IDeliveryModelService service, ILogger<DeliveryModelController> logger)
        {
            this.deliveryModelService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllDeliveryModels")]
        public IActionResult GetAllDeliveryModels()
        {
            logger.LogInformation("GetAllDeliveryModels");
            try
            {
                var deliveryModel = deliveryModelService.GetAllDeliveryModels();
                return Ok(new ApiOkResponse(deliveryModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllDeliveryModels() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveDeliveryModels")]
        public IActionResult GetActiveDeliveryModels()
        {
            logger.LogInformation("GetActiveDeliveryModels");
            try
            {
                var deliveryModel = deliveryModelService.GetActiveDeliveryModels();
                return Ok(new ApiOkResponse(deliveryModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveDeliveryModels() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetDeliveryModelById")]
        public IActionResult GetDeliveryModelById(int id)
        {
            try
            {
                logger.LogInformation("GetDeliveryModelById");
                var deliveryModel = deliveryModelService.GetDeliveryModelById(id);
                return Ok(new ApiOkResponse(deliveryModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetDeliveryModelById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddDeliveryModel")]
        public IActionResult AddDeliveryModel([FromBody]DeliveryModelViewModel deliveryModel)
        {
            logger.LogInformation("AddDeliveryModel");
            try
            {
                deliveryModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                deliveryModelService.AddDeliveryModel(deliveryModel);
                return Ok(new ApiOkResponse(deliveryModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddDeliveryModel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateDeliveryModel")]
        public IActionResult UpdateDeliveryModel([FromBody]DeliveryModelViewModel deliveryModel)
        {
            logger.LogInformation("UpdateDeliveryModel", deliveryModel);
            try
            {
                var getdeliveryModel = deliveryModelService.GetDeliveryModelById(deliveryModel.DeliveryModelId);
                if (getdeliveryModel == null)
                {
                    return NotFound("Delivery Model not found.");
                }
                else
                {
                    deliveryModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    deliveryModelService.UpdateDeliveryModel(deliveryModel);
                    return Ok(new ApiOkResponse(deliveryModel));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateDeliveryModel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
