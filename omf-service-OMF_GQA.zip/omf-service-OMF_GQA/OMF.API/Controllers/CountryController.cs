﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class CountryController : Controller
    {
        private readonly ICountryService countriesService;

        private readonly ILogger<CountryController> logger;

        public CountryController(ICountryService service, ILogger<CountryController> logger)
        {
            this.countriesService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllCountries")]
        public IActionResult GetCountries()
        {
            logger.LogInformation("GetAllCountries");
            try
            {
                var countries = countriesService.GetCountries();
                return Ok(new ApiOkResponse(countries));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllCountries() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveCountries")]
        public IActionResult GetActiveCountries()
        {
            logger.LogInformation("GetActiveCountries");
            try
            {
                var countries = countriesService.GetActiveCountries();
                return Ok(new ApiOkResponse(countries));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveCountries() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetcountryById")]
        public IActionResult GetcountryById(int id)
        {
            try
            {
                logger.LogInformation("GetcountryById");
                var country = countriesService.GetCountryById(id);
                return Ok(new ApiOkResponse(country));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetcountryById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddCountry")]
        public IActionResult AddCountry([FromBody]CountryViewModel country)
        {
            logger.LogInformation("AddCountry");
            try
            {
                country.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                countriesService.AddCountry(country);
                return Ok(new ApiOkResponse(country));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddCountry() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateCountry")]
        public IActionResult UpdateCountry([FromBody]CountryViewModel country)
        {
            logger.LogInformation("UpdateCountry", country);
            try
            {
                var getcountry = countriesService.GetCountryById(country.CountryId);
                if (getcountry == null)
                {
                    // logger.LogWarning("country is null", country);
                    return NotFound("Country not found.");
                }
                else
                {
                    country.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    countriesService.UpdateCountry(country);
                    return Ok(new ApiOkResponse(country));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateCountry() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}