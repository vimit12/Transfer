﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;

    [Route("api/omf/[controller]/[action]")]
    public class COPController : Controller
    {
        private readonly ICOPService copService;

        private readonly ILogger<COPController> logger;

        public COPController(ICOPService service, ILogger<COPController> logger)
        {
            this.copService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllCOPs")]
        public IActionResult GetAllCOPs()
        {
            this.logger.LogInformation("GetAllCOPs");
            try
            {
                var cop = this.copService.GetAllCOPs();
                return this.Ok(new ApiOkResponse(cop));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllCOPs() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{oppId}")]
        [ActionName("GetActiveCOPs")]
        public IActionResult GetActiveLineOfBusinesses(int oppId)
        {
            this.logger.LogInformation("GetActiveCOPs");
            try
            {
                var lineOfBusinesses = this.copService.GetActiveCOPs(oppId);
                return this.Ok(new ApiOkResponse(lineOfBusinesses));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActiveCOPs() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetCOPById")]
        public IActionResult GetCOPById(int id)
        {
            this.logger.LogInformation("GetCOPById");
            try
            {
                var cops = this.copService.GetCOPById(id);
                return this.Ok(new ApiOkResponse(cops));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetCOPById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddCOP")]
        public IActionResult AddCOP([FromBody]COPViewModel cop)
        {
            this.logger.LogInformation("AddCOP");
            try
            {
                cop.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.copService.AddCOP(cop);
                return this.Ok(new ApiOkResponse(cop));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddCOP() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateCOP")]
        public IActionResult UpdateCOP([FromBody]COPViewModel cop)
        {
            this.logger.LogInformation("UpdateCOP", cop);
            try
            {
                var getCOP = this.copService.GetCOPById(cop.COPId);
                if (getCOP == null)
                {
                    return this.NotFound("Type not found.");
                }
                else
                {
                    cop.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.copService.UpdateCOP(cop);
                    return this.Ok(new ApiOkResponse(cop));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateLineOfBusiness() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
        [HttpGet]
        [ActionName("GetActiveCOPs")]
        public IActionResult GetActiveLineOfBusinesses()
        {
            this.logger.LogInformation("GetActiveCOPs");
            try
            {
                var lineOfBusinesses = this.copService.GetActiveCOPs();
                return this.Ok(new ApiOkResponse(lineOfBusinesses));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActiveCOPs() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}