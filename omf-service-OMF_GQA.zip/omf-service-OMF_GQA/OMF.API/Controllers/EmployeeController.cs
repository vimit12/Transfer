﻿namespace OMF.API.Controllers
{
    using System;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;

    [Route("api/omf/[controller]/[action]")]
    public class EmployeeController : Controller
    {
        private readonly IReadEmailIdsService readEmailIdsService;
        private readonly ILogger<EmployeeController> logger;

        public EmployeeController(IReadEmailIdsService service, ILogger<EmployeeController> logger)
        {
            this.readEmailIdsService = service;
            this.logger = logger;
        }

        [HttpGet("{searchString}")]
        [ActionName("GetEmployees")]
        public IActionResult GetEmployees([FromRoute]string searchString)
        {
            try
            {
                logger.LogInformation("GetEmployees");
                return Ok(new ApiOkResponse(readEmailIdsService.GetAllUsers(searchString)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetEmployees");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // POST: api/ReadEmailIds
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/ReadEmailIds/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
