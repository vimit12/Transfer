﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class TaxRateController : Controller
    {
        private readonly ITaxRateService taxRateService;

        private readonly ILogger<TaxRateController> logger;

        public TaxRateController(ITaxRateService service, ILogger<TaxRateController> logger)
        {
            this.taxRateService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllTaxRates")]
        public IActionResult GetAllTaxRates()
        {
            logger.LogInformation("GetAllTaxRates");
            try
            {
                var taxRates = taxRateService.GetTaxRates();
                return Ok(new ApiOkResponse(taxRates));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllTaxRates() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveTaxRates")]
        public IActionResult GetActiveTaxRates()
        {
            logger.LogInformation("GetActiveTaxRates");
            try
            {
                var taxRates = taxRateService.GetActiveTaxRates();
                return Ok(new ApiOkResponse(taxRates));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveTaxRates() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetTaxRateById")]
        public IActionResult GetTaxRateById(int id)
        {
            try
            {
                logger.LogInformation("GetTaxRateById");
                var taxRate = taxRateService.GetTaxRateById(id);
                return Ok(new ApiOkResponse(taxRate));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetTaxRateById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddTaxRate")]
        public IActionResult AddTaxRate([FromBody]TaxRateViewModel taxRateViewModel)
        {
            logger.LogInformation("AddTaxRate");
            try
            {
                taxRateViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                taxRateService.AddTaxRate(taxRateViewModel);
                return Ok(new ApiOkResponse(taxRateViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddTaxRate() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateTaxRate")]
        public IActionResult UpdateTaxRate([FromBody]TaxRateViewModel taxRateViewModel)
        {
            logger.LogInformation("UpdateTaxRate", taxRateViewModel);
            try
            {
                var taxRate = taxRateService.GetTaxRateById(taxRateViewModel.TaxRateId);
                if (taxRate == null)
                {
                    return NotFound("TaxRate not found.");
                }
                else
                {
                    taxRateViewModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    taxRateService.UpdateTaxRate(taxRateViewModel);
                    return Ok(new ApiOkResponse(taxRateViewModel));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateTaxRate() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}