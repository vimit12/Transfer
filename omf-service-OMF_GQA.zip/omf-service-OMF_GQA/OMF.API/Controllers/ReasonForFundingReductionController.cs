﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;

    [Route("api/omf/[controller]/[action]")]
    public class ReasonForFundingReductionController : Controller
    {
        private readonly IReasonForFundingReductionService reasonFundingReductionService;

        private readonly ILogger<ReasonForFundingReductionController> logger;

        public ReasonForFundingReductionController(IReasonForFundingReductionService service, ILogger<ReasonForFundingReductionController> logger)
        {
            this.reasonFundingReductionService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllReasonForFundingReductions")]
        public IActionResult GetAllReasonForFundingReductions()
        {
            this.logger.LogInformation("GetAllReasonForFundingReductions");
            try
            {
                var rff = this.reasonFundingReductionService.GetAllReasonForFundingReductions();
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllReasonForFundingReductions() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveReasonForFundingReductions")]
        public IActionResult GetActiveReasonForFundingReductions()
        {
            this.logger.LogInformation("GetActiveReasonForFundingReductions");
            try
            {
                var rff = this.reasonFundingReductionService.GetActiveReasonForFundingReductions();
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActiveReasonForFundingReductions() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetReasonForFundingReductionById")]
        public IActionResult GetReasonForFundingReductionById(int id)
        {
            this.logger.LogInformation("GetReasonForFundingReductionById");
            try
            {
                var rff = this.reasonFundingReductionService.GetReasonForFundingReductionById(id);
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetReasonForFundingReductionById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddReasonForFundingReduction")]
        public IActionResult AddReasonForFundingReduction([FromBody]ReasonForFundingReductionViewModel rff)
        {
            this.logger.LogInformation("AddReasonForFundingReduction");
            try
            {
                rff.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.reasonFundingReductionService.AddReasonForFundingReduction(rff);
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddReasonForFundingReduction() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateReasonForFundingReduction")]
        public IActionResult UpdateReasonForFundingReduction([FromBody]ReasonForFundingReductionViewModel rff)
        {
            this.logger.LogInformation("UpdateReasonForFundingReduction", rff);
            try
            {
                var getRFF = this.reasonFundingReductionService.GetReasonForFundingReductionById(rff.ReasonForFundingReductionId);
                if (getRFF == null)
                {
                    return this.NotFound("Type not found.");
                }
                else
                {
                    rff.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.reasonFundingReductionService.UpdateReasonForFundingReduction(rff);
                    return this.Ok(new ApiOkResponse(rff));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateReasonForFundingReduction() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}