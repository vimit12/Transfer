﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ApproverTypeController : Controller
    {
        private readonly IApproverTypeService approverService;

        private readonly ILogger<ApproverTypeController> logger;

        public ApproverTypeController(IApproverTypeService service, ILogger<ApproverTypeController> logger)
        {
            this.approverService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetApproverTypes")]
        public IActionResult GetApproverTypes()
        {
            logger.LogInformation("GetApproverTypes");
            try
            {
                var approverTypes = approverService.GetApproverTypes();
                return Ok(new ApiOkResponse(approverTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetApproverTypes() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveApproverTypes")]
        public IActionResult GetActiveApproverTypes()
        {
            logger.LogInformation("GetActiveApproverTypes");
            try
            {
                var approverTypes = approverService.GetActiveApproverTypes();
                return Ok(new ApiOkResponse(approverTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveApproverTypes() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetAproverById")]
        public IActionResult GetApproverById(int id)
        {
            try
            {
                logger.LogInformation("GetApproverById");
                var approveType = approverService.GetApproverTypeById(id);
                return Ok(new ApiOkResponse(approveType));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetApproverById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddApproverType")]
        public IActionResult AddApproverType([FromBody]ApproverTypeViewModel approverType)
        {
            logger.LogInformation("AddCurrency");
            try
            {
                approverService.AddApproverType(approverType);
                return Ok(new ApiOkResponse(approverType));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddApproverType() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateApproverType")]
        public IActionResult UpdateApproverType([FromBody]ApproverTypeViewModel approverType)
        {
            logger.LogInformation("UpdateApproverType", approverType);
            try
            {
                var approverTypeObj = approverService.GetApproverTypeById(approverType.ApproverTypeId);
                if (approverTypeObj == null)
                {
                    return NotFound("Approver Type not found.");
                }
                else
                {
                    approverService.UpdateApproverType(approverType);
                    return Ok(new ApiOkResponse(approverTypeObj));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateApproverType() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetFRApproverType")]
        public IActionResult GetFRApproverType()
        {
            logger.LogInformation("GetFRApproverType");
            try
            {
                var approverTypes = approverService.GetFRApproverType();
                return Ok(new ApiOkResponse(approverTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetFRApproverType() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}