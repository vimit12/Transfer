﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class CapabilitySubCapabilityMappingController : Controller
    {
        private readonly ICapabilitySubCapabilityMappingService capabilitySubCapabilityMappingService;

        private readonly ILogger<CapabilitySubCapabilityMappingController> logger;

        public CapabilitySubCapabilityMappingController(ICapabilitySubCapabilityMappingService service, ILogger<CapabilitySubCapabilityMappingController> logger)
        {
            this.capabilitySubCapabilityMappingService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllCapabilitySubCapabilities")]
        public IActionResult GetAllCapabilitySubCapabilities()
        {
            logger.LogInformation("GetAllCapabilitySubCapabilities");
            try
            {
                var capabilitySubCapabilityMappings = capabilitySubCapabilityMappingService.GetAllCapabilitySubCapabilities();
                return Ok(new ApiOkResponse(capabilitySubCapabilityMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllCapabilitySubCapabilities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddCapabilitySubCapability")]
        public IActionResult AddCapabilitySubCapability([FromBody]CapabilitySubCapabilityMappingViewModel capabilitySubCapabilityMappingViewModel)
        {
            logger.LogInformation("AddCapabilitySubCapability");
            try
            {
                capabilitySubCapabilityMappingViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                capabilitySubCapabilityMappingService.AddCapabilitySubCapability(capabilitySubCapabilityMappingViewModel);
                return Ok(new ApiOkResponse(capabilitySubCapabilityMappingViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddCapabilitySubCapability() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}