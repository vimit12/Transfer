﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class GlobalSolutionController : Controller
    {
        private readonly IGlobalSolutionService globalSolutionService;

        private readonly ILogger<GlobalSolutionController> logger;

        public GlobalSolutionController(IGlobalSolutionService service, ILogger<GlobalSolutionController> logger)
        {
            this.globalSolutionService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllGlobalSolutions")]
        public IActionResult GetAllGlobalSolutions()
        {
            logger.LogInformation("GetAllGlobalSolutions");
            try
            {
                var globalSolution = globalSolutionService.GetAllGlobalSolutions();
                return Ok(new ApiOkResponse(globalSolution));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllGlobalSolutions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetGlobalSolutionById")]
        public IActionResult GetGlobalSolutionById(int id)
        {
            try
            {
                logger.LogInformation("GetGlobalSolutionById");
                var globalSolution = globalSolutionService.GetGlobalSolutionById(id);
                return Ok(new ApiOkResponse(globalSolution));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetGlobalSolutionById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddGlobalSolution")]
        public IActionResult AddGlobalSolution([FromBody]GlobalSolutionViewModel globalSolution)
        {
            logger.LogInformation("AddGlobalSolution");
            try
            {
                globalSolution.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                globalSolutionService.AddGlobalSolution(globalSolution);
                return Ok(new ApiOkResponse(globalSolution));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddGlobalSolution() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateGlobalSolution")]
        public IActionResult UpdateGlobalSolution([FromBody]GlobalSolutionViewModel globalSolution)
        {
            logger.LogInformation("UpdateGlobalSolution", globalSolution);
            try
            {
                var getglobalSolution = globalSolutionService.GetGlobalSolutionById(globalSolution.GlobalSolutionId);
                if (getglobalSolution == null)
                {
                    return NotFound("Global Solution not found.");
                }
                else
                {
                    globalSolution.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    globalSolutionService.UpdateGlobalSolution(globalSolution);
                    return Ok(new ApiOkResponse(globalSolution));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateGlobalSolution() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
