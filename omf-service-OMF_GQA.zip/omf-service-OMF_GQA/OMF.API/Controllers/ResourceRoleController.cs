﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]

    public class ResourceRoleController : Controller
    {
        private readonly IResourceRoleService resourceRoleService;

        private readonly ILogger<ResourceRoleController> logger;

        public ResourceRoleController(IResourceRoleService service, ILogger<ResourceRoleController> logger)
        {
            this.resourceRoleService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllResourceRole")]
        public IActionResult GetResourceRole()
        {
            logger.LogInformation("GetAllResourceRole");
            try
            {
                var resource = resourceRoleService.GetResourceRole();
                return Ok(new ApiOkResponse(resource));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllResourceRole() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveResourceRole")]
        public IActionResult GetActiveResourceRole()
        {
            logger.LogInformation("GetActiveResourceRole");
            try
            {
                var resource = resourceRoleService.GetActiveResourceRole();
                return Ok(new ApiOkResponse(resource));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveResourceRole() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetResourceRoleById")]
        public IActionResult GetResourceRoleById(int id)
        {
            try
            {
                logger.LogInformation("GetResourceRoleById");
                var resource = resourceRoleService.GetResourceRoleById(id);
                return Ok(new ApiOkResponse(resource));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetResourceRoleById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddResourceRole")]
        public IActionResult AddResourceRole([FromBody]ResourceRoleViewModel resource)
        {
            logger.LogInformation("AddResourceRole");
            try
            {
                resource.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                resourceRoleService.AddResourceRole(resource);
                return Ok(new ApiOkResponse(resource));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddResourceRole() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateResourceRole")]
        public IActionResult UpdateResourceRole([FromBody]ResourceRoleViewModel resource)
        {
            logger.LogInformation("UpdateResourceRole", resource);
            try
            {
                var getresource = resourceRoleService.GetResourceRoleById(resource.ResourceRoleId);
                if (getresource == null)
                {
                    // logger.LogWarning("country is null", country);
                    return NotFound("Resource Role is not found.");
                }
                else
                {
                    resource.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    resourceRoleService.UpdateResourceRole(resource);
                    return Ok(new ApiOkResponse(resource));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateTechAlliance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}