﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class YearController : Controller
    {
        private readonly IYearService yearService;

        private readonly ILogger<YearController> logger;

        public YearController(IYearService service, ILogger<YearController> logger)
        {
            this.yearService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllYears")]
        public IActionResult GetAllYears()
        {
            logger.LogInformation("GetAllYears");
            try
            {
                var years = yearService.GetAllYears();
                return Ok(new ApiOkResponse(years));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllYears() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetYearByOrder/{operatr}/{order}")]
        public IActionResult GetYearByOrder(string operatr, string order)
        {
            logger.LogInformation("GetYearByOrder");
            try
            {
                var years = yearService.GetYearByOrder(operatr, order);
                return Ok(new ApiOkResponse(years));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetYearByOrder() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetYearById")]
        public IActionResult GetYearById(int id)
        {
            try
            {
                logger.LogInformation("GetYearById");
                var year = yearService.GetYearById(id);
                return Ok(new ApiOkResponse(year));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetYearById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddYear")]
        public IActionResult AddYear([FromBody]YearViewModel year)
        {
            logger.LogInformation("AddYear");
            try
            {
                year.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                yearService.AddYear(year);
                return Ok(new ApiOkResponse(year));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddYear() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateYear")]
        public IActionResult UpdateYear([FromBody]YearViewModel year)
        {
            logger.LogInformation("UpdateYear", year);
            try
            {
                var getYear = yearService.GetYearById(year.YearId);
                if (getYear == null)
                {
                    return NotFound("Year not found.");
                }
                else
                {
                    year.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    yearService.UpdateYear(year);
                    return Ok(new ApiOkResponse(year));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateYear() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetAllYearsByOrder/{operatr}/{order}")]
        public IActionResult GetAllYearsByOrder(string operatr, string order)
        {
            logger.LogInformation("GetAllYearsByOrder");
            try
            {
                var years = yearService.GetAllYearsByOrder(operatr, order);
                return Ok(new ApiOkResponse(years));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllYearsByOrder() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetFinancialYearsByopprtunityId")]
        public IActionResult GetFinancialYearsByopprtunityId(int id)
        {
            try
            {
                logger.LogInformation("GetFinancialYearsByopprtunityId", id);
                string message = string.Empty;
                var fYears = yearService.GetFinancialYears(id, ref message);
                if (message == string.Empty)
                {
                    return Ok(new ApiOkResponse(fYears));
                }
                else
                {
                    return BadRequest(message);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetFinancialYearsByopprtunityId", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}