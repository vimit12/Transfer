﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Common;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ApproverByWorkLocationController : Controller
    {
        private readonly IApproverByWorkLocationService approverByWorkLocationService;

        private readonly ILogger<ApproverByWorkLocationController> logger;

        public ApproverByWorkLocationController(IApproverByWorkLocationService service, ILogger<ApproverByWorkLocationController> logger)
        {
            this.approverByWorkLocationService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetApproversByWorkLocationLOB")]
        public IActionResult GetApproversByWorkLocationLOB()
        {
            logger.LogInformation("GetApproversByWorkLocationLOB");
            try
            {
                var approversByWorkLocation = approverByWorkLocationService.GetApproversByWorkLocationLOB();
                return Ok(new ApiOkResponse(approversByWorkLocation));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetApproversByWorkLocation() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetApproversByWorkLocationCOP")]
        public IActionResult GetApproversByWorkLocationCOP()
        {
            logger.LogInformation("GetApproversByWorkLocationCOP");
            try
            {
                var approversByWorkLocation = approverByWorkLocationService.GetApproversByWorkLocationCOP();
                return Ok(new ApiOkResponse(approversByWorkLocation));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetApproversByWorkLocation() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddApproverByWorkLocation")]
        public IActionResult AddApproverByWorkLocation([FromBody]ApproverByWorkLocationViewModel approverByWorkLocationViewModel)
        {
            logger.LogInformation("AddApproverByWorkLocation");
            try
            {
                approverByWorkLocationViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                approverByWorkLocationService.AddApproverByWorkLocation(approverByWorkLocationViewModel);
                return Ok(new ApiOkResponse(approverByWorkLocationViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddApproverByWorkLocation() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateApproverByWorkLocation")]
        public IActionResult UpdateApproverByWorkLocation([FromBody]ApproverByWorkLocationViewModel approverByWorkLocationViewModel)
        {
            logger.LogInformation("UpdateApproverByWorkLocation", approverByWorkLocationViewModel);
            try
            {
                approverByWorkLocationViewModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                approverByWorkLocationService.UpdateApproverByWorkLocation(approverByWorkLocationViewModel);
                return Ok(new ApiOkResponse(approverByWorkLocationViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateApproverByWorkLocation() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetApproversByWorkLocation")]
        public IActionResult GetApproversByWorkLocation()
        {
            logger.LogInformation("GetApproversByWorkLocationCOP");
            try
            {
                var approversByWorkLocation = approverByWorkLocationService.GetApproversByWorkLocation();
                return Ok(new ApiOkResponse(approversByWorkLocation));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetApproversByWorkLocation() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
