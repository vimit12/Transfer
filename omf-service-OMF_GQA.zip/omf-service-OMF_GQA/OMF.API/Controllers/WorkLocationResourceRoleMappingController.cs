﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class WorkLocationResourceRoleMappingController : Controller
    {
        private readonly IWorkLocationResourceRoleMappingService workLocationResourceRoleMappingService;

        private readonly ILogger<WorkLocationResourceRoleMappingController> logger;

        public WorkLocationResourceRoleMappingController(IWorkLocationResourceRoleMappingService service, ILogger<WorkLocationResourceRoleMappingController> logger)
        {
            this.workLocationResourceRoleMappingService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllWorkLocationResourceRoleMappings")]
        public IActionResult GetAllWorkLocationResourceRoleMappings()
        {
            logger.LogInformation("GetAllWorkLocationResourceRoleMappings");
            try
            {
                var workLocationResourceRoleMappings = workLocationResourceRoleMappingService.GetWorkLocationResourceRoleMappings();
                return Ok(new ApiOkResponse(workLocationResourceRoleMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllWorkLocationResourceRoleMappings() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveWorkLocationResourceRoleMappings")]
        public IActionResult GetActiveWorkLocations()
        {
            logger.LogInformation("GetActiveWorkLocationResourceRoleMappings");
            try
            {
                var workLocationResourceRoleMappings = workLocationResourceRoleMappingService.GetActiveWorkLocationResourceRoleMappings();
                return Ok(new ApiOkResponse(workLocationResourceRoleMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveWorkLocationResourceRoleMappings() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetWorkLocationResourceRoleMappingById")]
        public IActionResult GetWorkLocationResourceRoleMappingById(int id)
        {
            try
            {
                logger.LogInformation("GetWorkLocationResourceRoleMappingById");
                var workLocationResourceRoleMapping = workLocationResourceRoleMappingService.GetWorkLocationResourceRoleMappingById(id);
                return Ok(new ApiOkResponse(workLocationResourceRoleMapping));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetWorkLocationResourceRoleMappingById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddWorkLocationResourceRoleMapping")]
        public IActionResult AddWorkLocationResourceRoleMapping([FromBody]WorkLocationResourceRoleMappingViewModel workLocationResourceRoleMappingViewModel)
        {
            logger.LogInformation("AddWorkLocationResourceRoleMapping");
            try
            {
                workLocationResourceRoleMappingViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                workLocationResourceRoleMappingService.AddWorkLocationResourceRoleMapping(workLocationResourceRoleMappingViewModel);
                return Ok(new ApiOkResponse(workLocationResourceRoleMappingViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddWorkLocationResourceRoleMapping() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateWorkLocationResourceRoleMapping")]
        public IActionResult UpdateWorkLocation([FromBody]WorkLocationResourceRoleMappingViewModel workLocationResourceRoleMappingViewModel)
        {
            logger.LogInformation("UpdateWorkLocationResourceRoleMapping", workLocationResourceRoleMappingViewModel);
            try
            {
                var workLocation = workLocationResourceRoleMappingService.GetWorkLocationResourceRoleMappingById(workLocationResourceRoleMappingViewModel.WorkLocationResourceRoleId);
                if (workLocation == null)
                {
                    return NotFound("WorkLocationResourceRoleMapping not found.");
                }
                else
                {
                    workLocationResourceRoleMappingViewModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    workLocationResourceRoleMappingService.UpdateWorkLocationResourceRoleMapping(workLocationResourceRoleMappingViewModel);
                    return Ok(new ApiOkResponse(workLocationResourceRoleMappingViewModel));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateWorkLocationResourceRoleMapping() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
