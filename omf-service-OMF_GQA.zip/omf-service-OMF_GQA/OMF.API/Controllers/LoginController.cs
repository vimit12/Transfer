﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Newtonsoft.Json.Linq;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [EnableCors("CorsPolicy")]
    [Route("api/omf/EmployeeSearch/[action]")]
    public class LoginController : Controller
    {
        private readonly ILoginService loginService;
        private readonly ILogger<LoginController> logger;

        public LoginController(ILoginService service, ILogger<LoginController> logger)
        {
            loginService = service;
            this.logger = logger;
        }

        [HttpPost]
        [ActionName("Login")]
        public async Task<IActionResult> Login([FromBody] LoginViewModel model)
        {
            logger.LogInformation("Login");
            try
            {
                string response = await loginService.Login(model);
                return Ok(new ApiOkResponse(response));
            }
            catch (Exception e)
            {
                logger.LogError(e, "Login - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetEmployees/{searchString}")]
        public async Task<IActionResult> GetEmployees(string searchString)
        {
            logger.LogInformation("GetEmployees");
            try
            {
                var response = await loginService.GetEmployees(searchString);
                return Ok(response.Content.ReadAsStringAsync().Result);
            }
            catch (Exception e)
            {
                logger.LogError(e, "GetEmployees - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
