﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class IndustrySubSegmentController : Controller
    {
        private readonly IIndustrySubSegmentService industrySubSegmentService;

        private readonly ILogger<IndustrySubSegmentController> logger;

        public IndustrySubSegmentController(IIndustrySubSegmentService service, ILogger<IndustrySubSegmentController> logger)
        {
            this.industrySubSegmentService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllIndustrySubSegments")]
        public IActionResult GetAllIndustrySubSegments()
        {
            logger.LogInformation("GetAllIndustrySubSegments");
            try
            {
                var industrySubSegments = industrySubSegmentService.GetAllIndustrySubSegments();
                return Ok(new ApiOkResponse(industrySubSegments));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllIndustrySubSegments() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetIndustrySubSegmentById")]
        public IActionResult GetIndustrySubSegmentById(int id)
        {
            try
            {
                logger.LogInformation("GetIndustrySubSegmentById");
                var industrySubSegment = industrySubSegmentService.GetIndustrySubSegmentById(id);
                return Ok(new ApiOkResponse(industrySubSegment));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetIndustrySubSegmentById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddIndustrySubSegment")]
        public IActionResult AddIndustrySubSegment([FromBody]IndustrySubSegmentViewModel industrySubSegment)
        {
            try
            {
                logger.LogInformation("AddIndustrySubSegment");
                industrySubSegment.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                industrySubSegmentService.AddIndustrySubSegment(industrySubSegment);
                return Ok(new ApiOkResponse(industrySubSegment));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddIndustrySubSegment() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateIndustrySubSegment")]
        public IActionResult UpdateIndustrySubSegment([FromBody]IndustrySubSegmentViewModel industrySubSegment)
        {
            logger.LogInformation("UpdateIndustrySubSegment", industrySubSegment);
            try
            {
                var getIndustrySubSegment = industrySubSegmentService.GetIndustrySubSegmentById(industrySubSegment.IndustrySubSegmentId);
                if (getIndustrySubSegment == null)
                {
                    return NotFound("IndustrySubSegment not found.");
                }
                else
                {
                    industrySubSegment.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    industrySubSegmentService.UpdateIndustrySubSegment(industrySubSegment);
                    return Ok(new ApiOkResponse(industrySubSegment));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateIndustrySubSegment() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveIndustrySubSegments")]
        public IActionResult GetActiveIndustrySubSegments()
        {
            logger.LogInformation("GetActiveIndustrySubSegments");
            try
            {
                var industrySubSegments = industrySubSegmentService.GetActiveIndustrySubSegments();
                return Ok(new ApiOkResponse(industrySubSegments));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveIndustrySubSegments() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
