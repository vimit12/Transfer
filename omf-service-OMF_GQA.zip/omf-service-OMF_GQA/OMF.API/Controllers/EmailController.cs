﻿namespace OMF.API.Controllers
{
    using System;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class EmailController : Controller
    {
        private readonly IEmailService emailService;

        private readonly ILogger<EmailController> logger;

        public EmailController(IEmailService service, ILogger<EmailController> logger)
        {
            this.emailService = service;
            this.logger = logger;
        }

        [HttpPut]
        [ActionName("SendEmail")]
        public IActionResult GetActiveDocumentTypes([FromBody]MailNotificationViewModel mailNotificationViewModel)
        {
            logger.LogInformation("SendEmail");
            try
            {
                emailService.SendMailAsync(mailNotificationViewModel);
                return Ok(new ApiOkResponse(Constants.NotificationSent));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SendEmail() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
