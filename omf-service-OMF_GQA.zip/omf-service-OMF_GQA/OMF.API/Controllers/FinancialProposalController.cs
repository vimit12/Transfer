﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class FinancialProposalController : Controller
    {
        private readonly IFinancialProposalService financialProposal;

        private readonly ILogger<FinancialProposalController> logger;

        public FinancialProposalController(IFinancialProposalService service, ILogger<FinancialProposalController> logger)
        {
            this.financialProposal = service;
            this.logger = logger;
        }

        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetExpenseDetails")]
        public IActionResult GetExpenseDetails(int opportunityId, int yearId)
        {
            try
            {
                logger.LogInformation("GetExpenseDetails", opportunityId, yearId);
                return Ok(new ApiOkResponse(financialProposal.GetNonBillableExpenseDetails(opportunityId, yearId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetExpenseDetails", opportunityId, yearId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveExpenseDetails")]
        public IActionResult SaveExpenseDetails([FromBody]IEnumerable<FinancialNonBillableExpenseDetailViewModel> expense)
        {
            logger.LogInformation("SaveExpenseDetails");
            try
            {
                financialProposal.SaveNonBillableExpenseDetails(expense);
                return Ok(new ApiOkResponse(expense));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveExpenseDetails() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveAnnualMaintenanceCosts")]
        public IActionResult SaveAnnualMaintenanceCosts([FromBody]IEnumerable<FinancialAnnualMaintenanceCostViewModel> expense)
        {
            logger.LogInformation("SaveAnnualMaintenanceCosts");
            try
            {
                financialProposal.SaveAnnualMaintenanceCosts(expense);
                return Ok(new ApiOkResponse(expense));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveAnnualMaintenanceCosts() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }


        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetFinancialAnnualMaintenanceCosts")]
        public IActionResult GetFinancialAnnualMaintenanceCosts(int opportunityId, int yearId)
        {
            try
            {
                logger.LogInformation("GetFinancialAnnualMaintenanceCosts", opportunityId, yearId);
                return Ok(new ApiOkResponse(financialProposal.GetFinancialAnnualMaintenanceCosts(opportunityId, yearId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetFinancialAnnualMaintenanceCosts", opportunityId, yearId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }


        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetManagedServicesDetail")]
        public IActionResult GetManagedServicesDetail(int opportunityId, int yearId)
        {
            try
            {
                logger.LogInformation("GetManagedServicesDetail", opportunityId, yearId);
                return Ok(new ApiOkResponse(financialProposal.GetManagedServicesDetail(opportunityId, yearId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetManagedServicesDetail", opportunityId, yearId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveManagedServiceDetail")]
        public IActionResult SaveManagedServiceDetail([FromBody]FinancialManagedServiceDetailViewModel mgdServiceDetail)
        {
            logger.LogInformation("SaveExpenseDetails");
            try
            {
                financialProposal.SaveManagedServiceDetail(mgdServiceDetail);
                return Ok(new ApiOkResponse(mgdServiceDetail));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveManagedServiceDetail() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // Billable Section Code
        // Get Billable Expense Detail
        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetBillableExpenseDetails")]
        public IActionResult GetBillableExpenseDetails(int opportunityId, int yearId)
        {
            try
            {
                logger.LogInformation("GetBillableExpenseDetails", opportunityId, yearId);
                return Ok(new ApiOkResponse(financialProposal.GetBillableExpenseDetails(opportunityId, yearId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetBillableExpenseDetails", opportunityId, yearId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // SAve Billable Expense Detail
        [HttpPost]
        [ActionName("SaveBillableExpense")]
        public IActionResult SaveBillableExpense([FromBody]FinancialBillableExpenseDetailViewModel billableExpense)
        {
            logger.LogInformation("SaveBillableExpense");
            try
            {
                financialProposal.SaveBillableExpenseDetails(billableExpense);
                return Ok(new ApiOkResponse(billableExpense));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveBillableExpense() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveBillableExpensesWithDetails")]
        public IActionResult SaveBillableExpensesWithDetails([FromBody]List<FinancialBillableExpensesWithDetailsViewModel> billableExpense)
        {
            logger.LogInformation("SaveBillableExpensesWithDetails");
            try
            {
                financialProposal.SaveBillableExpensesWithDetails(billableExpense);
                return Ok(new ApiOkResponse(billableExpense));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveBillableExpensesWithDetails() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("DeleteBillableExpensesWithDetails")]
        public IActionResult DeleteBillableExpensesWithDetails([FromBody]List<FinancialBillableExpensesWithDetailsViewModel> billableExpense)
        {
            logger.LogInformation("DeleteBillableExpensesWithDetails");
            try
            {
                financialProposal.DeleteBillableExpensesWithDetails(billableExpense);
                return Ok(new ApiOkResponse(billableExpense));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "DeleteBillableExpensesWithDetails() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetBillableExpensesWithDetails")]
        public IActionResult GetBillableExpensesWithDetails(int opportunityId, int yearId)
        {
            try
            {
                logger.LogInformation("GetBillableExpensesWithDetails", opportunityId, yearId);
                return Ok(new ApiOkResponse(financialProposal.GetBillableExpensesWithDetails(opportunityId, yearId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetBillableExpensesWithDetails", opportunityId, yearId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // Project-Staffing
        [HttpGet]
        [ActionName("GetProjectStaffingDetails")]
        public IActionResult GetProjectStaffingDetails()
        {
            try
            {
                logger.LogInformation("GetProjectStaffingDetails");
                return Ok(new ApiOkResponse(financialProposal.GetProjectStaffDetails()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectStaffingDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetProjectStaffDetailsByYear")]
        public IActionResult GetProjectStaffDetailsByYear(int opportunityId, int financialyear)
        {
            try
            {
                logger.LogInformation("GetProjectStaffDetailsByYear");
                return Ok(new ApiOkResponse(financialProposal.GetProjectStaffDetailsByYear(opportunityId, financialyear)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectStaffDetailsByYear");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetProjectStaffWorkHours")]
        public IActionResult GetProjectStaffWorkHours(int financialEmployeeDetailId)
        {
            try
            {
                logger.LogInformation("GetProjectStaffWorkHours");
                return Ok(new ApiOkResponse(financialProposal.GetProjectStaffWorkHours(financialEmployeeDetailId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectStaffWorkHours");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("AddOrModifyStaffDetails")]
        public IActionResult AddOrModifyStaffDetails([FromBody]List<FinancialEmployeeDetailViewModel> model)
        {
            try
            {
                logger.LogInformation("AddOrModifyStaffDetails");
                string errorMessage = string.Empty;
                financialProposal.AddOrModifyStaffDetails(model, ref errorMessage);
                return errorMessage == string.Empty ? Ok(new ApiOkResponse(model)) : (IActionResult)BadRequest(errorMessage);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "AddOrModifyStaffDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("DeleteStaffDetails")]
        public IActionResult DeleteStaffDetails([FromBody]List<FinancialEmployeeDetailViewModel> model)
        {
            logger.LogInformation("DeleteStaffDetails", model);
            try
            {
                logger.LogInformation("DeleteStaffDetails");
                string errorMessage = string.Empty;
                financialProposal.DeleteEmployeeDetails(model, ref errorMessage);
                return errorMessage == string.Empty ? Ok(new ApiOkResponse(model)) : (IActionResult)BadRequest(errorMessage);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "DeleteStaffDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // Project -Contractor
        [HttpGet]
        [ActionName("GetProjectContractorDetails")]
        public IActionResult GetProjectContractorDetails()
        {
            try
            {
                logger.LogInformation("GetProjectContractorDetails");
                return Ok(new ApiOkResponse(financialProposal.GetProjectContractorDetails()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectContractorDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetProjectContractorDetailsByYear")]
        public IActionResult GetProjectContractorDetailsByYear(int opportunityId, int financialYear)
        {
            try
            {
                logger.LogInformation("GetProjectContractorDetailsByYear");
                return Ok(new ApiOkResponse(financialProposal.GetProjectContractorDetailsByYear(opportunityId, financialYear)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectContractorDetailsByYear");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetProjectContractorWorkHours")]
        public IActionResult GetProjectContractorWorkHours(int financialContractorDetailId)
        {
            try
            {
                logger.LogInformation("GetProjectContractorWorkHours");
                return Ok(new ApiOkResponse(financialProposal.GetProjectContractorWorkHours(financialContractorDetailId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectContractorWorkHours");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("AddOrModifyProjectContractorDetails")]
        public IActionResult AddOrModifyProjectContractorDetails([FromBody]List<FinancialContractorDetailViewModel> model)
        {
            try
            {
                logger.LogInformation("AddOrModifyProjectContractorDetails");
                string errorMessage = string.Empty;
                financialProposal.AddOrModifyContractorDetails(model, ref errorMessage);
                return errorMessage == string.Empty ? Ok(new ApiOkResponse(model)) : (IActionResult)BadRequest(errorMessage);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "AddOrModifyProjectContractorDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("DeleteProjectContractorDetails")]
        public IActionResult DeleteProjectContractorDetails([FromBody]List<FinancialContractorDetailViewModel> model)
        {
            logger.LogInformation("DeleteProjectContractorDetails", model);
            try
            {
                logger.LogInformation("DeleteProjectContractorDetails");
                string errorMessage = string.Empty;
                financialProposal.DeleteFinancialContractor(model, ref errorMessage);
                return errorMessage == string.Empty ? Ok(new ApiOkResponse(model)) : (IActionResult)BadRequest(errorMessage);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "DeleteProjectContractorDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // copy
        [HttpPut]
        [ActionName("CopyFinancialProposal")]
        public IActionResult CopyFinancialProposal([FromBody]CopyFinancialProposalInputViewModel model)
        {
            try
            {
                logger.LogInformation("CopyFinancialProposal");
                string errorMessage = string.Empty;
                return Ok(new ApiOkResponse(financialProposal.CopyFinancialProposal(model, ref errorMessage)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "CopyFinancialProposal");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{oppId}")]
        [ActionName("ExtractEmployeeStaffingDetails")]
        public IActionResult ExtractEmployeeStaffingDetails(int oppId)
        {
            logger.LogInformation("ExtractEmployeeStaffingDetails");
            try
            {
                var template = financialProposal.ExtractEmployeeDetailsTemplate(oppId, out string fileName);
                fileName = fileName.Replace(" ", "_");
                return Ok(new ApiOkResponse(new
                {
                    FileName = fileName,
                    Excel = template
                }));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ExtractEmployeeStaffingDetails()");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{oppId}")]
        [ActionName("ExtractEmployeeStaffingDetailsWithMargins")]
        public IActionResult ExtractEmployeeStaffingDetailsWithMargins(int oppId)
        {
            logger.LogInformation("ExtractEmployeeStaffingDetailsWithMargins");
            try
            {
                var template = financialProposal.ExtractEmployeeStaffingDetailsWithMargins(oppId, out string fileName);
                fileName = fileName.Replace(" ", "_");
                return Ok(new ApiOkResponse(new
                {
                    FileName = fileName,
                    Excel = template
                }));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ExtractEmployeeStaffingDetailsWithMargins()");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("UploadEmployeeDetails")]
        public IActionResult UploadEmployeeDetails([FromBody]EmployeeFileUploadDetailsViewModel employeeFileUploadDetails)
        {
            logger.LogInformation("UploadEmployeeDetails");
            try
            {
                string message = string.Empty;
                var uploadResult = financialProposal.UploadEmployeeDetails(employeeFileUploadDetails, out message, out string newFile);
                //var newFile = $"Opportunity - {employeeFileUploadDetails.OpportunityId} Employee Details.xlsx";
                if (uploadResult.Length == 0)
                {
                    return Ok(new ApiOkResponse(new
                    {
                        Message = "Upload successful",
                        Excel = uploadResult,
                        FileName = newFile
                    }));
                }
                else
                {
                    return Ok(new ApiOkResponse(new
                    {
                        Message = "Please check the excel for issues - fix the issues and try uploading again - " + message,
                        Excel = uploadResult,
                        FileName = newFile
                    }));
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UploadEmployeeDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{oppId}")]
        [ActionName("ExtractContractorDetailsTemplate")]
        public IActionResult ExtractContractorDetailsTemplate(int oppId)
        {
            logger.LogInformation("ExtractContractorDetailsTemplate");
            try
            {
                var template = financialProposal.ExtractContractorDetailsTemplate(oppId, out string fileName);
                fileName = fileName.Replace(" ", "_");
                return Ok(new ApiOkResponse(new
                {
                    FileName = fileName,
                    Excel = template
                }));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ExtractContractorDetailsTemplate()");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{oppId}")]
        [ActionName("ExtractContractorDetailsTemplateWithMargins")]
        public IActionResult ExtractContractorDetailsTemplateWithMargins(int oppId)
        {
            logger.LogInformation("ExtractContractorDetailsTemplateWithMargins");
            try
            {
                var template = financialProposal.ExtractContractorDetailsTemplateWithMargins(oppId, out string fileName);
                fileName = fileName.Replace(" ", "_");
                return Ok(new ApiOkResponse(new
                {
                    FileName = fileName,
                    Excel = template
                }));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ExtractContractorDetailsTemplateWithMargins()");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
        [HttpPost]
        [ActionName("UploadContractorDetails")]
        public IActionResult UploadContractorDetails([FromBody]EmployeeFileUploadDetailsViewModel employeeFileUploadDetails)
        {
            logger.LogInformation("UploadContractorDetails");
            try
            {
                string message = string.Empty;
                var uploadResult = financialProposal.UploadContractorDetails(employeeFileUploadDetails, out message, out string newFile);
                //var newFile = $"Opportunity - {employeeFileUploadDetails.OpportunityId} Employee Details.xlsx";
                if (uploadResult.Length == 0)
                {
                    return Ok(new ApiOkResponse(new
                    {
                        Message = "Upload successful",
                        Excel = uploadResult,
                        FileName = newFile
                    }));
                }
                else
                {
                    return Ok(new ApiOkResponse(new
                    {
                        Message = "Please check the excel for issues - fix the issues and try uploading again - " + message,
                        Excel = uploadResult,
                        FileName = newFile
                    }));
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UploadContractorDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }


        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetFinancialsDiscountAndRebates")]
        public IActionResult GetFinancialsDiscountAndRebates(int opportunityId, int yearId)
        {
            try
            {
                logger.LogInformation("GetFinancialsDiscountAndRebates", opportunityId);
                return Ok(new ApiOkResponse(financialProposal.GetFinancialsDiscountAndRebates(opportunityId, yearId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetFinancialsDiscountAndRebates");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveFinancialsDiscountAndRebates")]
        public IActionResult SaveFinancialsDiscountAndRebates([FromBody]IEnumerable<FinancialsDiscountAndRebateViewModel> financialsStaffAugmentations)
        {
            try
            {
                logger.LogInformation("SaveFinancialsDiscountAndRebates");
                financialProposal.SaveFinancialsDiscountAndRebates(financialsStaffAugmentations);
                return Ok(new ApiOkResponse(financialsStaffAugmentations));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "SaveFinancialsDiscountAndRebates");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("DeleteFinancialsDiscountAndRebates")]
        public IActionResult DeleteFinancialsDiscountAndRebates([FromBody]FinancialsDiscountAndRebateViewModel financialsDiscountAndRebateViewModel)
        {
            try
            {
                logger.LogInformation("DeleteFinancialsDiscountAndRebates");
                financialProposal.DeleteFinancialsDiscountAndRebates(financialsDiscountAndRebateViewModel);
                return Ok(new ApiOkResponse("Deleted"));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "DeleteFinancialsDiscountAndRebates");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
