﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class EmailTemplateController : Controller
    {
        private readonly IEmailTemplateService emailTemplateService;

        private readonly ILogger<EmailTemplateController> logger;

        public EmailTemplateController(IEmailTemplateService service, ILogger<EmailTemplateController> logger)
        {
            this.emailTemplateService = service;
            this.logger = logger;
        }

        [HttpGet("{templateId}")]
        [ActionName("GetEmailTemplatesDetails")]
        public IActionResult GetEmailTemplatesDetails(int templateId)
        {
            logger.LogInformation("GetEmailTemplatesDetails");
            try
            {
                var emailTemplateDetails = emailTemplateService.GetEmailTemplatesDetails(templateId);
                return Ok(new ApiOkResponse(emailTemplateDetails));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetEmailTemplatesDetails() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetEmailTemplates")]
        public IActionResult GetEmailTemplates()
        {
            logger.LogInformation("GetEmailTemplates");
            try
            {
                var emailTemplateDetails = emailTemplateService.GetEmailTemplates();
                return Ok(new ApiOkResponse(emailTemplateDetails));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetEmailTemplates() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddEmailTemplate")]
        public IActionResult AddEmailTemplate([FromBody]EmailTemplateViewModel emailTemplateView)
        {
            logger.LogInformation("AddEmailTemplate");
            try
            {
                emailTemplateView.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                emailTemplateService.AddEmailTemplate(emailTemplateView);
                return Ok(new ApiOkResponse(emailTemplateView));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddEmailTemplate() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateEmailTemplate")]
        public IActionResult UpdateEmailTemplate([FromBody]EmailTemplateViewModel emailTemplateView)
        {
            logger.LogInformation("UpdateEmailTemplate", emailTemplateView);
            try
            {
                emailTemplateView.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                emailTemplateService.UpdateEmailTemplate(emailTemplateView);
                return Ok(new ApiOkResponse(emailTemplateView));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateEmailTemplate() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
