﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class IndustrySubVerticalsController : Controller
    {
        private readonly IIndustrySubVerticalsService industrySubVerticalsService;

        private readonly ILogger<IndustrySubVerticalsController> logger;

        public IndustrySubVerticalsController(IIndustrySubVerticalsService service, ILogger<IndustrySubVerticalsController> logger)
        {
            this.industrySubVerticalsService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllIndustrySubVerticals")]
        public IActionResult GetAllIndustrySubVerticals()
        {
            logger.LogInformation("GetAllIndustrySubVerticals");
            try
            {
                var industrySubVerticals = industrySubVerticalsService.GetAllIndustrySubVerticals();
                return Ok(new ApiOkResponse(industrySubVerticals));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllIndustrySegments() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetIndustrySubVerticalById")]
        public IActionResult GetIndustrySubVerticalById(int id)
        {
            try
            {
                logger.LogInformation("GetIndustrySubVerticalById");
                var industrySubVertical = industrySubVerticalsService.GetIndustrySubVerticalById(id);
                return Ok(new ApiOkResponse(industrySubVertical));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetIndustrySubVerticalById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddIndustrySubVertical")]
        public IActionResult AddIndustrySubVertical([FromBody]IndustrySubVerticalsViewModel industrySubVertical)
        {
            logger.LogInformation("AddIndustrySubVertical");
            try
            {
                industrySubVertical.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                industrySubVerticalsService.AddIndustrySubVertical(industrySubVertical);
                return Ok(new ApiOkResponse(industrySubVertical));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddIndustrySubVertical() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateIndustrySubVertical")]
        public IActionResult UpdateIndustrySubVertical([FromBody]IndustrySubVerticalsViewModel industrySubVertical)
        {
            logger.LogInformation("UpdateIndustrySubVertical", industrySubVertical);
            try
            {
                var getIndustrySubVertical = industrySubVerticalsService.GetIndustrySubVerticalById(industrySubVertical.IndustrySubVerticalId);
                if (getIndustrySubVertical == null)
                {
                    return NotFound("IndustrySegment not found.");
                }
                else
                {
                    industrySubVertical.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    industrySubVerticalsService.UpdateIndustrySubVertical(industrySubVertical);
                    return Ok(new ApiOkResponse(industrySubVertical));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateIndustrySubVertical() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveIndustrySubVerticals")]
        public IActionResult GetActiveIndustrySubVerticals()
        {
            logger.LogInformation("GetActiveIndustrySubVerticals");
            try
            {
                var industrySubVerticals = industrySubVerticalsService.GetActiveIndustrySubVerticals();
                return Ok(new ApiOkResponse(industrySubVerticals));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveIndustrySubVerticals() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
