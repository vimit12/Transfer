﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;

    [Route("api/omf/[controller]/[action]")]
    public class FundingReductionController : Controller
    {
        private readonly IFundingReductionService fundingReductionService;

        private readonly ILogger<FundingReductionController> logger;

        public FundingReductionController(IFundingReductionService service, ILogger<FundingReductionController> logger)
        {
            this.fundingReductionService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllFundingReductions")]
        public IActionResult GetAllFundingReductions()
        {
            this.logger.LogInformation("GetAllFundingReductions");
            try
            {
                var cop = this.fundingReductionService.GetAllFundingReductions();
                return this.Ok(new ApiOkResponse(cop));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllFundingReductions() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetFundingReductionHistory")]
        public IActionResult GetFundingReductionHistory()
        {
            this.logger.LogInformation("GetFundingReductionHistory");
            try
            {
                var cop = this.fundingReductionService.GetFundingReductionHistory();
                return this.Ok(new ApiOkResponse(cop));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetFundingReductionHistory() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveFundingReductions")]
        public IActionResult GetActiveFundingReductions()
        {
            this.logger.LogInformation("GetActiveFundingReductions");
            try
            {
                var lineOfBusinesses = this.fundingReductionService.GetActiveFundingReductions();
                return this.Ok(new ApiOkResponse(lineOfBusinesses));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActiveFundingReductions() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetFundingReductionById")]
        public IActionResult GetFundingReductionById(int id)
        {
            this.logger.LogInformation("GetFundingReductionById");
            try
            {
                var cops = this.fundingReductionService.GetFundingReductionById(id);
                return this.Ok(new ApiOkResponse(cops));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetFundingReductionById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddFundingReduction")]
        public IActionResult AddFundingReduction([FromBody]FundingReductionViewModel fundingReduction)
        {
            this.logger.LogInformation("AddFundingReduction");
            try
            {
                fundingReduction.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.fundingReductionService.AddFundingReduction(fundingReduction);
                return this.Ok(new ApiOkResponse(fundingReduction));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddFundingReduction() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateFundingReduction")]
        public IActionResult UpdateFundingReduction([FromBody]FundingReductionViewModel fundingReduction)
        {
            this.logger.LogInformation("UpdateFundingReduction", fundingReduction);
            try
            {
                var getCOP = this.fundingReductionService.GetFundingReductionById(fundingReduction.FundingReductionId);
                if (getCOP == null)
                {
                    return this.NotFound("Type not found.");
                }
                else
                {
                    fundingReduction.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.fundingReductionService.UpdateFundingReduction(fundingReduction);
                    return this.Ok(new ApiOkResponse(fundingReduction));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateFundingReduction() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
      
        [HttpPost]
        [ActionName("SaveDocuments")]
        public async Task<IActionResult> SaveDocuments([FromBody] FundingReductionDocumentDetailsViewModel model)
        {
            try
            {
                logger.LogInformation("SaveDocuments");
                await fundingReductionService.SaveDocuments(model);
                return Ok(new ApiOkResponse("Success"));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "SaveDocuments");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{fundingReductionDocumentDetailsId}")]
        [ActionName("GetFundingReductionDocumentDetails")]
        public async Task<IActionResult> GetOpportunityDocumentDetails(int fundingReductionDocumentDetailsId)
        {
            try
            {
                logger.LogInformation("GetOpportunityDocumentDetails");
                return Ok(new ApiOkResponse(await fundingReductionService.GetFundingReductionDocumentDetails(fundingReductionDocumentDetailsId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityDocumentDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}