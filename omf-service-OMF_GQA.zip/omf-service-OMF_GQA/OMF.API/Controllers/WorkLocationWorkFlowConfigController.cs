﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OMF.API.Common;
using OMF.Business.Interfaces;
using OMF.Business.Services;
using OMF.Business.Common;
using OMF.Business.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OMF.API.Controllers
{
    [Route("api/omf/[controller]/[action]")]
    public class WorkLocationWorkFlowConfigController : Controller
    {
        private readonly IWorkLocationWorkFlowConfigService workLocationWorkFlowConfigService;

        private readonly ILogger<WorkLocationWorkFlowConfigController> logger;

        public WorkLocationWorkFlowConfigController(IWorkLocationWorkFlowConfigService service, ILogger<WorkLocationWorkFlowConfigController> logger)
        {
            this.workLocationWorkFlowConfigService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllWorkLocationWorkFlows")]
        public IActionResult GetAllWorkLocationWorkFlows()
        {
            logger.LogInformation("GetAllWorkLocationWorkFlows");
            try
            {
                var workLocationWorkFlows = workLocationWorkFlowConfigService.GetAllWorkLocationWorkFlows();
                return Ok(new ApiOkResponse(workLocationWorkFlows));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetAllWorkLocationWorkFlows");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddWorkLocationWorkFlow")]
        public IActionResult AddWorkLocationWorkFlow([FromBody]WorkLocationWorkFlowConfigViewModel workLocationWorkFlowConfigViewModel)
        {
            logger.LogInformation("AddWorkLocationWorkFlow");
            try
            {
                workLocationWorkFlowConfigViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                workLocationWorkFlowConfigService.AddWorkLocationWorkFlow(workLocationWorkFlowConfigViewModel);
                return Ok(new ApiOkResponse(workLocationWorkFlowConfigViewModel));
            }
            catch(Exception ex)
            {
                logger.LogError(ex, "AddWorkLocationWorkFlow()");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("UpdateWorkLocationWorkFlow")]
        public IActionResult UpdateWorkLocationWorkFlow([FromBody]WorkLocationWorkFlowConfigViewModel workLocationWorkFlowConfigViewModel)
        {
            logger.LogInformation("UpdateWorkLocationWorkFlow");
            try
            {
                workLocationWorkFlowConfigViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                workLocationWorkFlowConfigService.UpdateWorkLocationWorkFlow(workLocationWorkFlowConfigViewModel);
                return Ok(new ApiOkResponse(workLocationWorkFlowConfigViewModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateWorkLocationWorkFlow()");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
