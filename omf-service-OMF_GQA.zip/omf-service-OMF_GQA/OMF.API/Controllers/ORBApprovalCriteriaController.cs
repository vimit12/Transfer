﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Models;
    using OMF.Business.Interfaces;
    using OMF.Business.Common;

    [Route("api/omf/[controller]/[action]")]
    public class ORBApprovalCriteriaController : Controller
    {
        private readonly IORBApprovalCriteriaService orbApprovalCriteriaService;

        private readonly ILogger<ORBApprovalCriteriaController> logger;

        public ORBApprovalCriteriaController(IORBApprovalCriteriaService oRBApprovalCriteriaService, ILogger<ORBApprovalCriteriaController> logger)
        {
            this.orbApprovalCriteriaService = oRBApprovalCriteriaService;
            this.logger = logger;
        }

        [HttpPost]
        [ActionName("SaveOrUpdateOpportunityRating")]
        public IActionResult SaveOrUpdateOpportunityRating([FromBody]ORBApprovalCriteriaViewModel oppRating)
        {
            logger.LogInformation("OpportunityRatingViewModel");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                orbApprovalCriteriaService.SaveOrUpdateOpportunityRating(oppRating);
                return Ok(new ApiOkResponse(oppRating));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "OpportunityRatingViewModel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityRatingDetails")]
        public IActionResult GetOpportunityRatingDetails(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityRatingDetails", opportunityId);
                return Ok(new ApiOkResponse(orbApprovalCriteriaService.GetORBApprovalRating(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityRatingDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddORBCategoryApprovers")]
        public IActionResult AddORBCategoryApprovers([FromBody]ORBCategoryApproverViewModel model)
        {
            logger.LogInformation("AddORBCategoryApprovers");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                orbApprovalCriteriaService.AddORBCategoryApprovers(model);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddORBCategoryApprovers() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddORBMarketApprovers")]
        public IActionResult AddORBMarketApprovers([FromBody]ORBMarketApproverViewModel model)
        {
            logger.LogInformation("AddORBMarketApprovers");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                orbApprovalCriteriaService.AddORBMarketApprovers(model);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddORBMarketApprovers() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddORBSalesLeadApprovers")]
        public IActionResult AddORBSalesLeadApprovers([FromBody]ORBSalesLeadApproverViewModel model)
        {
            logger.LogInformation("AddORBSalesLeadApprovers");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                orbApprovalCriteriaService.AddORBSalesLeadApprovers(model);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddORBSalesLeadApprovers() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetORBCategoryApprovers")]
        public IActionResult GetORBCategoryApprovers()
        {
            try
            {
                logger.LogInformation("GetORBCategoryApprovers");
                return Ok(new ApiOkResponse(orbApprovalCriteriaService.GetORBCategoryApprovers()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetORBCategoryApprovers");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetORBMarketApprovers")]
        public IActionResult GetORBMarketApprovers()
        {
            try
            {
                logger.LogInformation("GetORBMarketApprovers");
                return Ok(new ApiOkResponse(orbApprovalCriteriaService.GetORBMarketApprovers()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetORBMarketApprovers");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetORBSalesLeadApprovers")]
        public IActionResult GetORBSalesLeadApprovers()
        {
            try
            {
                logger.LogInformation("GetORBSalesLeadApprovers");
                return Ok(new ApiOkResponse(orbApprovalCriteriaService.GetORBSalesLeadApprovers()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetORBSalesLeadApprovers");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateORBCategoryUserRoleMapping")]
        public IActionResult UpdateORBCategoryUserRoleMapping([FromBody] ORBCategoryApproverViewModel oRBCategoryApprover)
        {
            try
            {
                logger.LogInformation("UpdateORBCategoryUserRoleMapping");
                orbApprovalCriteriaService.UpdateORBCategoryUserRoleMapping(oRBCategoryApprover);
                return this.Ok(new ApiOkResponse(oRBCategoryApprover));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateORBCategoryUserRoleMapping() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateORBMarketUserRoleMapping")]
        public IActionResult UpdateORBMarketUserRoleMapping([FromBody] ORBMarketApproverViewModel oRBMarketApprover)
        {
            try
            {
                logger.LogInformation("UpdateORBMarketUserRoleMapping");
                orbApprovalCriteriaService.UpdateORBMarketUserRoleMapping(oRBMarketApprover);
                return this.Ok(new ApiOkResponse(oRBMarketApprover));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateORBMarketUserRoleMapping() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateORBSalesLeadUserRoleMapping")]
        public IActionResult UpdateORBSalesLeadUserRoleMapping([FromBody] ORBSalesLeadApproverViewModel oRBSalesLeadApprover)
        {
            try
            {
                logger.LogInformation("UpdateORBSalesLeadUserRoleMapping");
                orbApprovalCriteriaService.UpdateORBSalesLeadUserRoleMapping(oRBSalesLeadApprover);
                return this.Ok(new ApiOkResponse(oRBSalesLeadApprover));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateORBSalesLeadUserRoleMapping() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{oppId}")]
        [ActionName("GetOpportunityACV")]
        public IActionResult GetOpportunityACV(int oppId)
        {
            try
            {
                logger.LogInformation("GetOpportunityACV");
                return Ok(new ApiOkResponse(orbApprovalCriteriaService.GetOpportunityACV(oppId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityACV");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}