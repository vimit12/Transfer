﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class PaymentTermsController : Controller
    {
        private readonly IPaymentTermsService paymentTermsService;

        private readonly ILogger<PaymentTermsController> logger;

        public PaymentTermsController(IPaymentTermsService service, ILogger<PaymentTermsController> logger)
        {
            this.paymentTermsService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllPaymentTerms")]
        public IActionResult GetAllPaymentTerms()
        {
            logger.LogInformation("GetAllPaymentTerms");
            try
            {
                var paymentTerms = paymentTermsService.GetAllPaymentTerms();
                return Ok(new ApiOkResponse(paymentTerms));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllPaymentTerms() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetPaymentTermById")]
        public IActionResult GetPaymentTermById(int id)
        {
            try
            {
                logger.LogInformation("GetPaymentTermById");
                var paymentTerms = paymentTermsService.GetPaymentTermById(id);
                return Ok(new ApiOkResponse(paymentTerms));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetPaymentTermById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddPaymentTerms")]
        public IActionResult AddPaymentTerms([FromBody]PaymentTermsViewModel paymentTerms)
        {
            logger.LogInformation("AddPaymentTerms");
            try
            {
                paymentTerms.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                paymentTermsService.AddPaymentTerms(paymentTerms);
                return Ok(new ApiOkResponse(paymentTerms));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddPaymentTerms() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdatePaymentTerms")]
        public IActionResult UpdatePaymentTerms([FromBody]PaymentTermsViewModel paymentTerms)
        {
            logger.LogInformation("UpdatePaymentTerms", paymentTerms);
            try
            {
                var getpaymentTerms = paymentTermsService.GetPaymentTermById(paymentTerms.PaymentTermId);
                if (getpaymentTerms == null)
                {
                    return NotFound("Payment Term not found.");
                }
                else
                {
                    paymentTerms.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    paymentTermsService.UpdatePaymentTerms(paymentTerms);
                    return Ok(new ApiOkResponse(paymentTerms));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdatePaymentTerms() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActivePaymentTerms")]
        public IActionResult GetActivePaymentTerms()
        {
            logger.LogInformation("GetActivePaymentTerms");
            try
            {
                var paymentTerms = paymentTermsService.GetActivePaymentTerms();
                return Ok(new ApiOkResponse(paymentTerms));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActivePaymentTerms() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
