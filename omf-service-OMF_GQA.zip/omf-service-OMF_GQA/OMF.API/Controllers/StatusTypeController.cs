﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class StatusTypeController : Controller
    {
        private readonly IStatusTypeService statusTypeService;

        private readonly ILogger<StatusTypeController> logger;

        public StatusTypeController(IStatusTypeService service, ILogger<StatusTypeController> logger)
        {
            this.statusTypeService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllStatusTypes")]
        public IActionResult GetAllStatusTypes()
        {
            logger.LogInformation("GetAllStatusTypes");
            try
            {
                var statusTypes = statusTypeService.GetAllStatusTypes();
                return Ok(new ApiOkResponse(statusTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllStatusTypes() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveStatusTypes")]
        public IActionResult GetActiveStatusTypes()
        {
            logger.LogInformation("GetActiveStatusTypes");
            try
            {
                var statusTypes = statusTypeService.GetActiveStatusTypes();
                return Ok(new ApiOkResponse(statusTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveStatusTypes() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetStatusTypeById")]
        public IActionResult GetStatusTypeById(int id)
        {
            try
            {
                logger.LogInformation("GetStatusTypeById");
                var statusType = statusTypeService.GetStatusTypeById(id);
                return Ok(new ApiOkResponse(statusType));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetStatusTypeById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddStatusType")]
        public IActionResult AddStatusType([FromBody]StatusTypeViewModel statusType)
        {
            logger.LogInformation("AddStatusType");
            try
            {
                statusType.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                statusTypeService.AddStatusType(statusType);
                return Ok(new ApiOkResponse(statusType));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddStatusType() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateStatusType")]
        public IActionResult UpdateStatusType([FromBody]StatusTypeViewModel statusType)
        {
            logger.LogInformation("UpdateStatusType", statusType);
            try
            {
                var getStatusType = statusTypeService.GetStatusTypeById(statusType.StatusId);
                if (getStatusType == null)
                {
                    return NotFound("StatusType not found.");
                }
                else
                {
                    statusType.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    statusTypeService.UpdateStatusType(statusType);
                    return Ok(new ApiOkResponse(statusType));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateStatusType() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
