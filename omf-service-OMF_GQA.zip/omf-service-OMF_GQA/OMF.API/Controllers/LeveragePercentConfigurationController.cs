﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [EnableCors("CorsPolicy")]
    [Route("api/omf/[controller]/[action]")]
    public class LeveragePercentConfigurationController : Controller
    {
        private readonly ILeveragePercentageConfigurationService leveragePercentVarianceService;

        private readonly ILogger<LeveragePercentConfigurationController> logger;

        public LeveragePercentConfigurationController(ILeveragePercentageConfigurationService service, ILogger<LeveragePercentConfigurationController> logger)
        {
            this.leveragePercentVarianceService = service;
            this.logger = logger;
        }

        [HttpPost]
        [ActionName("SaveLeverageVariance")]
        public IActionResult SaveLeverageVariance([FromBody] LeveragePercentageConfigurationViewModel leveragePercentageViewModel)
        {
            logger.LogInformation("SaveLeverageVariance");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {

                leveragePercentVarianceService.SaveLeverageVariance(leveragePercentageViewModel);
                return Ok(new ApiOkResponse(leveragePercentageViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveLeverageVariance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetLeverageVarianceConfigDetails")]
        public IActionResult GetLeverageVarianceConfigDetails()
        {
            try
            {
                logger.LogInformation("GetLeverageVarianceConfigDetails");
                return Ok(new ApiOkResponse(leveragePercentVarianceService.GetLeverageVarianceConfigDetails()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetLeverageVarianceConfigDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}/{screenId}")]
        [ActionName("ValidateVariancePercentage")]
        public IActionResult ValidateVariancePercentage(int opportunityId,int screenId)
        {
            try
            {
                logger.LogInformation("ValidateVariancePercentage", opportunityId);
                return Ok(new ApiOkResponse(leveragePercentVarianceService.ValidateVariancePercentageByOppId(opportunityId, screenId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ValidateVariancePercentage", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}