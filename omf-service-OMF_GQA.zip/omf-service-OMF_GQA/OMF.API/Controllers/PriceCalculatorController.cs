﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class PriceCalculatorController : Controller
    {
        private readonly IPriceCalculatorService priceCalculatorService;
        private readonly ILogger<PriceCalculatorController> logger;

        public PriceCalculatorController(IPriceCalculatorService service, ILogger<PriceCalculatorController> logger)
        {
            this.priceCalculatorService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetMarginViewPriceSimulation")]
        public IActionResult GetMarginViewPriceSimulation(PriceCalculatorViewModel priceCalculatorView)
        {
            logger.LogInformation("GetMarginViewPriceSimulation");
            try
            {
                var excel = priceCalculatorService.GetMarginViewPriceSimulation(priceCalculatorView);
                return Ok(new ApiOkResponse(excel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetMarginViewPriceSimulation() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetMarginViewPriceSimulationExcel")]
        public IActionResult GetMarginViewPriceSimulationExcel(PriceCalculatorViewModel priceCalculatorView)
        {
            logger.LogInformation("GetMarginViewPriceSimulationExcel");
            try
            {
                var excel = priceCalculatorService.GetMarginViewPriceSimulationExcel(priceCalculatorView);
                return Ok(new ApiOkResponse(excel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetMarginViewPriceSimulationExcel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetLeverageViewPriceSimulationExcel")]
        public IActionResult GetLeverageViewPriceSimulationExcel(PriceCalculatorViewModel priceCalculatorView)
        {
            logger.LogInformation("GetLeverageViewPriceSimulationExcel");
            try
            {
                var excel = priceCalculatorService.GetLeverageViewPriceSimulationExcel(priceCalculatorView);
                return Ok(new ApiOkResponse(excel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetLeverageViewPriceSimulationExcel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetLeverageViewPriceSimulation")]
        public IActionResult GetLeverageViewPriceSimulation(PriceCalculatorViewModel priceCalculatorView)
        {
            logger.LogInformation("GetLeverageViewPriceSimulation");
            try
            {
                var excel = priceCalculatorService.GetLeverageViewPriceSimulation(priceCalculatorView);
                return Ok(new ApiOkResponse(excel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetLeverageViewPriceSimulation() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
