﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class OmfJourneyController : Controller
    {
        private readonly IOmfJourney omfJourneyService;

        private readonly ILogger<OmfJourneyController> logger;

        public OmfJourneyController(IOmfJourney service, ILogger<OmfJourneyController> logger)
        {
            this.omfJourneyService = service;
            this.logger = logger;
        }

        [HttpGet("{id}")]
        [ActionName("GetOmfJourneyByOpportunityId")]
        public IActionResult GetOmfJourneyByOpportunityId(int id)
        {
            logger.LogInformation("GetOmfJourneyByOpportunityId");
            try
            {
                var oMFJourney = omfJourneyService.GetOmfJourneyByOpportunityId(id);
                return Ok(new ApiOkResponse(oMFJourney));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOmfJourneyByOpportunityId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetDefaultJourney")]
        public IActionResult GetDefaultJourney()
        {
            logger.LogInformation("GetDefaultJourney");
            try
            {
                var oMFJourney = omfJourneyService.GetDefaultJourney();
                return Ok(new ApiOkResponse(oMFJourney));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetDefaultJourney() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetDefaultJourneyByOpportunityId")]
        public IActionResult GetDefaultJourneyByOpportunityId(int opportunityId)
        {
            logger.LogInformation("GetDefaultJourneyByOpportunityId");
            try
            {
                var oMFJourney = omfJourneyService.GetDefaultJourneyByOpportunityId(opportunityId);
                return Ok(new ApiOkResponse(oMFJourney));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetDefaultJourneyByOpportunityId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
        
        [HttpGet("{oppId}")]
        [ActionName("GetDefaultWorkLocationJourney")]
        public IActionResult GetDefaultWorkLocationJourney(int oppId)
        {
            logger.LogInformation("GetDefauGetDefaultWorkLocationJourneyltJourney");
            try
            {
                var oMFJourney = omfJourneyService.GetDefaultWorkLocationJourney(oppId);
                return Ok(new ApiOkResponse(oMFJourney));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetDefaultWorkLocationJourney() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{oppId}")]
        [ActionName("GetWorkLocationJourney")]
        public IActionResult GetWorkLocationJourney(int oppId)
        {
            logger.LogInformation("GettWorkLocationJourney");
            try
            {
                var oMFJourney = omfJourneyService.GetWorkLocationJourney(oppId);
                return Ok(new ApiOkResponse(oMFJourney));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GettWorkLocationJourney() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetDefaultORBJourneyForOpportunity")]
        public IActionResult GetDefaultORBJourneyForOpportunity(int id)
        {
            logger.LogInformation("GetDefaultORBJourneyForOpportunity");
            try
            {
                var oMFJourney = omfJourneyService.GetDefaultORBJourneyForOpportunity(id);
                return Ok(new ApiOkResponse(oMFJourney));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetDefaultORBJourneyForOpportunity() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetORBWorkFlowJourneyForOpportunity")]
        public IActionResult GetORBWorkFlowJourneyForOpportunity(int id)
        {
            logger.LogInformation("GetORBWorkFlowJourneyForOpportunity");
            try
            {
                var oMFJourney = omfJourneyService.GetORBWorkFlowJourneyForOpportunity(id);
                return Ok(new ApiOkResponse(oMFJourney));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetORBWorkFlowJourneyForOpportunity() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetDefaultFundingReductionJourney")]
        public IActionResult GetDefaultFundingReductionJourney()
        {
            logger.LogInformation("GetDefaultFundingReductionJourney");
            try
            {
                var oMFJourney = omfJourneyService.GetDefaultFundingReductionJourney();
                return Ok(new ApiOkResponse(oMFJourney));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetDefaultFundingReductionJourney() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetFRJourneyByFundingReductionId")]
        public IActionResult GetFRJourneyByFundingReductionId(int id)
        {
            logger.LogInformation("GetFRJourneyByFundingReductionId");
            try
            {
                var frJourney = omfJourneyService.GetFRJourneyByFundingReductionId(id);
                return Ok(new ApiOkResponse(frJourney));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetFRJourneyByFundingReductionId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
