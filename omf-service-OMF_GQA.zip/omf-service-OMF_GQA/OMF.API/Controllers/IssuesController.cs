﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OMF.API.Common;
using OMF.Business.Interfaces;
using OMF.Business.Common;
using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;

namespace OMF.API.Controllers
{
    [Route("api/omf/[controller]/[action]")]
    public class IssuesController : Controller
    {

        private readonly IIssuesService issuesService;
        private readonly ILogger<IssuesController> logger;

        public IssuesController(IIssuesService service, ILogger<IssuesController> logger)
        {
            this.issuesService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetIssues")]
        public IActionResult GetIssues()
        {
            List<string> errors = new List<string>();
            try
            {
                logger.LogInformation("GetIssues");
                IEnumerable<IssuesViewModel> issuesViewModel = issuesService.GetAllIssues();
                return Ok(new ApiOkResponse(issuesViewModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetIssues");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetIssueById/{issueId}")]
        public IActionResult GetIssueById(int issueId)
        {
            List<string> errors = new List<string>();
            try
            {
                logger.LogInformation("GetIssueById");
                IEnumerable<IssuesViewModel> issuesViewModel = issuesService.GetIssueById(issueId);
                return Ok(new ApiOkResponse(issuesViewModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetIssueById", issueId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetOMFSupport")]
        public IActionResult GetOMFSupport()
        {
            List<string> errors = new List<string>();
            try
            {
                logger.LogInformation("GetOMFSupport");
                IEnumerable<OMFSupportViewModel> OMFSupportViewModel = issuesService.GetOMFSupport();
                return Ok(new ApiOkResponse(OMFSupportViewModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOMFSupport");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetOMFScreens")]
        public IActionResult GetOMFScreens()
        {
            List<string> errors = new List<string>();
            try
            {
                logger.LogInformation("GetOMFScreens");
                IEnumerable<OMFScreensViewModel> OMFScreensViewModel = issuesService.GetOMFScreens();
                return Ok(new ApiOkResponse(OMFScreensViewModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOMFScreens");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // POST  the values in the table based on the
        [HttpPost]
        [ActionName("AddNewIssue")]
        public IActionResult AddNewIssue([FromBody] IssuesViewModel issuesViewModel)
        {
            logger.LogInformation("AddNewIssue", issuesViewModel);
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                var userClaimsValues = GetUserClaims();
                var response = issuesService.AddIssue(issuesViewModel, userClaimsValues);
                return this.Ok(new ApiOkResponse(response));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "AddNewIssue", issuesViewModel);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateIssue")]
        public IActionResult UpdateIssue([FromBody] IssuesViewModel issuesViewModel)
        {
            logger.LogInformation("UpdateIssue", issuesViewModel);
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                var userClaimsValues = GetUserClaims();
                var response = issuesService.UpdateIssue(issuesViewModel, userClaimsValues);
                return this.Ok(new ApiOkResponse(response));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateIssue", issuesViewModel);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut("{id}")]
        [ActionName("DeleteIssue")]
        public IActionResult DeleteIssue(int id)
        {
            logger.LogInformation("DeleteIssue", id);
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                var response = issuesService.DeleteIssue(id);
                return this.Ok(new ApiOkResponse(response));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "DeleteIssue", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        private Business.Models.UserViewModel GetUserClaims()
        {
            try
            {
                logger.LogInformation("GetUserClaims");
                Business.Models.UserViewModel userViewModel = new Business.Models.UserViewModel
                {
                    Name = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value,
                    EmployeeId = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.UserId).Value,
                    Email = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.UserEmail).Value,
                    Role = HttpContext.User.FindFirst(ClaimTypes.Role).Value,
                    //Alias = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value,
                    //Location = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Location).Value,
                    //ManagerName = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.ManagerName).Value,
                    //ManagerMail = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.ManagerMail).Value
                };
                return userViewModel;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetUserClaims");
                return default(Business.Models.UserViewModel);
            }
        }
    }
}

