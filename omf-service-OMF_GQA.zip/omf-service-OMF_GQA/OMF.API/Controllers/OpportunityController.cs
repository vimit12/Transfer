﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [EnableCors("CorsPolicy")]
    [Route("api/omf/[controller]/[action]")]
    public class OpportunityController : Controller
    {
        private readonly IOpportunityService opportunityService;
        private readonly ILogger<OpportunityController> logger;
        private readonly IHiQService hiQService;

        public OpportunityController(IOpportunityService service, ILogger<OpportunityController> logger, IHiQService hiQService)
        {
            this.opportunityService = service;
            this.logger = logger;
            this.hiQService = hiQService;
        }

        [HttpGet("{opportunityId}/{contractTypeId}")]
        [ActionName("GetOpportunitySections")]
        public IActionResult GetOpportunitySections(int opportunityId, int contractTypeId)
        {
            try
            {
                logger.LogInformation("GetOpportunitySections", opportunityId, contractTypeId);
                return Ok(new ApiOkResponse(opportunityService.GetOpportunitySections(opportunityId, contractTypeId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunitySections", opportunityId, contractTypeId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetAllSectionsForOpportunity")]
        public IActionResult GetAllSectionsForOpportunity(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetAllSectionsForOpportunity", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetAllSectionsForOpportunity(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetAllSectionsForOpportunity", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetOpportunityMasterDetails")]
        public IActionResult GetOpportunityMasterDetails(int id)
        {
            try
            {
                logger.LogInformation("GetContingencyValue", id);
                return Ok(new ApiOkResponse(opportunityService.GetOpportunityMasterDetails(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetContingencyValue", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetAllOpportunities")]
        public IActionResult GetAllOpprtunities()
        {
            logger.LogInformation("GetAllOpprtunities");
            try
            {
                var opprtunity = opportunityService.GetAllOpportunities();
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllOpprtunities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetOmfFinancialSections")]
        public IActionResult GetOmfFinancialSections()
        {
            logger.LogInformation("GetOmfFinancialSections");
            try
            {
                var opprtunity = opportunityService.GetOmfFinancialSections();
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOmfFinancialSections() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetOpportunityById")]
        public async Task<IActionResult> GetOpportunityById(int id)
        {
            try
            {
                logger.LogInformation("GetOpportunityById", id);
                return Ok(new ApiOkResponse(await opportunityService.GetOpportunityById(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityById", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityQpeDetailsFromHiq")]
        public async Task<IActionResult> GetOpportunityQpeDetailsFromHiq(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityQpeDetailsFromHiq", opportunityId);
                return Ok(new ApiOkResponse(await hiQService.GetOpportunityQpeDetailsFromHiq(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityQpeDetailsFromHiq", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityQpeDetails")]
        public async Task<IActionResult> GetOpportunityQpeDetails(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityQpeDetails", opportunityId);
                return Ok(new ApiOkResponse(await opportunityService.GetOpportunityQpeDetails(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityQpeDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetOpportunities")]
        public IActionResult GetOpportunities()
        {
            try
            {
                logger.LogInformation("GetOpportunities");
                return Ok(new ApiOkResponse(opportunityService.GetOpportunities()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunities");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetAllClients")]
        public IActionResult GetAllClients()
        {
            logger.LogInformation("GetAllClients");
            try
            {
                var clientNames = opportunityService.GetAllClients();
                return Ok(new ApiOkResponse(clientNames));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllClients() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetAccessDetailsByOpportunityId")]
        public IActionResult GetAccessDetailsByOpportunityId(int id)
        {
            logger.LogInformation("GetAccessDetailsByOpportunityId");
            try
            {
                var accessDetails = opportunityService.GetAccessDetailsByOpportunityId(id, HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value);
                return Ok(new ApiOkResponse(accessDetails));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAccessDetailsByOpportunityId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut("{id}")]
        [ActionName("DeleteOpportunity")]
        public IActionResult DeleteOpportunity(int id)
        {
            logger.LogInformation("DeleteOpportunity");
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                opportunityService.DeleteOpportunity(id);
                return Ok(new ApiOkResponse(id));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "DeleteOpportunity() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetCountryDetailsByContractingOrganization")]
        public IActionResult GetCountryDetailsByContractingOrganization(OpportunityBasicDetailsViewModel opportunityBasicDetailsView)
        {
            try
            {
                logger.LogInformation("opportunityBasicDetailsView");
                return Ok(new ApiOkResponse(opportunityService.GetCountryDetailsByContractingOrganization(opportunityBasicDetailsView)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "opportunityBasicDetailsView");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveInfoCompliance")]
        public IActionResult SaveInfoCompliance([FromBody]InfoViewModel info)
        {
            logger.LogInformation("SaveInfoCompliance");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                var validate = opportunityService.ValidateInfoCompliance(info, out string errorMessage);
                if (!validate)
                {
                    return Ok(new ApiOkResponse(errorMessage));//BadRequest(errorMessage);
                }
                var validateReportingPractice = opportunityService.ValidateReportingPracticeAndCOPByOppId(info);
                if (!validateReportingPractice.IsValidData)
                {
                    return Ok(new ApiOkResponse(validateReportingPractice));
                }
                var opportunityStatusViewModel = opportunityService.SaveInfoCompliance(info);
                return Ok(new ApiOkResponse(opportunityStatusViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveInfoCompliance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("ComplianceDetailsByOpportunity")]
        public IActionResult ComplianceDetailsByOpportunity(int id)
        {
            try
            {
                logger.LogInformation("ComplianceDetailsByOpportunity", id);
                return Ok(new ApiOkResponse(opportunityService.ComplianceDetailsByOpportunity(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ComplianceDetailsByOpportunity", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveCompliance")]
        public IActionResult SaveCompliance([FromBody]ComplianceViewModel compl)
        {
            logger.LogInformation("SaveCompliance");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveCompliance(compl);
                return Ok(new ApiOkResponse(compl));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveCompliance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // Project Summary Section Code

        // Project Summary Capabilities
        [HttpGet("{id}")]
        [ActionName("GetProjectSummaryCapabilities")]
        public IActionResult GetProjectSummaryCapabilities(int id)
        {
            try
            {
                logger.LogInformation("GetProjectSummaryCapabilities", id);
                return Ok(new ApiOkResponse(opportunityService.GetProjectSummaryCapabilities(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectSummaryCapabilities", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveProjectSummaryCapabilities")]
        public IActionResult SaveProjectSummaryCapabilities([FromBody]IEnumerable<OpportunityProjectSummaryCapabilityViewModel> prjSummary)
        {
            logger.LogInformation("SaveProjectSummaryCapabilities");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveProjectSummaryCapabilities(prjSummary);
                return Ok(new ApiOkResponse(prjSummary));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveProjectSummaryCapabilities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // Project Summary Technologies
        [HttpGet("{id}")]
        [ActionName("GetProjectSummaryTechnologies")]
        public IActionResult GetProjectSummaryTechnologies(int id)
        {
            try
            {
                logger.LogInformation("GetProjectSummaryTechnologies", id);
                return Ok(new ApiOkResponse(opportunityService.GetProjectSummaryTechnologies(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectSummaryTechnologies", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveProjectTechnologies")]
        public IActionResult SaveProjectTechnologies([FromBody]IEnumerable<OpportunityProjectSummaryTechnologyViewModel> prjTechnologies)
        {
            logger.LogInformation("SaveProjectTechnologies");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveProjectTechnologies(prjTechnologies);
                return Ok(new ApiOkResponse(prjTechnologies));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveProjectTechnologies() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // Global Solutions Section
        [HttpGet("{id}")]
        [ActionName("GetProjectGlobalSolutions")]
        public IActionResult GetProjectGlobalSolutions(int id)
        {
            try
            {
                logger.LogInformation("GetProjectGlobalSolutions", id);
                return Ok(new ApiOkResponse(opportunityService.GetProjectGlobalSolutions(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectGlobalSolutions", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // Save GLobal  Solutions Section Code
        [HttpPost]
        [ActionName("SaveGlobalSolutions")]
        public IActionResult SaveGlobalSolutions([FromBody]IEnumerable<OpportunityProjectSummaryGlobalSolutionViewModel> prjGolbalSolutions)
        {
            logger.LogInformation("SaveGlobalSolutions");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveProjectGlobalSolutions(prjGolbalSolutions);
                return Ok(new ApiOkResponse(prjGolbalSolutions));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveGlobalSolutions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // Main Project Summary Section
        [HttpGet("{id}")]
        [ActionName("GetProjectSummary")]
        public IActionResult GetProjectSummary(int id)
        {
            try
            {
                logger.LogInformation("GetProjectSummary", id);
                return Ok(new ApiOkResponse(opportunityService.GetMainProjectSummary(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectSummary", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveProjectSummary")]
        public IActionResult SaveProjectSummary([FromBody]OpportunityProjectSummaryViewModel prjSummary)
        {
            logger.LogInformation("OpportunityProjectSummaryViewModel");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveProjectSummary(prjSummary);
                return Ok(new ApiOkResponse(prjSummary));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "OpportunityProjectSummaryViewModel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetFinancialWeeklyHoursByQuarters")]
        public IActionResult GetFinancialWeeklyHoursByQuarters(FinancialWeeklyHoursViewModel financialWeeklyHoursViewModel)
        {
            try
            {
                logger.LogInformation("GetFinancialWeeklyHoursByQuarters");
                return Ok(new ApiOkResponse(opportunityService.GetFinancialWeeklyHoursByQuarters(financialWeeklyHoursViewModel)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetFinancialWeeklyHoursByQuarters");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}/{year}/{loadingpercentage}")]
        [ActionName("GetOMFCurrentFinancialWeeklyHours")]
        public IActionResult GetOMFCurrentFinancialWeeklyHours(int opportunityId, int year, decimal loadingpercentage)
        {
            try
            {
                logger.LogInformation("GetOMFCurrentFinancialWeeklyHours", opportunityId, year);
                return Ok(new ApiOkResponse(opportunityService.GetOMFCurrentFinancialWeeklyHours(opportunityId, year, loadingpercentage)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOMFCurrentFinancialWeeklyHours", opportunityId, year);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetProposalFinancialSummaryDetails")]
        public IActionResult GetProposalFinancialSummaryDetails(int opportunityId, int yearId)
        {
            try
            {
                logger.LogInformation("GetProposalFinancialSummaryDetails", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetProposalFinancialSummaryDetails(opportunityId, yearId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProposalFinancialSummaryDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("CheckOpportunityAccess")]
        public IActionResult CheckOpportunityAccess(int opportunityId)
        {
            try
            {
                logger.LogInformation("CheckOpportunityAccess", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.CheckOpportunityAccess(opportunityId, HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "CheckOpportunityAccess", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityOverviewDetails")]
        public IActionResult GetOpportunityOverviewDetails(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityOverviewDetails", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetOpportunityOverview(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProposalFinancialSummaryDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveOpportunityOverview")]
        public IActionResult SaveOpportunityOverview([FromBody]OpportunityOverviewViewModel oppOverview)
        {
            logger.LogInformation("OpportunityOverviewViewModel");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveOpportunityOverview(oppOverview);
                return Ok(new ApiOkResponse(oppOverview));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "OpportunityOverviewViewModel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityRisksDetails")]
        public IActionResult GetOpportunityRisksDetails(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityRisksDetails", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetOpportunityRisks(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityRisksDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveOrUpdateOpportunityRisks")]
        public IActionResult SaveOrUpdateOpportunityRisks([FromBody]List<OpportunityRisksViewModel> oppRisks)
        {
            logger.LogInformation("OpportunityRisksViewModel");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveOrUpdateOpportunityRisks(oppRisks);
                return Ok(new ApiOkResponse(oppRisks));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "OpportunityRisksViewModel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("DeleteOpportunityRisks")]
        public IActionResult DeleteOpportunityRisks([FromBody]List<OpportunityRisksViewModel> oppRisks)
        {
            logger.LogInformation("DeleteOpportunityRisks");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.DeleteOpportunityRisks(oppRisks);
                return Ok(new ApiOkResponse(oppRisks));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "DeleteOpportunityRisks() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetProposalFinancialOverviewSummaryDetails")]
        public IActionResult GetProposalFinancialOverviewSummaryDetails(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetProposalFinancialOverviewSummaryDetails", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetProposalFinancialOverviewSummaryDetails(opportunityId, 0)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProposalFinancialOverviewSummaryDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityProjectDetail")]
        public IActionResult GetOpportunityProjectDetail(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityProjectDetails", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetOpportunityProjectDetails(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityProjectDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveOrUpdateOpportunityProjectDetail")]
        public IActionResult SaveOrUpdateOpportunityProjectDetail([FromBody] OpportunityProjectDetailsViewModel oppProjectDetail)
        {
            logger.LogInformation("OpportunityProjectDetailViewModel");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveOrUpdateOpportunityProjectDetail(oppProjectDetail);
                return Ok(new ApiOkResponse(oppProjectDetail));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "OpportunityProjectDetailViewModel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetComplianceScreeningInstructions")]
        public IActionResult GetComplianceScreeningInstructions()
        {
            try
            {
                logger.LogInformation("GetComplianceScreeningInstructions");
                return Ok(new ApiOkResponse(opportunityService.GetComplianceScreeningInstructions()));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetComplianceScreeningInstructions");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // Code for CROpportunity
        [HttpPost]
        [ActionName("SaveCROpportunity")]
        public IActionResult SaveCROpportunity([FromBody] CROpportunityViewModel crOpportunity)
        {
            logger.LogInformation("SaveCROpportunity");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveCROpportunity(crOpportunity);
                return Ok(new ApiOkResponse(this.Response.StatusCode));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveCROpportunity() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityRatingDetails")]
        public IActionResult GetOpportunityRatingDetails(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityRatingDetails", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetOpportunityRating(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityRatingDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveOrUpdateOpportunityRating")]
        public IActionResult SaveOrUpdateOpportunityRating([FromBody]OpportunityRatingViewModel oppRating)
        {
            logger.LogInformation("OpportunityRatingViewModel");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveOrUpdateOpportunityRating(oppRating);
                return Ok(new ApiOkResponse(oppRating));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "OpportunityRatingViewModel() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetOpportunitiesByUser")]
        public IActionResult GetOpportunitiesByUser()
        {
            logger.LogInformation("GetOpportunitiesByUser");
            try
            {
                var opprtunity = opportunityService.GetOpportunitiesByUser();
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOpportunitiesByUser() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetProjectDealPercentage")]
        public IActionResult GetProjectDealPercentage(int id)
        {
            try
            {
                logger.LogInformation("GetProjectDealPercentage", id);
                return Ok(new ApiOkResponse(opportunityService.GetProjectDealPercentage(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectDealPercentage", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost("{oppId}")]
        [ActionName("SaveNewVersion")]
        public IActionResult SaveNewVersion(int oppId)
        {
            logger.LogInformation("SaveNewVersion");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveNewVersion(oppId);
                return Ok(new ApiOkResponse(this.Response.StatusCode));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveNewVersion() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveORBAttachments")]
        public async Task<IActionResult> SaveORBAttachments([FromBody] ORBAttachmentViewModel viewModel)
        {
            logger.LogInformation("SaveORBAttachments");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                await opportunityService.SaveORBAttachments(viewModel);
                return Ok(new ApiOkResponse(this.Response.StatusCode));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveORBAttachments() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetORBAttachmentsForOpportunity")]
        public IActionResult GetORBAttachmentsForOpportunity(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetORBAttachmentsForOpportunity", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetORBAttachmentsForOpportunity(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetORBAttachmentsForOpportunity", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetOpportunitiesForHistoryPage")]
        public IActionResult GetOpportunitiesForHistoryPage(DateTime startDate, DateTime endDate)
        {
            logger.LogInformation("GetOpportunitiesForHistoryPage");
            try
            {
                var opprtunity = opportunityService.GetOpportunitiesForHistoryPage(startDate, endDate);
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOpportunitiesForHistoryPage() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet()]
        [ActionName("GetOpportunitiesForHistoryPageByDates/{startDate}/{endDate}")]
        public IActionResult GetOpportunitiesForHistoryPageByDates(DateTime startDate, DateTime endDate)
        {
            logger.LogInformation("GetOpportunitiesForHistoryPage");
            try
            {
                var opprtunity = opportunityService.GetOpportunitiesForHistoryPage(startDate, endDate);
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOpportunitiesForHistoryPage() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        //[HttpGet]
        //[ActionName("GetStatusesForLandingPage")]
        //public IActionResult GetStatusesForLandingPage(DateTime startDate, DateTime endDate)
        //{
        //    logger.LogInformation("GetStatusesForLandingPage");
        //    try
        //    {
        //        var opprtunity = opportunityService.GetStatusesForLandingPage(startDate, endDate);
        //        return Ok(new ApiOkResponse(opprtunity));
        //    }
        //    catch (Exception exception)
        //    {
        //        logger.LogError(exception, "GetStatusesForLandingPage() - Exception");
        //        return BadRequest(Constants.PageErrorMessage);
        //    }
        //}

        [HttpGet("{option}")]
        [ActionName("GetOpportunitiesForLandingPage")]
        public IActionResult GetOpportunitiesForLandingPage(int option)
        {
            logger.LogInformation("GetOpportunitiesForLandingPage");
            try
            {
                var opprtunity = opportunityService.GetOpportunitiesForLandingPage(option);
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOpportunitiesForLandingPage() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetCurrentStatusForOpportunity")]
        public IActionResult GetCurrentStatusForOpportunity(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetCurrentStatusForOpportunity", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetCurrentStatusForOpportunity(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetCurrentStatusForOpportunity", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetCompletedOpportunitiesForCRList")]
        public IActionResult GetCompletedOpportunitiesForCRList()
        {
            try
            {
                logger.LogInformation("GetCompletedOpportunitiesForCRList");
                return Ok(new ApiOkResponse(opportunityService.GetCompletedOpportunitiesForCRList()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetCompletedOpportunitiesForCRList");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveDocuments")]
        public async Task<IActionResult> SaveDocuments([FromBody]OpportunityDocumentDetailsViewModel model)
        {
            try
            {
                logger.LogInformation("SaveDocuments");
                await opportunityService.SaveDocuments(model);
                return Ok(new ApiOkResponse("Success"));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "SaveDocuments");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityDocumentDetailsId}")]
        [ActionName("GetOpportunityDocumentDetails")]
        public async Task<IActionResult> GetOpportunityDocumentDetails(int opportunityDocumentDetailsId)
        {
            try
            {
                logger.LogInformation("GetOpportunityDocumentDetails");
                return Ok(new ApiOkResponse(await opportunityService.GetOpportunityDocumentDetails(opportunityDocumentDetailsId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityDocumentDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut("{opportunityDocumentDetailsId}")]
        [ActionName("DeleteDocument")]
        public async Task<IActionResult> DeleteDocument(int opportunityDocumentDetailsId)
        {
            try
            {
                logger.LogInformation("DeleteDocument");
                return Ok(new ApiOkResponse(await opportunityService.DeleteDocument(opportunityDocumentDetailsId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityDocumentDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityDocumentMetaData")]
        public ActionResult GetOpportunityDocumentMetaData(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityDocumentMetaData");
                return Ok(new ApiOkResponse(opportunityService.GetOpportunityDocumentMetaData(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityDocumentMetaData");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut("{opportunityId}")]
        [ActionName("InsertDataToRevenueTableForMissingOpportunity")]
        public IActionResult InsertDataToRevenueTableForMissingOpportunity(int opportunityId)
        {
            try
            {
                opportunityService.InsertDataToRevenueTableForMissingOpportunity(opportunityId);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [ActionName("UpdateProjectDiscountPercentages")]
        public IActionResult UpdateProjectDiscountPercentages()
        {
            try
            {
                opportunityService.UpdateProjectDiscountPercentages();
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [ActionName("MoveCommentsFromOrb")]
        public async Task<IActionResult> MoveCommentsFromOrb()
        {
            try
            {
                return Ok(await opportunityService.MoveCommentsFromOrb());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}/{type}")]
        [ActionName("SetOpportunityForAudit")]
        public IActionResult SetOpportunityForAudit(int id, int type)
        {
            logger.LogInformation("SetOpportunityForAudit");
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                opportunityService.SetOpportunityForAudit(id, type);
                return Ok(new ApiOkResponse(id));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SetOpportunityForAudit() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut("{id}/{type}")]
        [ActionName("SetOpportunityForAuditAsComplete")]
        public IActionResult SetOpportunityForAuditAsComplete(int id, int type)
        {
            logger.LogInformation("SetOpportunityForAuditAsComplete");
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                opportunityService.SetOpportunityForAuditAsComplete(id, type);
                return Ok(new ApiOkResponse(id));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SetOpportunityForAuditAsComplete() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveOpportunityComplianceUserMapping")]
        public async Task<IActionResult> SaveOpportunityComplianceUserMapping([FromBody]OpportunityComplianceUserMappingViewModel model)
        {
            try
            {
                logger.LogInformation("SaveOpportunityComplianceUserMapping");
                opportunityService.SaveOpportunityComplianceUserMapping(model);
                return Ok(new ApiOkResponse("Success"));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "SaveOpportunityComplianceUserMapping");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateOICMissingUserIds")]
        public async Task<IActionResult> UpdateOICMissingUserIds()
        {
            try
            {
                logger.LogInformation("UpdateOICMissingUserIds");
                opportunityService.UpdateOICMissingUserIds();
                return Ok(new ApiOkResponse("Success"));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateOICMissingUserIds");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetPeriscopeModelForOpportunity")]
        public IActionResult GetPeriscopeModelForOpportunity(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetPeriscopeModelForOpportunity", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetPeriscopeModelForOpportunity(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetPeriscopeModelForOpportunity", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost("{oppId}")]
        [ActionName("CopyOpportunityInfo")]
        public IActionResult CopyOpportunityInfo(int oppId)
        {
            logger.LogInformation("CopyOpportunityInfo");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.CopyOpportunityInfo(oppId, false);
                return Ok(new ApiOkResponse(this.Response.StatusCode));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "CopyOpportunityInfo() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("PendingStatus")]
        public IActionResult PendingStatus([FromBody]PendingStatusViewModel pendingStatusViewModel)
        {
            logger.LogInformation("PendingStatus");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.PendingStatus(pendingStatusViewModel);
                return Ok(new ApiOkResponse(this.Response.StatusCode));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "PendingStatus() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityEmployeeRevenueCost")]
        public IActionResult GetOpportunityEmployeeRevenueCost(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityEmployeeRevenueCost", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetOpportunityEmployeeRevenueCost(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityEmployeeRevenueCost", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityContractRevenueCost")]
        public IActionResult GetOpportunityContractRevenueCost(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityContractRevenueCost", opportunityId);
                return Ok(new ApiOkResponse(opportunityService.GetOpportunityContractRevenueCost(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityContractRevenueCost", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }
        //[HttpGet]
        //[ActionName("GetSharePointToken")]
        //public async Task<IActionResult> GetSharePointToken()
        //{
        //    return Ok(new ApiOkResponse(await sharePointService.GetSharePointAccessToken()));
        //}

        [HttpGet]
        [ActionName("GetProjectCodesAccessWise")]
        public IActionResult GetProjectCodesAccessWise()
        {
            logger.LogInformation("GetProjectCodesAccessWise");
            try
            {
                var opprtunity = opportunityService.GetProjectCodesAccessWise();
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetProjectCodesAccessWise() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{projectCode}/{crmId}/{clientId}")]
        [ActionName("GetOpportunitiesByProjectCodeOrCrmIdOrClientId")]
        public IActionResult GetOpportunitiesByProjectCodeOrCrmIdOrClientId(string projectCode, string crmId, int clientId)
        {
            logger.LogInformation("GetOpportunitiesByProjectCodeOrCrmIdOrClientId");
            try
            {
                var opprtunity = opportunityService.GetOpportunitiesByProjectCodeOrCrmIdOrClientId(projectCode, crmId, clientId);
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOpportunitiesByProjectCodeOrCrmIdOrClientId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunitiyAccessUsers")]
        public IActionResult GetOpportunitiyAccessUsers(int opportunityId)
        {
            logger.LogInformation("GetOpportunitiyAccessUsers");
            try
            {
                var opprtunity = opportunityService.GetOpportunitiyAccessUsers(opportunityId);
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOpportunitiyAccessUsers() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveOrUpdateOpportunitiyAccessUsers")]
        public IActionResult SaveOrUpdateOpportunitiyAccessUsers([FromBody]IEnumerable<OpportunityAccessViewModel> oppAccessUsers)
        {
            logger.LogInformation("SaveOrUpdateOpportunitiyAccessUsers");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.SaveOrUpdateOpportunitiyAccessUsers(oppAccessUsers);
                return Ok(new ApiOkResponse(oppAccessUsers));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveOrUpdateOpportunitiyAccessUsers() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunitiyAuditAccess")]
        public IActionResult GetOpportunitiyAuditAccess(int opportunityId)
        {
            logger.LogInformation("GetOpportunitiyAuditAccess");
            try
            {
                var opprtunity = opportunityService.GetOpportunitiyAuditAccess(opportunityId);
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOpportunitiyAuditAccess() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveOpportunityIFRSUserMapping")]
        public async Task<IActionResult> SaveOpportunityIFRSUserMapping([FromBody] OpportunityComplianceUserMappingViewModel model)
        {
            try
            {
                logger.LogInformation("SaveOpportunityIFRSUserMapping");
                opportunityService.SaveOpportunityIFRSUserMapping(model);
                return Ok(new ApiOkResponse("Success"));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "SaveOpportunityIFRSUserMapping");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("CostRateUpdate")]
        public IActionResult CostRateUpdate([FromBody]PendingStatusViewModel pendingStatusViewModel)
        {
            logger.LogInformation("CostRateUpdate");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.PendingStatus(pendingStatusViewModel);
                return Ok(new ApiOkResponse(this.Response.StatusCode));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "CostRateUpdate() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{crmId}")]
        [ActionName("GetOpportunitiesByCrmId")]
        public IActionResult GetOpportunitiesByCrmId(string crmId)
        {
            logger.LogInformation("GetOpportunitiesByCrmId");
            try
            {
                var opprtunity = opportunityService.GetOpportunitiesByCrmId(crmId);
                return Ok(new ApiOkResponse(opprtunity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOpportunitiesByCrmId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateBAByOpportunityIds")]
        public IActionResult UpdateBAByOpportunityIds([FromBody] BillingAdminByOpportunities billingAdminViewModel)
        {
            logger.LogInformation("UpdateBAByOpportunityIds");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                opportunityService.UpdateBillingAdministratorByOpportunityIds(billingAdminViewModel);
                return Ok(new ApiOkResponse(this.Response.StatusCode));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateBAByOpportunityIds() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}