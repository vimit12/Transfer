﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [EnableCors("CorsPolicy")]
    [Route("api/omf/[controller]/[action]")]
    public class OppLeveragePercentVarianceController : Controller
    {
        private readonly IOppLeveragePercentVarianceService oppLeveragePercentVarianceService;

        private readonly ILogger<OppLeveragePercentVarianceController> logger;

        public OppLeveragePercentVarianceController(IOppLeveragePercentVarianceService service, ILogger<OppLeveragePercentVarianceController> logger)
        {
            this.oppLeveragePercentVarianceService = service;
            this.logger = logger;
        }

        [HttpPost]
        [ActionName("SaveOppLeverageVariance")]
        public IActionResult SaveOppLeverageVariance([FromBody] OpportunityLeveragePercentVarianceViewModel oppLeveragePercentVarianceAssessmentViewModel)
        {
            logger.LogInformation("SaveOppLeverageVariance");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {

                oppLeveragePercentVarianceService.SaveOppLeverageVariance(oppLeveragePercentVarianceAssessmentViewModel);
                return Ok(new ApiOkResponse(oppLeveragePercentVarianceAssessmentViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveOppLeverageVariance() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOppLeverageVarianceDetails")]
        public IActionResult GetOppLeverageVarianceDetails(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOppLeverageVarianceDetails", opportunityId);
                return Ok(new ApiOkResponse(oppLeveragePercentVarianceService.GetOppLeverageVarianceDetails(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOppLeverageVarianceDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetLeverageConfigDetailsForOpp")]
        public IActionResult GetLeverageConfigDetailsForOpp(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetLeverageConfigDetailsForOpp", opportunityId);
                return Ok(new ApiOkResponse(oppLeveragePercentVarianceService.GetLeverageConfigDetailsForOpp(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetLeverageConfigDetailsForOpp", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}