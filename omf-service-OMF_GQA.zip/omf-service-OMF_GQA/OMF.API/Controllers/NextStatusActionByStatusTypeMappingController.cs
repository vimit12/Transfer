﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class NextStatusActionByStatusTypeMappingController : Controller
    {
        private readonly INextStatusActionByStatusTypeMappingService nextStatusTypeMappingService;

        private readonly ILogger<NextStatusActionByStatusTypeMappingController> logger;

        public NextStatusActionByStatusTypeMappingController(INextStatusActionByStatusTypeMappingService service, ILogger<NextStatusActionByStatusTypeMappingController> logger)
        {
            this.nextStatusTypeMappingService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllNextStatusActions")]
        public IActionResult GetAllNextStatusActions()
        {
            logger.LogInformation("GetAllNextStatusActions");
            try
            {
                var nextStatusActionByStatusTypeMappings = nextStatusTypeMappingService.GetAllNextStatusActions();
                return Ok(new ApiOkResponse(nextStatusActionByStatusTypeMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllNextStatusActions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveNextStatusActions")]
        public IActionResult GetActiveNextStatusActions(int opportunityId)
        {
            logger.LogInformation("GetActiveNextStatusActions");
            try
            {
                var nextStatusActions = nextStatusTypeMappingService.GetActiveNextStatusActions(opportunityId);
                return Ok(new ApiOkResponse(nextStatusActions));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveNextStatusActions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddNextStatusAction")]
        public IActionResult AddNextStatusAction([FromBody]NextStatusActionByStatusTypeMappingViewModel model)
        {
            logger.LogInformation("AddNextStatusAction");
            try
            {
                model.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                nextStatusTypeMappingService.AddNextStatusAction(model);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddNextStatusAction() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
