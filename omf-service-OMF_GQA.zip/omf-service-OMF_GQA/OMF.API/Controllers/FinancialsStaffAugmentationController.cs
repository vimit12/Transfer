﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OMF.API.Common;
using OMF.Business.Interfaces;
using OMF.Business.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OMF.Business.Models;

namespace OMF.API.Controllers
{
    [Route("api/omf/[controller]/[action]")]
    public class FinancialsStaffAugmentationController : Controller
    {
        private readonly IFinancialsStaffAugmentationService financialsStaffAugmentationService;
        private readonly ILogger<FinancialsStaffAugmentationController> logger;

        public FinancialsStaffAugmentationController(IFinancialsStaffAugmentationService financialsStaffAugmentationService, ILogger<FinancialsStaffAugmentationController> logger)
        {
            this.financialsStaffAugmentationService = financialsStaffAugmentationService;
            this.logger = logger;
        }

        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetFinancialsStaffAugmentations")]
        public IActionResult GetFinancialStaffAugmentations(int opportunityId, int yearId)
        {
            try
            {
                logger.LogInformation("GetFinancialStaffAugmentations", opportunityId);
                return Ok(new ApiOkResponse(financialsStaffAugmentationService.GetFinancialsStaffAugmentations(opportunityId, yearId)));
            }
            catch(Exception ex)
            {
                logger.LogError(ex, "GetFinancialStaffAugmentations");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetEmptyFinancialsStaffAugmentations")]
        public IActionResult GetFinancialStaffAugmentations()
        {
            try
            {
                logger.LogInformation("GetFinancialStaffAugmentations");
                return Ok(new ApiOkResponse(financialsStaffAugmentationService.GetFinancialsStaffAugmentations()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetFinancialStaffAugmentations");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveFinancialsStaffAugmentations")]
        public IActionResult SaveFinancialsStaffAugmentations([FromBody]IEnumerable<FinancialsStaffAugmentationViewModel> financialsStaffAugmentations)
        {
            try
            {
                logger.LogInformation("SaveFinancialsStaffAugmentations");
                financialsStaffAugmentationService.SaveFinancialsStaffAugmentations(financialsStaffAugmentations);
                return Ok(new ApiOkResponse(financialsStaffAugmentations));
            }
            catch(Exception ex)
            {
                logger.LogError(ex, "SaveFinancialsStaffAugmentations");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("DeleteFinancialsStaffAugmentations")]
        public IActionResult DeleteFinancialsStaffAugmentations([FromBody]FinancialsStaffAugmentationViewModel financialsStaffAugmentationViewModels)
        {
            try
            {
                logger.LogInformation("DeleteFinancialsStaffAugmentations");
                financialsStaffAugmentationService.DeleteFinancialsStaffAugmentation(financialsStaffAugmentationViewModels);
                return Ok(new ApiOkResponse("Deleted"));
            }
            catch(Exception ex)
            {
                logger.LogError(ex, "DeleteFinancialsStaffAugmentations");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
