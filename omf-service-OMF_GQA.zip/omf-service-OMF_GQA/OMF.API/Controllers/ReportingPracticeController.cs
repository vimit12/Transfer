﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;

    [Route("api/omf/[controller]/[action]")]
    public class ReportingPracticeController : Controller
    {
        private readonly IReportingPracticeService reportingPracticeService;

        private readonly ILogger<ReportingPracticeController> logger;

        public ReportingPracticeController(IReportingPracticeService service, ILogger<ReportingPracticeController> logger)
        {
            this.reportingPracticeService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllReportingPractices")]
        public IActionResult GetAllReportingPractices()
        {
            this.logger.LogInformation("GetAllReportingPractices");
            try
            {
                var reportingPractices = this.reportingPracticeService.GetReportingPractices();
                return this.Ok(new ApiOkResponse(reportingPractices));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllReportingPractices() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveReportingPractice")]
        public IActionResult GetActiveReportingPractices()
        {
            this.logger.LogInformation("GetActiveReportingPractices");
            try
            {
                var reportingPractices = this.reportingPracticeService.GetActiveReportingPractices();
                return this.Ok(new ApiOkResponse(reportingPractices));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActiveReportingPractices() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetReportingPracticeById")]
        public IActionResult GetReportingPracticeById(int id)
        {
            this.logger.LogInformation("GetReportingPracticeById");
            try
            {
                var employeetype = this.reportingPracticeService.GetReportingPracticeById(id);
                return this.Ok(new ApiOkResponse(employeetype));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetReportingPracticeById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddReportingPractice")]
        public IActionResult AddReportingPractice([FromBody]ReportingPracticeViewModel reportingPractice)
        {
            this.logger.LogInformation("AddReportingPractice");
            try
            {
                reportingPractice.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.reportingPracticeService.AddReportingPractice(reportingPractice);
                return this.Ok(new ApiOkResponse(reportingPractice));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddReportingPractice() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateReportingPractice")]
        public IActionResult UpdateReportingPractice([FromBody]ReportingPracticeViewModel reportingPractice)
        {
            this.logger.LogInformation("UpdateReportingPractice", reportingPractice);
            try
            {
                var getemployeetype = this.reportingPracticeService.GetReportingPracticeById(reportingPractice.ReportingPracticeId);
                if (getemployeetype == null)
                {
                    return this.NotFound("Employee Type not found.");
                }
                else
                {
                    reportingPractice.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.reportingPracticeService.UpdateReportingPractice(reportingPractice);
                    return this.Ok(new ApiOkResponse(reportingPractice));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateReportingPractice() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetReportingPracticeDetails")]
        public IActionResult GetReportingPracticeDetails()
        {
            this.logger.LogInformation("GetReportingPracticeDetails");
            try
            {
                var reportingPractices = this.reportingPracticeService.GetReportingPracticeDetails();
                return this.Ok(new ApiOkResponse(reportingPractices));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetReportingPracticeDetails() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}