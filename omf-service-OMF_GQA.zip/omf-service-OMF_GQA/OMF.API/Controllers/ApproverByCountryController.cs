﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ApproverByCountryController : Controller
    {
        private readonly IApproverByCountryService approverByCountryService;

        private readonly ILogger<ApproverByCountryController> logger;

        public ApproverByCountryController(IApproverByCountryService service, ILogger<ApproverByCountryController> logger)
        {
            this.approverByCountryService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetApproversByCountry")]
        public IActionResult GetApproversByCountry()
        {
            logger.LogInformation("GetApproversByCountry");
            try
            {
                var approversByCountry = approverByCountryService.GetApproversByCountry();
                return Ok(new ApiOkResponse(approversByCountry));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetApproversByCountry() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddApproverByCountry")]
        public IActionResult AddApproverByCountry([FromBody]ApproverByCountryViewModel approverByCountryViewModel)
        {
            logger.LogInformation("AddApproverByCountry");
            try
            {
                // todo ..
                approverByCountryViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                approverByCountryService.AddApproverByCountry(approverByCountryViewModel);
                return Ok(new ApiOkResponse(approverByCountryViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddApproverByCountry() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateApproverByCountry")]
        public IActionResult UpdateApproverByCountry([FromBody]ApproverByCountryViewModel approverByCountryViewModel)
        {
            logger.LogInformation("UpdateApproverByCountry", approverByCountryViewModel);
            try
            {
                approverByCountryViewModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                approverByCountryService.UpdateApproverByCountry(approverByCountryViewModel);
                return Ok(new ApiOkResponse(approverByCountryViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateApproverByCountry() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}