﻿namespace OMF.API
{
    using System;
    using System.Net;
    using System.Text;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Diagnostics;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Authorization;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using OMF.Data.Repository;
    using Microsoft.AspNetCore.HttpsPolicy;
    using Swashbuckle.AspNetCore.Swagger;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.OpenApi.Models;
    using Newtonsoft.Json.Serialization;
    using Microsoft.Extensions.Hosting;
    using Microsoft.EntityFrameworkCore.Diagnostics;

    //using Joonasw.AspNetCore.SecurityHeaders;

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Cors configuration
            services.AddCors(options =>
            {
                // options.AddPolicy("CorsPolicy", builder => builder.WithOrigins("*")
                options.AddPolicy("CorsPolicy", builder => builder.WithOrigins("http://localhost:4200", "http://10.78.166.59:9047", "http://vdpapp01d:9047", "http://vdpomfapp01t:9047", "http://vdpomfapp01:9047", "https://om.hitachivantara.com", "https://om-uat.hitachivantara.com", "https://bookroom.hitachivantara.com", "http://vusdencast01t")
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });

            // Http Client configuration
            services.AddHttpClient("service", c =>
            {
                // Github API versioning
                c.DefaultRequestHeaders.Add("Accept", "application/json, text/plain, */*");
                // Github requires a user-agent
                c.DefaultRequestHeaders.Add("User-Agent", "HttpClientFactory-Sample");
            });

            services.AddOptions();
            services.Configure<AuthenticationSettings>(Configuration.GetSection("AuthenticationSettings"));
            services.Configure<OmfSettings>(Configuration.GetSection("OmfSettings"));
            services.Configure<SharePointSettings>(Configuration.GetSection("SharePointSettings"));
            services.Configure<HiQSettings>(Configuration.GetSection("HiQSettings"));
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            var connectionString = Configuration.GetConnectionString("DefaultConnection");
            //services.AddDbContext<OMFContext>(options => options.UseNpgsql(connectionString));
            services.AddDbContext<OMFContext>(options =>
            {
                options.UseNpgsql(connectionString);
                options.ConfigureWarnings(warnings =>

                warnings.Ignore(CoreEventId.InvalidIncludePathError));
            });
           
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

            services.AddTransient<IUow, Uow>();
            services.AddTransient<ICountryService, CountryService>();
            services.AddTransient<ICapabilityService, CapabilityService>();
            services.AddTransient<ISubCapabilityService, SubCapabilityService>();
            services.AddTransient<ICapabilitySubCapabilityMappingService, CapabilitySubCapabilityMappingService>();
            services.AddTransient<IApproverByRegionService, ApproverByRegionService>();
            services.AddTransient<IApproverByCountryService, ApproverByCountryService>();
            services.AddTransient<IYearService, YearService>();
            services.AddTransient<IContractTypeService, ContractTypeService>();
            services.AddTransient<ITaxRateService, TaxRateService>();
            services.AddTransient<IEmployeeTypeService, EmployeeTypeService>();
            services.AddTransient<ICurrencyService, CurrencyService>();
            services.AddTransient<IQuarterService, QuarterService>();
            services.AddTransient<IColaService, ColaService>();
            services.AddTransient<IIndustrySegmentService, IndustrySegmentService>();
            services.AddTransient<IIndustrySubSegmentService, IndustrySubSegmentService>();
            services.AddTransient<IRateCardService, RateCardService>();
            services.AddTransient<IFxRateService, FxRateService>();
            services.AddTransient<IIndustrySegmentSubSegmentMappingService, IndustrySegmentSubSegmentMappingService>();
            services.AddTransient<IProjectOrganizationService, ProjectOrganizationService>();
            services.AddTransient<ITechAllianceService, TechAllianceService>();
            services.AddTransient<ISubTechAllianceService, SubTechAllianceService>();
            services.AddTransient<ITechnologySubTechnologyMappingService, TechnologySubTechnologyMappingService>();
            services.AddTransient<IResourceRoleService, ResourceRoleService>();
            services.AddTransient<IWorkLocationService, WorkLocationService>();
            services.AddTransient<IWorkLocationResourceRoleMappingService, WorkLocationResourceRoleMappingService>();
            services.AddTransient<IPriceCalculatorService, PriceCalculatorService>();
            services.AddTransient<IRegionService, RegionService>();
            services.AddTransient<IGlobalSolutionService, GlobalSolutionService>();
            services.AddTransient<IDeliveryModelService, DeliveryModelService>();
            services.AddTransient<IReportingPracticeService, ReportingPracticeService>();
            services.AddTransient<IProjectOrganizationReportingPracticeMappingService, ProjectOrganizationReportingPracticeMappingService>();
            services.AddTransient<IProjectDomainService, ProjectDomainService>();
            services.AddTransient<IProjectDealTypeService, ProjectDealTypeService>();
            services.AddTransient<IApproverTypeService, ApproverTypeService>();
            services.AddTransient<IPaymentTermsService, PaymentTermsService>();
            services.AddTransient<IRoleService, RoleService>();
            services.AddTransient<IUserRoleService, UserRoleService>();
            services.AddTransient<IStatusActionService, StatusActionService>();
            services.AddTransient<IEmailEntityService, EmailEntityService>();
            services.AddTransient<IStatusTypeService, StatusTypeService>();
            services.AddTransient<IOpportunityService, OpportunityService>();
            services.AddTransient<IFinancialSoftwareHardwareDetailService, FinancialSoftwareHardwareDetailService>();
            services.AddTransient<IEmailTemplateService, EmailTemplateService>();
            services.AddTransient<IDocumentTypeService, DocumentTypeService>();
            services.AddTransient<IEmailTemplatePlaceHolderService, EmailTemplatePlaceHolderService>();
            services.AddTransient<IFinancialProposalService, FinancialServiceProposaService>();
            services.AddTransient<IOpportunityTypeService, OpportunityTypeService>();
            services.AddTransient<IWorkflowService, WorkflowService>();
            services.AddTransient<INextStatusActionByStatusTypeMappingService, NextStatusActionByStatusTypeMappingService>();
            services.AddTransient<IFinancialInitialSetupService, FinancialInitialSetupService>();
            services.AddTransient<IPaymentTermApprovalTrackerService, PaymentTermApprovalTrackerService>();
            services.AddTransient<IWorkFlowConfigService, WorkFlowConfigService>();
            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IScreenActionsByRoleService, ScreenActionsByRoleService>();
            services.AddTransient<IClientMasterService, ClientMasterService>();
            services.AddTransient<IOmfJourney, OmfJourneyService>();
            services.AddTransient<IContractFinancialSectionsMappingService, ContractFinancialSectionsMappingService>();
            services.AddTransient<ILineOfBusinessService, LineOfBusinessService>();
            services.AddTransient<IReadEmailIdsService, ReadEmailIdsService>();
            services.AddTransient<ICOPService, COPService>();
            services.AddTransient<IApproverByWorkLocationService, ApproverByWorkLocationService>();
            services.AddTransient<IWorkLocationWorkFlowConfigService, WorkLocationWorkFlowConfigService>();
            services.AddTransient<IWorkLocationWorkFlowService, WorkLocationWorkFlowService>();
            services.AddTransient<IIssuesService, IssuesService>();
            services.AddTransient<ILoginService, LoginService>();
            services.AddTransient<IORBApprovalCriteriaService, ORBApprovalCriteriaService>();
            services.AddTransient<IOpportunityCRDetailsService, OpportunityCRDetailsService>();
            services.AddTransient<IApproverByRegionAndLineOfBusinessService, ApproverByRegionAndLineOfBusinessService>();
            services.AddTransient<ISharePointService, SharePointService>();
            services.AddTransient<IHiQService, HiQService>();
            services.AddTransient<IFinancialCloudHostingService, FinancialCloudHostingService>();
            //services.AddSingleton<Microsoft.Extensions.Hosting.IHostedService, DataValidatorBackgroundService>();
            services.AddTransient<IORBWorkFlowService, ORBWorkFlowService>();
            services.AddTransient<IITOSolutionService, ITOSolutionService>();
            services.AddTransient<IFinancialsStaffAugmentationService, FinancialsStaffAugmentationService>();
            services.AddTransient<IHVContractingEntity, HVContractingEntityService>();
            services.AddTransient<IHVOUPracticeService, HVOUPracticeService>();
            services.AddTransient<IIndustrySubVerticalsService, IndustrySubVerticalsService>();
            services.AddTransient<IEmailService, EmailService>();
            //services.AddTransient<IReadOutlookMailService, ReadOutlookMailService>();
            services.AddTransient<IFinancialRoyaltyService, FinancialRoyaltyService>();
            services.AddTransient<IIFRS15CheckListService, IFRS15CheckListService>();
            services.AddTransient<IProjectTemplateMatrixService, ProjectTemplateMatrixService>();
            services.AddTransient<IDPAUploadStatusService, DPAUploadStatusService>();
            services.AddTransient<IReasonForFundingReductionService, ReasonForFundingReductionService>();
            services.AddTransient<IIFRSReferbackOnHoldReasonService, IFRSReferbackOnHoldReasonService>();
            services.AddTransient<IFundingReductionService, FundingReductionService>();
            services.AddTransient<IPCReferbackOnHoldReasonService, PCReferbackOnHoldReasonService>();
            services.AddTransient<IUserRegistrationRequestService, UserRegistrationRequestService>();
            //services.AddMvc().AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver()).SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.AddTransient<IOppLeveragePercentVarianceService, OppLeveragePercentVarianceService>();
            services.AddTransient<ILeveragePercentageConfigurationService, LeveragePercentageConfigurationService>();
            services.AddMvc(config =>
            {
                var policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
                config.Filters.Add(new AuthorizeFilter(policy));
            })
                .AddNewtonsoftJson(options =>
                {
                    {
                        options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                    };
                });

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "OMF API", Version = "v1" });
                c.AddSecurityDefinition(
                    "Bearer",
                    securityScheme: new OpenApiSecurityScheme
                    {
                        In = ParameterLocation.Header,
                        Description = "Please enter into field the word 'Bearer' following by space and JWT",
                        Name = "Authorization",
                        Type = SecuritySchemeType.ApiKey,
                        BearerFormat = "Bearer"
                    });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement()
      {
        {
          new OpenApiSecurityScheme
          {
            Reference = new OpenApiReference
              {
                Type = ReferenceType.SecurityScheme,
                Id = "Bearer"
              },
              Scheme = "Bearer",
              Name = "Bearer",
              In = ParameterLocation.Header,

            },
            new List<string>()
          }
        });
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.

        public void Configure(WebApplication app, IWebHostEnvironment env)
        {
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");

                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "OMF API v1");
            });
            app.UseRouting();
            app.UseCors("CorsPolicy");

            app.UseHttpsRedirection();
            app.UseTokenAuthentication();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            app.Run();

        }

        [Obsolete]
        public void ConfigureOld(IApplicationBuilder app, Microsoft.AspNetCore.Hosting.IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            try
            {
                app.UseExceptionHandler(
                    builder =>
                    {
                        builder.Run(async context =>
                        {
                            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                            context.Response.ContentType = "application/json";
                            var ex = context.Features.Get<IExceptionHandlerFeature>();
                            if (ex != null)
                            {
                                var err = JsonConvert.SerializeObject(new Error()
                                {
                                    Stacktrace = ex.Error.StackTrace,
                                    Message = ex.Error.Message
                                });
                                await context.Response.Body.WriteAsync(Encoding.ASCII.GetBytes(err), 0, err.Length).ConfigureAwait(false);
                            }
                        });
                    });
                if (env.IsDevelopment())
                {
                    app.UseDeveloperExceptionPage();
                }
                else
                {
                    //app.UseHttpsEnforcement();
                    //app.UseHttpsRedirection();
                    app.UseHsts();
                }

                loggerFactory.AddFile("Logs/OMF-{Date}.txt");
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "OMF API v1");
                });
                app.UseCors("CorsPolicy");
                //loggerFactory.AddConsole(Configuration.GetSection("Logging"));
                //loggerFactory.AddDebug();
                //app.UseHttpsEnforcement();
                app.UseHttpsRedirection();
                app.UseTokenAuthentication();
                app.UseMvc();
            }
            catch (Exception exception)
            {
                app.Run(
                    async context =>
                    {
                        context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        context.Response.ContentType = "application/json";
                        if (exception != null)
                        {
                            var err = JsonConvert.SerializeObject(new Error()
                            {
                                Stacktrace = exception.StackTrace,
                                Message = exception.Message
                            });
                            await context.Response.Body.WriteAsync(Encoding.ASCII.GetBytes(err), 0, err.Length).ConfigureAwait(false);
                        }
                    });
            }
        }
    }
}
