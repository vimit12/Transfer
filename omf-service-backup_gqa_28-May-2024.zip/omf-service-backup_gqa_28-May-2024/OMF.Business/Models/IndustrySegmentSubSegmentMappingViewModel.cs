﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;
    using System.Linq;

    public class IndustrySegmentSubSegmentMappingViewModel : BaseClass
    {
        public int IndustrySegmentId { get; set; }

        public int IndustrySegmentSubSegmentId { get; set; }

        public string IndustrySegmentName { get; set; }

        public string IndustrySubSegmentNames { get; set; }

        public IEnumerable<IndustrySubSegmentViewModel> IndustrySubSegments { get; set; }
    }
}
