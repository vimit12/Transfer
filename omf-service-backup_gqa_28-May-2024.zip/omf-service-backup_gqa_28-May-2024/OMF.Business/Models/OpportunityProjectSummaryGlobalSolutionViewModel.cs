﻿namespace OMF.Business.Models
{
    public class OpportunityProjectSummaryGlobalSolutionViewModel : BaseClass
    {
        public int OpportunityProjectSummaryGlobalSolutionId { get; set; }

        public int OpportunityId { get; set; }

        public int GlobalSolutionId { get; set; }

        public float Percentage { get; set; }

        public bool IsUpdate { get; set; }

        public bool IsDelete { get; set; }

        public string GlobalSolutionName { get; set; }
    }
}
