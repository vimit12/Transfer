﻿namespace OMF.Business.Models
{
    using System;

    public class InfoFinancialSummaryViewModel
    {
        // Opportunity
        public int OpportunityWeeklyHours { get; set; }

        // OnShore Hitachi Employees
        public double OnshoreHitachiEmp_GrossRevenue { get; set; }

        public double OnshoreHitachiEmp_AvgBillRate { get; set; }

        public double OnshoreHitachiEmp_TotalHours { get; set; }

        public double OnshoreHitachiEmp_TotalStdCosts { get; set; }

        public double OnshoreHitachiEmp_NonBillableExpenses { get; set; }

        public double OnshoreHitachiEmp_ProjGrossMargin { get; set; }

        public double OnshoreHitachiEmp_ProjGrossMarginPercentage { get; set; }

        public double OnshoreHitachiEmp_Target { get; set; }

        // Onshore Employees (IT__ + PES)
        public double OnshoreITPES_GrossRevenue { get; set; }

        public double OnshoreITPES_AvgBillRate { get; set; }

        public double OnshoreITPES_TotalHours { get; set; }

        public double OnshoreITPES_TotalStdCosts { get; set; }

        public double OnshoreITPES_NonBillableExpenses { get; set; }

        public double OnshoreITPES_ProjGrossMargin { get; set; }

        public double OnshoreITPES_ProjGrossMarginPercentage { get; set; }

        public double OnshoreITPES_Target { get; set; }

        // Offshore Employees ( IDC )
        public double OffShoreEmpIDC_GrossRevenue { get; set; }

        public double OffShoreEmpIDC_AvgBillRate { get; set; }

        public double OffShoreEmpIDC_TotalHours { get; set; }

        public double OffShoreEmpIDC_TotalStdCosts { get; set; }

        public double OffShoreEmpIDC_NonBillableExpenses { get; set; }

        public double OffShoreEmpIDC_ProjGrossMargin { get; set; }

        public double OffShoreEmpIDC_ProjGrossMarginPercentage { get; set; }

        public double OffShoreEmpIDC_Target { get; set; }

        // Offshore Employees ( VDN )
        public double OffShoreEmpVDN_GrossRevenue { get; set; }

        public double OffShoreEmpVDN_AvgBillRate { get; set; }

        public double OffShoreEmpVDN_TotalHours { get; set; }

        public double OffShoreEmpVDN_TotalStdCosts { get; set; }

        public double OffShoreEmpVDN_NonBillableExpenses { get; set; }

        public double OffShoreEmpVDN_ProjGrossMargin { get; set; }

        public double OffShoreEmpVDN_ProjGrossMarginPercentage { get; set; }

        public double OffShoreEmpVDN_Target { get; set; }

        // REAN Employees
        public double ReanEmp_GrossRevenue { get; set; }

        public double ReanEmp_AvgBillRate { get; set; }

        public double ReanEmp_TotalHours { get; set; }

        public double ReanEmp_TotalStdCosts { get; set; }

        public double ReanEmp_NonBillableExpenses { get; set; }

        public double ReanEmp_ProjGrossMargin { get; set; }

        public double ReanEmp_ProjGrossMarginPercentage { get; set; }

        public double ReanEmp_Target { get; set; }

        // Employee SubTotal
        public double EmpSubTotal_GrossRevenue { get; set; }

        public double EmpSubTotal_AvgBillRate { get; set; }

        public double EmpSubTotal_TotalHours { get; set; }

        public double EmpSubTotal_TotalStdCosts { get; set; }

        public double EmpSubTotal_NonBillableExpenses { get; set; }

        public double EmpSubTotal_ProjGrossMargin { get; set; }

        public double EmpSubTotal_ProjGrossMarginPercentage { get; set; }

        public double EmpSubTotal_Target { get; set; }

        // Employee Contigency Fund
        public double EmpContigencyFund_GrossRevenue { get; set; }

        public double EmpContigencyFund_AvgBillRate { get; set; }

        public double EmpContigencyFund_TotalHours { get; set; }

        public double EmpContigencyFund_TotalStdCosts { get; set; }

        public double EmpContigencyFund_ProjGrossMargin { get; set; }

        public double EmpContigencyFund_ProjGrossMarginPercentage { get; set; }

        // Employee Total
        public double EmpTotal_GrossRevenue { get; set; }

        public double EmpTotal_AvgBillRate { get; set; }

        public double EmpTotal_TotalHours { get; set; }

        public double EmpTotal_TotalStdCosts { get; set; }

        public double EmpTotal_NonBillableExpenses { get; set; }

        public double EmpTotal_ProjGrossMargin { get; set; }

        public double EmpTotal_ProjGrossMarginPercentage { get; set; }

        // Contractor SubTotal
        public double ContractorSubTotal_GrossRevenue { get; set; }

        public double ContractorSubTotal_AvgBillRate { get; set; }

        public double ContractorSubTotal_TotalHours { get; set; }

        public double ContractorSubTotal_TotalStdCosts { get; set; }

        public double ContractorSubTotal_ProjGrossMargin { get; set; }

        public double ContractorSubTotal_ProjGrossMarginPercentage { get; set; }

        //GL and Others Sub Total
        public double ContractorSubTotalGL_GrossRevenue { get; set; }

        public double ContractorSubTotalGL_AvgBillRate { get; set; }

        public double ContractorSubTotalGL_TotalHours { get; set; }

        public double ContractorSubTotalGL_TotalStdCosts { get; set; }

        public double ContractorSubTotalGL_NonBillableExpenses { get; set; }

        public double ContractorSubTotalGL_ProjGrossMargin { get; set; }

        public double ContractorSubTotalGL_ProjGrossMarginPercentage { get; set; }

        public double ContractorSubTotalOther_GrossRevenue { get; set; }

        public double ContractorSubTotalOther_AvgBillRate { get; set; }

        public double ContractorSubTotalOther_TotalHours { get; set; }

        public double ContractorSubTotalOther_NonBillableExpenses { get; set; }

        public double ContractorSubTotalOther_TotalStdCosts { get; set; }

        public double ContractorSubTotalOther_ProjGrossMargin { get; set; }

        public double ContractorSubTotalOther_ProjGrossMarginPercentage { get; set; }

        public double ContractorSubTotal_Target { get; set; }

        // Contractor Contigency Fund
        public double ContractorContigencyFund_GrossRevenue { get; set; }

        public double ContractorContigencyFund_AvgBillRate { get; set; }

        public double ContractorContigencyFund_TotalHours { get; set; }

        public double ContractorContigencyFund_TotalStdCosts { get; set; }

        public double ContractorContigencyFund_ProjGrossMargin { get; set; }

        public double ContractorContigencyFund_ProjGrossMarginPercentage { get; set; }

        // Contractor Total
        public double ContractorTotal_GrossRevenue { get; set; }

        public double ContractorTotal_AvgBillRate { get; set; }

        public double ContractorTotal_TotalHours { get; set; }

        public double ContractorTotal_TotalStdCosts { get; set; }

        public double ContractorTotal_ProjGrossMargin { get; set; }

        public double ContractorTotal_ProjGrossMarginPercentage { get; set; }

        // Services Total
        public double ServicesTotal_GrossRevenue { get; set; }

        public double ServicesTotal_AvgBillRate { get; set; }

        public double ServicesTotal_TotalHours { get; set; }

        public double ServicesTotal_TotalStdCosts { get; set; }

        public double ServicesTotal_NonBillableExpenses { get; set; }

        public double ServicesTotal_ProjGrossMargin { get; set; }

        public double ServicesTotal_ProjGrossMarginPercentage { get; set; }

        public double ServicesTotal_Target { get; set; }

        // Cloud Services
        public double CloudServices_GrossRevenue { get; set; }

        public double CloudServices_TotalStdCosts { get; set; }

        public double CloudServices_ProjGrossMargin { get; set; }

        public double CloudServices_ProjGrossMarginPercentage { get; set; }

        // Opportunity Total
        public double OpportunityTotal_GrossRevenue { get; set; }

        public double OpportunityTotal_AvgBillRate { get; set; }

        public double OpportunityTotal_TotalHours { get; set; }

        public double OpportunityTotal_TotalStdCosts { get; set; }

        public double OpportunityTotal_NonBillableExpenses { get; set; }

        public double OpportunityTotal_ProjGrossMargin { get; set; }

        public double OpportunityTotal_ProjGrossMarginPercentage { get; set; }

        // Billable Expenses
        public double BillableExpenses_GrossRevenue { get; set; }

        public double BillableExpenses_AvgBillRate { get; set; }

        public double BillableExpenses_TotalHours { get; set; }

        public double BillableExpenses_TotalStandardCosts { get; set; }

        public double BillableExpenses_NonBillableEspenses { get; set; }

        public double BillableExpenses_ProjGrossMargin { get; set; }

        public double BillableExpenses_ProjGrossMarginPercentage { get; set; }

        // Total With Billable Expenses
        public double TotalWithBillableExpenses_GrossRevenue { get; set; }

        public double TotalWithBillableExpenses_AverageBillRate { get; set; }

        public double TotalWithBillableExpenses_TotalHours { get; set; }

        public double TotalWithBillableExpenses_TotalStandardCosts { get; set; }

        public double TotalWithBillableExpenses_NonBillableExpenses { get; set; }

        public double TotalWithBillableExpenses_ProjGrossMargin { get; set; }

        public double TotalWithBillableExpenses_ProjGrossMarginPercentage { get; set; }

        // Client Details
        public int BaseCurrencyId { get; set; }

        public string CurrencyCode { get; set; }

        public int ClientMasterId { get; set; }

        public string ClientName { get; set; }

        public string CrmId { get; set; }
 
        public string LocalizedAccountName { get; set; }

        public string ProjectName { get; set; }

        public string PrjectContractingOrganization { get; set; }

        public string ReportingPracticeName { get; set; }

        public string ContractType { get; set; }

        public int ContractId { get; set; }

        public float? ContigencyFundPercentage { get; set; }

        public DateTime ProjectStartDate { get; set; }

        public DateTime ProjectEndDate { get; set; }

        // Overview fields
        public int ProjectDuration { get; set; }

        public int PeakTeamSize { get; set; }

        public int PeakGDCTeamSize { get; set; }

        public double OnshoreEmployeePercent { get; set; }

        public double OnshoreEmployeeITPSPercent { get; set; }

        public double ContractorPercent { get; set; }

        public double OffshoreEmployeePercent { get; set; }

        public string ProjectCode { get; set; }

        public string OracleProjectName { get; set; }

        public double ProjectDiscountPercentage { get; set; }

        public int ProjectSetupType { get; set; }

        public string ProjectReviewer { get; set; }

        public string ProjectRemarks { get; set; }

        // PSI fields
        public double OnshorePSI { get; set; }

        public double OnshoreItpesPSI { get; set; }

        public double GdcPSI { get; set; }

        public double VdnPSI { get; set; }

        //AMC fields
        public double AMC_GrossRevenue { get; set; }

        public double AMC_TotalStdCosts { get; set; }

        public double AMC_ProjGrossMargin { get; set; }

        public double AMC_ProjGrossMarginPercentage { get; set; }

        //Software, Hardware and Other Total
        public double SwHw_GrossRevenue { get; set; }

        public double SwHw_TotalStdCosts { get; set; }

        public double SwHw_ProjGrossMargin { get; set; }

        public double SwHw_ActualPGM { get; set; }

        public double SwHw_TargetPGM { get; set; }

        //Total of SWHW and AMC
        public double TotalOfSWHWAmc_GrossRevenue { get; set; }

        public double TotalOfSWHWAmc_TotalStdCosts { get; set; }

        public double TotalOfSWHWAmc_ProjGrossMargin { get; set; }

        public double TotalOfSWHWAmc_ProjGrossMarginPercentage { get; set; }

        // Onshore SubTotal
        public double OnShoreTotal_GrossRevenue { get; set; }

        public double OnShoreTotal_AvgBillRate { get; set; }

        public double OnShoreTotal_TotalHours { get; set; }

        public double OnShoreTotal_TotalStdCosts { get; set; }

        public double OnShoreTotal_NonBillableExpenses { get; set; }

        public double OnShoreTotal_ProjGrossMargin { get; set; }

        public double OnShoreTotal_ProjGrossMarginPercentage { get; set; }

        public double OnShoreTotal_Target { get; set; }

        // OffShore SubTotal
        public double OffShoreTotal_GrossRevenue { get; set; }

        public double OffShoreTotal_AvgBillRate { get; set; }

        public double OffShoreTotal_TotalHours { get; set; }

        public double OffShoreTotal_TotalStdCosts { get; set; }

        public double OffShoreTotal_NonBillableExpenses { get; set; }

        public double OffShoreTotal_ProjGrossMargin { get; set; }

        public double OffShoreTotal_ProjGrossMarginPercentage { get; set; }

        public double OffShoreTotal_Target { get; set; }

        //CloudHosting fields
        public double CloudHosting_TotalStandardRevenue { get; set; }

        public double CloudHosting_TotalStdCosts { get; set; }

        public double CloudHosting_PGM { get; set; }

        public double CloudHosting_PGMPercentage { get; set; }

        public double TotalServicesRevenue { get; set; }

        public double TotalServicesCost { get; set; }

        public double TotalServicesPGMValue { get; set; }

        public double TotalServicePGMPergentage { get; set; }

        //ThirdPartyPassThru
        public double ThirdPartyPassThru_Revenue { get; set; }

        public double ThirdPartPassThru_Cost { get; set; }

        public double ThirdPartyPassThru_ProjectGrossMargin { get; set; }

        public double ThirdPartPassThru_PGMPercentage { get; set; }

        //Staff Augmentation fields
        public double StaffAug_Revenue { get; set; }

        public double StaffAug_Cost { get; set; }

        public double StaffAug_ProjGrossMargin { get; set; }

        public double StaffAug_ProjGrossMarginPercentage { get; set; }

        //Rebate fields
        public double Rebate_Value { get; set; }

        public double TotalServicesRevenueAfterRebate { get; set; }

        public double TotalServicesCostAfterRebate { get; set; }

        public double TotalServicesPGMValueAfterRebate { get; set; }

        public double TotalServicePGMPergentageAfterRebate { get; set; }

        //Royalty
        public double Royalty_Revenue { get; set; }

        public double Royalty_Cost { get; set; }

        public double Royalty_ProjectGrossMargin { get; set; }

        public double Royalty_PGMPercentage { get; set; }

        public int DPAAvailable { get; set; }

        public string ClientLevelPaymentTerm { get; set; }

        public string ProjectLevelPaymentTerm { get; set; }

        public string DPARemarks { get; set; }

        public int? DPAUploadStatusId { get; set; }

        public string DPAUploadStatusName { get; set; }

        public double ManagedServiceCallOffRevenue { get; set; }

        public double ManagedServiceCallOffCost { get; set; }

        public int OppProjectSetupType { get; set; }

        public string EtcRequired { get; set; }
    }
}
