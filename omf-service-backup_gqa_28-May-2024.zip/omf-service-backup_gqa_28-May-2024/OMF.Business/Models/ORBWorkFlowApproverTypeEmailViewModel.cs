﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class ORBWorkFlowApproverTypeEmailViewModel
    {
        public List<UserEmailRecipientViewModel> UserRoleIdsToSend { get; set; }

        public int OpportunityId { get; set; }

        public int ORBWorkFlowId { get; set; }

        public int ApproverTypeId { get; set; }

        public string UpdatedBy { get; set; }
    }
}
