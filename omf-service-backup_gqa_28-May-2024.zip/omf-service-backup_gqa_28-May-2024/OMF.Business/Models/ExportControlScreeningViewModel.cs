﻿namespace OMF.Business.Models
{
    using System;

    public class ExportControlScreeningViewModel : BaseClass
    {
        public int ExportControlScreeningId { get; set; }

        public int OpportunityId { get; set; }

        public double EstimatedFees { get; set; }

        public string NatureOfServicesProvided { get; set; }

        public string EndUseOfDeliverables { get; set; }

        public string URL { get; set; }

        public bool IsNewClient { get; set; }

        public string PMComments { get; set; }

        public long? RequesterContactNumber { get; set; }

        public bool ThirdPartyContract { get; set; }

        public string UltimateEndCustomer { get; set; }

        public int? Reason { get; set; }

        public string Remark { get; set; }
    }
}
