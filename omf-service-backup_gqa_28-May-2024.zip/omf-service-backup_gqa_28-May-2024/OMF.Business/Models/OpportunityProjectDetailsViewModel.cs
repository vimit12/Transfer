﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class OpportunityProjectDetailsViewModel : BaseClass
    {
        public int OpportunityId { get; set; }

        public int OpportunityProjectDetailId { get; set; }

        public string ProjectCode { get; set; }

        public string ProjectName { get; set; }

        public int SetupType { get; set; }

        public float EstimatedFees { get; set; }

        public string CrmId { get; set; }

        public int? Reviewer { get; set; }

        public string Remarks { get; set; }
    }
}
