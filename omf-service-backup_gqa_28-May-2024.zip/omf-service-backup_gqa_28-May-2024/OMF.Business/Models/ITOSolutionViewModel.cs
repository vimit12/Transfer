﻿namespace OMF.Business.Models
{
    public class ITOSolutionViewModel : BaseClass
    {
        public int ITOSolutionId { get; set; }

        public string ITOSolutionName { get; set; }
    }
}
