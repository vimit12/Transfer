﻿namespace OMF.Business.Models
{
    public class OpportunitySectionFilterViewModel
    {
        public int SectionId { get; set; }

        public string SectionName { get; set; }

        public bool IsSelected { get; set; }
    }
}
