﻿namespace OMF.Business.Models
{
    using System;

    public class CreditCheckApprovalMatrixViewModel : BaseClass
    {
        public int CreditCheckApprovalMatrixId { get; set; }

        public int RegionId { get; set; }

        public string RiskLevel { get; set; }

        public int MinOpportunityValue { get; set; }

        public int MaxOpportunityValue { get; set; }

        public bool IsApprover1Required { get; set; }

        public bool IsApprover2Required { get; set; }
        public string CustomerRelationship { get; set; }


    }
}
