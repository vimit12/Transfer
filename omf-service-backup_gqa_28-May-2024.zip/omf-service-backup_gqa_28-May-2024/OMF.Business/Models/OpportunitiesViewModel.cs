﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class OpportunitiesViewModel
    {
        public int OpportunityId { get; set; }

        public string OpportunityName { get; set; }

        public string CrmId { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public int StatusId { get; set; }

        public int IsShared { get; set; }

        public int ClientMasterId { get; set; }

        public string OracleProjectName { get; set; }

        public string OracleProjectCode { get; set; }

        public string CustomerName { get; set; }

        public string CurrentStatusName { get; set; }

        public bool IsSentForAudit { get; set; }

        public bool IsProjectCreatedInPending { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public bool IsActive { get; set; }

        public bool IsSentForCRMAudit { get; set; }

        public bool IsSentForPCAudit { get; set; }

        public bool IsSentForSCAudit { get; set; }

        public bool IsSentForECFAudit { get; set; }

        public bool IsSentForIFRSAudit { get; set; }

        public string SfdcId { get; set; }

        public int? HVContractingEntityId { get; set; }

        public string KimbleId { get; set; }

        public string IFRSUserAssignedTo { get; set; }

        public int IFRSUserRoleId { get; set; }

        public string ComplianceUserAssignedTo { get; set; }

        public int ComplianceUserRoleId { get; set; }
    }
}
