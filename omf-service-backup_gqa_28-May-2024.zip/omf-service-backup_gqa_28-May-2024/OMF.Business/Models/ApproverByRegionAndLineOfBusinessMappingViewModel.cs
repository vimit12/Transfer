﻿namespace OMF.Business.Models
{
    public class ApproverByRegionAndLineOfBusinessMappingViewModel : BaseClass
    {
        public int ApproverByRegionAndLineOfBusinessMappingId { get; set; }

        public int ApproverByRegionAndLineOfBusinessId { get; set; }

        public int UserRoleId { get; set; }
    }
}
