﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class HiQOMFIntegrationViewModel
    {
        public bool IsValidCrmId { get; set; }

        public string HiQOpportunityType { get; set; }

        public string SFDCID { get; set; }

        public string Name { get; set; }

        public string DeliveryPartner { get; set; }

        public string DeliveryPartnerEmail { get; set; }

        public float HiQValue { get; set; }

        public string Synergy { get; set; }

        public string ClientEngagementPartner { get; set; }

        public string ClientEngagementPartnerEmail { get; set; }

        public string SalesExecutiveName { get; set; }

        public string SalesExecutiveEmail { get; set; }

        public string AccountManager { get; set; }

        public string AccountManagerEmail { get; set; }

        public bool IsSalesExecutiveOwned { get; set; }

        public int CustomerId { get; set; }

        public string CustomerName { get; set; }

        public ClientBillingAddressViewModel ClientBillingAddressView { get; set; }
    }
}
