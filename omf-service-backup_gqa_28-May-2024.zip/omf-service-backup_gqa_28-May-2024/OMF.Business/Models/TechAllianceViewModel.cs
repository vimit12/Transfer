﻿namespace OMF.Business.Models
{
    public class TechAllianceViewModel : BaseClass
    {
        public int TechnologyId { get; set; }

        public string TechnologyName { get; set; }

        public string Comments { get; set; }
    }
}