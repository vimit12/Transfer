﻿namespace OMF.Business.Models
{
    public class DeliveryModelViewModel : BaseClass
    {
        public int DeliveryModelId { get; set; }

        public string DeliveryModelName { get; set; }

        public float TargetMargin { get; set; }

        public string Comments { get; set; }
    }
}