﻿namespace OMF.Business.Models
{
   public class WorkLocationResourceRoleMappingViewModel : BaseClass
    {
        public int WorkLocationResourceRoleId { get; set; }

        public int WorkLocationId { get; set; }

        public string WorkLocationName { get; set; }

        public int ResourceRoleId { get; set; }

        public string ResourceRoleName { get; set; }
    }
}
