﻿namespace OMF.Business.Models
{
    public class ValidateRourceLocationViewModel
    {
        public bool IsValidRourceLocation { get; set; }

        public string Message { get; set; }
    }
}
