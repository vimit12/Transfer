﻿namespace OMF.Business.Models
{
    public class EmailCommentsByUserViewModel : BaseClass
    {
        public int EmailCommentsByUserId { get; set; }

        public int OpportunityId { get; set; }

        public int StatusActionId { get; set; }

        public string Comments { get; set; }

        public string UserName { get; set; }

        public string StatusActionName { get; set; }

        public string CreatedByEmail { get; set; }

        public int OpportunityDocumentDetailsId { get; set; }
    }
}
