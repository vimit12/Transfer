﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

   public class FinancialSoftwareHardwareDetailViewModel : BaseClass
    {
        public int FinancialSoftwareHardwareDetailId { get; set; }

        public int OpportunityId { get; set; }

        public int YearId { get; set; }

        public string OpportunityType { get; set; }

        public int SoftwareHardwareId { get; set; }

        public float PgmPercentage { get; set; }

        public string Details { get; set; }

        public double TotalStandardRevenue { get; set; }

        public double TotalStandardCost { get; set; }

        public bool IsDelete { get; set; }

        public bool IsUpdate { get; set; }

        public string VendorName { get; set; }

        public string ProductName { get; set; }

        public string ModelNumber { get; set; }

        public int? Quantity { get; set; }

        public bool HitachiProductAvailable { get; set; }

        public string ReasonForNotUsingHitachiProduct { get; set; }

        public string PurchaseFrom { get; set; }

        public float? PurchasePricePerUnit { get; set; }

        public float? MarkupPercent { get; set; }

        public float? TargetMarkupPercent { get; set; }

        public double? TargetMarkupVariance { get; set; }

        public double? FinalStandardPrice { get; set; }

        public string EndUserCustomerName { get; set; }

        public float? SellingPricePerUnit { get; set; }

        public float? TotalProjectGrossMargin { get; set; }

        public double? PgmValue { get; set; }

        public bool WarrantyApplicable { get; set; }

        public string WarrantyProvider { get; set; }

        public DateTime? WarrantyStartDate { get; set; }

        public DateTime? WarrantyEndDate { get; set; }
    }
}
