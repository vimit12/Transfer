﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class FundingReductionViewModel : BaseClass
    {
        public int FundingReductionId { get; set; }

        public string ProjectName { get; set; }

        public string ProjectNumber { get; set; }

        public string ClientName { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public int ProjectOrganizationId { get; set; }

        public string ProjectOrganizationName { get; set; }

        public int ReportingPracticeId { get; set; }

        public string ReportingPracticeName { get; set; }

        public int LineOfBusinessId { get; set; }

        public string LineOfBusinessName { get; set; }

        public string OnShoreProjectManager { get; set; }

        public string OfficerInCharge { get; set; }

        public int OpportunityTypeId { get; set; }

        public string OpportunityTypeName { get; set; }

        public int ContractTypeId { get; set; }

        public string ContractTypeName { get; set; }

        public int CurrencyId { get; set; }

        public string CurrencyName { get; set; }

        public double CurrentProjectFunding { get; set; }

        public double AmountAccruedInProject { get; set; }

        public double CurrentBalanceFundingOnProject { get; set; }

        public float CurrentScheduledWork { get; set; }

        public float CurrentUnScheduledWork { get; set; }

        public double ReductionValue { get; set; }

        public float NumberOfHrs { get; set; }

        public int FundingReductionReasonId { get; set; }

        public string FundingReductionReasonName { get; set; }

        public string FundingReductionDetailDesc { get; set; }

        public int StatusId { get; set; }

        public string StatusName { get; set; }

        /*Code changes made o 22nd Sept 22 for adding CRM, Billing and Schedulng Team  and Assign To roles*/
        public string AssignToUser { get; set; }

        public string CurrentAssignedTo { get; set; }

        /*End Code changes made o 22nd Sept 22 for adding CRM, Billing and Schedulng Team  and Assign To roles*/
    }
}
