﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class PendingStatusViewModel
    {
        public int ParentOpportunityId { get; set; }

        public string ChangeInFunding { get; set; }

        public string ChangeInOffshoreMixOrPgmPer { get; set; }

        public bool IsCostRateUpdated { get; set; }
    }
}
