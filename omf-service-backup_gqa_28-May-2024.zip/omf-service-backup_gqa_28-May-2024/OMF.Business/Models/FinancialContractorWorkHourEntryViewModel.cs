﻿namespace OMF.Business.Models
{
    using System;

    public class FinancialContractorWorkHourEntryViewModel : BaseClass
    {
        public int FinancialContractorWorkHourEntryId { get; set; }

        public int FinancialContractorDetailId { get; set; }

        public int QuarterId { get; set; }

        public int MonthId { get; set; }

        public DateTime WeekStartDay { get; set; }

        public decimal Hours { get; set; }

        public short MaxHours { get; set; }
    }
}
