﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class ReportingPracticeDetailsViewModel
    {
        public int ReportingPracticeId { get; set; }

        public string ReportingPracticeName { get; set; }

        public string LineOfBusinessName { get; set; }

        public int LineOfBusinessId { get; set; }

        public IEnumerable<COPViewModel> COPs { get; set; }
    }
}
