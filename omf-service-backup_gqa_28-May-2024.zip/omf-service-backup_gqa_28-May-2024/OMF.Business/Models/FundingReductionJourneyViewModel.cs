﻿namespace OMF.Business.Models
{
    public class FundingReductionJourneyViewModel : BaseClass
    {
        public int FundingReductionJourneyId { get; set; }

        public int FundingReductionId { get; set; }

        public int StatusId { get; set; }

        public string StatusName { get; set; }

        public string Comments { get; set; }

        public string CreatedByUserName { get; set; }
    }
}
