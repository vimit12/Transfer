﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;
    using System.Linq;

    public class CapabilitySubCapabilityMappingViewModel : BaseClass
    {
        public int CapabilityId { get; set; }

        public int CapabilitySubCapabilityId { get; set; }

        public string CapabilityName { get; set; }

        public string SubCapabilityNames { get; set; }

        public IEnumerable<SubCapabilityViewModel> SubCapabilities { get; set; }
    }
}
