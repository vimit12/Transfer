﻿namespace OMF.Business.Models
{
    public class PriceCalculatorViewModel
    {
        public int PriceId { get; set; }

        public double OnsiteRevenue { get; set; }

        public double OnsiteITPSRevenue { get; set; }

        public double OffshoreRevenue { get; set; }

        public double VDNRevenue { get; set; }

        public double TotalRevenueValue { get; set; }

        public double OnsiteHours { get; set; }

        public double OnsiteITPSHours { get; set; }

        public double OffshoreHours { get; set; }

        public double VDNHours { get; set; }

        public double TotalHours { get; set; }

        public double OnsiteCost { get; set; }

        public double OnsiteITPSCost { get; set; }

        public double OffshoreCost { get; set; }

        public double VDNCost { get; set; }

        public double BlendedCostRate { get; set; }

        public double OnsiteNetRate { get; set; }

        public double ITPSNetRate { get; set; }

        public double OffshoreNetRate { get; set; }

        public double VDNNetRate { get; set; }

        public double TotalMarginValue { get; set; }

        public double OffshoreLeverage { get; set; }

        public double OnsiteMarginPercentage { get; set; }

        public double ITPSMarginPercentage { get; set; }

        public double OffshoreMarginPercentage { get; set; }

        public double VDNMarginPercentage { get; set; }

        public double TotalMarginPercentage { get; set; }
    }
}
