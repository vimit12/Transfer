﻿namespace OMF.Business.Models
{
    using System;

    public class ComplianceScreeningQuestionnaireViewModel : BaseClass
    {
        public int ComplianceScreeningQuestionnaireId { get; set; }

        public int OpportunityId { get; set; }

        public bool Question1 { get; set; }

        public bool Question2 { get; set; }

        public bool Question3 { get; set; }

        public bool Question4 { get; set; }

        public bool Question5 { get; set; }

        public bool Question6 { get; set; }

        public bool Question7 { get; set; }

        public bool Question8 { get; set; }

        public bool Question9 { get; set; }

        public bool Question10 { get; set; }

        public bool Question11 { get; set; }

        public bool Question12 { get; set; }

        public bool Question13 { get; set; }

        public bool Question14 { get; set; }

        public bool Question15 { get; set; }

        public string Question1Description { get; set; }

        public string Question2Description { get; set; }

        public string Question3Description { get; set; }

        public string Question4Description { get; set; }

        public string Question5Description { get; set; }

        public string Question6Description { get; set; }

        public string Question7Description { get; set; }

        public string Question8Description { get; set; }

        public string Question9Description { get; set; }

        public string Question10Description { get; set; }

        public string Question11Description { get; set; }

        public string Question12Description { get; set; }

        public string Question13Description { get; set; }

        public string Question14Description { get; set; }

        public string Question15Description { get; set; }

        public bool IsEcf { get; set; }

        public string Question1Comments { get; set; }

        public string Question13Comments { get; set; }

        public string Question15Comments { get; set; }

        public string Question1UploadContent { get; set; }

        public byte[] Question1DownloadContent { get; set; }

        public string Question1UploadFileName { get; set; }

        public string Question1UploadFileExtension { get; set; }
    }
}
