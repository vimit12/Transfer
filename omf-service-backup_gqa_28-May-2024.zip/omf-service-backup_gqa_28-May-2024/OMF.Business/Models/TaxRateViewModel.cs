﻿namespace OMF.Business.Models
{
    public class TaxRateViewModel : BaseClass
    {
        public int TaxRateId { get; set; }

        public string TaxRateName { get; set; }

        public string Comments { get; set; }
    }
}