﻿namespace OMF.Business.Models
{
    public class ReasonForFundingReductionViewModel : BaseClass
    {
        public int ReasonForFundingReductionId { get; set; }

        public string ReasonForFundingReductionName { get; set; }

        public string Comments { get; set; }
    }
}
