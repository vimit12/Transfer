﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class FinancialEmployeeDetailViewModel : BaseClass
    {
        public int FinancialEmployeeDetailId { get; set; }

        public int OpportunityId { get; set; }

        public int WorkLocationId { get; set; }

        public string WorkLocation { get; set; }

        public int ResourceRoleId { get; set; }

        public string RoleName { get; set; }

        public float ResourceLoadingPercentage { get; set; }

        public string ResourceId { get; set; }

        public string ResourceName { get; set; }

        public int YearId { get; set; }

        public int Year { get; set; }

        public string Skills { get; set; }

        public DateTime? ResourceStartDate { get; set; }

        public DateTime? ResourceEndDate { get; set; }

        public float TotalWorkHours { get; set; }

        public double StandardHourlyBillingRate { get; set; }

        public float DiscountPercentage { get; set; }

        public double DiscountedHourlyBillingRate { get; set; }

        public double RevenueDiscountedRate { get; set; }

        public double StandardCostRate { get; set; }

        public double TotalStandardCost { get; set; }

        public double ProjectGrossMargin { get; set; }

        public float PgmPercentage { get; set; }

        public IEnumerable<FinancialQuarterViewModel> FinancialEmployeeWorkHours { get; set; }

        public bool IsOverrideRate { get; set; }

        // public IEnumerable<FinancialEmployeeWorkHourEntryViewModel> FinancialEmployeeWorkHours { get; set; }
    }
}
