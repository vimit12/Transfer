﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class RateCardForWorkLocationsViewModel
    {
        public int OpportunityId { get; set; }

        public OpportunityViewModel Opportunity { get; set; }

        public List<int> WorkLocations { get; set; }

        public string CreatedBy { get; set; }
    }
}
