﻿namespace OMF.Business.Models
{
    public class OpportunityWorkLocationViewModel : BaseClass
    {
        public int OpportunityWorkLocationId { get; set; }

        public int OpportunityId { get; set; }

        public int WorkLocationId { get; set; }
    }
}
