﻿namespace OMF.Business.Models
{
    using System;

    public class OpportunityProjectSummaryViewModel : BaseClass
    {
        public int ProjectSummaryId { get; set; }

        public int OpportunityId { get; set; }

        public int TaxRateId { get; set; }

        public bool IsResourceWorkingOutsideBaseCountry { get; set; }

        public bool IsRateOrDiscountInSow { get; set; }

        public double? RebateRangeAmount { get; set; }

        public float? RebateRatePercentage { get; set; }

        public string RebateExplanation { get; set; }

        public bool FullyExecutedSowAvailable { get; set; }

        public double TotalContractValue { get; set; }

        public string PONumber { get; set; }

        public short QATier { get; set; }

        public string QAReviewer { get; set; }

        public string QATeamMember { get; set; }

        public string ProjectManagersResourceManager { get; set; }

        public DateTime? QAReviewFirstDate { get; set; }

        public DateTime? QAReviewSecondDate { get; set; }

        public bool ISOMFValueEqualSOW { get; set; }

        public short? RiskLevelId { get; set; }

        public int? ProjectDomainId { get; set; }

        public int? ProjectDealTypeId { get; set; }

        public string PrimaryContactName { get; set; }

        public string ClientExecutiveSponsor { get; set; }

        public string ClientExecutiveSponsorEmail { get; set; }

        public DateTime? ClientSatSurveyPrimaryDate { get; set; }

        public DateTime? ClientSatSurveySecondaryDate { get; set; }
    }
}
