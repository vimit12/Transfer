﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class OpportunityOverviewViewModel : BaseClass
    {
        public int OpportunityId { get; set; }

        public int OpportunityOverviewId { get; set; }

        public string ClientOverview { get; set; }

        public string ProjectOverview { get; set; }

        public string Scope { get; set; }
    }
}
