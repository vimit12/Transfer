﻿namespace OMF.Business.Models
{
    using System;

    public class DataRiskQuestionnaireViewModel : BaseClass
    {
        public int DataRiskQuestionnaireId { get; set; }

        public int OpportunityId { get; set; }

        public bool Question1 { get; set; }

        public bool Question2 { get; set; }

        public bool Question3 { get; set; }

        public bool Question4 { get; set; }

        public bool IsGdprApprovalRequired { get; set; }
    }
}
