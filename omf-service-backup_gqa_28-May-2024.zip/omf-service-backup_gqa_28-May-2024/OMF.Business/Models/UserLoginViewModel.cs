﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class UserLoginViewModel
    {
        public int UserId { get; set; }

        public bool IsValid { get; set; }

        public string StatusMessage { get; set; }
    }
}
