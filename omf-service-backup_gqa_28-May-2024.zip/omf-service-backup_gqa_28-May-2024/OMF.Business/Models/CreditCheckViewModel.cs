﻿namespace OMF.Business.Models
{
    using System;

    public class CreditCheckViewModel : BaseClass
    {
        public int CreditCheckId { get; set; }

        public string CreditComments { get; set; }

        public string CreditRating { get; set; }

        public int? CreditLimit { get; set; }

        public DateTime? CreditAssessmentDate { get; set; }

        public string PaymentBehaviour { get; set; }

        public int OpportunityId { get; set; }

    }
}
