﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class ApproversForCreditCheckViewModel : BaseClass
    {        
        public int ApproversForCreditCheckId { get; set; }
       
        public int CreditCheckApprovalMatrixId { get; set; }
        
        public int UserRoleId { get; set; }
       
        public int ApprovalLevel { get; set; }

    }
}
