﻿namespace OMF.Business.Models
{
    using System;

    public class OpportunityAuditAccessViewModel
    {

        public int OpportunityId { get; set; }

        public bool CRMAudit { get; set; }

        public bool ProjectComplianceAudit { get; set; }

        public bool SensitiveComplianceAudit { get; set; }

        public bool ECFGTCAudit { get; set; }

        public bool IFRSAudit { get; set; }
    }
}
