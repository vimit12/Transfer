﻿namespace OMF.Business.Models
{
    using System;

    public class OpportunityAccessViewModel : BaseClass
    {
        public int OpportunityAccessId { get; set; }

        public int OpportunityId { get; set; }

        public int UserRoleId { get; set; }

        public bool EditAccess { get; set; }

        public bool ViewOnlyAccess { get; set; }

        public bool DeleteAccess { get; set; }

        public string FullName { get; set; }

        // commented it as it is not required
        // public UserRoleViewModel User { get; set; }
    }
}
