﻿namespace OMF.Business.Models
{
    public class ORBWorkFlowNextStatusActionsViewModel : BaseClass
    {
        public int ORBWorkFlowNextStatusId { get; set; }

        public int OppORBStatusId { get; set; }

        public int ORBWorkFlowId { get; set; }

        public int ApproverTypeId { get; set; }
    }
}
