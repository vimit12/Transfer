﻿namespace OMF.Business.Models
{
    public class FRWorkFlowActionViewModel
    {
        public int FundingReductionId { get; set; }

        public int ActionId { get; set; }

        public string UpdatedBy { get; set; }

        public string Comments { get; set; }

        public string Role { get; set; }

        public string URL { get; set; }
    }
}
