﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class ORBWorkFlowStatusViewModel
    {
        public int UserCommentId { get; set; }
    }
}
