﻿namespace OMF.Business.Models
{
    public class PCReferBackOnHoldReasonViewModel : BaseClass
    {
        public int PCReferBackOnHoldReasonId { get; set; }

        public string PCReferBackOnHoldReasonName { get; set; }

        public string Comments { get; set; }

        public int StatusTypeId { get; set; }
    }
}
