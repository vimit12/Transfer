﻿using System.Collections.Generic;

namespace OMF.Business.Models
{
    public class OMFWorkLocationWorkFlowJourneyViewModel : BaseClass
    {
        public int WorkLocationId { get; set; }

        public string WorkLocationName { get; set; }

        public IEnumerable<OMFJourneyViewModel> JourneyViewModels { get; set; }
    }
}