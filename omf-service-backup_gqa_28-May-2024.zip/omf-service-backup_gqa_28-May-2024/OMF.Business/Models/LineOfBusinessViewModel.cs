﻿namespace OMF.Business.Models
{
    public class LineOfBusinessViewModel : BaseClass
    {
        public int LineOfBusinessId { get; set; }

        public string LineOfBusinessName { get; set; }

        public string Comments { get; set; }
    }
}
