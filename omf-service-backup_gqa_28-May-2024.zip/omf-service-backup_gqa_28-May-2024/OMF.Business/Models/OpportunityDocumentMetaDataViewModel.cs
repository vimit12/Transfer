﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class OpportunityDocumentMetaDataViewModel
    {
        public int OpportunityDocumentDetailsId { get; set; }

        public int OpportunityId { get; set; }

        public string OpportunityName { get; set; }

        public int DocumentTypeId { get; set; }

        public string DocumentTypeName { get; set; }

        public string FileName { get; set; }

        public string FileExtension { get; set; }

        public int CommentId { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
