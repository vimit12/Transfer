﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class ORBJourneyViewModel : BaseClass
    {
        public int ORBWorkFlowJourneyId { get; set; }

        public int OpportunityId { get; set; }

        public int ApproverTypeId { get; set; }

        public string ApproverTypeName { get; set; }

        public IEnumerable<OMFJourneyViewModel> JourneyViewModels { get; set; }

    }
}
