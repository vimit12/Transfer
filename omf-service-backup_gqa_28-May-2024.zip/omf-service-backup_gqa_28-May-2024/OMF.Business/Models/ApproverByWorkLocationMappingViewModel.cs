﻿using System.Collections.Generic;

namespace OMF.Business.Models
{
    public class ApproverByWorkLocationMappingViewModel
    {
        public int ApproverByWorkLocationMappingId { get; set; }

        public int ApproverByWorkLocationId { get; set; }

        public int UserRoleId { get; set; }

    }
}
