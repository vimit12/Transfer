﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class LandingPageStatusViewModel
    {
        public string Status { get; set; }

        public int Count { get; set; }

        public IEnumerable<LandingPageOpportunityViewModel> Opportunities { get; set; }
    }
}
