﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class ComplianceScreeningInstructionsViewModel
    {
        public string RegionName { get; set; }

        public string ApproverName { get; set; }

        public string ApproverMailId { get; set; }
    }
}
