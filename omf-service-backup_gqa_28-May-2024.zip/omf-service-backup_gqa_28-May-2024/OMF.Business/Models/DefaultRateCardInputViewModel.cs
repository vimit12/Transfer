﻿namespace OMF.Business.Models
{
    public class DefaultRateCardInputViewModel
    {
        public int Id { get; set; }

        public int YearId { get; set; }

        public int OppourtunityBaseCurrencyId { get; set; }
    }
}
