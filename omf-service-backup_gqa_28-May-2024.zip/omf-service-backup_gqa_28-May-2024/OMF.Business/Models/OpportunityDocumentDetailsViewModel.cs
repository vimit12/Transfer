﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class OpportunityDocumentDetailsViewModel
    {
        public int OpportunityId { get; set; }

        public string DocumentName { get; set; }

        public string DocumentExtension { get; set; }

        public string DocumentTypeName { get; set; }

        public int DocumentTypeId { get; set; }

        public byte[] DocumentContent { get; set; }

        public string UploadedDocumentContent { get; set; }

        public int CommentId { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
