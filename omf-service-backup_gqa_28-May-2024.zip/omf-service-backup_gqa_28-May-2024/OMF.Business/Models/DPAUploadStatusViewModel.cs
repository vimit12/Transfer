﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class DPAUploadStatusViewModel
    {
       public int DPAUploadStatusId { get; set; }

       public string DPAUploadStatusName { get; set; }
    }
}
