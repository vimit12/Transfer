﻿using System.Collections.Generic;

namespace OMF.Business.Models
{
    public class ProjectOrganizationDetailsViewModel
    {
        public int ProjectOrganizationId { get; set; }

        public string ProjectOrganizationName { get; set; }

        public string Comments { get; set; }

        public int CountryId { get; set; }

        public string CountryName { get; set; }

        public List<ReportingPracticeDetailsViewModel> ReportingPracticeViewModels { get; set; }
    }
}