﻿namespace OMF.Business.Models
{
    public class ResourceRoleViewModel : BaseClass
    {
        public int ResourceRoleId { get; set; }

        public string ResourceRoleName { get; set; }

        public string Comments { get; set; }

        public int PSI { get; set; }

        public double StandardCostValue { get; set; }

        public double BillCardCostValue { get; set; }

        public double DiscountedHourlyBillRate { get; set; }
    }
}