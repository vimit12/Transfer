﻿namespace OMF.Business.Models
{
    using System;

    public class FinancialEmployeeWorkHourEntryViewModel : BaseClass
    {
        public int FinancialEmployeeWorkHourEntryId { get; set; }

        public int FinancialEmployeeDetailId { get; set; }

        public int QuarterId { get; set; }

        public int MonthId { get; set; }

        public DateTime WeekStartDay { get; set; }

        public decimal Hours { get; set; }

        public short MaxHours { get; set; }
    }
}
