﻿namespace OMF.Business.Models
{
    using System;

    public class OpportunityCreditAssessmentViewModel : BaseClass
    {
        public int CreditAssessmentId { get; set; }

        public int EvaluationType { get; set; }

        public int PriorCreditLimit { get; set; }

        public int ProposedCreditLimit { get; set; }

        public int CustomerRelationship { get; set; }

        public DateTime? DateReviewPerformed { get; set; }

        public DateTime? DateofNextReview { get; set; }

        public DateTime? SpecificDate { get; set; }

        public DateTime? DateofFinancials { get; set; }

        public int? ParentChildRelationshipSetuUp { get; set; }

        public int? ParentalGuarantee { get; set; }

        public string FinancialSource { get; set; }

        public string Industry { get; set; }

        public string EvaluatingOffice { get; set; }

        public int Americas { get; set; }

        public int EMEA { get; set; }

        public int APAC { get; set; }

        public string RecommendationFromAnalyst { get; set; }

        public string RecommendationFromApprover { get; set; }

        public string CreditApprovalsPreparedBy { get; set; }

        public DateTime? CreditApprovalsPreparedOn { get; set; }

        public int ProposedRiskRating { get; set; }

        public int PriorRiskRating { get; set; }

        public int OpportunityId { get; set; }

        public int? CreditCheckApprovalType { get; set; }

        public string RecommendationByApprover2 { get; set; }

        public string CreditApproval2PreparedBy { get; set; }

        public DateTime? CreditApproval2PreparedOn { get; set; }

        public string CAFDetailsPreparedBy { get; set; }

        public DateTime? CAFDetailsPreparedOn { get; set; }

        public int? ApprovalTypeForApprover2 { get; set; }
    }
}
