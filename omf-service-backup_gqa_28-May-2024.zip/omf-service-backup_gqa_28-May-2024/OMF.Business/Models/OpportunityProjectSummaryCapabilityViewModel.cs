﻿namespace OMF.Business.Models
{
    public class OpportunityProjectSummaryCapabilityViewModel : BaseClass
    {
        public int OpportunityProjectSummaryCapabilityId { get; set; }

        public int OpportunityId { get; set; }

        public int CapabilityId { get; set; }

        public int SubCapabilityId { get; set; }

        public float Percentage { get; set; }

        public bool IsUpdate { get; set; }

        public bool IsDelete { get; set; }

        public string CapabilityName { get; set; }

        public string SubCapabilityName { get; set; }
    }
}
