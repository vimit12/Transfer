﻿namespace OMF.Business.Models
{
    public class CopyFinancialProposalInputViewModel
    {
        public int OpportunityId { get; set; }

        public int CopyFromYear { get; set; }

        public int CopyToYear { get; set; }

        public string CopySections { get; set; }

        public float Discount { get; set; }

        public string FinancialSectionSelection { get; set; }

        public int CopyFromYearId { get; set; }

        public int CopyToYearId { get; set; }

        public int OpportunityStartYearId { get; set; }

        public bool CopyTargets { get; set; }
    }
}
