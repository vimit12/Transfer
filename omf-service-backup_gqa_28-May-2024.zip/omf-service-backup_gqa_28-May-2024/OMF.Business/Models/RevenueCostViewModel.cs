﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class RevenueCostViewModel
    {
        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public double EmployeeRevenue { get; set; }

        public double EmployeeCost { get; set; }

        public double ContractorsRevenue { get; set; }

        public double ContractorsCost { get; set; }

        public double MSDRevenue { get; set; }

        public double AMCRevenue { get; set; }

        public double SWHWRevenue { get; set; }

        public double CloudRevenue { get; set; }

        public double BillableRevenue { get; set; }

        public double SARevenue { get; set; }

        public double TotalYearRevenue { get; set; }
    }
}
