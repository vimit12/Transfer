﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class PricingMatrixViewModel
    {
        public int MatrixId { get; set; }

        public double OnsiteMargin { get; set; }

        public double PricingMatrix1 { get; set; }

        public double PricingMatrix2 { get; set; }

        public double PricingMatrix3 { get; set; }

        public double PricingMatrix4 { get; set; }

        public double PricingMatrix5 { get; set; }

        public double PricingMatrix6 { get; set; }

        public double PricingMatrix7 { get; set; }

        public double PricingMatrix8 { get; set; }

        public double PricingMatrix9 { get; set; }

        public double PricingMatrix10 { get; set; }

        public double PricingMatrix11 { get; set; }

        public double PricingMatrix12 { get; set; }

        public double PricingMatrix13 { get; set; }

        public double PricingMatrix14 { get; set; }
    }
}
