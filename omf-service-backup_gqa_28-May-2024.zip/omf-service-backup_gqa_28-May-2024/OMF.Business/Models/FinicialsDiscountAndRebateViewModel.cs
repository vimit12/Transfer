﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class FinancialsDiscountAndRebateViewModel
    {
        public int FinancialsDiscountAndRebateId { get; set; }

        public int OpportunityId { get; set; }

        public int YearId { get; set; }

        public double Amount { get; set; }

        public string Comments { get; set; }
    }
}
