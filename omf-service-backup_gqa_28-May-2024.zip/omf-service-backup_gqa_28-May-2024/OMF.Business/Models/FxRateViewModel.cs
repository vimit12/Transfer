﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;

    public class FxRateViewModel
    {
        public int FxRateId { get; set; }

        public int CurrencyId { get; set; }

        public string CurrencyCode { get; set; }

        public int YearId { get; set; }

        public int YearIdValue { get; set; }

        public int Quarter1Id { get; set; }

        public double Quarter1Value { get; set; }

        public int Quarter2Id { get; set; }

        public double Quarter2Value { get; set; }

        public int Quarter3Id { get; set; }

        public double Quarter3Value { get; set; }

        public int Quarter4Id { get; set; }

        public double Quarter4Value { get; set; }

        public string Comments { get; set; }

        public int ActiveQuarterid { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }
    }
}