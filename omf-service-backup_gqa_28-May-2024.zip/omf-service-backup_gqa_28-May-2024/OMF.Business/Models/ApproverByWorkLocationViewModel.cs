﻿namespace OMF.Business.Models
{
    using OMF.Data.Models;
    using System.Collections.Generic;

    public class ApproverByWorkLocationViewModel : BaseClass
    {
        public int ApproverByWorkLocationId { get; set; }

        public int WorkLocationId { get; set; }

        public int ApproverTypeId { get; set; }

        public string Comments { get; set; }

        public string ApproverNames { get; set; }

        public string WorkLocationName { get; set; }

        public string ApproverTypeName { get; set; }

        public IEnumerable<ApproverByWorkLocationMappingViewModel> Approvers { get; set; }

        public IEnumerable<LineOfBusinessViewModel> LinesOfBusinesses { get; set; }

        public string LinesOfBusinessesNames { get; set; }

        public IEnumerable<COPViewModel> COPs { get; set; }

        public string COPNames { get; set; }

    }
}
