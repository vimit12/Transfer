﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class OpportunityDocumentDeleteViewModel
    {
        public int OpportunityId { get; set; }

        public int OpportunityDocumentDetailId { get; set; }
    }
}
