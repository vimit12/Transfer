﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class CurrencyRateViewModel
    {
        public int CurrencyId { get; set; }

        public int YearId { get; set; }
    }
}
