﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class WorkflowJourneyViewModel : BaseClass
    {
        public int WorkFlowJourneyId { get; set; }

        public int OpportunityId { get; set; }

        public int ApproverTypeId { get; set; }

        public string ApproverTypeName { get; set; }

        public int StatusTypeId { get; set; }

        public int ScreenId { get; set; }

        public IEnumerable<OMFJourneyViewModel> JourneyViewModels { get; set; }

    }
}
