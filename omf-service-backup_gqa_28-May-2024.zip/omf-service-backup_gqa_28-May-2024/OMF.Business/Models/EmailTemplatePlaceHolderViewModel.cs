﻿namespace OMF.Business.Models
{
    public class EmailTemplatePlaceHolderViewModel : BaseClass
    {
        public int PlaceHolderId { get; set; }

        public string PlaceHolderName { get; set; }
    }
}
