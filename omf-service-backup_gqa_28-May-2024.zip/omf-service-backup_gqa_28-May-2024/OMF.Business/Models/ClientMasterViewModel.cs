﻿namespace OMF.Business.Models
{
    using System;

    public class ClientMasterViewModel : BaseClass
    {
        public int ClientMasterId { get; set; }

        public string ClientName { get; set; }

        public string LocalizedAccountName { get; set; }

        public string ClientAlias { get; set; }

        public int IndustrySegmentId { get; set; }

        public string IndustrySegmentName { get; set; }

        public int IndustrySubSegmentId { get; set; }

        public string IndustrySubSegmentName { get; set; }

        public int PaymentTermId { get; set; }

        public bool HitachiCompany { get; set; }

        public bool JapaneseCompany { get; set; }

        public string Url { get; set; }

        public string PrimaryContactName { get; set; }

        public string Comments { get; set; }

        public string InsideViewId { get; set; }

        public string OracleClientNumber { get; set; }

        public string OracleRegistryId { get; set; }

        public int ClientQuadrantId { get; set; }

        public string PaymentTermName { get; set; }

        public int DPAAvailable { get; set; }

        public bool COLAAtDPALevel { get; set; }

        public string DPARemarks { get; set; }

        public string COLARemarks { get; set; }

        public int DPAUploadStatusId { get; set; }

        public string DPAUploadStatusName { get; set; }

        public string BillingAdministrator { get; set; }

        public DateTime? COLAStartDate { get; set; }
    }
}
