﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class OpportunityProjectTemplateMatrixViewModel
    {
        public int ProjectTemplateMatrixId { get; set; }

        public int ReportingPracticeId { get; set; }

        public string ReportingPracticeName { get; set; }

        public int CapabilityId { get; set; }

        public string CapabilityName { get; set; }

        public int SubCapabilityId { get; set; }

        public string SubCapabilityName { get; set; }

        public int ContractTypeId { get; set; }

        public string ContractTypeName { get; set; }

        public int ProjectTemplateId { get; set; }

        public string ProjectTemplateName { get; set; }

        public string BillingMethod { get; set; }

        public string BillingMethodName { get; set; }
    }
}
