﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class OMFSupportViewModel
    {
        public int OMFSupportId { get; set; }

        public string EmployeeName { get; set; }

        public string EmployeeAlias { get; set; }

        public string Email { get; set; }

        public string EmployeeId { get; set; }

        public string Role { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public bool Active { get; set; }
    }
}