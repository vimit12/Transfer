﻿namespace OMF.Business.Models
{
    public class OpportunityTypeViewModel
    {
        public int OpportunityTypeId { get; set; }

        public string OpportunityTypeName { get; set; }
    }
}
