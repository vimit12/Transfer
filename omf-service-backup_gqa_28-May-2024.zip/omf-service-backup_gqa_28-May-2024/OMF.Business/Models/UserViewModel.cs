﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class UserViewModel
    {
        public string EmployeeId { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public string Role { get; set; }

        public string Alias { get; set; }

        public string Location { get; set; }

        public string ManagerName { get; set; }

        public string ManagerMail { get; set; }

        public string CheckTokenUrl { get; set; }

        public string CheckTokenRelativeUrl { get; set; }

        public string CheckTokenAppId { get; set; }
    }
}
