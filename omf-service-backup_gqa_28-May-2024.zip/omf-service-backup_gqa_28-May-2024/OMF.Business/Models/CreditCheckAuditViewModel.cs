﻿namespace OMF.Business.Models
{
    using System;

    public class CreditCheckAuditViewModel : BaseClass
    {
        public int CreditCheckAuditId { get; set; }
        public string CrmId { get; set; }
        public string CreditComments { get; set; }
        public string CreditRating { get; set; }
        public int? CreditLimit { get; set; }
        public DateTime? CreditAssessmentDate { get; set; }
        public string PaymentBehaviour { get; set; }
        public string OracleRegistryId { get; set; }
        public int? ClientMasterId { get; set; }
        public double? OpportunityValue { get; set; }
        public int? OpportunityVersion { get; set; }
        public int? HiQOpportunityType { get; set; }
        public int? ProjectSetupType { get; set; }
        public string CreditExposureByRegistryId { get; set; }
        public string CreditExposureFileName { get; set; }
        public double? InFlightOpportunitiesValue { get; set; }
        public int? ProposedCreditLimit { get; set; }
        public int? ProposedRiskRating { get; set; }
        public int? CustomerRelationship { get; set; }
        public bool CreditCheckRequired { get; set; }
        public int OpportunityId { get; set; }

    }
}
