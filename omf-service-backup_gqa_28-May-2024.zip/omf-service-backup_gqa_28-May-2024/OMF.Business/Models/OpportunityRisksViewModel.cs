﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class OpportunityRisksViewModel : BaseClass
    {
        public int OpportunityRiskId { get; set; }

        public int OpportunityId { get; set; }

        public string RiskDescription { get; set; }

        public string RiskMitigationPlan { get; set; }

    }
}
