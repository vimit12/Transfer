﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class NextStatusActionByStatusTypeMappingViewModel : BaseClass
    {
        public int NextStatusActionByStatusTypeMappingId { get; set; }

        public int StatusId { get; set; }

        public string Status { get; set; }

        public int StatusActionId { get; set; }

        public string StatusActionText { get; set; }

        public string Actions { get; set; }

        public IEnumerable<StatusActionViewModel> StatusActions { get; set; }
    }
}
