﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class ColaViewModel
    {
       public List<ColaValues> ColaValues { get; set; }

       public IEnumerable<Comments> Comments { get; set; }
    }
}
