﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class RoleScreenActionsViewModel : BaseClass
    {
        public int RoleScreenActionsId { get; set; }

        public int RoleId { get; set; }

        public string RoleName { get; set; }

        public int ScreenId { get; set; }

        public string ScreenName { get; set; }

        public string Actions { get; set; }

        public List<ScreenActionsViewModel> ScreenActions { get; set; }
    }
}
