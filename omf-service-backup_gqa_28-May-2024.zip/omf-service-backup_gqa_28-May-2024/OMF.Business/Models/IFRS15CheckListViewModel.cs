﻿namespace OMF.Business.Models
{
    using System;

    public class IFRS15CheckListViewModel : BaseClass
    {
        public int IFRS15CheckListId { get; set; }

        public int OpportunityId { get; set; }

        public bool Question1 { get; set; }

        public string Question1Description { get; set; }

        public bool Question2 { get; set; }

        public string Question2Description { get; set; }

        public bool Question3 { get; set; }

        public string Question3Description { get; set; }

        public bool Question4 { get; set; }

        public string Question4Description { get; set; }

        public bool Question5 { get; set; }

        public string Question5Description { get; set; }

        public bool Question6 { get; set; }

        public string Question6Description { get; set; }

        public bool Question7 { get; set; }

        public string Question7Description { get; set; }

        public bool Question8 { get; set; }

        public string Question8Description { get; set; }
    }
}