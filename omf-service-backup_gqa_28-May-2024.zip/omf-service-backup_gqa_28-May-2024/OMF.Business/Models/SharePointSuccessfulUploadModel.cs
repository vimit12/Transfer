﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace OMF.Business.Models
{
    public class SharePointSuccessfulUploadModel
    {
        [JsonPropertyName("LinkingUri")]
        public string LinkingUri { get; set; }

        [JsonPropertyName("LinkingUrl")]
        public string LinkingUrl { get; set; }

        [JsonPropertyName("ServerRelativeUrl")]
        public string ServerRelativeUrl { get; set; }

        [JsonPropertyName("Name")]
        public string Name { get; set; }
    }
}
