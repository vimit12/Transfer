﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class FRWorkFlowActionsViewModel
    {
        public int RoleId { get; set; }

        public int FundingReductionId { get; set; }

        public string UpdatedBy { get; set; }

        public List<StatusActionViewModel> StatusActionViewModelList { get; set; }

        public int ScreenId { get; set; }
    }
}
