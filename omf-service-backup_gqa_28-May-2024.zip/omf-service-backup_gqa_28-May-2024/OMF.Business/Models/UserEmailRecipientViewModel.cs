﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class UserEmailRecipientViewModel
    {
        public int UserRoleId { get; set; }

        public string Recipient { get; set; }

    }
}
