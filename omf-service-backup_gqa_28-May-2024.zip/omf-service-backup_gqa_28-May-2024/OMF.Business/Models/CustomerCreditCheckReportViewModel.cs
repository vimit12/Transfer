﻿namespace OMF.Business.Models
{
    using System;

    public class CustomerCreditCheckReportViewModel : BaseClass
    {

        public int CustomerCreditCheckReportId { get; set; }

        public string Asofdate { get; set; }

        public string CustomerName { get; set; }

        public DateTime? CustomerCreationDate { get; set; }

        public string AccountNumber { get; set; }

        public string RegistryID { get; set; }

        public string Entity { get; set; }

        public string PaymentTerms { get; set; }

        public double? AverageDaysLate { get; set; }

        public string ProfileClass { get; set; }

        public string CreditClassification { get; set; }

        public string CreditRating { get; set; }

        public int? CustomerCreditLimit { get; set; }

        public int? OrderCreditLimit { get; set; }

        public bool? CreditCheck { get; set; }

        public bool? Credithold { get; set; }

        public string CreditAnalyst { get; set; }

        public double? TotalFunding { get; set; }

        public double? TotalBilled { get; set; }

        public double? ARBalance { get; set; }

        public double? UnbilledBalance { get; set; }

        public double? OnAccountUnApplied { get; set; }

        public double? CreditExposure { get; set; }

        public double? AvailableCreditLimit { get; set; }

        public string ReviewCycle { get; set; }

        public DateTime? NextCreditReview { get; set; }

        public DateTime? LastPeriodicReview { get; set; }

        public string AccountStatus { get; set; }

        public string CreditExposureFileName { get; set; }
    }
}
