﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class ORBApproverViewModel
    {
        public string ApproverName { get; set; }

        public string ApproverType { get; set; }

        public string COPName { get; set; }

        public string ApproverOrder { get; set; }

        public string ApproverUserId { get; set; }
    }
}
