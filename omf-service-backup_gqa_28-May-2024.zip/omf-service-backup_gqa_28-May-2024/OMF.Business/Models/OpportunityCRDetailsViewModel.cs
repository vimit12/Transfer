﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class OpportunityCRDetailsViewModel : BaseClass
    {
        public int OpportunityCRDetailsId { get; set; }

        public int ProjectSetupType { get; set; }

        public string LegacyProjectCode { get; set; }

        public string LegacyProjectName { get; set; }

        public int OpportunityId { get; set; }

        public bool IsOpportunityCR { get; set; }

        public bool IsTAndCAndMarginChanged { get; set; }

        public bool IsValueOverOneMillion { get; set; }

        public bool IsSoftwareAndHardwareInvolved { get; set; }

        public string SfdcId { get; set; }

        public string KimbleId { get; set; }

        public bool IsCrmIdAvailable { get; set; }

        public bool IsHiQDataSynced { get; set; }

        public double BaseOMFAllServicesPGMPer { get; set; }

        public string BaseOMFORBCriteria { get; set; }

        public bool IsProjectCreatedInPending { get; set; }

        public int HiQOpportunityTypeId { get; set; }

        public int? HVContractingEntityId { get; set; }

        public string HVContractingEntityName { get; set; }

        public int? HVOUId { get; set; }

        public string HVOUName { get; set; }

        public int? HVOUPracticeId { get; set; }

        public string HVOUPracticeName { get; set; }

        public bool IsStdCostUpdated { get; set; }
    }
}
