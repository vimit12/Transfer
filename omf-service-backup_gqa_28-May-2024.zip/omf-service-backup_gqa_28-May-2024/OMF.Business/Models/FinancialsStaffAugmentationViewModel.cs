﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class FinancialsStaffAugmentationViewModel
    {
        public int FinancialsStaffAugmentationId { get; set; }

        public string EmployeeName { get; set; }

        public string PoNumber { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public double TotalRevenue { get; set; }

        public double TotalCost { get; set; }

        public double PgmValue { get; set; }

        public float PgmPercentage { get; set; }

        public int OpportunityId { get; set; }

        public int YearId { get; set; }

    }
}
