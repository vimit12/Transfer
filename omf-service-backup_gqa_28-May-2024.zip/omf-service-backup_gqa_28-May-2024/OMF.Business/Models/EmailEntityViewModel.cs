﻿namespace OMF.Business.Models
{
    public class EmailEntityViewModel : BaseClass
    {
        public int EmailEntityId { get; set; }

        public string EmailEntityName { get; set; }

        public bool? IsConfig { get; set; }

        public string Comments { get; set; }
    }
}