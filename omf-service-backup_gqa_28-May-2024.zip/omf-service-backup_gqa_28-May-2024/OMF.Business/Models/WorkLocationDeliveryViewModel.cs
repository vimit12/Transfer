﻿namespace OMF.Business.Models
{
    public class WorkLocationDeliveryViewModel
    {
        public int WorkLocationId { get; set; }

        public string WorkLocationName { get; set; }

        public int DeliveryModelId { get; set; }

        public string DeliveryModelName { get; set; }
    }
}
