﻿namespace OMF.Business.Models
{
    using System;

    public class OpportunityCreditCheckViewModel : BaseClass
    {
        public int OpportunityCreditCheckId { get; set; }

        public int OpportunityId { get; set; }

        public double EcfOpportunityValue { get; set; }

        public int HiQCrmId { get; set; }

        public double HiQOpportunityValue { get; set; }

        public string HiQClientName { get; set; }

        public string HiQClientCountry { get; set; }

        public string HiQBillingAddress { get; set; }

        public string HiQCreditRating { get; set; }

        public int HiQCreditLimit { get; set; }

        public DateTime HiQCreditAssessmentDate { get; set; }

        public string HiQPaymentBehaviour { get; set; }

        public string HiQSalesStage { get; set; }

        public string HiQWinProbability { get; set; }

        public string HiQOracleRegistryId { get; set; }

        public DateTime HiQFetchDateTime { get; set; }

        public string HiQStatus { get; set; }

        public double OpportunityValue { get; set; }

        public bool NewClientFlag { get; set; }

        public int OpportunityStatus { get; set; }

        public int OpportunityType { get; set; }

        public int ProjectSetupType { get; set; }

        public int TotalHours { get; set; }

        public int TotalHoursOnshore { get; set; }

        public int TotalHoursIDC { get; set; }

        public int TotalHoursVDN { get; set; }

        public int TotalHoursPDC { get; set; }

        public double CreditExposureInOracle { get; set; }

        public DateTime CreditExposureDateTime { get; set; }

        public string CreditExposureFileName { get; set; }

        public double ValueOfOtherOpportunities { get; set; }

        public string OmfEvent { get; set; }

        public int OmfStatus { get; set; }

        public bool SendForCreditCheck { get; set; }

        public string ReasonForCCResult { get; set; }

        public bool NotifyCreditReviewTeam { get; set; }

        public int Region { get; set; }

        public string Approver1 { get; set; }

        public string Approver2 { get; set; }
    }
}
