﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Models
{
    public class FinancialYearDatesModel
    {
        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public double EmployeeRevenue { get; set; }

        public double EmployeeCost { get; set; }

        public double ContractorRevenue { get; set; }

        public double ContractorCost { get; set; }

        public double DayRevenue { get; set; }

        public double AMCRevenue { get; set; }

        public double SWHWRevenue { get; set; }

        public double CloudRevenue { get; set; }

        public double BillableRevenue { get; set; }

        public double StaffAugmentationRevenue { get; set; }

        public double NoOfDays { get; set; }
    }
}
