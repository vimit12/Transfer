﻿namespace OMF.Business.Models
{
    using System.Collections.Generic;

    public class FinancialQuarterViewModel
    {
        public int QuarterId { get; set; }

        public List<FinancialMonthViewModel> Months { get; set; }
    }
}
