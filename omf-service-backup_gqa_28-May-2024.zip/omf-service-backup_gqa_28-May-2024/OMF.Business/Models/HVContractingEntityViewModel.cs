﻿namespace OMF.Business.Models
{
    public class HVContractingEntityViewModel : BaseClass
    {
        public int HVContractingEntityId { get; set; }

        public string HVContractingEntityName { get; set; }
    }
}
