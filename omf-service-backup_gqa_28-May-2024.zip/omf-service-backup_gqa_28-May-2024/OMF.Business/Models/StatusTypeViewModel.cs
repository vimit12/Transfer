﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class StatusTypeViewModel : BaseClass
    {
        public int StatusId { get; set; }

        public string Status { get; set; }

        public string Comments { get; set; }

        public string Region { get; set; }

        public string Country { get; set; }
    }
}
