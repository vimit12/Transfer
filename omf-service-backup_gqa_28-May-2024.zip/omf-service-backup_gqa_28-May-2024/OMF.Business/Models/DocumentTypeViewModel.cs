﻿namespace OMF.Business.Models
{
    public class DocumentTypeViewModel : BaseClass
    {
        public int DocumentTypeId { get; set; }

        public string DocumentTypeName { get; set; }
    }
}
