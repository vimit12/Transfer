﻿namespace OMF.Business.Models
{
    using System;

    public class CreditCheckInflightOpportunitiesViewModel : BaseClass
    {
        public int CreditCheckInflightOpportunitiesId { get; set; }
        public int OpportunityId { get; set; }
        public double? OpportunityValue { get; set; }
        public int OpportunityStatusId { get; set; }
        public string CrmId { get; set; }
        public int CreditCheckAuditId { get; set; }
        public int InflightOpportunityId { get; set; }

    }
}
