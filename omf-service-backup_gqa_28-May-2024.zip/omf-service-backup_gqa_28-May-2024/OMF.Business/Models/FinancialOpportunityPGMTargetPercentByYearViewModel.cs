﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class FinancialOpportunityPGMTargetPercentByYearViewModel : BaseClass
    {
        public int FinancialOpportunityPGMTargetPercentByYearId { get; set; }

        public int OpportunityId { get; set; }

        public int WorkLocationId { get; set; }

        public int YearId { get; set; }

        public float PGMTargetPercent { get; set; }

        public float PGMActualPercent { get; set; }

        public string WorkLocationName { get; set; }

        public int Year { get; set; }

        public int DeliveryModelId { get; set; }

        public string DeliveryModelName { get; set; }

    }
}
