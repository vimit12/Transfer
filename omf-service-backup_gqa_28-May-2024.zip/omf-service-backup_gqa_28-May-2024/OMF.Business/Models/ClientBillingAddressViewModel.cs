﻿namespace OMF.Business.Models
{
    using System;

    public class ClientBillingAddressViewModel : BaseClass
    {
        public int ClientBillingAddressId { get; set; }

        public int ClientMasterId { get; set; }

        public int BillingCountryId { get; set; }

        public string BillingCountryName { get; set; }

        public string BillingAddress { get; set; }

        public string BillingState { get; set; }

        public string BillingCity { get; set; }

        public string BillingPostCode { get; set; }

        public int? BranchOrClientOffice { get; set; }

        public string ClientContactPerson { get; set; }

        public string TaxRegistrationNumber { get; set; }

        public string FaxNumber { get; set; }

        public string PhoneNumber { get; set; }

        public bool ExportFriendly { get; set; }

        public string BranchNumber { get; set; }
    }
}
