﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class WorkLocationWorkFlowTemplateMappingViewModel
    {
        public int WorkFlowTemplateMappingId { get; set; }

        public int WorkLocationWorkFlowId { get; set; }

        public int TemplateId { get; set; }

        public WorkFlowConfigViewModel WorkFlow { get; set; }

        public EmailTemplateViewModel EmailTemplate { get; set; }
    }
}
