﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class CROpportunityViewModel : BaseClass
    {
        public int CRID { get; set; }

        public int OpportunityId { get; set; }

        public int ParentOpportunityId { get; set; }

        public int CRType { get; set; }

        public bool CopyFinancials { get; set; }

        public DateTime? CRStartDate { get; set; }

        public DateTime? CREndDate { get; set; }

        public OpportunityCRDetailsViewModel OpportunityCRDetailsViewModel { get; set; }
    }
}
