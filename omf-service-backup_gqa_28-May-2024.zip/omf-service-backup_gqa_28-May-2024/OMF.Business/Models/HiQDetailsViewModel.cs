﻿
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace OMF.Business.Models
{
    public class HiQDetailsViewModel
    {
        [JsonPropertyName("OrganizationDEO_LocalMarket_AObj_cMeaning")]
        public string AccountManager { get; set; }

        [JsonPropertyName("OrganizationDEO_AccountManagerEmail_c")]
        public string AccountManagerEmail { get; set; }

        [JsonPropertyName("OrganizationDEO_OSAccountType_cMeaning")]
        public string ClientEngagementPartner { get; set; }

        [JsonPropertyName("OrganizationDEO_CEPEmail_c")]
        public string ClientEngagementPartnerEmail { get; set; }

        [JsonPropertyName("OrganizationDEO_DeliveryPartnerValues_c")]
        public string DeliveryPartner { get; set; }

        [JsonPropertyName("OrganizationDEO_DeliveryPartnerEmail_c")]
        public string DeliveryPartnerEmail { get; set; }
    }
}
