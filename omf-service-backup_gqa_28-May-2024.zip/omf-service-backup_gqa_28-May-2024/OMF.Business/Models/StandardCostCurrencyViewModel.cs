﻿namespace OMF.Business.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Text;

    public class StandardCostCurrencyViewModel
    {
        public string Currency { get; set; }

        public int CurrencyId { get; set; }

        public double Value { get; set; }
    }
}
