﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IProjectDomainService
    {
        IEnumerable<ProjectDomainViewModel> GetAllProjectDomains();

        IEnumerable<ProjectDomainViewModel> GetActiveProjectDomains();

        ProjectDomainViewModel GetProjectDomainById(int id);

        void AddProjectDomain(ProjectDomainViewModel model);

        void UpdateProjectDomain(ProjectDomainViewModel model);
    }
}
