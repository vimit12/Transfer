﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ISubCapabilityService
    {
        IEnumerable<SubCapabilityViewModel> GetSubCapabilities();

        IEnumerable<SubCapabilityViewModel> GetActiveSubCapabilities();

        IEnumerable<SubCapabilityViewModel> GetActiveSubCapabilitiesWithCapabilityId();

        SubCapabilityViewModel GetSubCapabilitiesById(int id);

        void AddSubCapability(SubCapabilityViewModel model);

        void UpdateSubCapability(SubCapabilityViewModel model);
    }
}