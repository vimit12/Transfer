﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

public interface IWorkLocationService
    {
        IEnumerable<WorkLocationViewModel> GetWorkLocations();

        IEnumerable<WorkLocationViewModel> GetActiveWorkLocations();

        WorkLocationViewModel GetWorkLocationById(int id);

        WorkLocationViewModel GetWorkLocationResourceMapping(int workLocationId, int yearId, int oppourtunityBaseCurrencyId);

        IEnumerable<WorkLocationViewModel> GetWorkLocationResourceByOpportunity(DefaultRateCardInputViewModel defaultRate);

        IEnumerable<WorkLocationDeliveryViewModel> GetWorkLocationDeliveryModel(int id);

        IEnumerable<CurrencyViewModel> GetCurrencyList();

        void AddWorkLocation(WorkLocationViewModel model);

        void UpdateWorkLocation(WorkLocationViewModel model);

    }
}
