﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using Microsoft.AspNetCore.Http;
    using OMF.Business.Models;

    public interface IFinancialCloudHostingService
    {
        IEnumerable<FinancialCloudHostingDetailsViewModel> GetFinancialCloudHostingDetails(int opportunityId, int yearId);

        void AddNewOrUpdateCloudHosting(List<FinancialCloudHostingDetailsViewModel> cloudViewModel, string userId);

        void DeleteCloudHostingDetails(List<FinancialCloudHostingDetailsViewModel> financialCloudHosting, ref string errorMessage);
    }
}
