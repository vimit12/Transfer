﻿using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Interfaces
{
    public interface IOpportunityCRDetailsService
    {
        OpportunityCRDetailsViewModel SaveOrUpdateCRDetails(OpportunityCRDetailsViewModel opportunityCRDetailsViewModel);

        OpportunityCRDetailsViewModel GetOpportunityCRDetails(int opportunityId);
    }
}
