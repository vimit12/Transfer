﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ITechnologySubTechnologyMappingService
    {
        IEnumerable<TechnologySubTechnologyMappingViewModel> GetAllTechnologySubTechnologies();

        void AddTechnologySubTechnology(TechnologySubTechnologyMappingViewModel model);
    }
}