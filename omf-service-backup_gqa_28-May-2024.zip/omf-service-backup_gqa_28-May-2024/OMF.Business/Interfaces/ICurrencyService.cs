﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ICurrencyService
    {
        IEnumerable<CurrencyViewModel> GetActiveCurrencies();

        IEnumerable<CurrencyViewModel> GetAllCurrencies();

        CurrencyViewModel GetCurrencyById(int id);

        void AddCurrency(CurrencyViewModel model);

        void UpdateCurrency(CurrencyViewModel model);
    }
}