﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ILineOfBusinessService
    {
        IEnumerable<LineOfBusinessViewModel> GetAllLineOfBusinesses();

        IEnumerable<LineOfBusinessViewModel> GetActiveLineOfBusinesses();

        LineOfBusinessViewModel GetLineOfBusinessById(int id);

        void AddLineOfBusiness(LineOfBusinessViewModel model);

        void UpdateLineOfBusiness(LineOfBusinessViewModel model);
    }
}
