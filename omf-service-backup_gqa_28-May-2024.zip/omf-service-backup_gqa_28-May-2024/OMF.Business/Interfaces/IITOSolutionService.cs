﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IITOSolutionService
    {
        IEnumerable<ITOSolutionViewModel> GetAllITOSolutions();

        IEnumerable<ITOSolutionViewModel> GetActiveITOSolutions();

        ITOSolutionViewModel GetITOSolutionById(int id);

        void AddITOSolution(ITOSolutionViewModel model);

        void UpdateITOSolution(ITOSolutionViewModel model);
    }
}
