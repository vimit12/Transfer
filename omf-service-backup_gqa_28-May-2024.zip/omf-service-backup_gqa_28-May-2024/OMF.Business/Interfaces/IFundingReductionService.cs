﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using OMF.Business.Models;

    public interface IFundingReductionService
    {
        IEnumerable<FundingReductionBasicDetailsViewModel> GetAllFundingReductions();

        IEnumerable<FundingReductionViewModel> GetActiveFundingReductions();

        FundingReductionViewModel GetFundingReductionById(int id);

        FundingReductionBasicDetailsViewModel AddFundingReduction(FundingReductionViewModel model);

        FundingReductionBasicDetailsViewModel UpdateFundingReduction(FundingReductionViewModel model);

        IEnumerable<FundingReductionBasicDetailsViewModel> GetFundingReductionHistory();

        Task SaveDocuments(FundingReductionDocumentDetailsViewModel model);

        Task<FundingReductionDocumentDetailsViewModel> GetFundingReductionDocumentDetails(int opportunityDocumentDetailsId);
    }
}