﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IClientMasterService
    {
        IEnumerable<ClientMasterViewModel> GetClientMasters();

        IEnumerable<ClientMasterViewModel> GetActiveClientMasters();

        ClientMasterViewModel GetClientMasterById(int id);

        void AddClientMaster(ClientMasterViewModel model);

        void UpdateClientMaster(ClientMasterViewModel model);

        IEnumerable<ClientDetailsViewModel> GetActiveClientDetails();

        ClientMasterDetailsViewModel GetClientDetailsById(int id);
    }
}
