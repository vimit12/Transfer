﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IIndustrySubVerticalsService
    {
        IEnumerable<IndustrySubVerticalsViewModel> GetAllIndustrySubVerticals();

        void AddIndustrySubVertical(IndustrySubVerticalsViewModel model);

        IndustrySubVerticalsViewModel GetIndustrySubVerticalById(int id);

        void UpdateIndustrySubVertical(IndustrySubVerticalsViewModel model);

        IEnumerable<IndustrySubVerticalsViewModel> GetActiveIndustrySubVerticals();
    }
}
