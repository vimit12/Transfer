﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IApproverByRegionService
    {
        IEnumerable<ApproverByRegionViewModel> GetApproversByRegion();

        void AddApproverByRegion(ApproverByRegionViewModel model);

        void UpdateApproverByRegion(ApproverByRegionViewModel model);
    }
}
