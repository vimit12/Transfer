﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IStatusTypeService
    {
        IEnumerable<StatusTypeViewModel> GetAllStatusTypes();

        IEnumerable<StatusTypeViewModel> GetActiveStatusTypes();

        void AddStatusType(StatusTypeViewModel model);

        StatusTypeViewModel GetStatusTypeById(int id);

        void UpdateStatusType(StatusTypeViewModel model);
    }
}
