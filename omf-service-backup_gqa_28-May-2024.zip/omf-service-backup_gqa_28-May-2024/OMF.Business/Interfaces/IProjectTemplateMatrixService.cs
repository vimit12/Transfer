﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;
    using OMF.Data.Models;

    public interface IProjectTemplateMatrixService
    {
        IEnumerable<ProjectTemplateMatrixViewModel> GetProjectTemplateMatrix();

        void AddProjectTemplateMatrix(ProjectTemplateMatrixViewModel model);

        void UpdateProjectTemplateMatrix(ProjectTemplateMatrixViewModel model);

        IEnumerable<ProjectTemplate> GetAllProjectTemplates();
    }
}
