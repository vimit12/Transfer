﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ISubTechAllianceService
    {
        IEnumerable<SubTechAllianceViewModel> GetSubTechAlliance();

        IEnumerable<SubTechAllianceViewModel> GetActiveSubTechnologies();

        SubTechAllianceViewModel GetSubTechAllianceById(int id);

        void AddSubTechAlliance(SubTechAllianceViewModel model);

        void UpdateSubTechAlliance(SubTechAllianceViewModel model);

        IEnumerable<SubTechAllianceViewModel> GetActiveSubTechnologiesWithTechnologyId();

    }
}