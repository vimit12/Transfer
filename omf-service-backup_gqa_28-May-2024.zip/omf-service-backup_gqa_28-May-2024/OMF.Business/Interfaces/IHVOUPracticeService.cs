﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Interfaces
{
    using OMF.Business.Models;

    public interface IHVOUPracticeService
    {
        IEnumerable<HVOUPracticesViewModel> GetActiveHVOUPractices();

        IEnumerable<HVOUPracticeMappingViewModel> GetActiveHVOUPracticeMappings();
    }
}
