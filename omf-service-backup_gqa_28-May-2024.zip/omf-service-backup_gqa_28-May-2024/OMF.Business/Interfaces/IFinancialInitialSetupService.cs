﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IFinancialInitialSetupService
    {
        IEnumerable<FinancialInitialSetupViewModel> GetAllFinancialsInitialSetup();

        void AddInitialSetup(FinancialInitialSetupViewModel model);

        FinancialInitialSetupViewModel GetInitialSetupById(int id);

        void UpdateInitialSetup(FinancialInitialSetupViewModel model);

        OpportunityDatesViewModel GetInitialSetupByOppourtunity(DefaultRateCardInputViewModel defaultInput);

        IEnumerable<FinancialInitialSetupViewModel> GetAllFinancialsInitialSetupByOpportunityId(int opportunityId);
    }
}
