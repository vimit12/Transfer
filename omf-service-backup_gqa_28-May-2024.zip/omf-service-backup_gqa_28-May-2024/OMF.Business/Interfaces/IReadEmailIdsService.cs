﻿using OMF.Business.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Interfaces
{
    public interface IReadEmailIdsService
    {
        List<UserViewModel> GetAllUsers(string searchString);
    }
}
