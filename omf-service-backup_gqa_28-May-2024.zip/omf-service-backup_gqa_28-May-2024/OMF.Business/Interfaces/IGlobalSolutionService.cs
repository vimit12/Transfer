﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IGlobalSolutionService
    {
        IEnumerable<GlobalSolutionViewModel> GetAllGlobalSolutions();

        GlobalSolutionViewModel GetGlobalSolutionById(int id);

        void AddGlobalSolution(GlobalSolutionViewModel model);

        void UpdateGlobalSolution(GlobalSolutionViewModel model);
    }
}
