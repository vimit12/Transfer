﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IWorkFlowConfigService
    {
        IEnumerable<WorkFlowConfigViewModel> GetAllWorkFlows();

        void AddWorkFlow(WorkFlowConfigViewModel workFlowConfigViewModel);

        void UpdateWorkFlow(WorkFlowConfigViewModel workFlowConfigViewModel);
    }
}
