﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IHVContractingEntity
    {
        IEnumerable<HVContractingEntityViewModel> GetAllHVContractingEntities();

        IEnumerable<HVContractingEntityViewModel> GetActiveHVContractingEntities();

        HVContractingEntityViewModel GetHVContractingEntityById(int id);

        void AddHVContractingEntity(HVContractingEntityViewModel model);

        void UpdateHVContractingEntity(HVContractingEntityViewModel model);
    }
}
