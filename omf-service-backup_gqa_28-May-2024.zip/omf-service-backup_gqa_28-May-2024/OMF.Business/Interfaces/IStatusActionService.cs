﻿namespace OMF.Business.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using OMF.Business.Models;
    using OMF.Data.Models;

    public interface IStatusActionService
    {
        IEnumerable<StatusActionViewModel> GetStatusActions();

        IEnumerable<StatusActionViewModel> GetActiveStatusActions();

        void AddStausAction(StatusActionViewModel model);

        StatusAction GetStatusActionById(int statusActionId);

        void UpdateStatusAction(StatusActionViewModel model);

        IEnumerable<OMFScreensViewModel> GetOmfScreens();
    }
}
