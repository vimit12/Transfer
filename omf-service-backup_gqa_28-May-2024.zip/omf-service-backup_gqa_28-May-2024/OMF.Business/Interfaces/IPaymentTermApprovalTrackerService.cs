﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IPaymentTermApprovalTrackerService
    {
        IEnumerable<PaymentTermApprovalTrackerViewModel> GetAllPaymentTermApprovalTrackers();

        void AddPaymentTermApprovalTracker(PaymentTermApprovalTrackerViewModel model);

        PaymentTermApprovalTrackerViewModel GetPaymentTermApprovalTrackerById(int id);

        void UpdatePaymentTermApprovalTracker(PaymentTermApprovalTrackerViewModel model);
    }
}
