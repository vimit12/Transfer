﻿using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Interfaces
{
    public interface IORBApprovalCriteriaService
    {
        ORBApprovalCriteriaViewModel GetORBApprovalRating(int opportunityId);

        void SaveOrUpdateOpportunityRating(ORBApprovalCriteriaViewModel oppRating);

        void AddORBCategoryApprovers(ORBCategoryApproverViewModel approverViewModel);

        void AddORBMarketApprovers(ORBMarketApproverViewModel approverViewModel);

        void AddORBSalesLeadApprovers(ORBSalesLeadApproverViewModel approverViewModel);

        IEnumerable<ORBCategoryApproverViewModel> GetORBCategoryApprovers();

        IEnumerable<ORBMarketApproverViewModel> GetORBMarketApprovers();

        IEnumerable<ORBSalesLeadApproverViewModel> GetORBSalesLeadApprovers();

        void UpdateORBCategoryUserRoleMapping(ORBCategoryApproverViewModel oRBCategoryApprover);

        void UpdateORBMarketUserRoleMapping(ORBMarketApproverViewModel oRBMarketApprover);

        void UpdateORBSalesLeadUserRoleMapping(ORBSalesLeadApproverViewModel oRBSalesLeadApprover);

        RevenueCostViewModel GetOpportunityACV(int oppId);

    }
}
