﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;
    using OMF.Data.Models;

    public interface IOpportunityCreditAssessmentService
    {       
        void SaveCreditAssessment(OpportunityCreditAssessmentViewModel creditAssessmentDetails);

        OpportunityCreditAssessmentViewModel GetCreditAssessmentDetails(int opprtunityId);

        //void BeginCreditCheckWorkflows(WorkFlowActionViewModel wfModel, Opportunity opportunity, int ccApproversCount);

        IEnumerable<WorkflowJourneyViewModel> GetDefaultCCJourneyForOpportunity(int opportunityId, int approvers);

        List<ORBApproverViewModel> GetApprovers(int opportunityId,int approvers);

        IEnumerable<StatusActionViewModel> GetCCWorkFlowActionsByStatus(WorkFlowActionsViewModel workFlowActionsViewModel);
        IEnumerable<WorkflowJourneyViewModel> GetCCWorkFlowJourneyForOpportunity(int oppId);
        ORBWorkFlowStatusViewModel UpdateCCNextStatus(WorkFlowActionViewModel workFlowViewModel);

        WorkflowJourneyViewModel GetCreditCheckCurrentStatus (int opportunityId);

        WorkFlow CheckWorkFlowAutoProgressPossibility(int opportunityId);

         bool CheckCCApprovalRequired(int opportunityId);
    }
}
