﻿namespace OMF.Business.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using OMF.Business.Models;

    public interface IColaService
    {
        ColaViewModel GetCurrentFinancialYearCola();

        void SaveColaValues(IEnumerable<ColaValues> colaValues);
    }
}
