﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ITechAllianceService
    {
        IEnumerable<TechAllianceViewModel> GetTechAlliance();

        IEnumerable<TechAllianceViewModel> GetActiveTechnologies();

        TechAllianceViewModel GetTechAllianceById(int id);

        void AddTechAlliance(TechAllianceViewModel model);

        void UpdateTechAlliance(TechAllianceViewModel model);
    }
}