﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ITaxRateService
    {
        IEnumerable<TaxRateViewModel> GetTaxRates();

        IEnumerable<TaxRateViewModel> GetActiveTaxRates();

        TaxRateViewModel GetTaxRateById(int id);

        void AddTaxRate(TaxRateViewModel model);

        void UpdateTaxRate(TaxRateViewModel model);
    }
}
