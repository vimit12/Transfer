﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IProjectOrganizationService
    {
        IEnumerable<ProjectOrganizationViewModel> GetAllProjectOrganizations();

        ProjectOrganizationViewModel GetProjectOrganizationById(int id);

        void AddProjectOrganization(ProjectOrganizationViewModel model);

        void UpdateProjectOrganization(ProjectOrganizationViewModel model);

        IEnumerable<ProjectOrganizationViewModel> GetActiveProjectOrganizations();

        IEnumerable<ProjectOrganizationDetailsViewModel> GetProjectOrganizationDetails(int opportunityId);

        ValidateDataViewModel ValidateReportingPracticeAndCOPByOppId(int opportunityId);
    }
}
