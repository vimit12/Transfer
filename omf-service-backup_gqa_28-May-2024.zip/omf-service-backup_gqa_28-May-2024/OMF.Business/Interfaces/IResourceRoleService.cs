﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IResourceRoleService
    {
        IEnumerable<ResourceRoleViewModel> GetResourceRole();

        ResourceRoleViewModel GetResourceRoleById(int id);

        IEnumerable<ResourceRoleViewModel> GetActiveResourceRole();

        void AddResourceRole(ResourceRoleViewModel model);

        void UpdateResourceRole(ResourceRoleViewModel model);
    }
}