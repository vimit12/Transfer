﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IDeliveryModelService
    {
        IEnumerable<DeliveryModelViewModel> GetAllDeliveryModels();

        IEnumerable<DeliveryModelViewModel> GetActiveDeliveryModels();

        DeliveryModelViewModel GetDeliveryModelById(int id);

        void AddDeliveryModel(DeliveryModelViewModel model);

        void UpdateDeliveryModel(DeliveryModelViewModel model);
    }
}
