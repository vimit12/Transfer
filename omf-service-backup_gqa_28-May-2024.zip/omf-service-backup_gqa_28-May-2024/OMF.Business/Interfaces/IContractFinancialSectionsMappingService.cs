﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IContractFinancialSectionsMappingService
    {
        IEnumerable<IncludeSectionByContractTypeViewModel> GetAllContractFinancialSections();

        void AddContractFinancialSection(IncludeSectionByContractTypeViewModel model);
    }
}