﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IIndustrySubSegmentService
    {
        IEnumerable<IndustrySubSegmentViewModel> GetAllIndustrySubSegments();

        void AddIndustrySubSegment(IndustrySubSegmentViewModel model);

        IndustrySubSegmentViewModel GetIndustrySubSegmentById(int id);

        void UpdateIndustrySubSegment(IndustrySubSegmentViewModel model);

        IEnumerable<IndustrySubSegmentViewModel> GetActiveIndustrySubSegments();
    }
}
