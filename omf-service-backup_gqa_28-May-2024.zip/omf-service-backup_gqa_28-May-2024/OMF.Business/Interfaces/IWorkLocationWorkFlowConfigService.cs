﻿using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Interfaces
{
    public interface IWorkLocationWorkFlowConfigService
    {
        IEnumerable<WorkLocationWorkFlowConfigViewModel> GetAllWorkLocationWorkFlows();

        void AddWorkLocationWorkFlow(WorkLocationWorkFlowConfigViewModel workLocationWorkFlowConfigViewModel);

        void UpdateWorkLocationWorkFlow(WorkLocationWorkFlowConfigViewModel workFlowConfigViewModel);

    }
}
