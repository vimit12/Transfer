﻿namespace OMF.Business.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using OMF.Business.Models;

    public interface IDPAUploadStatusService
    {
        IEnumerable<DPAUploadStatusViewModel> GetActiveDPAUploadStatuses();
    }
}
