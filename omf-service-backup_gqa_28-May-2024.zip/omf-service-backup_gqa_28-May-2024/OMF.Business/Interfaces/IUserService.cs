﻿namespace OMF.Business.Interfaces
{
    using OMF.Business.Common;

    public interface IUserService
    {
        UserViewModel GetUserDetails();
    }
}
