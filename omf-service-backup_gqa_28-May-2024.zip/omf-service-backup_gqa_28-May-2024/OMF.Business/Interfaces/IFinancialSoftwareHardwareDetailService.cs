﻿namespace OMF.Business.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using OMF.Business.Models;
    using OMF.Data.Models;

    public interface IFinancialSoftwareHardwareDetailService
    {
        IQueryable<FinancialSoftwareHardwareDetailViewModel> GetFSHD(int opportunityId, int yearId);

        IQueryable<FinancialSoftwareHardwareDetailViewModel> GetFSHDByOpportunityId(int opportunityId, int yearId);

        IQueryable<FinancialSoftwareHardwareDetailViewModel> GetFinancialSoftwareHardwareDetailsById(int financialSoftwareHardwareDetailId);

        void UpdateFSHD(IEnumerable<FinancialSoftwareHardwareDetailViewModel> softwarehardWare);

        byte[] ExtractSoftwareHardwareDetailsTemplate(int opportunityId, out string fileName);

        byte[] UploadSoftwareHardwareDetails(EmployeeFileUploadDetailsViewModel fileUploadDetails, out string messages, out string fileName);
    }
}
