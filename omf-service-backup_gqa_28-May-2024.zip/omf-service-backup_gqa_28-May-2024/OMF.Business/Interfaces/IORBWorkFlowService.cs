﻿using OMF.Business.Models;
using OMF.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OMF.Business.Interfaces
{
    public interface IORBWorkFlowService
    {
        void SaveORBWorkFlows(ORBWorkFlowViewModel model);

        IEnumerable<ORBWorkFlowViewModel> GetORBWorkFlows();

        void UpdateORBWorkFlow(ORBWorkFlowViewModel workFlowViewModel);

        void BeginORBWorkFlows(WorkFlowActionViewModel wfModel, Opportunity opportunity);

        void BeginORBWorkFlowsForCategoryTwo(WorkFlowActionViewModel wfModel, Opportunity opportunity);

        void AdditionalApproverWorkFlow(WorkFlowActionViewModel wfModel);

        Task<ORBWorkFlowStatusViewModel> UpdateORBNextStatus(WorkFlowActionViewModel workFlowViewModel);

        IEnumerable<StatusActionViewModel> GetORBWorkFlowActions(WorkFlowActionsViewModel workFlowViewModel);

        List<ORBApproverViewModel> GetORBApprovers(int opportunityId);
    }
}
