﻿using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Interfaces
{
    public interface IWorkLocationWorkFlowService
    {
        IEnumerable<WorkLocationStatusActionViewModel> GetWorkLocationWorkFlowActionsByStatus(WorkFlowActionsViewModel workFlowActionsViewModel);

        IEnumerable<OpportunityWorkLocationWorkfFlowBasicDetailsViewModel> UpdateNextWorkLocationStatus(WorkLocationWorkFlowActionViewModel workFlowActionViewModel);

        void EndChildWorkFlows(WorkLocationWorkFlowActionViewModel workFlowActionViewModel);

    }
}
