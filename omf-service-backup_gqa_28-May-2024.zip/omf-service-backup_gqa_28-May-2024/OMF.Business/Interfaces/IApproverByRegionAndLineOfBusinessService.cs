﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IApproverByRegionAndLineOfBusinessService
    {
        IEnumerable<ApproverByRegionAndLineOfBusinessViewModel> GetApproversByRegion();

        void AddApproverByRegion(ApproverByRegionAndLineOfBusinessViewModel model);

        void UpdateApproverByRegion(ApproverByRegionAndLineOfBusinessViewModel model);
    }
}
