﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ICountryService
    {
        IEnumerable<CountryViewModel> GetCountries();

        IEnumerable<CountryViewModel> GetActiveCountries();

        CountryViewModel GetCountryById(int id);

        void AddCountry(CountryViewModel model);

        void UpdateCountry(CountryViewModel model);
    }
}