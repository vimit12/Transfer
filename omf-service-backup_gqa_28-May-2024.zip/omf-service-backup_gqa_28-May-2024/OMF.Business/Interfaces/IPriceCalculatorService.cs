﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IPriceCalculatorService
    {
        byte[] GetMarginViewPriceSimulationExcel(PriceCalculatorViewModel priceCalculatorView);

        PriceMatrixCalculatorViewModel GetMarginViewPriceSimulation(PriceCalculatorViewModel priceCalculatorView);

        byte[] GetLeverageViewPriceSimulationExcel(PriceCalculatorViewModel priceCalculatorView);

        PriceMatrixCalculatorViewModel GetLeverageViewPriceSimulation(PriceCalculatorViewModel priceCalculatorView);
    }
}
