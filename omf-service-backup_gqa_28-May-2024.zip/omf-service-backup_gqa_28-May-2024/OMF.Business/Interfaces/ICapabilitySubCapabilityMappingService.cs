﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface ICapabilitySubCapabilityMappingService
    {
        IEnumerable<CapabilitySubCapabilityMappingViewModel> GetAllCapabilitySubCapabilities();

        void AddCapabilitySubCapability(CapabilitySubCapabilityMappingViewModel model);
    }
}