﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IPCReferbackOnHoldReasonService
    {
        IEnumerable<PCReferBackOnHoldReasonViewModel> GetAllPCReferBackOnHoldReason();

        IEnumerable<PCReferBackOnHoldReasonViewModel> GetActivePCReferBackOnHoldReason();

        PCReferBackOnHoldReasonViewModel GetPCReferBackOnHoldReasonById(int id);

        void AddPCReferBackOnHoldReason(PCReferBackOnHoldReasonViewModel model);

        void UpdatePCReferBackOnHoldReason(PCReferBackOnHoldReasonViewModel model);

        void AddPCReferBackOnHoldReasonByOpportunity(PCReferBackOnHoldReasonByOpportunityViewModel model);

        List<PCReferBackOnHoldReasonByOpportunityViewModel> GetPCReferBackOnHoldReasonByOpportunityId(int id);
    }
}