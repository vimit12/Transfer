﻿namespace OMF.Business.Interfaces
{
    using System.Collections.Generic;
    using OMF.Business.Models;

    public interface IUserRoleService
    {
        IEnumerable<UserRoleViewModel> GetUserRoles();

        void AddUserRole(UserRoleViewModel model);

        void UpdateUserRole(UserRoleViewModel model);

        UserRoleViewModel GetUserRoleByUserId(string userId);

        UserRoleViewModel GetUserRoleById(int userRoleId);

        IEnumerable<UserRoleViewModel> GetUserRolesForApproval();

        IEnumerable<UserRoleViewModel> GetOICUsers();

        IEnumerable<UserRoleViewModel> GetComplianceUserList();

        IEnumerable<dynamic> GetUserRolesDetails();

        IEnumerable<UserSearchViewModel> GetUserSearch(string name);

        IEnumerable<UserRoleViewModel> GetIFRSUserList();
    }
}
