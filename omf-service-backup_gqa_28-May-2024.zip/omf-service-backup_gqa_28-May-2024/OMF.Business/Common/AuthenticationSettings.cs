﻿namespace OMF.Business.Common
{
    public class AuthenticationSettings
    {
        public string CheckTokenUrl { get; set; }

        public string CheckTokenRelativeUrl { get; set; }

        public string CheckTokenAppId { get; set; }

        public string CheckTokenAppSecret { get; set; }

        public string ConnectionString { get; set; }

        public string AuthenticationUrl { get; set; }

        public string AuthenticationRelativeUrl { get; set; }
    }
}
