﻿namespace OMF.Business.Common
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public static class Year
    {
        public static int GetFinacialyear()
        {
            var today = DateTime.Today;
            var currentFyear = today.Year;
            var fyearStarts = Convert.ToDateTime(currentFyear + "-" + Constants.Year.FYearStarts);
            if (fyearStarts > today)
            {
                currentFyear = currentFyear - 1;
            }

            return currentFyear;
        }

        public static DateTime CurrentFYstarts()
        {
            return Convert.ToDateTime(GetFinacialyear() + Constants.Year.FYearStarts);
        }

        public static DateTime CurrentFYEnds()
        {
            return Convert.ToDateTime((GetFinacialyear() + 1) + Constants.Year.FYearEnds);
        }

        public static int GetFYByDate(DateTime date)
        {
            var fYear = date.Year;
            var fyearStarts = Convert.ToDateTime(fYear + "-" + Constants.Year.FYearStarts);
            if (fyearStarts > date)
            {
                fYear = fYear - 1;
            }

            return fYear;
        }

        public static DateTime CompareDates(DateTime? createdDate, DateTime? updatedDate)
        {
          return Convert.ToDateTime(createdDate > (updatedDate == null ? default(DateTime) : updatedDate) ? createdDate : updatedDate);
        }
    }
}
