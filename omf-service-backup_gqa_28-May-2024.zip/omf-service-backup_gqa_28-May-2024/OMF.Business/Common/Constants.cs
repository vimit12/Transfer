﻿namespace OMF.Business.Common
{
    public static class Constants
    {
        // Common Message for Error Logging
        public const string PageErrorMessage = "Oops ..Something went wrong !";
        public const string NotificationSent = "Notification sent";
        public const string NotApplicable = "Not Applicable";
        public const string Zero = "0";

        public enum Screen
        {
            Fx = 1,
            Cola = 2
        }

        public static class ScreenActionsByRole
        {
            public const string DuplicateRoleScreenValidation = "Combination of Role and Screen already exits";
        }

        public static class Year
        {
            public const string GTOET = "GTOET";

            public const string LTOET = "LTOET";

            public const string Asc = "Asc";

            public const string Desc = "Desc";

            public const string FYearStarts = "Apr-1";

            public const string FYearEnds = "Mar-31";
        }

        public static class SmtpMailDetails
        {
            public const string Host = "mail.hitachivantara.com";
            public const string SmtpMail = "omf-smtp@hitachivantara.com";
            public const string SmtpPassword = "9c1Lxmicek@58";
        }

        public static class RecipientType
        {
            public const string To = "TO";
            public const string From = "FROM";
            public const string CC = "CC";
            public const string Primary = "Primary";
            public const string Secondary = "Secondary";
        }

        public static class PlaceHolders
        {
            public const string ECFTeam = "ECFTEAM";
            public const string PM = "PM";
            public const string OIC = "OIC";
            public const string UserComments = "USERCOMMENTS";
            public const string UserName = "USERNAME";
            public const string OpportunityName = "OPPORTUNITYNAME";
            public const string SimulationUrl = "SIMULATIONURL";
            public const string LoginUser = "LOGINUSER";
            public const string ORBApprover = "ORBAPPROVER";
            public const string ProjectSetupTeam = "PROJECTSETUPTEAM";
            public const string BaseCurrency = "BASECURRENCY";
            public const string CrmId = "CRMID";
            public const string ProjectStartDate = "PROJECTSTARTDATE";
            public const string ProjectCountry = "PROJECTCOUNTRY";
            public const string ProjectCode = "PROJECTCODE";
            public const string ProjectName = "PROJECTNAME";
            public const string Region = "REGION";
            public const string SetupType = "SETUPTYPE";
            public const string ReportingPractice = "REPORTINGPRACTICE";
            public const string ProjectContractingOrganizations = "PROJECTCONTRACTINGORGANIZATIONS";
            public const string ProjectEndDate = "PROJECTENDDATE";
            public const string CustomerName = "CUSTOMERNAME";
            public const string IndustrySubVertical = "INDUSTRYSUBVERTICAL";
            public const string ContractType = "CONTRACTTYPE";
            public const string PGMPercent = "PGMPERCENT";
            public const string ORBCategory = "ORBCATEGORY";
            public const string OrbCategoryApprover = "ORBCATEGORYAPPROVER";
            public const string RevenueWithOutBilliableExp = "REVENUEWITHOUTBILLIABLEEXP";
            public const string RevenueWithOutBilliableExpUSD = "REVENUEWITHOUTBILLIABLEEXPUSD";
            public const string OpportunityId = "OPPORTUNITYID";
            public const string OnshoreHitachiRevenue = "ONSHOREHITACHIREVENUE";
            public const string OnshoreITPESRevenue = "ONSHOREITPESREVENUE";
            public const string OnshoreTotalRevenue = "ONSHORETOTALREVENUE";
            public const string OffshoreIDCRevenue = "OFFSHOREIDCREVENUE";
            public const string OffshoreVDCRevenue = "OFFSHOREVDCREVENUE";
            public const string OffShoreTotalRevenue = "OFFSHORETOTALREVENUE";
            public const string ContTotalRevenue = "CONTTOTALREVENUE";
            public const string MgdServicesRevenue = "MGDSERVICESREVENUE";
            public const string StaffAugRevenue = "STAFFAUGREVENUE";
            public const string RebateValue = "REBATEVALUE";
            public const string TotalSrvRevenueAfterRebate = "TOTALSERVICESREVENUEAFTERRABATE";
            public const string PassThruRevenue = "PASSTHRUREVENUE";
            public const string OnshoreHitachiRevenueUSD = "ONSHOREHITACHIREVENUEUSD";
            public const string OnshoreITPESRevenueUSD = "ONSHOREITPESREVENUEUSD";
            public const string OnshoreTotalRevenueUSD = "ONSHORETOTALREVENUEUSD";
            public const string OffshoreIDCRevenueUSD = "OFFSHOREIDCREVENUEUSD";
            public const string OffshoreVDCRevenueUSD = "OFFSHOREVDCREVENUEUSD";
            public const string OffShoreTotalRevenueUSD = "OFFSHORETOTALREVENUEUSD";
            public const string ContTotalRevenueUSD = "CONTTOTALREVENUEUSD";
            public const string MgdServicesRevenueUSD = "MGDSERVICESREVENUEUSD";
            public const string StaffAugRevenueUSD = "STAFFAUGREVENUEUSD";
            public const string RebateVaueUSD = "REBATEVALUEUSD";
            public const string TotalSrvRevenueAfterRebateUSD = "TOTALSERVICESREVENUEAFTERRABATEUSD";
            public const string PassThruRevenueUSD = "PASSTHRUREVENUEUSD";
            public const string PassThruPgmPer = "PASSTHRUPGMPER";
            public const string OnshoreHitachiPgmPer = "ONSHOREHITACHIPGMPER";
            public const string OnshoreITPESPgmPer = "ONSHOREITPESPGMPER";
            public const string OnshoreTotalPgmPer = "ONSHORETOTALPGMPER";
            public const string OffshoreIDCPgmPer = "OFFSHOREIDCPGMPER";
            public const string OffshoreVDCPgmPer = "OFFSHOREVDCPGMPER";
            public const string OffShoreTotalPgmPer = "OFFSHORETOTALPGMPER";
            public const string ContTotalPgmPer = "CONTTOTALPGMPER";
            public const string MgdServicesPgmPer = "MGDSERVICESPGMPER";
            public const string StaffAugPgmPer = "STAFFAUGPGMPER";
            public const string TotalServicesPgmAfterRebate = "TOTALSERVICESPGMAFTERREBATE";
            public const string ApproverName = "APPROVER";
            public const string TopIndustry = "TOPINDUSTRY";
            public const string SubIndustry = "SUBINDUSTRY";
            public const string IVID = "IVID";
            public const string OracleCustomerID = "ORACLECUSTOMERID";
            public const string OracleRegistryID = "ORACLEREGISTRYID";
            public const string ClientAlias = "CLIENTALIAS";
            public const string LOB = "LOB";
            public const string COPorPractice = "COPORPRACTICE";
            public const string COPApprove = "COPAPPROVE";
            public const string LOBApprove = "LOBAPPROVE";
            public const string FinanceApprove = "FINANCEAPPROVE";
            public const string OICApprove = "OICAPPROVE";
            public const string ReferBack = "REFERBACK";
            public const string DeliveryApprove = "DELIVERYAPPROVE";
            public const string MarketsApprove = "MARKETSAPPROVE";
            public const string PracticeLeadApprove = "PRACTICELEADAPPROVE";
            public const string LowMarginApprove = "LOWMARGINAPPROVE";
            public const string OICReferBack = "OICREFERBACK";
            public const string ORBReferBack = "ORBREFERBACK";
            public const string IFRSanalyst = "IFRSANALYST";
            public const string IFRSApprovalType = "IFRSAPPROVALTYPE";
            public const string IFRSApprovalTypeInSubject = "IFRSAPPROVALTYPEINSUBJECT";
            public const string SentToECFDate = "SENTTOECFDATE";
            public const string UserApprovalComments = "USERAPPROVALCOMMENTS";
        }

        public static class FinancialProposal
        {
            public const int WorkHours = 40;
        }

        public static class MailTemplate
        {
            public const string IFRSAssignedTo = "OMF has been assigned for IFRS screening";
        }

        public static class User
        {
            public const string Alias = "Alias";
            public const string UserEmail = "UserEmail";
            public const string FirstName = "FirstName";
            public const string LastName = "LastName";
            public const string UserId = "UserId";
            public const string RoleId = "RoleId";
            public const string Name = "Name";
            public const string EmployeeId = "EmployeeId";
            public const string Email = "Email";
            public const string Location = "Location";
            public const string ManagerName = "ManagerName";
            public const string ManagerMail = "ManagerMail";
            public const string MobileNumber = "MobileNumber";
            public const string EmpLocation = "Location";
            public const string EmpManagerMail = "Manager Email ID";
            public const string EmployeEmail = "Work Email ID";
            public const string ContactNumber = "Mobile Number";
            public const string Country = "Country";
            public const string EmpWorkStation = "Desk Location";
            public const string FRApproverType = "ApproverType";
            public const string FRApprover = "FRApprover";
            public const string FROIC = "OIC";
            public const string FRLOB = "LOB";
            public const string FRQA = "QA";
            public const string FRFinance = "Finance";
        }

        public static class Issues
        {
            // Ok Status
            public const string UpdatedSuccessfully = "Issue Updated";
            public const string DeletedSuccessfully = "Issue Deleted";
            public const string AddedSuccessfully = "Added New Issue";
            public const string IssueActioned = "Actioned Issue";
            public const string IssueUnactioned = "Unactioned Issue";

            // mails
            public const string OMF = "OpportunityManagementSupport@hitachivantara.com";
            public const string OMFSMTP = "omf-smtp@hitachivantara.com";
            public const string Subject = "OMF - New Issue";
            public const string MailBody = "Hi Team,<p>New Issue <strong>@IssueDescription@</strong> raised by <strong>@ReportedBy@</strong>.<br />Priority: <strong>@Priority@</strong><br /><br />Please do the needful.<br /><br />Thank you";

            // placeholders
            public const string IssueDescription = "@IssueDescription@";
            public const string ReportedBy = "@ReportedBy@";
            public const string Priority = "@Priority@";

            //System Messages
            public const string SystemEmailComments = "System send to next status";
            public const string SystemEmailCreatedBy = "System Generated";
        }

        public static class HiQConstants
        {
            public const string ORBApproved = "APPROVED";
            public const string ORBCategory1 = "Category 1";
            public const string ORBCategory2 = "Category 2";
            public const string ORBCategory3 = "Category 3";
            public const string ORBCategory4 = "Category 4";    
        }

        public static class StatusConstants
        {
            public const string SentToProjectCompliance = "Sent To Project Compliance";
            public const string SentToSensitiveCompliance = "Sent To Sensitive Compliance";
            public const string InProgression = "In-Progression";
            public const string InProgressBySensitiveCompliance = "In Progress By Sensitive Compliance";
            public const string OnHold = "On Hold";
            public const string SOWAwaited = "SOW Awaited";
            public const string Completed = "Completed";
        }

        public static class CloudHosting
        {
            // Ok Status
            public const string UpdatedSuccessfully = "Cloud Details Updated";
            public const string DeletedSuccessfully = "Cloud Details Deleted";
            public const string AddedSuccessfully = "Added New Cloud Hosting Details";
        }


        public static class EmailApproval
        {
            public const string Semicolon = ";";
            public const string Comma = ",";
            public const string Approved = "Approved";
            public const string Body = "Add comments by editing the text between the brackets in Comments section and please don't remove brackets.%0D%0A%0D%0AComments: [your comments]%0D%0A%0D%0A-----Do not edit below this line-----%0D%0A%0D%0A";
            public const string COP = "COP";
            public const string LOB = "LOB";
            public const string Finance = "Finance";
        }

        public static class IFRSApprovalType
        {
            public const string ProvisionalApproval = "Provisional Approval - Project to be created in Pending Status";
            public const string FullyApproved = "Fully Approved - Project to be created in Approved Status";
        }

        public static class UserRegEmailsRecipients
        {
            public const string Omfsupport = "omfsupport";
            public const string Omftechteam = "sr_omfapiuser";
        }

    }
}
