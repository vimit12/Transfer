﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Common
{
    public class HiQSettings
    {
        public string Username { get; set; }

        public string Password { get; set; }

        public string PatchUrl { get; set; }

        public string AccountUrl { get; set; }
    }
}
