﻿namespace OMF.Business.Common
{
    public static class Enums
    {
        public enum Quarter
        {
            Quarter1 = 1, Quarter2 = 2, Quarter3 = 3, Quarter4 = 4
        }

        public enum Screen
        {
            FxRate = 1, Cola = 2, RateCard = 3, Financial = 7, ORB = 8
        }

        public enum Currency
        {
            USD = 65
        }

        public enum EmailEntity
        {
            Leagal = 1, Finance = 2, LoggedInUser = 3, PM = 4, OIC = 5, Compliance = 7, EmailId = 0, AccessUsers = 15, IFRSAnalyst = 34, CEP = 40
                , CreditAnalyst = 41, CreditApprover = 42
        }

        public enum RateCardType
        {
            DefaultRateCard = 1, RateCardForCompleteOMF = 2, RateCardByYear = 3
        }

        public enum FinancialProposalSelection
        {
            ProjectStaffingEmployees = 1, ProjectStaffingContractors = 2, SoftwareHardwareDetails = 3, CloudService = 4, ExpenceDetails = 5, CloudHosting = 6, StaffAugmentation = 7, DiscountRibate = 8
        }

        public enum DeliveryModel
        {
            Hitachi = 1, IT_PES = 2, IDC = 3, VDN = 4, ChinaPES = 5, ContractorSubtotal = 6, REAN = 11
        }

        public enum DocumentType
        {
            WorkflowDocument = 3
        }

        public enum StatusType
        {
            New = 14, SentToECFApproval = 16, SentToCompliance = 19, ApprovedByLegalTeam = 15, ReferbackByLegalTeam = 18, ReferBackbyCompliance = 21,
            InProgress = 22, Completed = 23, SentToORB = 24, ApprovedByORB = 26, ReferBackByORB = 25, Lost = 29, SentToWorkLocations = 30, SentToOIC = 32,
            ApprovedByOIC = 34, ApprovedByWorkLocations = 31, SentToLOB = 40, ApprovedByLOB = 41, SentToCOP = 33, ApprovedByCOP = 37, ReferBackByWorkLocations = 42,
            ApprovedByRegionalVP = 43, SentToRegionalVP = 44, SentToEnterpriseVP = 46, ApprovedByEnterpriseVP = 47, SentToSensitiveCompliance = 48,
            InProgressBySensitiveCompliance = 49, ReferBackBySensitiveCompliance = 50, NoSale = 51, ReferBackByOIC = 39, DuplicateVersion = 52, CompleteOnHold = 57,
            SentToDeliveryORB = 58, SentToMarketsORB = 59, ApprovedByDeliveryORB = 60, ApprovedByMarketsORB = 61, ProjectCreationOnKimble = 62, RecalledFromECFApproval = 27,
            SOWAwaited = 63, SentToAdditionalApproversORB = 64, ApprovedByAdditionalApproversORB = 69, SentToPracticeLeadApproversORB = 65, ApprovedByPracticeLeadApproversORB = 70,
            InReview = 71, SentToCustomerCreation = 72, CustomerCreatedInOracle = 73, SentToIFRS = 74, ApprovedByIFRS = 75, ReferBackByIFRS = 76, SentToIFRSReReview = 77,
            ReReviewedByIFRS = 78, ReferBackByIFRSAtReReview = 79, ReferBackToIFRS = 80, ReSentToProjectCompliance = 81, ReferBackToProjectCompliance = 82, ReferBackToSensitiveCompliance = 83,
            IFRSInReview = 84, OnHoldByIFRS = 85, SentToOICForFRApproval = 86, ApprovedByOICForFR = 87, SentToLOBForFRApproval = 88, ApprovedByLOBForFR = 89,
            SentToQAForFRApproval = 90, ApprovedByQAForFR = 91, SentToFinancialForFRApproval = 92, ApprovedByFinancialForFR = 93 , NewFundingReduction = 94,
            FundingReductionCompleted = 95, SentToComplianceforFRApproval = 96 , SentToCreditCheckReview = 97, InProgressReviewbyCreditAnalyst = 98,
            SentToCreditCheckApproval = 99, ApprovedByApprover1 = 100, ApprovedByApprover2 = 101
            , ReferbackbyApprover1 = 102, ReferbackbyApprover2 = 103, ApprovedByCreditCheck = 104, CreditCheckRejected = 105,
        }

        public enum EmployeeType
        {
            Regular = 1, Contractor = 2
        }

        public enum RoleType
        {
            SuperAdmin = 15,
            Admin = 16,
            PM = 17,
            Compliance = 18,
            SE = 19,
            OAM = 20,
            SLM = 21,
            OIC = 22,
            ECF = 23,
            ORB = 25,
            CRM = 26,
            Billing = 27,
            Scheduling = 28,
            TaxAndMobility = 29,
            LOB = 30,
            COP = 31,
            RegionalVP = 33,
            EnterpriseVP = 32,
            SensitiveCompliance = 34,
            GDPR = 35,
            Leadership = 36,
            Audit = 40,
            IFRS = 43,
            DeliveryExcellence = 41,
            FinanceExecutive = 24,
            CCAnalyst = 46,
            CCApprover = 47,
        }

        public enum Regions
        {
            APAC = 33,
            Americas = 35,
            EMEA = 36
        }

        public enum ApproverType
        {
            ECF = 25,
            ORB = 29,
            COP = 24,
            LOB = 28,
            Billing = 39,
            Leadership = 50,
            System = 55,
            SalesLead = 54,
            DeliveryApprover = 53,
            PracticeLeadApprover = 60,
            SubPracticeLead = 61,
            VerticalLead = 62,
            SubVerticalLead = 63,
            MarketsApprover = 64,
            AdditionalApprover = 65,
            CRMAudit = 66,
            ProjectComplianceAudit = 67,
            SensitiveCompliancAudit = 68,
            ECFGTCAudit = 69,
            IFRS = 72,
            IFRSAudit = 73,
            FRLOBApprover = 79,
            FRQAApprover = 80,
            FRFinanceApprover = 81,
            CreditcheckApprover1 = 82,
            CreditcheckApprover2 = 83,
        }

        public enum CRType
        {
            LessThan200K = 0,//CO/CR - Add to existing Project
            GreaterThanorEqualTo200K = 1,//CO/CR - Create New Project in Oracle
            Version = 2,
            COCRForCrossChargeProject = 3//CO/CR for Cross Charge Project
        }

        public enum StatusAction
        {
            SendToCompliance = 18,
            Lost = 29,
            SentToOrb = 22,
            SentToECF = 14,
            ReferBackByECF = 15,
            ECFTeamApproval = 12,
            SendToSensitiveCompliance = 32,
            ApprovedByOrb = 24,
            ORBReferBack = 23,
            SystemAction = 26,
            OICReferBack = 31,
            DeliveryApproval = 47,
            MarketsApproval = 48,
            PracticeLeaderApproval = 52,
            AdditionalMarginsApproval = 51,
            LOBApproval = 33,
            COPApproval = 30,
            ApprovedByFinance = 38,
            SentToIFRS = 58,
            ReferBackToIFRS = 67,
            SendToIFRSReReview = 64,
            Complete = 13,
            SendToOICForFR = 74,
            OICApprovalForFR = 75,
            SendToLOBForFR = 84,
            LOBApprovalForFR = 85,
            SendToQAForFR = 86,
            QAApprovalForFR = 87,
            SendToFinanceForFR = 88,
            FinanceApprovalForFR = 89,
            FundingReductionCompleted = 90,          
            SentToComplianceforFRApproval = 91,
            SendToCCA = 84,
            SendToCCR = 85,
            CCReferBack = 86,
            CCApproval = 87,
            CCConditionalApproval = 88,
            CCReject = 89

        }

        public enum OmfFinancialSections
        {
            Employees = 1,
            Contractors = 2,
            SwHwOthers = 3,
            ManagedServices = 4,
            ExpenseDetails = 5,
            CloudConsumptionAndHosting = 6,
            StaffAugmentation = 7,
            DiscountAndRebate = 8
        }

        public enum OMFConstants
        {
            TinyURL,
            ClientUploadDocsPath,
            EmailServiceURL,
            DefaultFromAddress
        }

        public enum ProjectSetupType
        {
            New = 0,
            CR = 1,
            CRCreateNewProject = 2,
            ClientLiquidation = 3,
            KimbleProject = 4,
            CrossCharge = 5,
            NewProjectHVandHCC = 6,
            NewProjectHVOnly = 7,
            COCRForCrossChargeProject = 8
        }

        public enum HiQOpportunityType
        {
            NA = 0,
            NetNewClient = 1,
            NewProject = 2,
            ChangeOrder = 3,
            Renewal = 4
        }

        public enum HttpMethods
        {
            Patch = 1,
            Get = 2
        }

        public enum HiQHelpers
        {
            Open = 1,
            No_Sale = 2,
            Lost = 3
        }

        public enum SoftwareHardwareTypes
        {
            Software = 1,
            Hardware = 2,
            Others = 3
        }

        public enum CloudHostingCategory
        {
            Hosting = 1,
            Tools = 2,
            Others = 3
        }

        public enum BillingMethod
        {
            Event_Event = 1,
            Work_Work = 2,
            Work_Event = 3
        }

        public enum ContractorType
        {
            GlobalLogic = 1,
            Other3rdParty = 2
        }

        public enum ContractType
        {
            TimeAndMaterialsCapOnTimeOnly = 4,
            TimeAndMaterialsCapOnTAndE = 5,
            TimeAndMaterials = 6,
            FixedFeeTimeOnly = 8,
            FixedFeeTimeAndExpense = 9,
        }

        public enum FundingReductionStage
        {
            AllStages = 0,
            LOBStage = 1,
            FinancialStage = 2,
            FundingReductionCompleted = 3,
            ComplianceFRStage = 4,
        }
        public enum RequestStatus
        {
            Requested = 0,
            Completed = 1
        }
    }
}
