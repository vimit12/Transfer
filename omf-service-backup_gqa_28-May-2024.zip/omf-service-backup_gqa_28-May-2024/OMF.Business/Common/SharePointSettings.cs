﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMF.Business.Common
{
    public class SharePointSettings
    {
        public string ClientId { get; set; }

        public string ClientSecret { get; set; }

        public string ResourceValue { get; set; }

        public string TenantId { get; set; }

        public string PostURL { get; set; }

        public string GetURL { get; set; }

        public string WebURL { get; set; }

        public string DeleteURL { get; set; }

        public string CreateFolderURL { get; set; }

        public string ServerRelativeUrl { get; set; }
    }
}
