﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class ContractFinancialSectionsMappingService : IContractFinancialSectionsMappingService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public ContractFinancialSectionsMappingService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<IncludeSectionByContractTypeViewModel> GetAllContractFinancialSections()
        {
            var contractList = uow.Repository<ContractType>().GetAll(x => x.IsActive);
            List<IncludeSectionByContractTypeViewModel> includeSectionByContractType = new List<IncludeSectionByContractTypeViewModel>();
            int sectionId = 0;
            foreach (var contract in contractList)
            {

                var subSectionsList = from mappings in uow.Repository<IncludeSectionByContractType>().GetAll()
                                      join contractTypes in uow.Repository<ContractType>().GetAll() on mappings.ContractTypeId equals contractTypes.ContractTypeId
                                      join sectionTypes in uow.Repository<OmfFinancialSections>().GetAll() on mappings.SectionId equals sectionTypes.SectionId
                                      where contractTypes.ContractTypeId == contract.ContractTypeId
                                      select new OmfFinancialSectionsViewModel
                                      {
                                          SectionId = sectionTypes.SectionId,
                                          SectionName = sectionTypes.SectionName,
                                          CreatedBy = mappings.CreatedBy,
                                          CreatedDate = mappings.CreatedDate
                                      };

                if (subSectionsList.Any())
                {
                    includeSectionByContractType.Add(new IncludeSectionByContractTypeViewModel
                    {
                        IncludeSectionByContractTypeId = ++sectionId,
                        ContractTypeId = contract.ContractTypeId,
                        ContractName = contract.ContractTypeName,
                        CreatedBy = subSectionsList.First().CreatedBy,
                        CreatedDate = subSectionsList.First().CreatedDate,
                        SectionNames = string.Join((char)44 + " ", subSectionsList.Select(x => x.SectionName))

                    });
                }
            }

            if (includeSectionByContractType != null)
            {
                includeSectionByContractType = includeSectionByContractType.OrderByDescending(x => x.CreatedDate).ToList();
            }

            return includeSectionByContractType;
        }

        public void AddContractFinancialSection(IncludeSectionByContractTypeViewModel model)
        {
            if (model != null)
            {
                uow.Repository<IncludeSectionByContractType>().DeleteRange(uow.Repository<IncludeSectionByContractType>().GetAll(item => item.ContractTypeId == model.ContractTypeId));

                foreach (var subSection in model.Sections)
                {
                    var includeSectionByContractTypeMapping = new IncludeSectionByContractType
                    {
                        ContractTypeId = model.ContractTypeId,
                        SectionId = subSection.SectionId,
                        CreatedBy = model.CreatedBy,
                        IsActive = true,
                        CreatedDate = DateTime.Now
                    };
                    uow.Repository<IncludeSectionByContractType>().Add(includeSectionByContractTypeMapping);
                }

                uow.SaveChanges();
            }
        }
    }
}
