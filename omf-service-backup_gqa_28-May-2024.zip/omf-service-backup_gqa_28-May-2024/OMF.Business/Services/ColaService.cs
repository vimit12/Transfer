﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Claims;
    using System.Text;
    using AutoMapper;
    using Microsoft.AspNetCore.Http;
    using Microsoft.EntityFrameworkCore.Internal;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class ColaService : IColaService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;
        private readonly IHttpContextAccessor httpContextAccessor;

        public ColaService(IUow uow, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            this.uow = uow;
            this.mapper = mapper;
            this.httpContextAccessor = httpContextAccessor;
        }

        public ColaViewModel GetCurrentFinancialYearCola()
        {
            AddMissingLocations();

            ColaViewModel colaViewModel = new ColaViewModel();
            var colas = (from cola in uow.Repository<Cola>().GetAll()
                              join caYear in uow.Repository<CAYear>().GetAll() on cola.YearId equals caYear.YearId
                              join workLocation in uow.Repository<WorkLocation>().GetAll() on cola.WorkLocationId equals workLocation.WorkLocationId
                              where workLocation.IsActive == true
                              select new { YearId = caYear.YearId, Year = caYear.Year, WorkLocationId = workLocation.WorkLocationId, WorkLocation = workLocation.WorkLocationName, ColaPercentage = cola.ColaPercentage }).ToList();

            var worklocations = colas.GroupBy(x => x.WorkLocationId);
            List<ColaValues> listcolaValues = new List<ColaValues>();
            ColaValues colaValue;
            var currentFyear = Year.GetFinacialyear();
            foreach (var location in worklocations)
            {
                colaValue = new ColaValues();
                colaValue.WorkLocationId = location.Select(loc => loc.WorkLocationId).FirstOrDefault();
                colaValue.WorkLocation = location.Select(loc => loc.WorkLocation).FirstOrDefault();

               // colaValue.ColaId = location.Where(loc => loc.Year == currentFyear).Select(loc => loc.ColaId).FirstOrDefault();
                colaValue.CurrentFYPercentage = location.Where(loc => loc.Year == currentFyear).Select(loc => loc.ColaPercentage).FirstOrDefault();
                colaValue.PreviousFYPercentage1 = location.Where(loc => loc.Year == (currentFyear - 1)).Select(loc => loc.ColaPercentage).FirstOrDefault();
                colaValue.PreviousFYPercentage2 = location.Where(loc => loc.Year == (currentFyear - 2)).Select(loc => loc.ColaPercentage).FirstOrDefault();
                colaValue.PreviousFYPercentage3 = location.Where(loc => loc.Year == (currentFyear - 3)).Select(loc => loc.ColaPercentage).FirstOrDefault();
                listcolaValues.Add(colaValue);
            }

            var comments = uow.Repository<CommentSummary>().GetAll().Where(x => x.ScreenId == (int)Enums.Screen.Cola && (x.CreatedDate > Year.CurrentFYstarts() && x.CreatedDate < Year.CurrentFYEnds())).OrderByDescending(y => y.CreatedDate);

            colaViewModel.ColaValues = listcolaValues.OrderBy(x => x.WorkLocation).ToList();
            colaViewModel.Comments = mapper.Map<IEnumerable<CommentSummary>, IEnumerable<Comments>>(comments);
            return colaViewModel;
        }

        public void SaveColaValues(IEnumerable<ColaValues> colaValues)
        {
            bool isIterated = false;
            foreach (ColaValues currentYearcola in colaValues)
            {
                var currentFyear = Year.GetFinacialyear();
                var currentFyearId = uow.Repository<CAYear>().GetAll().Where(caYear => caYear.Year == Year.GetFinacialyear()).Select(x => x.YearId).FirstOrDefault();
                var cola = uow.Repository<Cola>().GetAll().Where(colaFYear => (colaFYear.WorkLocationId == currentYearcola.WorkLocationId && colaFYear.YearId == currentFyearId)).FirstOrDefault();
                cola.ColaPercentage = currentYearcola.CurrentFYPercentage;
                cola.UpdatedBy = string.Empty;
                cola.UpdatedDate = DateTime.Now;
                uow.Repository<Cola>().Update(cola);
                if (!isIterated)
                {
                    CommentSummary commentSummary = new CommentSummary();
                    commentSummary.Comment = currentYearcola.UserComment;
                    commentSummary.ScreenId = (int)Enums.Screen.Cola;
                    commentSummary.Year = DateTime.Now.Year;
                    commentSummary.IsActive = true;
                    commentSummary.CreatedDate = DateTime.Now;
                    commentSummary.CreatedBy = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.Role).Value;
                    uow.Repository<CommentSummary>().Add(commentSummary);
                    isIterated = true;
                }

                uow.SaveChanges();
            }
        }

        public void AddMissingLocations()
        {
            var currentFyear = Year.GetFinacialyear();
            var currentFYId = uow.Repository<CAYear>().GetAll(year => year.Year == currentFyear).FirstOrDefault().YearId;
            var missedLocatons = uow.Repository<WorkLocation>().GetAll().Select(x => x.WorkLocationId)
                                 .Except(uow.Repository<Cola>().GetAll(cola => cola.YearId == currentFYId).Select(y => y.WorkLocationId));

            foreach (var loc in missedLocatons)
            {
                var cola = new Cola
                {
                    YearId = currentFYId,
                    WorkLocationId = loc,
                    ColaPercentage = 0,
                    CreatedBy = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.Role).Value,
                    CreatedDate = DateTime.Now
                };

                uow.Repository<Cola>().Add(cola);
            }

            uow.SaveChanges();
        }
    }
}
