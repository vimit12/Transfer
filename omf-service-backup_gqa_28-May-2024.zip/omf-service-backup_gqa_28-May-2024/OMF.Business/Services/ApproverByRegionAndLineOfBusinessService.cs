﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class ApproverByRegionAndLineOfBusinessService : IApproverByRegionAndLineOfBusinessService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public ApproverByRegionAndLineOfBusinessService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<ApproverByRegionAndLineOfBusinessViewModel> GetApproversByRegion()
        {
            var approversByRegion = uow.Repository<ApproverByRegionAndLineOfBusiness>().GetAll(aByR => aByR.ApproverType.IsActive, "ApproverType").OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));

            List<ApproverByRegionAndLineOfBusinessViewModel> approversByRegionVMList = new List<ApproverByRegionAndLineOfBusinessViewModel>();

            foreach (var approver in approversByRegion)
            {
                var approverMapping = from approverMappings in uow.Repository<ApproverByRegionAndLineOfBusinessMapping>().GetAll()
                                      join approverByRegion in uow.Repository<ApproverByRegionAndLineOfBusiness>().GetAll() on approverMappings.ApproverByRegionAndLineOfBusinessId equals approverByRegion.ApproverByRegionAndLineOfBusinessId
                                      join userRole in uow.Repository<UserRole>().GetAll() on approverMappings.UserRoleId equals userRole.UserRoleId
                                      where approverByRegion.ApproverByRegionAndLineOfBusinessId == approver.ApproverByRegionAndLineOfBusinessId
                                      select new
                                      {
                                          approverByRegionId = approverByRegion.ApproverByRegionAndLineOfBusinessId,
                                          approverTypeId = approver.ApproverTypeId,
                                          name = userRole.FirstName + " " + userRole.LastName + " - " + userRole.UserId,
                                          isActive = userRole.IsActive
                                      };

                if (approverMapping.Any())
                {
                    var regionDetails = (from approverByRegion in uow.Repository<ApproverByRegionAndLineOfBusiness>().GetAll()
                                         join region in uow.Repository<Region>().GetAll() on approverByRegion.RegionId equals region.RegionId
                                         join lob in uow.Repository<LineOfBusiness>().GetAll() on approverByRegion.LineOfBusinessId equals lob.LineOfBusinessId
                                         join approverType in uow.Repository<ApproverType>().GetAll() on approverByRegion.ApproverTypeId equals approverType.ApproverTypeId
                                         where approverByRegion.ApproverByRegionAndLineOfBusinessId == approver.ApproverByRegionAndLineOfBusinessId && region.IsActive
                                         select new
                                         {
                                             region.RegionName,
                                             approverType.ApproverTypeName,
                                             lob.LineOfBusinessName
                                         }).FirstOrDefault();

                    if (regionDetails != null)
                    {
                        var approverByRegionModel = new ApproverByRegionAndLineOfBusiness
                        {
                            ApproverByRegionAndLineOfBusinessId = approver.ApproverByRegionAndLineOfBusinessId,
                            ApproverTypeId = approver.ApproverTypeId,
                            RegionId = approver.RegionId,
                            Comments = approver.Comments,
                            IsActive = approver.IsActive,
                            CreatedBy = approver.CreatedBy,
                            CreatedDate = approver.CreatedDate,
                            UpdatedBy = approver.UpdatedBy,
                            UpdatedDate = approver.UpdatedDate,
                            LineOfBusinessId = approver.LineOfBusinessId,

                        };

                        var approverVM = mapper.Map<ApproverByRegionAndLineOfBusiness, ApproverByRegionAndLineOfBusinessViewModel>(approverByRegionModel);
                        approverVM.ApproverNames = string.Join((char)44 + " ", approverMapping.Where(y => y.isActive).Select(x => x.name));
                        approverVM.RegionName = regionDetails.RegionName;
                        approverVM.LineOfBusinessName = regionDetails.LineOfBusinessName;
                        approverVM.ApproverTypeName = regionDetails.ApproverTypeName;
                        approversByRegionVMList.Add(approverVM);
                    }
                }
            }

            return approversByRegionVMList;
        }

        public void AddApproverByRegion(ApproverByRegionAndLineOfBusinessViewModel model)
        {
            if (model != null)
            {
                var approverByRegionAndLOB = mapper.Map<ApproverByRegionAndLineOfBusinessViewModel, ApproverByRegionAndLineOfBusiness>(model);

                // Created by should get from claims
                approverByRegionAndLOB.CreatedBy = model.CreatedBy;
                approverByRegionAndLOB.IsActive = true;
                approverByRegionAndLOB.CreatedDate = DateTime.Now;
                uow.Repository<ApproverByRegionAndLineOfBusiness>().Add(approverByRegionAndLOB);
                uow.SaveChanges();

                if (model.Approvers != null && model.Approvers.Any())
                {
                    var approverMappingsByRegion = mapper.Map<IEnumerable<ApproverByRegionAndLineOfBusinessMappingViewModel>, IEnumerable<ApproverByRegionAndLineOfBusinessMapping>>(model.Approvers);

                    foreach (var approverMapping in approverMappingsByRegion)
                    {
                        approverMapping.ApproverByRegionAndLineOfBusinessId = approverByRegionAndLOB.ApproverByRegionAndLineOfBusinessId;
                    }

                    uow.Repository<ApproverByRegionAndLineOfBusinessMapping>().AddRange(approverMappingsByRegion);
                }

                uow.SaveChanges();
            }
        }

        public void UpdateApproverByRegion(ApproverByRegionAndLineOfBusinessViewModel model)
        {
            var approverByRegionModel = mapper.Map<ApproverByRegionAndLineOfBusinessViewModel, ApproverByRegionAndLineOfBusiness>(model);
            var approverByRegion = uow.Repository<ApproverByRegionAndLineOfBusiness>().GetById(approverByRegionModel.ApproverByRegionAndLineOfBusinessId);
            if (model.Approvers != null && model.Approvers.Any())
            {
                var approverByRegionMapping = uow.Repository<ApproverByRegionAndLineOfBusinessMapping>().GetAll(apprMap => apprMap.ApproverByRegionAndLineOfBusinessId == approverByRegionModel.ApproverByRegionAndLineOfBusinessId);
                uow.Repository<ApproverByRegionAndLineOfBusinessMapping>().DeleteRange(uow.Repository<ApproverByRegionAndLineOfBusinessMapping>().GetAll(apprMap => apprMap.ApproverByRegionAndLineOfBusinessId == approverByRegionModel.ApproverByRegionAndLineOfBusinessId));
                var approverMappingsByRegion = mapper.Map<IEnumerable<ApproverByRegionAndLineOfBusinessMappingViewModel>, IEnumerable<ApproverByRegionAndLineOfBusinessMapping>>(model.Approvers);
                foreach (var approverMapping in approverMappingsByRegion)
                {
                    approverMapping.ApproverByRegionAndLineOfBusinessId = approverByRegion.ApproverByRegionAndLineOfBusinessId;
                }

                uow.Repository<ApproverByRegionAndLineOfBusinessMapping>().AddRange(approverMappingsByRegion);
            }

            approverByRegion.ApproverTypeId = approverByRegionModel.ApproverTypeId;
            approverByRegion.RegionId = approverByRegionModel.RegionId;
            approverByRegion.LineOfBusinessId = approverByRegionModel.LineOfBusinessId;
            approverByRegion.Comments = approverByRegionModel.Comments;
            approverByRegion.IsActive = approverByRegionModel.IsActive;
            approverByRegion.CreatedDate = approverByRegion.CreatedDate;
            approverByRegion.CreatedBy = approverByRegion.CreatedBy;

            // Created by should get from claims
            approverByRegion.UpdatedBy = model.UpdatedBy;
            approverByRegion.UpdatedDate = DateTime.Now;
            uow.Repository<ApproverByRegionAndLineOfBusiness>().Update(approverByRegion);
            uow.SaveChanges();
        }
    }
}