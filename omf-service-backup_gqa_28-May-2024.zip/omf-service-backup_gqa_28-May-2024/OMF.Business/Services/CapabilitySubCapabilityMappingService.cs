﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class CapabilitySubCapabilityMappingService : ICapabilitySubCapabilityMappingService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public CapabilitySubCapabilityMappingService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<CapabilitySubCapabilityMappingViewModel> GetAllCapabilitySubCapabilities()
        {
            var capabilityList = uow.Repository<Capability>().GetAll(capability => capability.IsActive);
            List<CapabilitySubCapabilityMappingViewModel> capabilitySubcapabilityMapping = new List<CapabilitySubCapabilityMappingViewModel>();
            int capabilitySubCapabilityId = 0;
            foreach (var capability in capabilityList)
            {
                var subCapabilityList = from capabilitySubCapabilityMappings in uow.Repository<CapabilitySubCapabilityMapping>().GetAll()
                                        join capabilities in uow.Repository<Capability>().GetAll() on capabilitySubCapabilityMappings.CapabilityId equals capabilities.CapabilityId
                                        join subCapabilities in uow.Repository<SubCapability>().GetAll() on capabilitySubCapabilityMappings.SubCapabilityId equals subCapabilities.SubCapabilityId
                                        where capabilities.CapabilityId == capability.CapabilityId && subCapabilities.IsActive
                                        select new SubCapabilityViewModel
                                        {
                                            SubCapabilityId = subCapabilities.SubCapabilityId,
                                            SubCapabilityName = subCapabilities.SubCapabilityName,
                                            CreatedBy = capabilitySubCapabilityMappings.CreatedBy,
                                            CreatedDate = capabilitySubCapabilityMappings.CreatedDate
                                        };
                if (subCapabilityList.Any())
                {
                    capabilitySubcapabilityMapping.Add(new CapabilitySubCapabilityMappingViewModel
                    {
                        CapabilitySubCapabilityId = ++capabilitySubCapabilityId, CapabilityId = capability.CapabilityId, CapabilityName = capability.CapabilityName, CreatedBy = subCapabilityList.First().CreatedBy, CreatedDate = subCapabilityList.First().CreatedDate,
                        SubCapabilityNames = string.Join((char)44 + " ", subCapabilityList.Select(x => x.SubCapabilityName))
                });
                }
            }

            if (capabilitySubcapabilityMapping != null)
            {
                capabilitySubcapabilityMapping = capabilitySubcapabilityMapping.OrderByDescending(m => m.CreatedDate).ToList();
            }

            return capabilitySubcapabilityMapping;
        }

        public void AddCapabilitySubCapability(CapabilitySubCapabilityMappingViewModel model)
        {
            if (model != null)
            {
                uow.Repository<CapabilitySubCapabilityMapping>().DeleteRange(uow.Repository<CapabilitySubCapabilityMapping>().GetAll(item => item.CapabilityId == model.CapabilityId));

                foreach (var subCapability in model.SubCapabilities)
                {
                    var capabilitySubCapabilityMapping = new CapabilitySubCapabilityMapping
                    {
                        SubCapabilityId = subCapability.SubCapabilityId,
                        CapabilityId = model.CapabilityId,
                        CreatedBy = model.CreatedBy,
                        IsActive = true,
                        CreatedDate = DateTime.Now
                    };
                    uow.Repository<CapabilitySubCapabilityMapping>().Add(capabilitySubCapabilityMapping);
                }

                uow.SaveChanges();
            }
        }
    }
}
