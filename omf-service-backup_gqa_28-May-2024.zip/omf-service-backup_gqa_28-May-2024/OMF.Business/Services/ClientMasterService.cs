﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class ClientMasterService : IClientMasterService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public ClientMasterService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<ClientMasterViewModel> GetActiveClientMasters()
        {
            var clients = uow.Repository<ClientMaster>().GetAll(client => client.IsActive).OrderByDescending(m => m.ClientName);
            return mapper.Map<IEnumerable<ClientMaster>, IEnumerable<ClientMasterViewModel>>(clients);
        }

        public IEnumerable<ClientMasterViewModel> GetClientMasters()
        {
            var clients = uow.Repository<ClientMaster>().GetAll().OrderByDescending(m => m.ClientName);
            return mapper.Map<IEnumerable<ClientMaster>, IEnumerable<ClientMasterViewModel>>(clients);
        }

        public ClientMasterViewModel GetClientMasterById(int id)
        {
            var clientMaster = uow.Repository<ClientMaster>().GetById(id);
            return mapper.Map<ClientMaster, ClientMasterViewModel>(clientMaster);
        }

        public void AddClientMaster(ClientMasterViewModel model)
        {
            if (model != null)
            {
                if (string.IsNullOrWhiteSpace(model.BillingAdministrator))
                {
                    model.BillingAdministrator = null;
                }
                var clientMaster = mapper.Map<ClientMasterViewModel, ClientMaster>(model);
                clientMaster.CreatedBy = model.CreatedBy;
                clientMaster.IsActive = true;
                clientMaster.CreatedDate = DateTime.Now;
                clientMaster.Url = model.Url?.Trim();
                uow.Repository<ClientMaster>().Add(clientMaster);
                uow.SaveChanges();
            }
        }

        public void UpdateClientMaster(ClientMasterViewModel model)
        {
            var clientMaster = uow.Repository<ClientMaster>().GetById(model.ClientMasterId);
            clientMaster.ClientName = model.ClientName;
            clientMaster.LocalizedAccountName = model.LocalizedAccountName;
            clientMaster.ClientAlias = model.ClientAlias;
            clientMaster.IndustrySegmentId = model.IndustrySegmentId;
            clientMaster.IndustrySubSegmentId = model.IndustrySubSegmentId;
            clientMaster.Url = model.Url?.Trim(); ;
            clientMaster.PaymentTermId = model.PaymentTermId;
            clientMaster.PrimaryContactName = model.PrimaryContactName;
            clientMaster.HitachiCompany = model.HitachiCompany;
            clientMaster.JapaneseCompany = model.JapaneseCompany;
            clientMaster.Comments = model.Comments;
            clientMaster.IsActive = model.IsActive;
            clientMaster.CreatedDate = clientMaster.CreatedDate;
            clientMaster.UpdatedBy = model.UpdatedBy;
            clientMaster.UpdatedDate = DateTime.Now;
            clientMaster.Comments = model.Comments;
            clientMaster.InsideViewId = model.InsideViewId;
            clientMaster.OracleClientNumber = model.OracleClientNumber;
            clientMaster.OracleRegistryId = model.OracleRegistryId;
            clientMaster.ClientQuadrantId = model.ClientQuadrantId;
            clientMaster.DPAAvailable = model.DPAAvailable;
            clientMaster.COLAAtDPALevel = model.COLAAtDPALevel;
            clientMaster.DPARemarks = model.DPARemarks;
            clientMaster.COLARemarks = model.COLARemarks;
            string billingAdministrator = string.IsNullOrWhiteSpace(model.BillingAdministrator) ? null : model.BillingAdministrator;
            if (clientMaster != null)
            {
                if (clientMaster.BillingAdministrator != null && clientMaster.BillingAdministrator.Equals(billingAdministrator, StringComparison.OrdinalIgnoreCase))
                {
                    // do nothing
                }
                else if (clientMaster.BillingAdministrator == null && billingAdministrator == null)
                {
                    // do nothing
                }
                else
                {
                    var statusesExcluded = new List<int>() { (int)Enums.StatusType.Completed, (int)Enums.StatusType.DuplicateVersion,
                    (int)Enums.StatusType.NoSale, (int)Enums.StatusType.SOWAwaited, (int)Enums.StatusType.Lost
                    };

                    var getClientBilling = uow.Repository<ClientBillingAddress>().GetAll(x => x.IsActive)
                                          .Where(x => x.ClientMasterId == model.ClientMasterId).Select(x => x.ClientBillingAddressId).ToList();

                    var baTobeUpdatedforOpps = uow.Repository<Opportunity>().GetAll(x => x.IsActive).Where(s => !statusesExcluded.Any(y => y == s.StatusId)
                    && getClientBilling.Contains(s.ClientBillingAddressId)).ToList();

                    if (baTobeUpdatedforOpps.Count > 0)
                    {
                        baTobeUpdatedforOpps.ForEach(e => e.BillingAdministrator = billingAdministrator);
                        uow.Repository<Opportunity>().BulkUpdate(baTobeUpdatedforOpps);
                    }
                }
            }

            clientMaster.BillingAdministrator = billingAdministrator;
            clientMaster.COLAStartDate = model.COLAStartDate;
            if (model.DPAUploadStatusId != 0)
            {
                clientMaster.DPAUploadStatusId = model.DPAUploadStatusId;
            }

            uow.Repository<ClientMaster>().Update(clientMaster);
            uow.SaveChanges();
            model = mapper.Map<ClientMaster, ClientMasterViewModel>(clientMaster);
        }

        public IEnumerable<ClientDetailsViewModel> GetActiveClientDetails()
        {
            var clients = uow.Repository<ClientMaster>().GetAll(client => client.IsActive).Select(x => new ClientDetailsViewModel { ClientMasterId = x.ClientMasterId, ClientName = x.ClientName }).OrderByDescending(m => m.ClientName).ToList();
            //return mapper.Map<IEnumerable<ClientMaster>, IEnumerable<ClientMasterViewModel>>(clients);
            return clients;
        }

        public ClientMasterDetailsViewModel GetClientDetailsById(int id)
        {
            var clientMaster = uow.Repository<ClientMaster>().GetById(id);
            ClientMasterDetailsViewModel detailsViewModel = new ClientMasterDetailsViewModel();
            detailsViewModel.ClientMasterId = clientMaster.ClientMasterId;
            detailsViewModel.ClientAlias = clientMaster.ClientAlias;
            detailsViewModel.ClientName = clientMaster.ClientName;
            detailsViewModel.ClientQuadrantId = clientMaster.ClientQuadrantId;
            detailsViewModel.DPAAvailable = clientMaster.DPAAvailable;
            detailsViewModel.COLAAtDPALevel = clientMaster.COLAAtDPALevel;
            detailsViewModel.Comments = clientMaster.Comments;
            detailsViewModel.HitachiCompany = clientMaster.HitachiCompany;
            detailsViewModel.IndustrySegmentId = clientMaster.IndustrySegmentId;
            detailsViewModel.IndustrySegmentName = uow.Repository<IndustrySegment>().GetById(clientMaster.IndustrySegmentId).IndustrySegmentName;
            detailsViewModel.IndustrySubSegmentId = clientMaster.IndustrySubSegmentId;
            detailsViewModel.IndustrySubSegmentName = uow.Repository<IndustrySubSegment>().GetById(clientMaster.IndustrySubSegmentId).IndustrySubSegmentName;
            detailsViewModel.InsideViewId = clientMaster.InsideViewId;
            detailsViewModel.JapaneseCompany = clientMaster.JapaneseCompany;
            detailsViewModel.LocalizedAccountName = clientMaster.LocalizedAccountName;
            detailsViewModel.OracleClientNumber = clientMaster.OracleClientNumber;
            detailsViewModel.OracleRegistryId = clientMaster.OracleRegistryId;
            detailsViewModel.PaymentTermId = clientMaster.PaymentTermId;
            detailsViewModel.PaymentTermName = uow.Repository<PaymentTerms>().GetById(clientMaster.PaymentTermId).PaymentTermCode;
            detailsViewModel.PrimaryContactName = clientMaster.PrimaryContactName;
            detailsViewModel.Url = clientMaster.Url?.Trim();
            detailsViewModel.DPARemarks = clientMaster.DPARemarks;
            detailsViewModel.COLARemarks = clientMaster.COLARemarks;
            detailsViewModel.DPAUploadStatusId = clientMaster.DPAUploadStatusId;
            detailsViewModel.DPAUploadStatusName = clientMaster.DPAUploadStatusId == null ? null : uow.Repository<DPAUploadStatus>().GetById(clientMaster.DPAUploadStatusId).DPAUploadStatusName;
            detailsViewModel.BillingAdministrator = clientMaster.BillingAdministrator;
            detailsViewModel.COLAStartDate = clientMaster.COLAStartDate;
            //ClientMasterDetailsViewModel detailsViewModel = mapper.Map<ClientMaster, ClientMasterDetailsViewModel>(clientMaster);
            return detailsViewModel;
        }
    }
}
