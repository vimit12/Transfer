﻿namespace OMF.Business.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Data.Models;
    using OMF.Data.Repository;

    public class CapabilityService : ICapabilityService
    {
        private readonly IUow uow;
        private readonly IMapper mapper;

        public CapabilityService(IUow uow, IMapper mapper)
        {
            this.uow = uow;
            this.mapper = mapper;
        }

        public IEnumerable<CapabilityViewModel> GetCapabilities()
        {
            var capabilities = uow.Repository<Capability>().GetAll().OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            return mapper.Map<IEnumerable<Capability>, IEnumerable<CapabilityViewModel>>(capabilities);
        }

        public IEnumerable<CapabilityViewModel> GetActiveCapabilities()
        {
            var capabilities = uow.Repository<Capability>().GetAll(capability => capability.IsActive).OrderByDescending(m => Year.CompareDates(m.CreatedDate, m.UpdatedDate));
            return mapper.Map<IEnumerable<Capability>, IEnumerable<CapabilityViewModel>>(capabilities);
        }

        public CapabilityViewModel GetCapabilitiesById(int id)
        {
            var capability = uow.Repository<Capability>().GetById(id);
            return mapper.Map<Capability, CapabilityViewModel>(capability);
        }

        public void AddCapability(CapabilityViewModel model)
        {
            if (model != null)
            {
                var capability = mapper.Map<CapabilityViewModel, Capability>(model);

                // Created by should get from claims
                capability.CreatedBy = model.CreatedBy;
                capability.IsActive = true;
                capability.CreatedDate = DateTime.Now;
                uow.Repository<Capability>().Add(capability);
                uow.SaveChanges();
            }
        }

        public void UpdateCapability(CapabilityViewModel model)
        {
            var capability = uow.Repository<Capability>().GetById(model.CapabilityId);
            capability.CapabilityName = model.CapabilityName;
            capability.Comments = model.Comments;
            capability.IsActive = model.IsActive;
            capability.CreatedDate = capability.CreatedDate;
            capability.CreatedBy = capability.CreatedBy;

            // Created by should get from claims
            capability.UpdatedBy = model.UpdatedBy;
            capability.UpdatedDate = DateTime.Now;
            uow.Repository<Capability>().Update(capability);
            uow.SaveChanges();
            model = mapper.Map<Capability, CapabilityViewModel>(capability);
        }
    }
}