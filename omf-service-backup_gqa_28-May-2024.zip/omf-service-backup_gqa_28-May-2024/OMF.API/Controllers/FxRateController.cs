﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class FxRateController : Controller
    {
        private readonly IFxRateService fxRateService;

        private readonly ILogger<FxRateController> logger;

        public FxRateController(IFxRateService service, ILogger<FxRateController> logger)
        {
            this.fxRateService = service;
            this.logger = logger;
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetFxRatesByYear")]
        public IActionResult GetFxRateByYear(int id)
        {
            try
            {
                logger.LogInformation("GetFxRateByYear");
                var currency = fxRateService.GetFxRatesByYear(id);
                return Ok(new ApiOkResponse(currency));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetFxRateByYear() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{year}/{quarter}")]
        [ActionName("GetFxCommentsSummary")]
        public IActionResult GetFxRateSummary(int year, string quarter)
        {
            try
            {
                logger.LogInformation("GetFxRateSummary");
                var comment = fxRateService.GetFxRatesSummary(year, quarter);
                return Ok(new ApiOkResponse(comment));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetFxRateSummary() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveFxRates")]
        public IActionResult AddUpdateFxRates([FromBody]IEnumerable<FxRateViewModel> fxRates)
        {
            logger.LogInformation("AddUpdateFxRates");
            try
            {
                fxRateService.SaveFxRates(fxRates);
                return Ok(new ApiOkResponse(fxRates));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddUpdateFxRates() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/
        [HttpGet]
        [ActionName("GetFxCurrentQtr")]
        public IActionResult GetFxCurrentQtr()
        {
            try
            {
                logger.LogInformation("GetFxCurrentQtr");
                var currencyQtr = fxRateService.GetFxCurrencyForCurrentQtr();
                return Ok(new ApiOkResponse(currencyQtr));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetFxCurrentQtr() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}