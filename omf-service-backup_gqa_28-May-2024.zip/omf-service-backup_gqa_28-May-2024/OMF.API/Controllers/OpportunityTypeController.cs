﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class OpportunityTypeController : Controller
    {
        private readonly IOpportunityTypeService opportunityTypeService;

        private readonly ILogger<OpportunityTypeController> logger;

        public OpportunityTypeController(IOpportunityTypeService service, ILogger<OpportunityTypeController> logger)
        {
            this.opportunityTypeService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetOpportunityTypes")]
        public IActionResult GetOpportunityTypes()
        {
            logger.LogInformation("GetOpportunityTypes");
            try
            {
                var opportunityTypes = opportunityTypeService.GetOpportunityTypes();
                return Ok(new ApiOkResponse(opportunityTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOpportunityTypes() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
