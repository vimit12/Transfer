﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class WorkflowController : Controller
    {
        private readonly IWorkflowService workflowService;
        private readonly IHiQService hiQService;

        private readonly ILogger<WorkflowController> logger;

        public WorkflowController(IWorkflowService service, ILogger<WorkflowController> logger, IHiQService hiQService)
        {
            this.workflowService = service;
            this.logger = logger;
            this.hiQService = hiQService;
        }

        [HttpPut]
        [ActionName("UpdateNextStatus")]
        public async Task<IActionResult> UpdateNextStatus([FromBody]WorkFlowActionViewModel workFlowActionView)
        {
            logger.LogInformation("UpdateNextStatus");
            try
            {
                workFlowActionView.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                var workLocations = workflowService.UpdateNextStatus(workFlowActionView);
                if (workLocations.StatusId == (int)Enums.StatusType.ApprovedByORB)
                {
                    await hiQService.UpdateORBComments(workFlowActionView, true);
                }

                if(workLocations.StatusId == (int)Enums.StatusType.SentToCompliance)
                {
                    await hiQService.UpdateORBComments(workFlowActionView);
                }

                if (workLocations.StatusId == (int)Enums.StatusType.SentToWorkLocations || workLocations.StatusId == (int)Enums.StatusType.SentToOIC || workLocations.StatusId == (int)Enums.StatusType.SentToORB || workLocations.StatusId == (int)Enums.StatusType.ApprovedByWorkLocations)
                {
                    await hiQService.UpdateOMFDetailsToHiQ(workFlowActionView, false);
                }

                if (workLocations.StatusId == (int)Enums.StatusType.SentToCompliance || workLocations.StatusId == (int)Enums.StatusType.InProgress || workLocations.StatusId == (int)Enums.StatusType.Completed || workLocations.StatusId == (int)Enums.StatusType.SentToSensitiveCompliance || workLocations.StatusId == (int)Enums.StatusType.InProgressBySensitiveCompliance || workLocations.StatusId == (int)Enums.StatusType.SOWAwaited)
                {
                    await hiQService.UpdateOMFDetailsToHiQ(workFlowActionView, true);
                }

                var autoFlowCheck = CheckWorkFlowAutoProgressPossibility(workFlowActionView.OpportunityId);

                if (autoFlowCheck)
                {
                    var wlStatus = workflowService.GetStatusOfWL(workFlowActionView.OpportunityId);
                    if (wlStatus.All(x => x.StatusId == (int)Enums.StatusType.Completed))
                    {
                        workLocations = WorkFlowAutoProgress(workFlowActionView.OpportunityId);
                    }
                }

                return Ok(new ApiOkResponse(workLocations));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateNextStatus() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        private OpportunityBasicDetailsViewModel WorkFlowAutoProgress(int opportunityId)
        {
            return workflowService.WorkFlowAutoProgress(opportunityId);
        }

        private bool CheckWorkFlowAutoProgressPossibility(int opportunityId)
        {
            var autoActions = workflowService.CheckWorkFlowAutoProgressPossibility(opportunityId);
            return autoActions == null ? false : true;
        }

        [HttpPost]
        [ActionName("AddCommentsByUser")]
        public IActionResult AddCommentsByUser([FromBody]EmailCommentsByUserViewModel emailComments)
        {
            logger.LogInformation("AddCommentsByUser");
            try
            {
                emailComments.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                workflowService.AddCommentsByUser(emailComments);
                return Ok(new ApiOkResponse(emailComments));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddCommentsByUser() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("ShareSimulation")]
        public IActionResult ShareSimulation([FromBody]ShareSimulationViewModel shareSimulationViewModel)
        {
            try
            {
                logger.LogInformation("ShareSimulation", shareSimulationViewModel);
                shareSimulationViewModel.UpdatedBy = string.IsNullOrWhiteSpace(shareSimulationViewModel.UpdatedBy) ? HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value : shareSimulationViewModel.UpdatedBy;
                workflowService.ShareSimulation(shareSimulationViewModel);
                return Ok(new ApiOkResponse(shareSimulationViewModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ShareSimulation", shareSimulationViewModel);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetWorkFlowActionsByStatus")]
        public IActionResult GetWorkFlowActionsByStatus(WorkFlowActionsViewModel workFlowActionsViewModel)
        {
            try
            {
                logger.LogInformation("GetWorkFlowActionsByStatus", workFlowActionsViewModel);
                workFlowActionsViewModel.UpdatedBy = string.IsNullOrWhiteSpace(workFlowActionsViewModel.UpdatedBy) ? HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value : workFlowActionsViewModel.UpdatedBy;
                var response = workflowService.GetWorkFlowActionsByStatus(workFlowActionsViewModel);
                return Ok(new ApiOkResponse(response));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetWorkFlowActionsByStatus", workFlowActionsViewModel);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut("{opportunityId}")]
        [ActionName("SetLostOpportunity")]
        public IActionResult SetLostOpportunity(int opportunityId)
        {
            try
            {
                logger.LogInformation("SetLostOpportunity", opportunityId);
                workflowService.SetOpportunityAsLost(opportunityId);
                return Ok(new ApiOkResponse(opportunityId));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "SetLostOpportunity", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut("{opportunityId}")]
        [ActionName("SetNoSaleOpportunity")]
        public IActionResult SetNoSaleOpportunity(int opportunityId)
        {
            try
            {
                logger.LogInformation("SetLostOpportunity", opportunityId);
                workflowService.SetNoSaleOpportunity(opportunityId);
                return Ok(new ApiOkResponse(opportunityId));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "SetNoSaleOpportunity", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut("{opportunityId}")]
        [ActionName("SetDuplicateOpportunity")]
        public IActionResult SetDuplicateOpportunity(int opportunityId)
        {
            try
            {
                logger.LogInformation("SetDuplicateOpportunity", opportunityId);
                workflowService.SetDuplicateOpportunity(opportunityId);
                return Ok(new ApiOkResponse(opportunityId));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "SetDuplicateOpportunity", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}/{screenId}")]
        [ActionName("GetCommentsForOpportunity")]
        public IActionResult GetCommentsForOpportunity(int opportunityId, int screenId)
        {
            try
            {
                logger.LogInformation("GetCommentsForOpportunity", opportunityId, screenId);
                return Ok(new ApiOkResponse(workflowService.GetCommentsForOpportunity(opportunityId, screenId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetCommentsForOpportunity", opportunityId, screenId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetApproversForWorkLocations")]
        public IActionResult GetApproversForWorkLocations(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetCommentsForOpportunity", opportunityId);
                return Ok(new ApiOkResponse(workflowService.GetApproversForWorkLocations(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetCommentsForOpportunity", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{oppId}")]
        [ActionName("CheckHiQRecordStatus")]
        public async Task<IActionResult> CheckHiQRecordStatus(int oppId)
        {
            try
            {
                logger.LogInformation("CheckHiQRecordStatus");
                var response = await hiQService.CheckHiQRecordStatus(oppId);
                return Ok(new ApiOkResponse(response));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "CheckHiQRecordStatus");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{crmId}")]
        [ActionName("HiQOMFIntegration")]
        public async Task<IActionResult> HiQOMFIntegration(int crmId)
        {
            try
            {
                logger.LogInformation("HiQOMFIntegration");
                var response = await hiQService.HiQOMFIntegration(crmId);
                return Ok(new ApiOkResponse(response));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "CheckHiQRecordStatus");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("IntegrateORB")]
        public async Task<IActionResult> IntegrateORB([FromBody] WorkFlowActionViewModel workFlowActionView)
        {
            await hiQService.UpdateORBComments(workFlowActionView, false);
            return Ok();
        }

        [HttpPut]
        [ActionName("UpdateORBStatus")]
        public async Task<IActionResult> UpdateORBStatus([FromBody] WorkFlowActionViewModel workFlowActionView)
        {
            await hiQService.UpdateOMFDetailsToHiQ(workFlowActionView, true);
            return Ok();
        }

        [HttpGet("{oppId}")]
        [ActionName("GetPGM")]
        public IActionResult GetPGM(int oppId)
        {
            return Ok(hiQService.GetORBApprovedPGM(oppId));
        }

        [HttpPut("{opportunityId}/{statusId}/{reminderOrEscalation}")]
        [ActionName("SendMailFromSmtp")]
        public IActionResult SendMailFromSmtp(int opportunityId, int statusId, int reminderOrEscalation)
        {
            try
            {
                logger.LogInformation("SendMailFromSmtp", opportunityId);
                workflowService.SendMailFromSmtp(opportunityId, statusId, reminderOrEscalation);
                return Ok(new ApiOkResponse(opportunityId));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "SendMailFromSmtp", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetFRWorkFlowActionsByStatus")]
        public IActionResult GetFRWorkFlowActionsByStatus(FRWorkFlowActionsViewModel workFlowActionsViewModel)
        {
            try
            {
                logger.LogInformation("GetFRWorkFlowActionsByStatus", workFlowActionsViewModel);
                workFlowActionsViewModel.UpdatedBy = string.IsNullOrWhiteSpace(workFlowActionsViewModel.UpdatedBy) ? HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value : workFlowActionsViewModel.UpdatedBy;
                var response = workflowService.GetFRWorkFlowActionsByStatus(workFlowActionsViewModel);
                return Ok(new ApiOkResponse(response));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetFRWorkFlowActionsByStatus", workFlowActionsViewModel);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateFRNextStatus")]
        public async Task<IActionResult> UpdateFRNextStatus([FromBody] FRWorkFlowActionViewModel workFlowActionView)
        {
            logger.LogInformation("UpdateFRNextStatus");
            try
            {
                workFlowActionView.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                var workLocations = workflowService.UpdateFRNextStatus(workFlowActionView);

                return Ok(new ApiOkResponse(workLocations));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateFRNextStatus() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{fundingReductionId}")]
        [ActionName("GetCommentsForFundingReduction")]
        public IActionResult GetCommentsForFundingReduction(int fundingReductionId)
        {
            try
            {
                logger.LogInformation("GetCommentsForFundingReduction", fundingReductionId);
                return Ok(new ApiOkResponse(workflowService.GetCommentsForFundingReduction(fundingReductionId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetCommentsForFundingReduction", fundingReductionId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("ValidateResourceWorkLocation")]
        public IActionResult ValidateResourceWorkLocation(int opportunityId)
        {
            try
            {
                logger.LogInformation("ValidateResourceWorkLocation", opportunityId);
                return Ok(new ApiOkResponse(workflowService.ValidateResourceWorkLocation(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ValidateResourceWorkLocation", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("ValidateOICAndPMForOpportunity")]
        public IActionResult ValidateOICAndPMForOpportunity(int opportunityId)
        {
            try
            {
                logger.LogInformation("ValidateOICAndPMForOpportunity", opportunityId);
                return Ok(new ApiOkResponse(workflowService.ValidateOICAndPMForOpportunity(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ValidateOICAndPMForOpportunity", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
