﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OMF.API.Common;
using OMF.Business.Interfaces;
using OMF.Business.Common;
using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;

namespace OMF.API.Controllers
{
    [Route("api/omf/[controller]/[action]")]
    [ApiController]
    public class FinancialCloudHostingController : Controller
    {
        private readonly IFinancialCloudHostingService financialCloudHostingService;
        private readonly ILogger<FinancialCloudHostingController> logger;

        public FinancialCloudHostingController(IFinancialCloudHostingService service, ILogger<FinancialCloudHostingController> logger)
        {
            this.financialCloudHostingService = service;
            this.logger = logger;
        }

        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetFinancialCloudHostingDetails")]
        public IActionResult GetFinancialCloudHostingDetails(int opportunityId, int yearId)
        {
            try
            {
                logger.LogInformation("GetFinancialCloudHostingDetails");
                return Ok(new ApiOkResponse(financialCloudHostingService.GetFinancialCloudHostingDetails(opportunityId, yearId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetFinancialCloudHostingDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddNewOrUpdateCloudHosting")]
        public IActionResult AddNewOrUpdateCloudHosting([FromBody] List<FinancialCloudHostingDetailsViewModel> hostingDetailsViewModel)
        {
            logger.LogInformation("AddNewOrUpdateCloudHosting");
            try
            {
                financialCloudHostingService.AddNewOrUpdateCloudHosting(hostingDetailsViewModel, HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value);
                return Ok(new ApiOkResponse(hostingDetailsViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddNewOrUpdateCloudHosting() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("DeleteCloudHosting")]
        public IActionResult DeleteCloudHosting([FromBody]List<FinancialCloudHostingDetailsViewModel> financialCloudHostings)
        {
            logger.LogInformation("DeleteCloudHosting", financialCloudHostings);
            try
            {
                logger.LogInformation("DeleteCloudHosting");
                string errorMessage = string.Empty;
                financialCloudHostingService.DeleteCloudHostingDetails(financialCloudHostings, ref errorMessage);
                return errorMessage == string.Empty ? Ok(new ApiOkResponse(financialCloudHostings)) : (IActionResult)BadRequest(errorMessage);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "DeleteCloudHosting");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}