﻿namespace OMF.API.Controllers
{
    using System;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ReadOutlookMailController : Controller
    {
        private readonly IReadOutlookMailService readOutlookMailService;

        private readonly ILogger<ReadOutlookMailController> logger;

        public ReadOutlookMailController(IReadOutlookMailService service, ILogger<ReadOutlookMailController> logger)
        {
            this.readOutlookMailService = service;
            this.logger = logger;
        }

        [HttpPut]
        [ActionName("ReadMails")]
        public IActionResult ReadMails()
        {
            logger.LogInformation("ReadMails");
            try
            {
                readOutlookMailService.ReadMails();
                return Ok(new ApiOkResponse(Constants.NotificationSent));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "ReadOutLookMail() - Exception");
                return BadRequest(exception.Message);
            }
        }
    }
}