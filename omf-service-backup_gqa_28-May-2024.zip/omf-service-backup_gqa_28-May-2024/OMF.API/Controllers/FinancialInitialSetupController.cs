﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class FinancialInitialSetupController : Controller
    {
        private readonly IFinancialInitialSetupService financialInitialSetupService;

        private readonly ILogger<FinancialInitialSetupController> logger;

        public FinancialInitialSetupController(IFinancialInitialSetupService service, ILogger<FinancialInitialSetupController> logger)
        {
            this.financialInitialSetupService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllFinancialsInitialSetup")]
        public IActionResult GetAllFinancialsInitialSetup()
        {
            this.logger.LogInformation("GetAllFinancialsInitialSetup");
            try
            {
                var financialInitials = this.financialInitialSetupService.GetAllFinancialsInitialSetup();
                return this.Ok(new ApiOkResponse(financialInitials));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllFinancialsInitialSetup() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetInitialSetupById")]
        public IActionResult GetInitialSetupById(int id)
        {
            this.logger.LogInformation("GetInitialSetupById");
            try
            {
                var financialInitial = this.financialInitialSetupService.GetInitialSetupById(id);
                return this.Ok(new ApiOkResponse(financialInitial));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetInitialSetupById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetInitialSetupByOppourtunity")]
        public IActionResult GetInitialSetupByOppourtunity(DefaultRateCardInputViewModel defaultInput)
        {
            this.logger.LogInformation("GetInitialSetupByOppourtunity");
            try
            {
                var financialInitial = this.financialInitialSetupService.GetInitialSetupByOppourtunity(defaultInput);
                return this.Ok(new ApiOkResponse(financialInitial));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetInitialSetupByOppourtunity() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddInitialSetup")]
        public IActionResult AddInitialSetup([FromBody]FinancialInitialSetupViewModel financialInitial)
        {
            this.logger.LogInformation("AddInitialSetup");
            try
            {
                financialInitial.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.financialInitialSetupService.AddInitialSetup(financialInitial);
                return this.Ok(new ApiOkResponse(financialInitial));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddInitialSetup() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateInitialSetup")]
        public IActionResult UpdateInitialSetup([FromBody]FinancialInitialSetupViewModel financialInitial)
        {
            this.logger.LogInformation("UpdateInitialSetup", financialInitial);
            try
            {
                var getemployeetype = this.financialInitialSetupService.GetInitialSetupById(financialInitial.FinancialInitialSetupId);
                if (getemployeetype == null)
                {
                    return this.NotFound("Finance Initial Details not found.");
                }
                else
                {
                    financialInitial.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.financialInitialSetupService.UpdateInitialSetup(financialInitial);
                    return this.Ok(new ApiOkResponse(financialInitial));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateInitialSetup() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{oppourtunityID}")]
        [ActionName("GetInitialSetupByOppourtunityID")]
        public IActionResult GetInitialSetupByOppourtunityID(int oppourtunityID)
        {
            this.logger.LogInformation("GetInitialSetupByOppourtunityID");
            try
            {
                var financialInitial = this.financialInitialSetupService.GetAllFinancialsInitialSetupByOpportunityId(oppourtunityID);
                return this.Ok(new ApiOkResponse(financialInitial));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetInitialSetupByOppourtunityID() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
