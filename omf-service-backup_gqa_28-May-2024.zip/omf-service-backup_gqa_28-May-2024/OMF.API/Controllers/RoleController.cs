﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class RoleController : Controller
    {
        private readonly IRoleService roleService;

        private readonly ILogger<RoleController> logger;

        public RoleController(IRoleService service, ILogger<RoleController> logger)
        {
            this.roleService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetRoles")]
        public IActionResult GetRoles()
        {
            logger.LogInformation("GetRoles");
            try
            {
                var currencies = roleService.GetRoles();
                return Ok(new ApiOkResponse(currencies));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetRoles() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveRoles")]
        public IActionResult GetActiveRoles()
        {
            logger.LogInformation("GetActiveRoles");
            try
            {
                var currencies = roleService.GetActiveRoles();
                return Ok(new ApiOkResponse(currencies));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveRoles() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddRole")]
        public IActionResult AddRole([FromBody]RoleViewModel role)
        {
            logger.LogInformation("AddRole");
            try
            {
                role.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                roleService.AddRole(role);
                return Ok(new ApiOkResponse(role));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddRole() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateRole")]
        public IActionResult UpdateRole([FromBody]RoleViewModel roleViewModel)
        {
            logger.LogInformation("UpdateRole", roleViewModel);
            try
            {
                roleViewModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                roleService.UpdateRole(roleViewModel);
                return Ok(new ApiOkResponse(roleViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateRole() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
