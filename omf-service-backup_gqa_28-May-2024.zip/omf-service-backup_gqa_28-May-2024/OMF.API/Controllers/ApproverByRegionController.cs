﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ApproverByRegionController : Controller
    {
        private readonly IApproverByRegionService approverByRegionService;

        private readonly IApproverByRegionAndLineOfBusinessService approverByRegionAndLineOfBusinessService;

        private readonly ILogger<ApproverByRegionController> logger;

        public ApproverByRegionController(IApproverByRegionService service, ILogger<ApproverByRegionController> logger, IApproverByRegionAndLineOfBusinessService approverByRegionAndLineOfBusinessService)
        {
            this.approverByRegionService = service;
            this.logger = logger;
            this.approverByRegionAndLineOfBusinessService = approverByRegionAndLineOfBusinessService;
        }

        [HttpGet]
        [ActionName("GetApproversByRegion")]
        public IActionResult GetApproversByRegion()
        {
            logger.LogInformation("GetApproversByRegion");
            try
            {
                var approversByRegion = approverByRegionService.GetApproversByRegion();
                return Ok(new ApiOkResponse(approversByRegion));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetApproversByRegion() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddApproverByRegion")]
        public IActionResult AddApproverByRegion([FromBody]ApproverByRegionViewModel approverByRegionViewModel)
        {
            logger.LogInformation("AddApproverByRegion");
            try
            {
                approverByRegionViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                approverByRegionService.AddApproverByRegion(approverByRegionViewModel);
                return Ok(new ApiOkResponse(approverByRegionViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddApproverByRegion() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateApproverByRegion")]
        public IActionResult UpdateApproverByRegion([FromBody]ApproverByRegionViewModel approverByRegionViewModel)
        {
            logger.LogInformation("UpdateApproverByRegion", approverByRegionViewModel);
            try
            {
                approverByRegionViewModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                approverByRegionService.UpdateApproverByRegion(approverByRegionViewModel);
                 return Ok(new ApiOkResponse(approverByRegionViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateApproverByRegion() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetApproversByRegionAndLOB")]
        public IActionResult GetApproversByRegionAndLOB()
        {
            logger.LogInformation("GetApproversByRegionAndLOB");
            try
            {
                var approversByRegion = approverByRegionAndLineOfBusinessService.GetApproversByRegion();
                return Ok(new ApiOkResponse(approversByRegion));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetApproversByRegionAndLOB() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddApproverByRegionAndLOB")]
        public IActionResult AddApproverByRegionAndLOB([FromBody]ApproverByRegionAndLineOfBusinessViewModel approverByRegionViewModel)
        {
            logger.LogInformation("AddApproverByRegionAndLOB");
            try
            {
                approverByRegionViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                approverByRegionAndLineOfBusinessService.AddApproverByRegion(approverByRegionViewModel);
                return Ok(new ApiOkResponse(approverByRegionViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddApproverByRegionAndLOB() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateApproverByRegionAndLOB")]
        public IActionResult UpdateApproverByRegionAndLOB([FromBody]ApproverByRegionAndLineOfBusinessViewModel approverByRegionViewModel)
        {
            logger.LogInformation("UpdateApproverByRegionAndLOB", approverByRegionViewModel);
            try
            {
                approverByRegionViewModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                approverByRegionAndLineOfBusinessService.UpdateApproverByRegion(approverByRegionViewModel);
                return Ok(new ApiOkResponse(approverByRegionViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateApproverByRegionAndLOB() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}