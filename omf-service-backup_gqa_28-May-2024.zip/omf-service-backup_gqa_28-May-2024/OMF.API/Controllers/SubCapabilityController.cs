﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class SubCapabilityController : Controller
    {
        private readonly ISubCapabilityService subCapabilityService;

        private readonly ILogger<SubCapabilityController> logger;

        public SubCapabilityController(ISubCapabilityService service, ILogger<SubCapabilityController> logger)
        {
            this.subCapabilityService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllSubCapabilities")]
        public IActionResult GetSubCapabilities()
        {
            logger.LogInformation("GetAllSubCapabilities");
            try
            {
                var subCapabilities = subCapabilityService.GetSubCapabilities();
                return Ok(new ApiOkResponse(subCapabilities));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllSubCapabilities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveSubCapabilities")]
        public IActionResult GetActiveSubCapabilities()
        {
            logger.LogInformation("GetActiveSubCapabilities");
            try
            {
                var subCapabilities = subCapabilityService.GetActiveSubCapabilities();
                return Ok(new ApiOkResponse(subCapabilities));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveSubCapabilities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveSubCapabilitiesWithCapabilityId")]
        public IActionResult GetActiveSubCapabilitiesWithCapabilityId()
        {
            logger.LogInformation("GetActiveSubCapabilitiesWithCapabilityId");
            try
            {
                var subCapabilities = subCapabilityService.GetActiveSubCapabilitiesWithCapabilityId();
                return Ok(new ApiOkResponse(subCapabilities));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveSubCapabilitiesWithCapabilityId() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }


        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetSubCapabilitiesById")]
        public IActionResult GetSubCapabilitiesById(int id)
        {
            try
            {
                logger.LogInformation("GetSubCapabilitiesById");
                var subCapability = subCapabilityService.GetSubCapabilitiesById(id);
                return Ok(new ApiOkResponse(subCapability));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetSubCapabilitiesById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddSubCapability")]
        public IActionResult AddSubCapability([FromBody]SubCapabilityViewModel subCapability)
        {
            logger.LogInformation("AddSubCapability");
            try
            {
                subCapability.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                subCapabilityService.AddSubCapability(subCapability);
                return Ok(new ApiOkResponse(subCapability));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddSubCapability() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateSubCapability")]
        public IActionResult UpdateSubCapability([FromBody]SubCapabilityViewModel subCapability)
        {
            logger.LogInformation("UpdateSubCapability", subCapability);
            try
            {
                var getsubCapability = subCapabilityService.GetSubCapabilitiesById(subCapability.SubCapabilityId);
                if (getsubCapability == null)
                {
                    return NotFound("Sub Capability not found.");
                }
                else
                {
                    subCapability.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    subCapabilityService.UpdateSubCapability(subCapability);
                    return Ok(new ApiOkResponse(subCapability));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateSubCapability() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}