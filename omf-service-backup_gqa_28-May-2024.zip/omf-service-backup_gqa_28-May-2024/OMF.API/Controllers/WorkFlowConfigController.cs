﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class WorkFlowConfigController : Controller
    {
        private readonly IWorkFlowConfigService workflowService;

        private readonly ILogger<WorkFlowConfigController> logger;

        public WorkFlowConfigController(IWorkFlowConfigService service, ILogger<WorkFlowConfigController> logger)
        {
            workflowService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllWorkFlows")]
        public IActionResult GetAllWorkFlows()
        {
            logger.LogInformation("GetAllWorkFlows");
            try
            {
                var workFlows = workflowService.GetAllWorkFlows();
                return Ok(new ApiOkResponse(workFlows));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllWorkFlows() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddWorkFlow")]
        public IActionResult AddWorkFlow([FromBody]WorkFlowConfigViewModel workFlowConfigViewModel)
        {
            logger.LogInformation("AddWorkFlow");
            try
            {
                workFlowConfigViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                workflowService.AddWorkFlow(workFlowConfigViewModel);
                return Ok(new ApiOkResponse(workFlowConfigViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddWorkFlow() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateWorkFlow")]
        public IActionResult UpdateWorkFlow([FromBody]WorkFlowConfigViewModel workFlowConfigViewModel)
        {
            logger.LogInformation("UpdateWorkFlow");
            try
            {
                workFlowConfigViewModel.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                workflowService.UpdateWorkFlow(workFlowConfigViewModel);
                return Ok(new ApiOkResponse(workFlowConfigViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateWorkFlow() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
