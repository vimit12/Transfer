﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class PaymentTermApprovalTrackerController : Controller
    {
        private readonly IPaymentTermApprovalTrackerService paymentTermApprovalTrackerService;

        private readonly ILogger<PaymentTermApprovalTrackerController> logger;

        public PaymentTermApprovalTrackerController(IPaymentTermApprovalTrackerService service, ILogger<PaymentTermApprovalTrackerController> logger)
        {
            this.paymentTermApprovalTrackerService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllPaymentTermApprovalTrackers")]
        public IActionResult GetAllPaymentTermApprovalTrackers()
        {
            logger.LogInformation("GetAllPaymentTermApprovalTrackers");
            try
            {
                var paymentTermApprovalTrackers = paymentTermApprovalTrackerService.GetAllPaymentTermApprovalTrackers();
                return Ok(new ApiOkResponse(paymentTermApprovalTrackers));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllPaymentTermApprovalTrackers() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetPaymentTermApprovalTrackerById")]
        public IActionResult GetPaymentTermApprovalTrackerById(int id)
        {
            try
            {
                logger.LogInformation("GetPaymentTermApprovalTrackerById");
                var paymentTermApprovalTracker = paymentTermApprovalTrackerService.GetPaymentTermApprovalTrackerById(id);
                return Ok(new ApiOkResponse(paymentTermApprovalTracker));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetPaymentTermApprovalTrackerById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddPaymentTermApprovalTracker")]
        public IActionResult AddPaymentTermApprovalTracker([FromBody]PaymentTermApprovalTrackerViewModel paymentTermApprovalTracker)
        {
            logger.LogInformation("AddPaymentTermApprovalTracker");
            try
            {
                paymentTermApprovalTracker.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                paymentTermApprovalTrackerService.AddPaymentTermApprovalTracker(paymentTermApprovalTracker);
                return Ok(new ApiOkResponse(paymentTermApprovalTracker));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddPaymentTermApprovalTracker() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdatePaymentTermApprovalTracker")]
        public IActionResult UpdatePaymentTermApprovalTracker([FromBody]PaymentTermApprovalTrackerViewModel paymentTermApprovalTracker)
        {
            logger.LogInformation("UpdatePaymentTermApprovalTracker", paymentTermApprovalTracker);
            try
            {
                var getPaymentTermApprovalTracker = paymentTermApprovalTrackerService.GetPaymentTermApprovalTrackerById(paymentTermApprovalTracker.PaymentTermApprovalTrackerId);
                if (getPaymentTermApprovalTracker == null)
                {
                    return NotFound("PaymentTermApprovalTracker not found.");
                }
                else
                {
                    paymentTermApprovalTracker.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    paymentTermApprovalTrackerService.UpdatePaymentTermApprovalTracker(paymentTermApprovalTracker);
                    return Ok(new ApiOkResponse(paymentTermApprovalTracker));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdatePaymentTermApprovalTracker() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
