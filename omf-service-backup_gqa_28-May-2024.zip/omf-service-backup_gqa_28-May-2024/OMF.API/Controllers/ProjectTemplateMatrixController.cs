﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OMF.API.Common;
using OMF.Business.Common;
using OMF.Business.Interfaces;
using OMF.Business.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OMF.API.Controllers
{
    [Route("api/omf/[controller]/[action]")]
    public class ProjectTemplateMatrixController : ControllerBase
    {
        private readonly IProjectTemplateMatrixService projectTemplateMatrixService;

        private readonly ILogger<ProjectTemplateMatrixController> logger;

        public ProjectTemplateMatrixController(IProjectTemplateMatrixService service, ILogger<ProjectTemplateMatrixController> logger)
        {
            this.projectTemplateMatrixService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetProjectTemplateMatrix")]
        public IActionResult GetProjectTemplateMatrix()
        {
            logger.LogInformation("GetApproversByCountry");
            try
            {
                var result = projectTemplateMatrixService.GetProjectTemplateMatrix();
                return Ok(new ApiOkResponse(result));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetApproversByCountry() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddProjectTemplateMatrix")]
        public IActionResult AddProjectTemplateMatrix([FromBody] ProjectTemplateMatrixViewModel model)
        {
            logger.LogInformation("AddApproverByCountry");
            try
            {
                // todo ..
                model.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                projectTemplateMatrixService.AddProjectTemplateMatrix(model);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddProjectTemplateMatrix() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateProjectTemplateMatrix")]
        public IActionResult UpdateProjectTemplateMatrix([FromBody] ProjectTemplateMatrixViewModel model)
        {
            logger.LogInformation("UpdateProjectTemplateMatrix", model);
            try
            {
                model.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                projectTemplateMatrixService.UpdateProjectTemplateMatrix(model);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateProjectTemplateMatrix() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetAllProjectTemplates")]
        public IActionResult GetAllProjectTemplates()
        {
            logger.LogInformation("GetAllProjectTemplates");
            try
            {
                var result = projectTemplateMatrixService.GetAllProjectTemplates();
                return Ok(new ApiOkResponse(result));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllProjectTemplates() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
