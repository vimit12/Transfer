﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class QuarterController : Controller
    {
        private readonly IQuarterService quarterService;

        private readonly ILogger<QuarterController> logger;

        public QuarterController(IQuarterService service, ILogger<QuarterController> logger)
        {
            this.quarterService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllQuarters")]
        public IActionResult GetAllQuarters()
        {
            logger.LogInformation("GetAllQuarters");
            try
            {
                var quarters = quarterService.GetAllQuarters();
                return Ok(new ApiOkResponse(quarters));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllQuarters() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetQuarterById")]
        public IActionResult GetQuarterById(int id)
        {
            try
            {
                logger.LogInformation("GetQuarterById");
                var quarter = quarterService.GetQuarterById(id);
                return Ok(new ApiOkResponse(quarter));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetQuarterById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet]
        [ActionName("GetCurrentQuarter")]
        public IActionResult GetCurrentQuarter()
        {
            try
            {
                logger.LogInformation("GetCurrentQuarter");
                var currentQuarter = quarterService.GetCurrentQuarter();
                return Ok(new ApiOkResponse(currentQuarter));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetCurrentQuarter() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}