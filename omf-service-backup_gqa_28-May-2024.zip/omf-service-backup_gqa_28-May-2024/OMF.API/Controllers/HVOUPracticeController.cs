﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class HVOUPracticeController : Controller
    {
        private readonly IHVOUPracticeService hvOUService;

        private readonly ILogger<HVOUPracticeController> logger;

        public HVOUPracticeController(IHVOUPracticeService service, ILogger<HVOUPracticeController> logger)
        {
            this.hvOUService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetActiveHVOUPractices")]
        public IActionResult GetActiveHVOUPractices()
        {
            logger.LogInformation("GetActiveHVOUPractices");
            try
            {
                var hvOUPractices = hvOUService.GetActiveHVOUPractices();
                return Ok(new ApiOkResponse(hvOUPractices));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveHVOUPractices() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveHVOUPracticeMappings")]
        public IActionResult GetActiveHVOUPracticeMappings()
        {
            logger.LogInformation("GetActiveHVOUPracticeMappings");
            try
            {
                var hvOUPracticeMappings = hvOUService.GetActiveHVOUPracticeMappings();
                return Ok(new ApiOkResponse(hvOUPracticeMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveHVOUPracticeMappings() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}