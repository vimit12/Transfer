﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ContractTypeController : Controller
    {
        private readonly IContractTypeService contractTypeService;

        private readonly ILogger<ContractTypeController> logger;

        public ContractTypeController(IContractTypeService service, ILogger<ContractTypeController> logger)
        {
            this.contractTypeService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllContractTypes")]
        public IActionResult GetAllContractTypes()
        {
            logger.LogInformation("GetAllContractTypes");
            try
            {
                var contractTypes = contractTypeService.GetAllContractTypes();
                return Ok(new ApiOkResponse(contractTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllContractTypes() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetContractTypeById")]
        public IActionResult GetContractTypeById(int id)
        {
            try
            {
                logger.LogInformation("GetContractTypeById");
                var contractType = contractTypeService.GetContractTypeById(id);
                return Ok(new ApiOkResponse(contractType));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetContractTypeById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddContractType")]
        public IActionResult AddContractType([FromBody]ContractTypeViewModel contractType)
        {
            logger.LogInformation("AddContractType");
            try
            {
                contractType.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                contractTypeService.AddContractType(contractType);
                return Ok(new ApiOkResponse(contractType));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddContractType() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateContractType")]
        public IActionResult UpdateContractType([FromBody]ContractTypeViewModel contractType)
        {
            logger.LogInformation("UpdateContractType", contractType);
            try
            {
                var getContractType = contractTypeService.GetContractTypeById(contractType.ContractTypeId);
                if (getContractType == null)
                {
                    return NotFound("ContractType not found.");
                }
                else
                {
                    contractType.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    contractTypeService.UpdateContractType(contractType);
                    return Ok(new ApiOkResponse(contractType));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateContractType() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveContractTypes")]
        public IActionResult GetActiveContractTypes()
        {
            logger.LogInformation("GetActiveContractTypes");
            try
            {
                var contractTypes = contractTypeService.GetActiveContractTypes();
                return Ok(new ApiOkResponse(contractTypes));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveContractTypes() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
