﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class HVContractingEntityController : Controller
    {
        private readonly IHVContractingEntity hvContractingEntityService;

        private readonly ILogger<HVContractingEntityController> logger;

        public HVContractingEntityController(IHVContractingEntity service, ILogger<HVContractingEntityController> logger)
        {
            this.hvContractingEntityService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllHVContractingEntities")]
        public IActionResult GetAllHVContractingEntities()
        {
            logger.LogInformation("GetAllHVContractingEntities");
            try
            {
                var entities = hvContractingEntityService.GetAllHVContractingEntities();
                return Ok(new ApiOkResponse(entities));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllHVContractingEntities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveHVContractingEntities")]
        public IActionResult GetActiveHVContractingEntities()
        {
            logger.LogInformation("GetActiveHVContractingEntities");
            try
            {
                var countries = hvContractingEntityService.GetActiveHVContractingEntities();
                return Ok(new ApiOkResponse(countries));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveHVContractingEntities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetHVContractingEntityById")]
        public IActionResult GetHVContractingEntityById(int id)
        {
            try
            {
                logger.LogInformation("GetHVContractingEntityById");
                var entity = hvContractingEntityService.GetHVContractingEntityById(id);
                return Ok(new ApiOkResponse(entity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetHVContractingEntityById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddHVContractingEntity")]
        public IActionResult AddHVContractingEntity([FromBody]HVContractingEntityViewModel hvContractingEntity)
        {
            logger.LogInformation("AddHVContractingEntity");
            try
            {
                hvContractingEntity.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                hvContractingEntityService.AddHVContractingEntity(hvContractingEntity);
                return Ok(new ApiOkResponse(hvContractingEntity));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddHVContractingEntity() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateHVContractingEntity")]
        public IActionResult UpdateHVContractingEntity([FromBody]HVContractingEntityViewModel hvContractingEntity)
        {
            logger.LogInformation("UpdateHVContractingEntity", hvContractingEntity);
            try
            {
                var getentity = hvContractingEntityService.GetHVContractingEntityById(hvContractingEntity.HVContractingEntityId);
                if (getentity == null)
                {
                    // logger.LogWarning("country is null", country);
                    return NotFound("Entity not found.");
                }
                else
                {
                    hvContractingEntity.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    hvContractingEntityService.UpdateHVContractingEntity(hvContractingEntity);
                    return Ok(new ApiOkResponse(hvContractingEntity));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateHVContractingEntity() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}