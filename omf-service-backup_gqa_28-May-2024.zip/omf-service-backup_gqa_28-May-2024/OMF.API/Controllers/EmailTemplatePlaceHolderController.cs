﻿namespace OMF.API.Controllers
{
    using System;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class EmailTemplatePlaceHolderController : Controller
    {
        private readonly IEmailTemplatePlaceHolderService emailTemplatePlaceHolderService;

        private readonly ILogger<EmailTemplatePlaceHolderController> logger;

        public EmailTemplatePlaceHolderController(IEmailTemplatePlaceHolderService service, ILogger<EmailTemplatePlaceHolderController> logger)
        {
            this.emailTemplatePlaceHolderService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetActivePlaceHolders")]
        public IActionResult GetActivePlaceHolders()
        {
            logger.LogInformation("GetActivePlaceHolders");
            try
            {
                var emailTemplatePlaceHolderViews = emailTemplatePlaceHolderService.GetActivePlaceHolders();
                return Ok(new ApiOkResponse(emailTemplatePlaceHolderViews));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActivePlaceHolders() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
