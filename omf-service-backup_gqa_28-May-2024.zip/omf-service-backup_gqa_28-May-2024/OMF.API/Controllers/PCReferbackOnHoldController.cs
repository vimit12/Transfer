﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;

    [Route("api/omf/[controller]/[action]")]
    public class PCReferbackOnHoldController : Controller
    {
        private readonly IPCReferbackOnHoldReasonService pcReferbackOnHoldService;

        private readonly ILogger<PCReferbackOnHoldController> logger;

        public PCReferbackOnHoldController(IPCReferbackOnHoldReasonService service, ILogger<PCReferbackOnHoldController> logger)
        {
            this.pcReferbackOnHoldService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllPCReferBackOnHoldReason")]
        public IActionResult GetAllPCReferBackOnHoldReason()
        {
            this.logger.LogInformation("GetAllPCReferBackOnHoldReason");
            try
            {
                var pcrb = this.pcReferbackOnHoldService.GetAllPCReferBackOnHoldReason();
                return this.Ok(new ApiOkResponse(pcrb));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllPCReferBackOnHoldReason() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActivePCReferBackOnHoldReason")]
        public IActionResult GetActivePCReferBackOnHoldReason()
        {
            this.logger.LogInformation("GetActivePCReferBackOnHoldReason");
            try
            {
                var pcrb = this.pcReferbackOnHoldService.GetActivePCReferBackOnHoldReason();
                return this.Ok(new ApiOkResponse(pcrb));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActivePCReferBackOnHoldReason() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetPCReferBackOnHoldReasonById")]
        public IActionResult GetPCReferBackOnHoldReasonById(int id)
        {
            this.logger.LogInformation("GetPCReferBackOnHoldReasonById");
            try
            {
                var pcrb = this.pcReferbackOnHoldService.GetPCReferBackOnHoldReasonById(id);
                return this.Ok(new ApiOkResponse(pcrb));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetPCReferBackOnHoldReasonById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddPCReferBackOnHoldReason")]
        public IActionResult AddPCReferBackOnHoldReason([FromBody]PCReferBackOnHoldReasonViewModel pcrb)
        {
            this.logger.LogInformation("AddPCReferBackOnHoldReason");
            try
            {
                pcrb.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.pcReferbackOnHoldService.AddPCReferBackOnHoldReason(pcrb);
                return this.Ok(new ApiOkResponse(pcrb));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddPCReferBackOnHoldReason() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdatePCReferBackOnHoldReason")]
        public IActionResult UpdatePCReferBackOnHoldReason([FromBody] PCReferBackOnHoldReasonViewModel pcrb)
        {
            this.logger.LogInformation("UpdatePCReferBackOnHoldReason", pcrb);
            try
            {
                var getRFF = this.pcReferbackOnHoldService.GetPCReferBackOnHoldReasonById(pcrb.PCReferBackOnHoldReasonId);
                if (getRFF == null)
                {
                    return this.NotFound("Type not found.");
                }
                else
                {
                    pcrb.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.pcReferbackOnHoldService.UpdatePCReferBackOnHoldReason(pcrb);
                    return this.Ok(new ApiOkResponse(pcrb));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdatePCReferBackOnHoldReason() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddPCReferBackOnHoldReasonByOpportunity")]
        public IActionResult AddPCReferBackOnHoldReasonByOpportunity([FromBody] PCReferBackOnHoldReasonByOpportunityViewModel rff)
        {
            this.logger.LogInformation("AddPCReferBackOnHoldReasonByOpportunity");
            try
            {
                //rff.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.pcReferbackOnHoldService.AddPCReferBackOnHoldReasonByOpportunity(rff);
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddPCReferBackOnHoldReasonByOpportunity() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetPCReferBackOnHoldReasonByOpportunityId")]
        public IActionResult GetPCReferBackOnHoldReasonByOpportunityId(int opportunityId)
        {
            this.logger.LogInformation("GetPCReferBackOnHoldReasonByOpportunityId");
            try
            {
                var rff = this.pcReferbackOnHoldService.GetPCReferBackOnHoldReasonByOpportunityId(opportunityId);
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetPCReferBackOnHoldReasonByOpportunityId() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}