﻿namespace OMF.API.Controllers
{
    using System;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class IFRS15CheckListController : Controller
    {
        private readonly IIFRS15CheckListService iFRS15CheckListService;

        private readonly ILogger<IFRS15CheckListController> logger;

        public IFRS15CheckListController(IIFRS15CheckListService service, ILogger<IFRS15CheckListController> logger)
        {
            this.iFRS15CheckListService = service;
            this.logger = logger;
        }

        [HttpPost]
        [ActionName("SaveIFRS15CheckList")]
        public IActionResult SaveIFRS15CheckList([FromBody] IFRS15CheckListViewModel ifrs)
        {
            logger.LogInformation("SaveIFRS15CheckList");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                iFRS15CheckListService.SaveIFRS15CheckList(ifrs);
                return Ok(new ApiOkResponse(ifrs));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveIFRS15CheckList() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetIFRS15CheckListByOpportunityId")]
        public IActionResult GetIFRS15CheckListByOpportunityId(int id)
        {
            try
            {
                logger.LogInformation("GetIFRS15CheckListByOpportunityId", id);
                return Ok(new ApiOkResponse(iFRS15CheckListService.GetIFRS15CheckListByOpportunityId(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetIFRS15CheckListByOpportunityId", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveIFRSRevenueTeamCheckList")]
        public IActionResult SaveIFRSRevenueTeamCheckList([FromBody] IFRSRevenueTeamCheckListViewModel ifrs)
        {
            logger.LogInformation("SaveIFRSRevenueTeamCheckList");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {
                iFRS15CheckListService.SaveIFRSRevenueTeamCheckList(ifrs);
                return Ok(new ApiOkResponse(ifrs));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveIFRSRevenueTeamCheckList() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetIFRSRevenueTeamCheckListByOppId")]
        public IActionResult GetIFRSRevenueTeamCheckListByOppId(int id)
        {
            try
            {
                logger.LogInformation("GetIFRSRevenueTeamCheckListByOppId", id);
                return Ok(new ApiOkResponse(iFRS15CheckListService.GetIFRSRevenueTeamCheckListByOppId(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetIFRSRevenueTeamCheckListByOppId", id);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{oppid}")]
        [ActionName("GetProjectMatrixTemplateByOppId")]
        public IActionResult GetProjectMatrixTemplateByOppId(int oppid)
        {
            try
            {
                logger.LogInformation("GetIFRSRevenueTeamCheckListByOppId", oppid);
                return Ok(new ApiOkResponse(iFRS15CheckListService.GetProjectMatrixTemplateByOppId(oppid)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetProjectMatrixTemplateByOppId", oppid);
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}