﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class RegionController : Controller
    {
        private readonly IRegionService regionService;

        private readonly ILogger<RegionController> logger;

        public RegionController(IRegionService service, ILogger<RegionController> logger)
        {
            this.regionService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetRegions")]
        public IActionResult GetAllRegions()
        {
            logger.LogInformation("GetRegions");
            try
            {
                var regions = regionService.GetAllRegions();
                return Ok(new ApiOkResponse(regions));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetRegions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveRegions")]
        public IActionResult GetActiveRegions()
        {
            logger.LogInformation("GetActiveRegions");
            try
            {
                var regions = regionService.GetActiveRegions();
                return Ok(new ApiOkResponse(regions));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveRegions() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetRegionById")]
        public IActionResult GetRegionById(int id)
        {
            try
            {
                logger.LogInformation("GetRegionById");
                var region = regionService.GetRegionById(id);
                return Ok(new ApiOkResponse(region));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetRegionById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddRegion")]
        public IActionResult AddRegion([FromBody]RegionViewModel region)
        {
            logger.LogInformation("AddRegion");
            try
            {
                region.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                regionService.AddRegion(region);
                return Ok(new ApiOkResponse(region));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddRegion() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateRegion")]
        public IActionResult UpdateRegion([FromBody]RegionViewModel region)
        {
            logger.LogInformation("UpdateRegion", region);
            try
            {
                var regionObj = regionService.GetRegionById(region.RegionId);
                if (regionObj == null)
                {
                    return NotFound("Region not found.");
                }
                else
                {
                    region.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    regionService.UpdateRegion(region);
                    return Ok(new ApiOkResponse(regionObj));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateRegion() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}