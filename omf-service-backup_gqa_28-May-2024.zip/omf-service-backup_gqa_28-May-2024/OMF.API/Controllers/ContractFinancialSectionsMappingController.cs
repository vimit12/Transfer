﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class ContractFinancialSectionsMappingController : Controller
    {
        private readonly IContractFinancialSectionsMappingService contractFinancialSectionsMappingService;

        private readonly ILogger<ContractFinancialSectionsMappingController> logger;

        public ContractFinancialSectionsMappingController(IContractFinancialSectionsMappingService service, ILogger<ContractFinancialSectionsMappingController> logger)
        {
            this.contractFinancialSectionsMappingService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllContractFinancialSections")]
        public IActionResult GetAllContractFinancialSections()
        {
            logger.LogInformation("GetAllContractFinancialSections");
            try
            {
                var contractFinancialSectionsMappings = contractFinancialSectionsMappingService.GetAllContractFinancialSections();
                return Ok(new ApiOkResponse(contractFinancialSectionsMappings));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllContractFinancialSections() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddContractFinancialSection")]
        public IActionResult AddContractFinancialSection([FromBody]IncludeSectionByContractTypeViewModel includeSectionByContractTypeViewModel)
        {
            logger.LogInformation("AddCapabilitySubCapability");
            try
            {
                includeSectionByContractTypeViewModel.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                contractFinancialSectionsMappingService.AddContractFinancialSection(includeSectionByContractTypeViewModel);
                return Ok(new ApiOkResponse(includeSectionByContractTypeViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddContractFinancialSection() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}