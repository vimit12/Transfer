﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OMF.API.Common;
using OMF.Business.Common;
using OMF.Business.Interfaces;
using OMF.Business.Models;

namespace OMF.API.Controllers
{
    [EnableCors("CorsPolicy")]
    [Route("api/omf/[controller]/[action]")]
    public class FinancialRoyaltyController : Controller
    {
        private readonly IFinancialRoyaltyService financialRoyaltyService;
        private readonly ILogger<FinancialRoyaltyController> logger;

        public FinancialRoyaltyController(IFinancialRoyaltyService service, ILogger<FinancialRoyaltyController> logger)
        {
            this.financialRoyaltyService = service;
            this.logger = logger;
        }

        [HttpGet("{opportunityId}/{yearId}")]
        [ActionName("GetFinancialRoyaltyDetails")]
        public IActionResult GetFinancialRoyaltyDetails(int opportunityId, int yearId)
        {
            try
            {
                logger.LogInformation("GetFinancialRoyaltyDetails");
                return Ok(new ApiOkResponse(financialRoyaltyService.GetFinancialRoyaltyDetails(opportunityId, yearId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetFinancialRoyaltyDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddNewOrUpdateRoyaltyDetails")]
        public IActionResult AddNewOrUpdateRoyaltyDetails([FromBody] List<FinancialRoyaltyDetailsViewModel> royaltyDetailsViewModel)
        {
            logger.LogInformation("AddNewOrUpdateRoyaltyDetails");
            try
            {
                financialRoyaltyService.AddNewOrUpdateRoyaltyDetails(royaltyDetailsViewModel, HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value);
                return Ok(new ApiOkResponse(royaltyDetailsViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddNewOrUpdateRoyaltyDetails() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("DeleteRoyaltyDetails")]
        public IActionResult DeleteRoyaltyDetails([FromBody] List<FinancialRoyaltyDetailsViewModel> financialRoyalty)
        {
            logger.LogInformation("DeleteRoyaltyDetails", financialRoyalty);
            try
            {
                logger.LogInformation("DeleteRoyaltyDetails");
                string errorMessage = string.Empty;
                financialRoyaltyService.DeleteRoyaltyDetails(financialRoyalty, ref errorMessage);
                return errorMessage == string.Empty ? Ok(new ApiOkResponse(financialRoyalty)) : (IActionResult)BadRequest(errorMessage);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "DeleteRoyaltyDetails");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}