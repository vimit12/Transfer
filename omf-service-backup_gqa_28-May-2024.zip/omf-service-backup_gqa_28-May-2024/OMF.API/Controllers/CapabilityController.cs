﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class CapabilityController : Controller
    {
        private readonly ICapabilityService capabilityService;

        private readonly ILogger<CapabilityController> logger;

        public CapabilityController(ICapabilityService service, ILogger<CapabilityController> logger)
        {
            this.capabilityService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllCapabilities")]
        public IActionResult GetCapabilities()
        {
            logger.LogInformation("GetAllCapabilities");
            try
            {
                var capabilities = capabilityService.GetCapabilities();
                return Ok(new ApiOkResponse(capabilities));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllCapabilities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveCapabilities")]
        public IActionResult GetActiveCapabilities()
        {
            logger.LogInformation("GetActiveCapabilities");
            try
            {
                var capabilities = capabilityService.GetActiveCapabilities();
                return Ok(new ApiOkResponse(capabilities));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveCapabilities() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // GET api/values/1
        [HttpGet("{id}")]
        [ActionName("GetCapabilitiesById")]
        public IActionResult GetCapabilitiesById(int id)
        {
            try
            {
                logger.LogInformation("GetCapabilitiesById");
                var capability = capabilityService.GetCapabilitiesById(id);
                return Ok(new ApiOkResponse(capability));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetCapabilitiesById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddCapability")]
        public IActionResult AddCapability([FromBody]CapabilityViewModel capability)
        {
            logger.LogInformation("AddCapability");
            try
            {
                capability.CreatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                capabilityService.AddCapability(capability);
                return Ok(new ApiOkResponse(capability));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddCapability() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [ActionName("UpdateCapability")]
        public IActionResult UpdateCapability([FromBody]CapabilityViewModel capability)
        {
            logger.LogInformation("UpdateCapability", capability);
            try
            {
                var getCapability = capabilityService.GetCapabilitiesById(capability.CapabilityId);
                if (getCapability == null)
                {
                    return NotFound(" Capability not found.");
                }
                else
                {
                    capability.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value;
                    capabilityService.UpdateCapability(capability);
                    return Ok(new ApiOkResponse(capability));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateCapability() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}