﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class OpportunityCRDetailsController : Controller
    {
        private readonly IOpportunityCRDetailsService opportunityCRDetailsService;

        private readonly ILogger<OpportunityCRDetailsController> logger;

        public OpportunityCRDetailsController(IOpportunityCRDetailsService opportunityCRDetailsService, ILogger<OpportunityCRDetailsController> logger)
        {
            this.logger = logger;
            this.opportunityCRDetailsService = opportunityCRDetailsService;
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetOpportunityCRDetails")]
        public IActionResult GetOpportunityCRDetails(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetOpportunityCRDetails", opportunityId);
                return Ok(new ApiOkResponse(opportunityCRDetailsService.GetOpportunityCRDetails(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOpportunityCRDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("SaveOrUpdateCRDetails")]
        public IActionResult SaveOrUpdateCRDetails([FromBody]OpportunityCRDetailsViewModel opportunityCRDetailsViewModel)
        {
            try
            {
                var model = opportunityCRDetailsService.SaveOrUpdateCRDetails(opportunityCRDetailsViewModel);
                return Ok(new ApiOkResponse(model));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveOrUpdateCRDetails() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

    }
}
