﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;

    [Route("api/omf/[controller]/[action]")]
    public class LineOfBusinessController : Controller
    {
        private readonly ILineOfBusinessService lineOfBusinessService;

        private readonly ILogger<LineOfBusinessController> logger;

        public LineOfBusinessController(ILineOfBusinessService service, ILogger<LineOfBusinessController> logger)
        {
            this.lineOfBusinessService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllLineOfBusinesses")]
        public IActionResult GetAllLineOfBusinesses()
        {
            this.logger.LogInformation("GetAllLineOfBusinesses");
            try
            {
                var lineOfBusinesses = this.lineOfBusinessService.GetAllLineOfBusinesses();
                return this.Ok(new ApiOkResponse(lineOfBusinesses));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllLineOfBusinesses() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveLineOfBusinesses")]
        public IActionResult GetActiveLineOfBusinesses()
        {
            this.logger.LogInformation("GetActiveLineOfBusinesses");
            try
            {
                var lineOfBusinesses = this.lineOfBusinessService.GetActiveLineOfBusinesses();
                return this.Ok(new ApiOkResponse(lineOfBusinesses));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActiveLineOfBusinesses() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetLineOfBusinessById")]
        public IActionResult GetLineOfBusinessById(int id)
        {
            this.logger.LogInformation("GetProjectDomainById");
            try
            {
                var lineOfBusinesses = this.lineOfBusinessService.GetLineOfBusinessById(id);
                return this.Ok(new ApiOkResponse(lineOfBusinesses));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetLineOfBusinessById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddLineOfBusiness")]
        public IActionResult AddLineOfBusiness([FromBody]LineOfBusinessViewModel lineOfBusiness)
        {
            this.logger.LogInformation("AddLineOfBusiness");
            try
            {
                lineOfBusiness.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.lineOfBusinessService.AddLineOfBusiness(lineOfBusiness);
                return this.Ok(new ApiOkResponse(lineOfBusiness));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddLineOfBusiness() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateLineOfBusiness")]
        public IActionResult UpdateLineOfBusiness([FromBody]LineOfBusinessViewModel lineOfBusiness)
        {
            this.logger.LogInformation("UpdateLineOfBusiness", lineOfBusiness);
            try
            {
                var getprojectDomain = this.lineOfBusinessService.GetLineOfBusinessById(lineOfBusiness.LineOfBusinessId);
                if (getprojectDomain == null)
                {
                    return this.NotFound("Employee Type not found.");
                }
                else
                {
                    lineOfBusiness.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.lineOfBusinessService.UpdateLineOfBusiness(lineOfBusiness);
                    return this.Ok(new ApiOkResponse(lineOfBusiness));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateLineOfBusiness() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}