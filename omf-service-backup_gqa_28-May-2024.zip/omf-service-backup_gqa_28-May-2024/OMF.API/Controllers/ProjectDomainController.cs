﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;

    [Route("api/omf/[controller]/[action]")]
    public class ProjectDomainController : Controller
    {
        private readonly IProjectDomainService projectDomainService;

        private readonly ILogger<ProjectDomainController> logger;

        public ProjectDomainController(IProjectDomainService service, ILogger<ProjectDomainController> logger)
        {
            this.projectDomainService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllProjectDomains")]
        public IActionResult GetAllProjectDomains()
        {
            this.logger.LogInformation("GetAllProjectDomains");
            try
            {
                var projectDomains = this.projectDomainService.GetAllProjectDomains();
                return this.Ok(new ApiOkResponse(projectDomains));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllProjectDomains() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveProjectDomain")]
        public IActionResult GetActiveProjectDomains()
        {
            this.logger.LogInformation("GetActiveProjectDomains");
            try
            {
                var projectDomains = this.projectDomainService.GetActiveProjectDomains();
                return this.Ok(new ApiOkResponse(projectDomains));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActiveProjectDomains() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetProjectDomainById")]
        public IActionResult GetProjectDomainById(int id)
        {
            this.logger.LogInformation("GetProjectDomainById");
            try
            {
                var projectDomain = this.projectDomainService.GetProjectDomainById(id);
                return this.Ok(new ApiOkResponse(projectDomain));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetProjectDomainById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddProjectDomain")]
        public IActionResult AddProjectDomain([FromBody]ProjectDomainViewModel projectDomain)
        {
            this.logger.LogInformation("AddProjectDomain");
            try
            {
                projectDomain.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.projectDomainService.AddProjectDomain(projectDomain);
                return this.Ok(new ApiOkResponse(projectDomain));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddProjectDomain() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateProjectDomain")]
        public IActionResult UpdateProjectDomain([FromBody]ProjectDomainViewModel projectDomain)
        {
            this.logger.LogInformation("UpdateProjectDomain", projectDomain);
            try
            {
                var getprojectDomain = this.projectDomainService.GetProjectDomainById(projectDomain.ProjectDomainId);
                if (getprojectDomain == null)
                {
                    return this.NotFound("Employee Type not found.");
                }
                else
                {
                    projectDomain.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.projectDomainService.UpdateProjectDomain(projectDomain);
                    return this.Ok(new ApiOkResponse(projectDomain));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateProjectDomain() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}