﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;

    [Route("api/omf/[controller]/[action]")]
    [ApiController]
    public class ITOSolutionController : Controller
    {
        private readonly ILogger<ITOSolutionController> logger;
        private readonly IITOSolutionService iTOSolution;

        public ITOSolutionController(IITOSolutionService service, ILogger<ITOSolutionController> logger)
        {
            this.iTOSolution = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllITOSolutions")]
        public IActionResult GetAllITOSolutions()
        {
            this.logger.LogInformation("GetAllITOSolutions");
            try
            {
                var ito = this.iTOSolution.GetAllITOSolutions();
                return this.Ok(new ApiOkResponse(ito));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllITOSolutions() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveITOSolutions")]
        public IActionResult GetActiveITOSolutions()
        {
            this.logger.LogInformation("GetActiveITOSolutions");
            try
            {
                var itos = this.iTOSolution.GetActiveITOSolutions();
                return this.Ok(new ApiOkResponse(itos));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActiveITOSolutions() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetITOSolutionById")]
        public IActionResult GetITOSolutionById(int id)
        {
            this.logger.LogInformation("GetITOSolutionById");
            try
            {
                var itos = this.iTOSolution.GetITOSolutionById(id);
                return this.Ok(new ApiOkResponse(itos));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetITOSolutionById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddITOSolution")]
        public IActionResult AddITOSolution([FromBody]ITOSolutionViewModel ito)
        {
            this.logger.LogInformation("AddITOSolution");
            try
            {
                ito.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.iTOSolution.AddITOSolution(ito);
                return this.Ok(new ApiOkResponse(ito));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddITOSolution() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateITOSolution")]
        public IActionResult UpdateITOSolution([FromBody]ITOSolutionViewModel ito)
        {
            this.logger.LogInformation("UpdateITOSolution", ito);
            try
            {
                var getITOSolution = this.iTOSolution.GetITOSolutionById(ito.ITOSolutionId);
                if (getITOSolution == null)
                {
                    return this.NotFound("Type not found.");
                }
                else
                {
                    ito.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.iTOSolution.UpdateITOSolution(ito);
                    return this.Ok(new ApiOkResponse(ito));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateITOSolution() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}