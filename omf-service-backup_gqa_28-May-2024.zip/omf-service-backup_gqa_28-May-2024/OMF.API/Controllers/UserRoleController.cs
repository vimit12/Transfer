﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class UserRoleController : Controller
    {
        private readonly IUserRoleService userRoleService;

        private readonly ILogger<UserRoleController> logger;

        public UserRoleController(IUserRoleService service, ILogger<UserRoleController> logger)
        {
            this.userRoleService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetUserRoles")]
        public IActionResult GetUserRoles()
        {
            logger.LogInformation("GetUserRoles");
            try
            {
                var userRoles = userRoleService.GetUserRoles();
                return Ok(new ApiOkResponse(userRoles));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetUserRoles() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetUserRolesDetails")]
        public IActionResult GetUserRolesDetails()
        {
            logger.LogInformation("GetUserRolesDetails");
            try
            {
                var userRoles = userRoleService.GetUserRolesDetails();
                return Ok(new ApiOkResponse(userRoles));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetUserRolesDetails() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddUserRole")]
        public IActionResult AddUserRole([FromBody]UserRoleViewModel userRole)
        {
            logger.LogInformation("AddUserRole");
            try
            {
                userRole.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                userRoleService.AddUserRole(userRole);
                return Ok(new ApiOkResponse(userRole));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddUserRole() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateUserRole")]
        public IActionResult UpdateUserRole([FromBody]UserRoleViewModel userRole)
        {
            logger.LogInformation("UpdateUserRole", userRole);
            try
            {
                userRole.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                userRoleService.UpdateUserRole(userRole);
                return Ok(new ApiOkResponse(userRole));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateUserRole() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetUserRolesForApproval")]
        public IActionResult GetUserRolesForApproval()
        {
            logger.LogInformation("GetUserRolesForApproval");
            try
            {
                var userRoles = userRoleService.GetUserRolesForApproval();
                return Ok(new ApiOkResponse(userRoles));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetUserRoles() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetOICUsers")]
        public IActionResult GetOICUsers()
        {
            logger.LogInformation("GetUserRoles");
            try
            {
                var userRoles = userRoleService.GetOICUsers();
                return Ok(new ApiOkResponse(userRoles));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetOICUsers() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetComplianceUserList")]
        public IActionResult GetComplianceUserList()
        {
            logger.LogInformation("GetComplianceUserList");
            try
            {
                var userRoles = userRoleService.GetComplianceUserList();
                return Ok(new ApiOkResponse(userRoles));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetComplianceUserList() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{name}")]
        [ActionName("GetUserSearch")]
        public IActionResult GetUserSearch(string name)
        {
            logger.LogInformation("GetUserSearch");
            try
            {
                var users = userRoleService.GetUserSearch(name);
                return Ok(new ApiOkResponse(users));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetUserSearch() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetIFRSUserList")]
        public IActionResult GetIFRSUserList()
        {
            logger.LogInformation("GetIFRSUserList");
            try
            {
                var userRoles = userRoleService.GetIFRSUserList();
                return Ok(new ApiOkResponse(userRoles));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetIFRSUserList() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
