﻿namespace OMF.API.Controllers
{
    using System;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class UserRegistrationRequestController : Controller
    {
        private readonly IUserRegistrationRequestService userRegistrationRequestService;

        private readonly ILogger<UserRegistrationRequestController> logger;

        public UserRegistrationRequestController(IUserRegistrationRequestService userRegRequestservice, ILogger<UserRegistrationRequestController> logger)
        {
            this.userRegistrationRequestService = userRegRequestservice;
            this.logger = logger;
        }

        [HttpPost]
        [ActionName("CreateUserRegistrationRequest")]
        public IActionResult CreateUserRegistrationRequest([FromBody] UserRegistrationRequestViewModel userRegViewModel)
        {
            logger.LogInformation("CreateUserRegistrationRequest");
            try
            {
                if (userRegViewModel != null)
                {
                    var checkUsernameorEmailExist = userRegistrationRequestService.CheckExistingEmailorUsername(userRegViewModel, out string errorMessage);
                    if (checkUsernameorEmailExist)
                    {
                        return Ok(new ApiOkResponse(errorMessage));
                    }

                    userRegistrationRequestService.CreateUserRegistrationRequest(userRegViewModel);
                    return Ok(new ApiOkResponse(userRegViewModel));
                }
                else
                {
                    return BadRequest(Constants.PageErrorMessage);
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "CreateUserRegistrationRequest() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{username}/{email}")]
        [ActionName("CheckDuplicateUsernameorEmail")]
        public IActionResult CheckDuplicateUsernameorEmail(string username, string email)
        {
            string retVal = string.Empty;
            logger.LogInformation("CheckDuplicateUsernameorEmail");
            try
            {
                if (!string.IsNullOrWhiteSpace(username) || !string.IsNullOrWhiteSpace(email))
                {
                    var isUsernameorEmailexist = userRegistrationRequestService.CheckDuplicateUsernameorEmail(username, email, out string errorMessage);
                    if (isUsernameorEmailexist)
                    {
                        retVal = errorMessage;
                    }

                    return Ok(new ApiOkResponse(retVal));
                }
                else
                {
                    return BadRequest(Constants.PageErrorMessage);
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "CheckDuplicateUsernameorEmail() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
