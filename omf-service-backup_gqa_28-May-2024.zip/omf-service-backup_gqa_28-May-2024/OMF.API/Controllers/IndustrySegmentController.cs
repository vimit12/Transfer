﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class IndustrySegmentController : Controller
    {
        private readonly IIndustrySegmentService industrySegmentService;

        private readonly ILogger<IndustrySegmentController> logger;

        public IndustrySegmentController(IIndustrySegmentService service, ILogger<IndustrySegmentController> logger)
        {
            this.industrySegmentService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllIndustrySegments")]
        public IActionResult GetAllIndustrySegments()
        {
            logger.LogInformation("GetAllIndustrySegments");
            try
            {
                var industrySegments = industrySegmentService.GetAllIndustrySegments();
                return Ok(new ApiOkResponse(industrySegments));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllIndustrySegments() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetIndustrySegmentById")]
        public IActionResult GetIndustrySegmentById(int id)
        {
            try
            {
                logger.LogInformation("GetIndustrySegmentById");
                var industrySegment = industrySegmentService.GetIndustrySegmentById(id);
                return Ok(new ApiOkResponse(industrySegment));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetIndustrySegmentById() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddIndustrySegment")]
        public IActionResult AddIndustrySegment([FromBody]IndustrySegmentViewModel industrySegment)
        {
            logger.LogInformation("AddIndustrySegment");
            try
            {
                industrySegment.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                industrySegmentService.AddIndustrySegment(industrySegment);
                return Ok(new ApiOkResponse(industrySegment));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "AddIndustrySegment() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateIndustrySegment")]
        public IActionResult UpdateIndustrySegment([FromBody]IndustrySegmentViewModel industrySegment)
        {
            logger.LogInformation("UpdateIndustrySegment", industrySegment);
            try
            {
                var getIndustrySegment = industrySegmentService.GetIndustrySegmentById(industrySegment.IndustrySegmentId);
                if (getIndustrySegment == null)
                {
                    return NotFound("IndustrySegment not found.");
                }
                else
                {
                    industrySegment.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    industrySegmentService.UpdateIndustrySegment(industrySegment);
                    return Ok(new ApiOkResponse(industrySegment));
                }
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "UpdateCountry() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveIndustrySegments")]
        public IActionResult GetActiveIndustrySegments()
        {
            logger.LogInformation("GetActiveIndustrySegments");
            try
            {
                var industrySegments = industrySegmentService.GetActiveIndustrySegments();
                return Ok(new ApiOkResponse(industrySegments));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetActiveIndustrySegments() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetAllIndustrySegmentsWithSubSegments")]
        public IActionResult GetAllIndustrySegmentsWithSubSegments()
        {
            logger.LogInformation("GetAllIndustrySegmentsWithSubSegments");
            try
            {
                var industrySegments = industrySegmentService.GetAllIndustrySegmentsWithSubSegments();
                return Ok(new ApiOkResponse(industrySegments));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetAllIndustrySegmentsWithSubSegments() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
