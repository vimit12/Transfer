﻿namespace OMF.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [EnableCors("CorsPolicy")]
    [Route("api/omf/[controller]/[action]")]
    public class OpportunityCreditAssessmentController : Controller
    {
        private readonly IOpportunityCreditAssessmentService creditCheckService;

        private readonly ILogger<OpportunityCreditAssessmentController> logger;

        public OpportunityCreditAssessmentController(IOpportunityCreditAssessmentService service, ILogger<OpportunityCreditAssessmentController> logger)
        {
            this.creditCheckService = service;
            this.logger = logger;
        }

        [HttpPost]
        [ActionName("SaveCreditAssessment")]
        public IActionResult SaveCreditAssessment([FromBody] OpportunityCreditAssessmentViewModel creditAssessmentViewModel)
        {
            logger.LogInformation("SaveCreditAssessment");
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            try
            {

                creditCheckService.SaveCreditAssessment(creditAssessmentViewModel);
                return Ok(new ApiOkResponse(creditAssessmentViewModel));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "SaveCreditAssessment() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetCreditAssessmentDetails")]
        public IActionResult GetCreditAssessmentDetails(int opportunityId)
        {
            try
            {
                logger.LogInformation("GetCreditAssessmentDetails", opportunityId);
                return Ok(new ApiOkResponse(creditCheckService.GetCreditAssessmentDetails(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetCreditAssessmentDetails", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}/{approvers}")]
        [ActionName("GetDefaultCCJourneyForOpportunity")]
        public IActionResult GetDefaultCCJourneyForOpportunity(int opportunityId, int approvers)
        {
            try
            {
                logger.LogInformation("GetDefaultCCJourneyForOpportunity", opportunityId);
                return Ok(new ApiOkResponse(creditCheckService.GetDefaultCCJourneyForOpportunity(opportunityId, approvers)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetDefaultCCJourneyForOpportunity", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }
        [HttpGet("{opportunityId}/{approvers}")]
        [ActionName("GetApprovers")]
        public IActionResult GetApprovers(int opportunityId, int approvers)
        {
            try
            {
                logger.LogInformation("GetApprovers", opportunityId);
                return Ok(new ApiOkResponse(creditCheckService.GetApprovers(opportunityId, approvers)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetApprovers", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }
        [HttpGet]
        [ActionName("GetCCWorkFlowActionsByStatus")]
        public IActionResult GetCCWorkFlowActionsByStatus(WorkFlowActionsViewModel workFlowActionsViewModel)
        {
            try
            {
                logger.LogInformation("GetCCWorkFlowActionsByStatus", workFlowActionsViewModel);
                workFlowActionsViewModel.UpdatedBy = string.IsNullOrWhiteSpace(workFlowActionsViewModel.UpdatedBy) ? HttpContext.User.Claims.FirstOrDefault(x => x.Type == Constants.User.Alias).Value : workFlowActionsViewModel.UpdatedBy;
                var response = creditCheckService.GetCCWorkFlowActionsByStatus(workFlowActionsViewModel);
                return Ok(new ApiOkResponse(response));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetCCWorkFlowActionsByStatus", workFlowActionsViewModel);
                return BadRequest(Constants.PageErrorMessage);
            }
        }
        [HttpGet("{id}")]
        [ActionName("GetCCWorkFlowJourneyForOpportunity")]
        public IActionResult GetCCWorkFlowJourneyForOpportunity(int id)
        {
            logger.LogInformation("GetCCWorkFlowJourneyForOpportunity");
            try
            {
                var oMFJourney = creditCheckService.GetCCWorkFlowJourneyForOpportunity(id);
                return Ok(new ApiOkResponse(oMFJourney));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetCCWorkFlowJourneyForOpportunity() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
        [HttpPut]
        [ActionName("UpdateCCNextStatus")]
        public IActionResult UpdateCCNextStatus([FromBody] WorkFlowActionViewModel oRBWorkFlowView)
        {
            try
            {
                logger.LogInformation("UpdateORBNextStatus");
                var result = creditCheckService.UpdateCCNextStatus(oRBWorkFlowView);               
                return this.Ok(new ApiOkResponse(result));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateCCNextStatus() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }
        private bool CheckWorkFlowAutoProgressPossibility(int opportunityId)
        {
            var autoActions = creditCheckService.CheckWorkFlowAutoProgressPossibility(opportunityId);
            return autoActions == null ? false : true;
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetCreditCheckCurrentStatus")]
        public IActionResult GetCreditCheckCurrentStatus(int opportunityId)
        {
            logger.LogInformation("GetCreditCheckCurrentStatus");
            try
            {
                var ccStatus = creditCheckService.GetCreditCheckCurrentStatus(opportunityId);
                return Ok(new ApiOkResponse(ccStatus));
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "GetCreditCheckCurrentStatus() - Exception");
                return BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("CheckCCApprovalRequired")]
        public IActionResult CheckCCApprovalRequired(int opportunityId)
        {
            try
            {
                logger.LogInformation("CheckCCApprovalRequired", opportunityId);
                return Ok(new ApiOkResponse(creditCheckService.CheckCCApprovalRequired(opportunityId)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "CheckCCApprovalRequired", opportunityId);
                return BadRequest(Constants.PageErrorMessage);
            }
        }

    }
}