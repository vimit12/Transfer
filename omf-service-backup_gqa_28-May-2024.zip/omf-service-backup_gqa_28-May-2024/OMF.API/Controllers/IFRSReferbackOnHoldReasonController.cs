﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;

    [Route("api/omf/[controller]/[action]")]
    public class IFRSReferbackOnHoldReasonController : Controller
    {
        private readonly IIFRSReferbackOnHoldReasonService ifrsReferbackOnHoldService;

        private readonly ILogger<IFRSReferbackOnHoldReasonController> logger;

        public IFRSReferbackOnHoldReasonController(IIFRSReferbackOnHoldReasonService service, ILogger<IFRSReferbackOnHoldReasonController> logger)
        {
            this.ifrsReferbackOnHoldService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllIFRSReferBackOnHoldReason")]
        public IActionResult GetAllIFRSReferBackOnHoldReason()
        {
            this.logger.LogInformation("GetAllIFRSReferBackOnHoldReason");
            try
            {
                var rff = this.ifrsReferbackOnHoldService.GetAllIFRSReferBackOnHoldReason();
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllIFRSReferBackOnHoldReason() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveIFRSReferBackOnHoldReason")]
        public IActionResult GetActiveIFRSReferBackOnHoldReason()
        {
            this.logger.LogInformation("GetActiveIFRSReferBackOnHoldReason");
            try
            {
                var rff = this.ifrsReferbackOnHoldService.GetActiveIFRSReferBackOnHoldReason();
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActiveIFRSReferBackOnHoldReason() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetIFRSReferBackOnHoldReasonById")]
        public IActionResult GetIFRSReferBackOnHoldReasonById(int id)
        {
            this.logger.LogInformation("GetIFRSReferBackOnHoldReasonById");
            try
            {
                var rff = this.ifrsReferbackOnHoldService.GetIFRSReferBackOnHoldReasonById(id);
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetIFRSReferBackOnHoldReasonById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddIFRSReferBackOnHoldReason")]
        public IActionResult AddIFRSReferBackOnHoldReason([FromBody]IFRSReferBackOnHoldReasonViewModel rff)
        {
            this.logger.LogInformation("AddIFRSReferBackOnHoldReason");
            try
            {
                rff.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.ifrsReferbackOnHoldService.AddIFRSReferBackOnHoldReason(rff);
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddIFRSReferBackOnHoldReason() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateIFRSReferBackOnHoldReason")]
        public IActionResult UpdateIFRSReferBackOnHoldReason([FromBody] IFRSReferBackOnHoldReasonViewModel rff)
        {
            this.logger.LogInformation("UpdateIFRSReferBackOnHoldReason", rff);
            try
            {
                var getRFF = this.ifrsReferbackOnHoldService.GetIFRSReferBackOnHoldReasonById(rff.IFRSReferBackOnHoldReasonId);
                if (getRFF == null)
                {
                    return this.NotFound("Type not found.");
                }
                else
                {
                    rff.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.ifrsReferbackOnHoldService.UpdateIFRSReferBackOnHoldReason(rff);
                    return this.Ok(new ApiOkResponse(rff));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateIFRSReferBackOnHoldReason() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddIFRSReferBackOnHoldReasonByOpportunity")]
        public IActionResult AddIFRSReferBackOnHoldReasonByOpportunity([FromBody] IFRSReferBackOnHoldReasonByOpportunityViewModel rff)
        {
            this.logger.LogInformation("AddIFRSReferBackOnHoldReasonByOpportunity");
            try
            {
                //rff.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.ifrsReferbackOnHoldService.AddIFRSReferBackOnHoldReasonByOpportunity(rff);
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddIFRSReferBackOnHoldReasonByOpportunity() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{opportunityId}")]
        [ActionName("GetIFRSReferBackOnHoldReasonByOpportunityId")]
        public IActionResult GetIFRSReferBackOnHoldReasonByOpportunityId(int opportunityId)
        {
            this.logger.LogInformation("GetIFRSReferBackOnHoldReasonByOpportunityId");
            try
            {
                var rff = this.ifrsReferbackOnHoldService.GetIFRSReferBackOnHoldReasonByOpportunityId(opportunityId);
                return this.Ok(new ApiOkResponse(rff));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetIFRSReferBackOnHoldReasonByOpportunityId() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}