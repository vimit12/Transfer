﻿namespace OMF.API.Controllers
{
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using OMF.API.Common;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;

    [Route("api/omf/[controller]/[action]")]
    public class EmployeeTypeController : Controller
    {
        private readonly IEmployeeTypeService employeeTypeService;

        private readonly ILogger<EmployeeTypeController> logger;

        public EmployeeTypeController(IEmployeeTypeService service, ILogger<EmployeeTypeController> logger)
        {
            this.employeeTypeService = service;
            this.logger = logger;
        }

        [HttpGet]
        [ActionName("GetAllEmployeeTypes")]
        public IActionResult GetEmployeeTypes()
        {
            this.logger.LogInformation("GetAllEmployeeTypes");
            try
            {
                var employeeTypes = this.employeeTypeService.GetEmployeeTypes();
                return this.Ok(new ApiOkResponse(employeeTypes));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetAllEmployeeTypes() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet]
        [ActionName("GetActiveEmployeeType")]
        public IActionResult GetActiveEmployeeTypes()
        {
            this.logger.LogInformation("GetActiveEmployeeTypes");
            try
            {
                var employeeTypes = this.employeeTypeService.GetActiveEmployeeTypes();
                return this.Ok(new ApiOkResponse(employeeTypes));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetActiveEmployeeTypes() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpGet("{id}")]
        [ActionName("GetEmployeeTypeById")]
        public IActionResult GetEmployeeTypeById(int id)
        {
            this.logger.LogInformation("GetEmployeeTypeById");
            try
            {
                var employeetype = this.employeeTypeService.GetEmployeeTypeById(id);
                return this.Ok(new ApiOkResponse(employeetype));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "GetEmployeeTypeById() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPost]
        [ActionName("AddEmployeeType")]
        public IActionResult AddEmployeeType([FromBody]EmployeeTypeViewModel employeeType)
        {
            this.logger.LogInformation("AddEmployeeType");
            try
            {
                employeeType.CreatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                this.employeeTypeService.AddEmployeeType(employeeType);
                return this.Ok(new ApiOkResponse(employeeType));
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "AddEmployeeType() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }

        [HttpPut]
        [ActionName("UpdateEmployeeType")]
        public IActionResult UpdateEmployeeType([FromBody]EmployeeTypeViewModel employee)
        {
            this.logger.LogInformation("UpdateEmployeeType", employee);
            try
            {
                var getemployeetype = this.employeeTypeService.GetEmployeeTypeById(employee.EmployeeTypeId);
                if (getemployeetype == null)
                {
                    return this.NotFound("Employee Type not found.");
                }
                else
                {
                    employee.UpdatedBy = HttpContext.User.Claims.FirstOrDefault(user => user.Type == Constants.User.Alias).Value;
                    this.employeeTypeService.UpdateEmployeeType(employee);
                    return this.Ok(new ApiOkResponse(employee));
                }
            }
            catch (Exception exception)
            {
                this.logger.LogError(exception, "UpdateEmployeeType() - Exception");
                return this.BadRequest(Constants.PageErrorMessage);
            }
        }
    }
}
