﻿namespace OMF.API.Common
{
    using Microsoft.AspNetCore.Builder;

    public static class TokenAuthenticationMiddlewareExtension
    {
        public static IApplicationBuilder UseTokenAuthentication(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<TokenAuthenticationMiddleware>();
        }

        //public static IApplicationBuilder UseHttpsEnforcement(this IApplicationBuilder builder)
        //{
        //    return builder.UseMiddleware<EnforceHttpsMiddleware>();
        //}
    }
}
