﻿namespace OMF.API.Common
{
    using System.Diagnostics.CodeAnalysis;

    [SuppressMessage("StyleCop.CSharp.NamingRules", "SA1300:ElementMustBeginWithUpperCaseLetter", Justification = "Reviewed.")]
    public class UserIdentity
    {
        public string exp { get; set; }

        public string user_name { get; set; }

        public string client_id { get; set; }

        public string[] scope { get; set; }
    }
}
