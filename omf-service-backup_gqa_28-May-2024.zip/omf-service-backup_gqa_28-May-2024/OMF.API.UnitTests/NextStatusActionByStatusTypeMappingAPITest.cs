﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class NextStatusActionByStatusTypeMappingAPITest : UnitTestBase
    {
        private static NextStatusActionByStatusTypeMappingController NextStatusActionByStatusTypeMappingController;
        private static NextStatusActionByStatusTypeMappingService NextStatusActionByStatusTypeMappingService;
        private static Mock<ILogger<NextStatusActionByStatusTypeMappingController>> logger;
        private static OpportunityAPITest oppTest;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            NextStatusActionByStatusTypeMappingService = new NextStatusActionByStatusTypeMappingService(Repository, Mapper);
            logger = new Mock<ILogger<NextStatusActionByStatusTypeMappingController>>();
            NextStatusActionByStatusTypeMappingController = new NextStatusActionByStatusTypeMappingController(NextStatusActionByStatusTypeMappingService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
            oppTest = new OpportunityAPITest();
            OpportunityAPITest.ClassInitialize(context);
        }

        [TestInitialize]
        public void TestInitialize()
        {
            prepareData();
        }

        [TestMethod]
        public void GetAllNextStatusActions()
        {
            var getAllNextStatusActions = NextStatusActionByStatusTypeMappingController.GetAllNextStatusActions();
            Assert.IsNotNull(getAllNextStatusActions);

            var result = (OkObjectResult)getAllNextStatusActions;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);
            
            var actions = (IEnumerable<NextStatusActionByStatusTypeMappingViewModel>)response.Result;
            Assert.IsTrue(actions.Any(x => x.NextStatusActionByStatusTypeMappingId == 1));
        }

        [TestMethod]
        public void GetActiveNextStatusActions()
        {
            var getAllNextStatusActions = NextStatusActionByStatusTypeMappingController.GetActiveNextStatusActions(1);
            Assert.IsNotNull(getAllNextStatusActions);

            var result = (OkObjectResult)getAllNextStatusActions;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var actions = (IEnumerable<NextStatusActionByStatusTypeMappingViewModel>)response.Result;
            Assert.IsTrue(actions.Any(x => x.NextStatusActionByStatusTypeMappingId == 2));
        }

        //[TestMethod]
        //public void AddNextStatusAction()
        //{
        //    var model = new NextStatusActionByStatusTypeMappingViewModel
        //    {
        //        NextStatusActionByStatusTypeMappingId = 0,
        //        StatusActionId = 1,
        //        StatusId = 1,
        //        IsActive = true,

        //    };

        //    var add = NextStatusActionByStatusTypeMappingController.AddNextStatusAction(model);
        //    Assert.IsNotNull(add);

        //    var result = (OkObjectResult)add;
        //    Assert.AreEqual(200, result.StatusCode);
        //}

        private void prepareData()
        {
            oppTest.TestInitialize();
            //oppTest.SaveInfoCompliance();
            var statusType = CreateStatusType();
            Repository.Repository<StatusType>().DeleteRange(Repository.Repository<StatusType>().GetAll());
            Repository.Repository<StatusType>().Add(statusType);
            Repository.SaveChanges();

            var statusAction = new StatusAction()
            {
                StatusActionId = 1,
                StatusActionText = "Test Action",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                Action = "Test Action",
                IsActive = true
            };

            Repository.Repository<StatusAction>().DeleteRange(Repository.Repository<StatusAction>().GetAll());
            Repository.Repository<StatusAction>().Add(statusAction);
            Repository.SaveChanges();

            var mapping = new NextStatusActionByStatusTypeMapping
            {
                NextStatusActionByStatusTypeMappingId = 1,
                StatusActionId = 1,
                StatusTypeId = 1,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true,

            };
            var newMapping = new NextStatusActionByStatusTypeMapping
            {
                NextStatusActionByStatusTypeMappingId = 2,
                StatusActionId = 1,
                StatusTypeId = 14,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true,

            };
            Repository.Repository<NextStatusActionByStatusTypeMapping>().DeleteRange(Repository.Repository<NextStatusActionByStatusTypeMapping>().GetAll());
            Repository.Repository<NextStatusActionByStatusTypeMapping>().Add(mapping);
            Repository.Repository<NextStatusActionByStatusTypeMapping>().Add(newMapping);
            Repository.SaveChanges();
        }
    }
}
