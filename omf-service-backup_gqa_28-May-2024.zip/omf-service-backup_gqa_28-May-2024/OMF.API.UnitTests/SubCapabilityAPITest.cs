﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class SubCapabilityAPITest : UnitTestBase
    {
        private static SubCapabilityController subCapabilityController;
        private static SubCapabilityService SubCapabilityService;
        private static SubCapabilityViewModel SubCapabilityViewModel;
        private static Mock<ILogger<SubCapabilityController>> logger;
        private List<SubCapabilityViewModel> subCapabilityList = new List<SubCapabilityViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            SubCapabilityService = new SubCapabilityService(Repository, Mapper);
            logger = new Mock<ILogger<SubCapabilityController>>();
            subCapabilityController = new SubCapabilityController(SubCapabilityService, logger.Object);
            Repository.Repository<SubCapability>().DeleteRange(Repository.Repository<SubCapability>().GetAll());

            subCapabilityController = new SubCapabilityController(SubCapabilityService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var subCapabilities = subCapabilityController.GetSubCapabilities();
            Assert.IsNotNull(subCapabilities);

            var result = (OkObjectResult)subCapabilities;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<SubCapabilityViewModel>)response.Result;

            if (getData.Count > 0)
            {
                subCapabilityList = getData;
            }
            else
            {
                SubCapabilityViewModel = new SubCapabilityViewModel
                {
                    SubCapabilityId = new Random().Next(1, randomInterval),
                    SubCapabilityName = "Sub Capability",
                    IsActive = true
                };

                var subCapability = subCapabilityController.AddSubCapability(SubCapabilityViewModel);
                subCapabilityList.Add(SubCapabilityViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            SubCapabilityViewModel = null;
            subCapabilityList = null;
        }

        [TestMethod]
        public void GetActiveSubCapabilities()
        {
            var getActiveSubCapabilities = subCapabilityController.GetActiveSubCapabilities();
            Assert.IsNotNull(getActiveSubCapabilities);

            var result = (OkObjectResult)getActiveSubCapabilities;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetSubCapabilities()
        {
            var subCapabilities = subCapabilityController.GetSubCapabilities();
            Assert.IsNotNull(subCapabilities);

            var result = (OkObjectResult)subCapabilities;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetSubCapabilitiesById()
        {
            var getSubCapability = subCapabilityController.GetSubCapabilitiesById(subCapabilityList.FirstOrDefault().SubCapabilityId);
            Assert.IsNotNull(getSubCapability);

            var result = (OkObjectResult)getSubCapability;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddSubCapability()
        {
            SubCapabilityViewModel = new SubCapabilityViewModel
            {
                SubCapabilityId = new Random().Next(1, randomInterval),
                SubCapabilityName = "Sub Capability",
                IsActive = true,
            };

            var createdsubCapability = subCapabilityController.AddSubCapability(SubCapabilityViewModel);
            Assert.IsNotNull(createdsubCapability);

            var result = (OkObjectResult)createdsubCapability;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getSubCapabilities = subCapabilityController.GetSubCapabilities();
            Assert.IsNotNull(getSubCapabilities);

            var getResult = (OkObjectResult)getSubCapabilities;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var subCapabilityList = (List<SubCapabilityViewModel>)getResponse.Result;
            Assert.IsTrue(subCapabilityList.Any(e => e.SubCapabilityName == SubCapabilityViewModel.SubCapabilityName));
        }

        [TestMethod]
        public void UpdateSubCapability()
        {
            var subCapabilityUpdate = subCapabilityList.FirstOrDefault();
            subCapabilityUpdate.SubCapabilityName = "Sub Capability Update";

            var editSubCapability = subCapabilityController.UpdateSubCapability(subCapabilityUpdate);
            Assert.IsNotNull(editSubCapability);

            var result = (OkObjectResult)editSubCapability;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getSubCapability = subCapabilityController.GetSubCapabilitiesById(subCapabilityUpdate.SubCapabilityId);
            Assert.IsNotNull(getSubCapability);

            var getResult = (OkObjectResult)getSubCapability;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var subCapability = (SubCapabilityViewModel)getResponse.Result;
            Assert.IsTrue(subCapabilityUpdate.SubCapabilityName == subCapability.SubCapabilityName);
        }


        [TestMethod]
        public void GetActiveSubCapabilitiesWithCapabilityId()
        {
            var getActiveSubCapabilities = subCapabilityController.GetActiveSubCapabilitiesWithCapabilityId();
            Assert.IsNotNull(getActiveSubCapabilities);

            var result = (OkObjectResult)getActiveSubCapabilities;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}