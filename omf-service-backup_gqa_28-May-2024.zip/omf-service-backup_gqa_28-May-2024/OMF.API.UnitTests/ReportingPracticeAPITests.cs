﻿
namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class ReportingPracticeAPITests : UnitTestBase
    {
        private static ReportingPracticeController reportingPracticeController;
        private static ReportingPracticeService reportingPracticeService;
        private static ReportingPracticeViewModel reportingPracticeViewModel;
        private static Mock<ILogger<ReportingPracticeController>> logger;
        private List<ReportingPracticeViewModel> reportingPracticeList = new List<ReportingPracticeViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            reportingPracticeService = new ReportingPracticeService(Repository, Mapper);
            logger = new Mock<ILogger<ReportingPracticeController>>();
            reportingPracticeController = new ReportingPracticeController(reportingPracticeService, logger.Object);
            Repository.Repository<ReportingPractice>().DeleteRange(Repository.Repository<ReportingPractice>().GetAll());

            reportingPracticeController = new ReportingPracticeController(reportingPracticeService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getReportingPractice = reportingPracticeController.GetAllReportingPractices();
            Assert.IsNotNull(getReportingPractice);

            var result = (OkObjectResult)getReportingPractice;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<ReportingPracticeViewModel>)response.Result;

            if (getData.Count > 0)
            {
                reportingPracticeList = getData;
            }
            else
            {
                reportingPracticeViewModel = new ReportingPracticeViewModel
                {
                    ReportingPracticeId = new Random().Next(1, randomInterval),
                    ReportingPracticeName = "Full Time",
                    IsActive = true

                };

                var reportingPractice = reportingPracticeController.AddReportingPractice(reportingPracticeViewModel);
                reportingPracticeList.Add(reportingPracticeViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            reportingPracticeViewModel = null;
            reportingPracticeList = null;
        }

        [TestMethod]
        public void GetActiveReportingPractices()
        {
            var getReportingPractice = reportingPracticeController.GetActiveReportingPractices();
            Assert.IsNotNull(getReportingPractice);

            var result = (OkObjectResult)getReportingPractice;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetAllReportingPractices()
        {
            var getReportingPractice = reportingPracticeController.GetAllReportingPractices();
            Assert.IsNotNull(getReportingPractice);

            var result = (OkObjectResult)getReportingPractice;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetReportingPracticeById()
        {
            var getReportingPractice = reportingPracticeController.GetReportingPracticeById(reportingPracticeList.FirstOrDefault().ReportingPracticeId);
            Assert.IsNotNull(getReportingPractice);

            var result = (OkObjectResult)getReportingPractice;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddReportingPractice()
        {
            reportingPracticeViewModel = new ReportingPracticeViewModel
            {
                ReportingPracticeId = new Random().Next(1, randomInterval),
                ReportingPracticeName = "COP",
                IsActive = true
            };

            var createdReportingPractice = reportingPracticeController.AddReportingPractice(reportingPracticeViewModel);
            Assert.IsNotNull(createdReportingPractice);

            var result = (OkObjectResult)createdReportingPractice;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getReportingPractice = reportingPracticeController.GetAllReportingPractices();
            Assert.IsNotNull(getReportingPractice);

            var getResult = (OkObjectResult)getReportingPractice;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var reportingPracticeList = (List<ReportingPracticeViewModel>)getResponse.Result;
            Assert.IsTrue(reportingPracticeList.Any(e => e.ReportingPracticeName == reportingPracticeViewModel.ReportingPracticeName));
        }

        [TestMethod]
        public void UpdateReportingPractice()
        {
            var reportingPracticeUpdate = reportingPracticeList.FirstOrDefault();
            reportingPracticeUpdate.ReportingPracticeName = "COP Practice";

            var editReportingPractice = reportingPracticeController.UpdateReportingPractice(reportingPracticeUpdate);
            Assert.IsNotNull(editReportingPractice);

            var result = (OkObjectResult)editReportingPractice;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getReportingPractice = reportingPracticeController.GetReportingPracticeById(reportingPracticeUpdate.ReportingPracticeId);
            Assert.IsNotNull(getReportingPractice);

            var getResult = (OkObjectResult)getReportingPractice;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var reportingPractice = (ReportingPracticeViewModel)getResponse.Result;
            Assert.IsTrue(reportingPracticeUpdate.ReportingPracticeName == reportingPractice.ReportingPracticeName);
        }
    }
}
