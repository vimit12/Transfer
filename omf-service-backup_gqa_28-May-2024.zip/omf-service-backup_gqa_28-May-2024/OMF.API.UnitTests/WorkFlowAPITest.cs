﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class WorkFlowAPITest : UnitTestBase
    {
        public static WorkflowController WorkflowController;
        public static WorkflowService WorkflowService;
        public static Mock<ILogger<WorkflowController>> logger;
        public static IOptions<OmfSettings> options;
        public static IOptions<HiQSettings> hiQptions;
        private static OpportunityAPITest oppTest;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            logger = new Mock<ILogger<WorkflowController>>();
            IUserRoleService userRoleService = new UserRoleService(Repository, Mapper, HttpContextAccessor);
            options = new OmfSettings() as IOptions<OmfSettings>;
            hiQptions = new HiQSettings() as IOptions<HiQSettings>;
            HttpContextAccessor.HttpContext = new DefaultHttpContext() { User = User };

            IQuarterService quarterService = new QuarterService(Repository, Mapper);
            IFxRateService fxRateService = new FxRateService(Repository, Mapper, quarterService, HttpContextAccessor);
            IHiQService hiQService = new HiQService(Repository, hiQptions, fxRateService, Mapper);
            IORBWorkFlowService orbWorkFlowService = new ORBWorkFlowService(Repository, Mapper, HttpContextAccessor, userRoleService, hiQService, fxRateService, options);
            IORBApprovalCriteriaService approvalCriteriaService = new ORBApprovalCriteriaService(Repository, Mapper, HttpContextAccessor);
            WorkflowService = new WorkflowService(Repository, Mapper, userRoleService, options, HttpContextAccessor, fxRateService, orbWorkFlowService, approvalCriteriaService);
            WorkflowController = new WorkflowController(WorkflowService, logger.Object, hiQService)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
            oppTest = new OpportunityAPITest();
            OpportunityAPITest.ClassInitialize(context);
        }

        [TestInitialize]
        public void TestInitialize()
        {
            prepareData();
        }

        [TestMethod]
        public void GetWorkFlowActionsByStatus()
        {
            oppTest.TestInitialize();
            var getWorkFlowActionsByStatus = WorkflowController.GetWorkFlowActionsByStatus(new WorkFlowActionsViewModel
            {
                OpportunityId = 1,
                RoleId = 1,
                StatusActionViewModelList = new List<StatusActionViewModel>()
                {
                    new StatusActionViewModel
                    {
                        Action="Test Action",
                        StatusActionId=1,
                        StatusActionText="Test Text",
                        CreatedBy="nbhat",
                        CreatedDate=DateTime.Now,
                        IsActive=true,
                    }
                },

            });
            Assert.IsNotNull(getWorkFlowActionsByStatus);

            var result = (OkObjectResult)getWorkFlowActionsByStatus;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var model = (IEnumerable<StatusActionViewModel>)response.Result;
            Assert.IsTrue(model.Any(x => x.StatusActionId == 1));
        }

        private void prepareData()
        {
            //var roleModel = new Role
            //{
            //    RoleId = 1,
            //    RoleName = "Test Role",
            //    IsActive = true,
            //    CreatedBy = "nbhat",
            //    CreatedDate = DateTime.Now,
            //};

            //Repository.Repository<Role>().DeleteRange(Repository.Repository<Role>().GetAll());
            //Repository.Repository<Role>().Add(roleModel);
            //Repository.SaveChanges();

            //var statusActionmodel = new StatusAction
            //{
            //    StatusActionId = 1,
            //    Action = "Test Action",
            //    StatusActionText = "Test Text",
            //    IsActive = true,
            //    CreatedBy = "nbhat",
            //    CreatedDate = DateTime.Now
            //};

            //Repository.Repository<StatusAction>().DeleteRange(Repository.Repository<StatusAction>().GetAll());
            //Repository.Repository<StatusAction>().Add(statusActionmodel);
            //Repository.SaveChanges();

            ////var statusTypeModel = new StatusType
            ////{
            ////    StatusId = 1,
            ////    Status = "Test Status",
            ////    CreatedBy = "nbhat",
            ////    CreatedDate = DateTime.Now,
            ////    IsActive = true,

            ////};

            ////Repository.Repository<StatusType>().DeleteRange(Repository.Repository<StatusType>().GetAll());
            ////Repository.Repository<StatusType>().Add(statusTypeModel);
            ////Repository.SaveChanges();

            //var model = new WorkFlow
            //{
            //    WorkFlowId = 1,
            //    StatusTypeId = 1,
            //    StatusActionId = 1,
            //    IsActive = true,
            //    CurrentStatusTypeId = 1,
            //    RoleId = 1,
            //    CreatedBy = "nbhat",
            //    CreatedDate = DateTime.Now,

            //};

            //Repository.Repository<WorkFlow>().DeleteRange(Repository.Repository<WorkFlow>().GetAll());
            //Repository.Repository<WorkFlow>().Add(model);
            //Repository.SaveChanges();
            
        }
    }
}
