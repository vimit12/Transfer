﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class TechAllianceAPITest : UnitTestBase
    {
        private static TechAllianceController techAllianceController;
        private static TechAllianceService techAllianceService;
        private static TechAllianceViewModel techAllianceViewModel;
        private static Mock<ILogger<TechAllianceController>> logger;
        private List<TechAllianceViewModel> techAllianceList = new List<TechAllianceViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            techAllianceService = new TechAllianceService(Repository, Mapper);
            logger = new Mock<ILogger<TechAllianceController>>();
            techAllianceController = new TechAllianceController(techAllianceService, logger.Object);
            Repository.Repository<TechAlliance>().DeleteRange(Repository.Repository<TechAlliance>().GetAll());

            techAllianceController = new TechAllianceController(techAllianceService, logger.Object)
            {
                ControllerContext = new  ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getTechAlliance = techAllianceController.GetTechAlliance();
            Assert.IsNotNull(getTechAlliance);

            var result = (OkObjectResult)getTechAlliance;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<TechAllianceViewModel>)response.Result;

            if (getData.Count > 0)
            {
                techAllianceList = getData;
            }
            else
            {
                techAllianceViewModel = new TechAllianceViewModel
                {
                    TechnologyId = new Random().Next(1, randomInterval),
                    TechnologyName = "Oracle",
                    IsActive = true,
                };

                var country = techAllianceController.AddTechAlliance(techAllianceViewModel);
                techAllianceList.Add(techAllianceViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            techAllianceViewModel = null;
            techAllianceList = null;
        }

        [TestMethod]
        public void GetAllTechAlliance()
        {
            var getTechAlliance = techAllianceController.GetTechAlliance();
            Assert.IsNotNull(getTechAlliance);

            var result = (OkObjectResult)getTechAlliance;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetTechAllianceById()
        {
            var getTechAlliance = techAllianceController.GetTechAllianceById(techAllianceList.FirstOrDefault().TechnologyId);
            Assert.IsNotNull(getTechAlliance);

            var result = (OkObjectResult)getTechAlliance;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddTechAlliance()
        {
            techAllianceViewModel = new TechAllianceViewModel
            {
                TechnologyId = new Random().Next(1, randomInterval),
                TechnologyName = "Oracle",
                IsActive = true,
            };

            var createdTechAlliance = techAllianceController.AddTechAlliance(techAllianceViewModel);
            Assert.IsNotNull(createdTechAlliance);

            var result = (OkObjectResult)createdTechAlliance;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getTechAlliance = techAllianceController.GetTechAlliance();
            Assert.IsNotNull(getTechAlliance);

            var getResult = (OkObjectResult)getTechAlliance;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var techAllianceList = (List<TechAllianceViewModel>)getResponse.Result;
            Assert.IsTrue(techAllianceList.Any(e => e.TechnologyName == techAllianceViewModel.TechnologyName));
        }

        [TestMethod]
        public void UpdateTechAlliance()
        {
            var techAllianceUpdate = techAllianceList.FirstOrDefault();
            techAllianceUpdate.TechnologyName = "IndiaInd";

            var editTechAlliance = techAllianceController.UpdateTechAlliance(techAllianceUpdate);
            Assert.IsNotNull(editTechAlliance);

            var result = (OkObjectResult)editTechAlliance;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getTechAlliance = techAllianceController.GetTechAllianceById(techAllianceUpdate.TechnologyId);
            Assert.IsNotNull(getTechAlliance);

            var getResult = (OkObjectResult)getTechAlliance;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var techAlliance = (TechAllianceViewModel)getResponse.Result;
            Assert.IsTrue(techAllianceUpdate.TechnologyName == techAlliance.TechnologyName);
        }
    }
}

