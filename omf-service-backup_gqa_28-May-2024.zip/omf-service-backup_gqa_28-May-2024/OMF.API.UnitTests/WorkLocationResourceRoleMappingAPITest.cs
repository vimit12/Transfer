﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class WorkLocationResourceRoleMappingAPITest : UnitTestBase
    {
       
        private static WorkLocationResourceRoleMappingController workLocationResourceRoleMappingController;
        private static WorkLocationResourceRoleMappingService workLocationResourceRoleMappingService;
        private static WorkLocationResourceRoleMappingViewModel workLocationResourceRoleMappingViewModel;
        private static Mock<ILogger<WorkLocationResourceRoleMappingController>> logger;
        private List<WorkLocationResourceRoleMappingViewModel> workLocationResourceRoleMappingsList = new List<WorkLocationResourceRoleMappingViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            workLocationResourceRoleMappingService = new WorkLocationResourceRoleMappingService(Repository, Mapper);
            logger = new Mock<ILogger<WorkLocationResourceRoleMappingController>>();
            workLocationResourceRoleMappingController = new WorkLocationResourceRoleMappingController(workLocationResourceRoleMappingService, logger.Object);
            Repository.Repository<WorkLocationResourceRoleMapping>().DeleteRange(Repository.Repository<WorkLocationResourceRoleMapping>().GetAll());
            Repository.Repository<ResourceRole>().Add(baseObject.CreateResourceRole());

            workLocationResourceRoleMappingController = new WorkLocationResourceRoleMappingController(workLocationResourceRoleMappingService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }


        [TestInitialize]
        public void TestInitialize()
        {
            var workLocationResourceRoleMappings = workLocationResourceRoleMappingController.GetAllWorkLocationResourceRoleMappings();
            Assert.IsNotNull(workLocationResourceRoleMappings);

            var result = (OkObjectResult)workLocationResourceRoleMappings;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<WorkLocationResourceRoleMappingViewModel>)response.Result;

            if (getData.Count > 0)
            {
                workLocationResourceRoleMappingsList = getData;
            }
            else
            {
                var workLocationResourceRoleMapping = workLocationResourceRoleMappingController.AddWorkLocationResourceRoleMapping(CreateWorkLocationResourceRoleMappingData());
                workLocationResourceRoleMappingsList.Add(workLocationResourceRoleMappingViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            workLocationResourceRoleMappingViewModel = null;
            workLocationResourceRoleMappingsList = null;
        }

        [TestMethod]
        public void GetActiveWorkLocationResourceRoleMappings()
        {
            var activeWorkLocationResourceRoleMappings = workLocationResourceRoleMappingController.GetActiveWorkLocations();
            Assert.IsNotNull(activeWorkLocationResourceRoleMappings);

            var result = (OkObjectResult)activeWorkLocationResourceRoleMappings;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetAllWorkLocationResourceRoleMappings()
        {
            var workLocationResourceRoleMappings = workLocationResourceRoleMappingController.GetAllWorkLocationResourceRoleMappings();
            Assert.IsNotNull(workLocationResourceRoleMappings);

            var result = (OkObjectResult)workLocationResourceRoleMappings;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetWorkLocationResourceRoleMappingById()
        {

            CreateWorkLocationResourceRoleMappingData();
            var workLocationResourceRoleMapping = workLocationResourceRoleMappingController.GetWorkLocationResourceRoleMappingById(workLocationResourceRoleMappingViewModel.WorkLocationResourceRoleId);
            Assert.IsNotNull(workLocationResourceRoleMapping);

            var result = (OkObjectResult)workLocationResourceRoleMapping;
            Assert.AreEqual(200, result.StatusCode);

        }
       
        [TestMethod]
        public void AddWorkLocationResourceRoleMapping()
        {

            var newWorkLocationResourceRoleMapping = workLocationResourceRoleMappingController.AddWorkLocationResourceRoleMapping(CreateWorkLocationResourceRoleMappingData());
            Assert.IsNotNull(newWorkLocationResourceRoleMapping);

            var result = (OkObjectResult)newWorkLocationResourceRoleMapping;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var workLocationResourceRoleMappings = workLocationResourceRoleMappingController.GetAllWorkLocationResourceRoleMappings();
            Assert.IsNotNull(workLocationResourceRoleMappings);

            var workLocationResourceRoleMappingsResults = (OkObjectResult)workLocationResourceRoleMappings;
            Assert.AreEqual(200, result.StatusCode);
            var workLocationResourceRoleMappingsResponse = (ApiOkResponse)workLocationResourceRoleMappingsResults.Value;
            Assert.IsNotNull(workLocationResourceRoleMappingsResponse.Result);

            var workLocationResourceRoleMappingList = (List<WorkLocationResourceRoleMappingViewModel>)workLocationResourceRoleMappingsResponse.Result;
            Assert.IsTrue(workLocationResourceRoleMappingList.Any(e => e.ResourceRoleId == workLocationResourceRoleMappingViewModel.ResourceRoleId));
            Assert.IsTrue(workLocationResourceRoleMappingList.Count > 0);
        }
        [TestMethod]
        public void UpdateWorkLocation()
        {
            var workLocationResourceRoleMapping = workLocationResourceRoleMappingsList.FirstOrDefault();
            workLocationResourceRoleMapping.WorkLocationResourceRoleId = workLocationResourceRoleMapping.WorkLocationResourceRoleId ;

            var updateResult = workLocationResourceRoleMappingController.UpdateWorkLocation(workLocationResourceRoleMapping);
            Assert.IsNotNull(updateResult);

            var result = (OkObjectResult)updateResult;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
            Assert.IsTrue(((WorkLocationResourceRoleMappingViewModel)response.Result).ResourceRoleId == workLocationResourceRoleMapping.ResourceRoleId);

            var updatedWorkLocationResourceRoleMapping = workLocationResourceRoleMappingController.GetWorkLocationResourceRoleMappingById(workLocationResourceRoleMapping.WorkLocationResourceRoleId);
            Assert.IsNotNull(updatedWorkLocationResourceRoleMapping);

            var updatedResult = (OkObjectResult)updatedWorkLocationResourceRoleMapping;
            Assert.AreEqual(200, result.StatusCode);
            Assert.IsNotNull(response.Result);

            var updatedResponse = (ApiOkResponse)updatedResult.Value;
            Assert.IsNotNull(updatedResponse.Result);

            var updatedViewModel = (WorkLocationResourceRoleMappingViewModel)updatedResponse.Result;
            Assert.IsTrue(workLocationResourceRoleMapping.WorkLocationId == updatedViewModel.WorkLocationId);

        }

        private WorkLocationResourceRoleMappingViewModel CreateWorkLocationResourceRoleMappingData()
        {
            int workLocationResourceRoleId = new Random().Next(1, randomInterval);
            workLocationResourceRoleMappingViewModel = new WorkLocationResourceRoleMappingViewModel
            {
                WorkLocationResourceRoleId= workLocationResourceRoleId,
                WorkLocationId = 1,
                ResourceRoleId=1,
                IsActive = true
            };

            return workLocationResourceRoleMappingViewModel;
        }
    }
}
