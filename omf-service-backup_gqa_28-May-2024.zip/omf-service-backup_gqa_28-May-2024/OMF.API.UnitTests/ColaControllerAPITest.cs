﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class ColaControllerAPITest : UnitTestBase
    {
        private static ColaViewModel ViewModel;
        private static ColaController colaController;
        private static ColaService colaService;
        private static Mock<ILogger<ColaController>> logger;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            HttpContextAccessor.HttpContext = new DefaultHttpContext() { User = User };
            colaService = new ColaService(Repository, Mapper, HttpContextAccessor);
            logger = new Mock<ILogger<ColaController>>();
            colaController = new ColaController(colaService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };

            prepareData();
        }

        [TestInitialize]
        public void TestInitialize()
        {

        }

        [TestMethod]
        public void GetColaByFYear()
        {
            var getCurrentFinancialYearCola = colaController.GetColaByFYear();
            Assert.IsNotNull(getCurrentFinancialYearCola);

            var result = (OkObjectResult)getCurrentFinancialYearCola;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var model = (ColaViewModel)response.Result;
        }

        //[TestMethod]
        //public void SaveColaByFYear()
        //{
        //    ColaValues colaModel = new ColaValues
        //    {
        //        CurrentFYPercentage=10,
        //        PreviousFYPercentage1=9,
        //        PreviousFYPercentage2=8,
        //        PreviousFYPercentage3=7,
        //        WorkLocationId=1
        //    };
        //    //var saveColaByFYear = colaController.SaveColaByFYear(colaModel as IEnumerable<ColaValues>);

        //    List<ColaValues> temp = new List<ColaValues>();
        //    temp.Add(colaModel);
        //    var saveColaByFYear = colaController.SaveColaByFYear(temp);
        //    Assert.IsNotNull(saveColaByFYear);

        //    var result = (OkObjectResult)saveColaByFYear;
        //    Assert.AreEqual(200, result.StatusCode);
        //}

        private static void prepareData()
        {
            Repository.Repository<CAYear>().DeleteRange(Repository.Repository<CAYear>().GetAll());
            var cAYears = new List<CAYear>()
            {
                new CAYear() { YearId = 1, Year = 2019, Comments = ""},
                new CAYear() { YearId = 2, Year = 2020, Comments = ""},
                new CAYear() { YearId = 3, Year = 2021, Comments = ""},
            };
            Repository.Repository<CAYear>().AddRange(cAYears);
            Repository.SaveChanges();

            var wlModel = CreateWorkLocation();
            // Insert worklocation
            Repository.Repository<WorkLocation>().DeleteRange(Repository.Repository<WorkLocation>().GetAll());
            Repository.Repository<WorkLocation>().Add(wlModel);

            var colaModel = new Cola
            {
                ColaId = 1,
                YearId = 1,
                WorkLocationId = 1,
                ColaPercentage = 5,
                CreatedDate = DateTime.Now,
                CreatedBy = "nbhat"
            };
            // Insert COLA
            Repository.Repository<Cola>().DeleteRange(Repository.Repository<Cola>().GetAll());
            Repository.Repository<Cola>().Add(colaModel);
            Repository.SaveChanges();
        }
    }
}
