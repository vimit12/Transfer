﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class FxRateAPITest : UnitTestBase
    {
        private static FxRateController FxRateController;
        private static FxRateService FxRateService;
        private static Mock<ILogger<FxRateController>> logger;
        private static IQuarterService QuarterService;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            HttpContextAccessor.HttpContext = new DefaultHttpContext() { User = User };
            QuarterService = new QuarterService(Repository, Mapper);
            FxRateService = new FxRateService(Repository, Mapper,QuarterService,HttpContextAccessor);
            logger = new Mock<ILogger<FxRateController>>();
            FxRateController = new FxRateController(FxRateService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            prepareData();
        }

        [TestMethod]
        public void AddUpdateFxRates()
        {
            var viewModel = new FxRateViewModel
            {
                CurrencyId = 1,
                FxRateId = 1,
                YearId = 1,
                Quarter1Id = 1,
                Quarter2Id = 2,
                Quarter3Id = 3,
                Quarter4Id = 4,
                ActiveQuarterid = 1,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now
            };

            var modelList = new List<FxRateViewModel>();
            modelList.Add(viewModel);

            var addUpdateFxRates = FxRateController.AddUpdateFxRates(modelList);
            Assert.IsNotNull(addUpdateFxRates);

            var result = (OkObjectResult)addUpdateFxRates;
            Assert.AreEqual(200, result.StatusCode);
        }

        [TestMethod]
        public void GetFxRateByYear()
        {
            var year = Repository.Repository<CAYear>().GetById(1);
            var getFxRateByYear = FxRateController.GetFxRateByYear(1);
            Assert.IsNotNull(getFxRateByYear);

            var result = (OkObjectResult)getFxRateByYear;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var viewModels = (IEnumerable<FxRateViewModel>)response.Result;
            Assert.IsTrue(viewModels.Any(x => x.YearId == year.YearId));
        }


        //[TestMethod]
        //public void GetFxCurrentQtr()
        //{
        //    //var year = Repository.Repository<CAYear>().GetById(1);
        //    var getFxRateByYear = FxRateController.GetFxCurrentQtr();
        //    Assert.IsNotNull(getFxRateByYear);

        //    var result = (OkObjectResult)getFxRateByYear;
        //    Assert.AreEqual(200, result.StatusCode);

        //    var response = (ApiOkResponse)result.Value;
        //    Assert.IsNotNull(response);

        //    var viewModels = (Dictionary<string, double>)response.Result;
        //    //Assert.IsTrue(viewModels.Any(x => x.YearId == year.YearId));
        //    Assert.IsTrue(viewModels["Q1"] == 1);
        //}

        //[TestMethod]
        //public void GetFxRateSummary()
        //{
        //    //var year = Repository.Repository<CAYear>().GetById(1);
        //    var getFxRateByYear = FxRateController.GetFxRateSummary(1, "Q1");
        //    Assert.IsNotNull(getFxRateByYear);

        //    var result = (OkObjectResult)getFxRateByYear;
        //    Assert.AreEqual(200, result.StatusCode);

        //    var response = (ApiOkResponse)result.Value;
        //    Assert.IsNotNull(response);

        //    var viewModels = (IEnumerable<CommentsSummaryViewModel>)response.Result;
        //    //Assert.IsTrue(viewModels.Any(x => x.YearId == year.YearId));
        //    Assert.IsTrue(viewModels.Any(x => x.Quarter == "Q1"));
        //}

        private void prepareData()
        {
            Repository.Repository<CAYear>().DeleteRange(Repository.Repository<CAYear>().GetAll());
            Repository.Repository<CAYear>().AddRange(CreateYears());
            Repository.SaveChanges();

            Repository.Repository<Quarter>().DeleteRange(Repository.Repository<Quarter>().GetAll());
            Repository.Repository<Quarter>().AddRange(CreateQuarters());
            Repository.SaveChanges();

            Repository.Repository<Currency>().DeleteRange(Repository.Repository<Currency>().GetAll());
            Repository.Repository<Currency>().AddRange(CreateCurrency());
            Repository.SaveChanges();
        }
    }
}
