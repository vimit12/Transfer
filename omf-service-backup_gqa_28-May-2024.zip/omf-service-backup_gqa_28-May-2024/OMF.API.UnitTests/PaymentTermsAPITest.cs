﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class PaymentTermsAPITest : UnitTestBase
    {
        private static PaymentTermsController paymentTermsController;
        private static PaymentTermsService paymentTermsService;
        private static PaymentTermsViewModel paymentTermsViewModel;
        private static Mock<ILogger<PaymentTermsController>> logger;
        private List<PaymentTermsViewModel> paymentTermsList = new List<PaymentTermsViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            paymentTermsService = new PaymentTermsService(Repository, Mapper);
            logger = new Mock<ILogger<PaymentTermsController>>();
            paymentTermsController = new PaymentTermsController(paymentTermsService, logger.Object);
            Repository.Repository<PaymentTerms>().DeleteRange(Repository.Repository<PaymentTerms>().GetAll());

            paymentTermsController = new PaymentTermsController(paymentTermsService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getPaymentTerms = paymentTermsController.GetAllPaymentTerms();
            Assert.IsNotNull(getPaymentTerms);

            var result = (OkObjectResult)getPaymentTerms;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<PaymentTermsViewModel>)response.Result;

            if (getData.Count > 0)
            {
                paymentTermsList = getData;
            }
            else
            {
                paymentTermsViewModel = new PaymentTermsViewModel
                {
                    PaymentTermId = new Random().Next(1, randomInterval),
                    PaymentTermCode = "TESTAPI",
                    PayTermDays = 10,
                    IsActive = true,
                    Comments = "TestComment"
                };

                var paymentTerms = paymentTermsController.AddPaymentTerms(paymentTermsViewModel);
                paymentTermsList.Add(paymentTermsViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            paymentTermsViewModel = null;
            paymentTermsList = null;
        }

        [TestMethod]
        public void GetAllPaymentTerms()
        {
            var getPaymentTerms = paymentTermsController.GetAllPaymentTerms();
            Assert.IsNotNull(getPaymentTerms);

            var result = (OkObjectResult)getPaymentTerms;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetPaymentTermsById()
        {
            var getPaymentTerms = paymentTermsController.GetPaymentTermById(paymentTermsList.FirstOrDefault().PaymentTermId);
            Assert.IsNotNull(getPaymentTerms);

            var result = (OkObjectResult)getPaymentTerms;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddPaymentTerms()
        {
            paymentTermsViewModel = new PaymentTermsViewModel
            {
                PaymentTermId = new Random().Next(1, randomInterval),
                PaymentTermCode = "TESTAPI",
                PayTermDays = 10,
                IsActive = true,
                Comments = "TestComment"
            };

            var createdPaymentTerms = paymentTermsController.AddPaymentTerms(paymentTermsViewModel);
            Assert.IsNotNull(createdPaymentTerms);

            var result = (OkObjectResult)createdPaymentTerms;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getPaymentTerms = paymentTermsController.GetAllPaymentTerms();
            Assert.IsNotNull(getPaymentTerms);

            var getResult = (OkObjectResult)getPaymentTerms;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var paymentTermsList = (List<PaymentTermsViewModel>)getResponse.Result;
            Assert.IsTrue(paymentTermsList.Any(e => e.PaymentTermCode == paymentTermsViewModel.PaymentTermCode));
        }

        [TestMethod]
        public void UpdatePaymentTerms()
        {
            var paymentTermsUpdate = paymentTermsList.FirstOrDefault();
            paymentTermsUpdate.PaymentTermCode = "TESTAPI";

            var editPaymentTerms = paymentTermsController.UpdatePaymentTerms(paymentTermsUpdate);
            Assert.IsNotNull(editPaymentTerms);

            var result = (OkObjectResult)editPaymentTerms;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getPaymentTerms = paymentTermsController.GetPaymentTermById(paymentTermsUpdate.PaymentTermId);
            Assert.IsNotNull(getPaymentTerms);

            var getResult = (OkObjectResult)getPaymentTerms;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var paymentTerms = (PaymentTermsViewModel)getResponse.Result;
            Assert.IsTrue(paymentTermsUpdate.PaymentTermCode == paymentTerms.PaymentTermCode);
        }

        [TestMethod]
        public void GetActivePaymentTerms()
        {
            var getPaymentTerms = paymentTermsController.GetActivePaymentTerms();
            Assert.IsNotNull(getPaymentTerms);

            var result = (OkObjectResult)getPaymentTerms;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}