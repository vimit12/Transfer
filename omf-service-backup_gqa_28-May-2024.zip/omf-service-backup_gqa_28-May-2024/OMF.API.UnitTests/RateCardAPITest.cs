﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class RateCardAPITest : UnitTestBase
    {
        private static RateCardController rateCardController;
        private static RateCardService rateCardService;
        private static Mock<ILogger<RateCardController>> logger;
        private List<WLRateCardViewModel> wLRateCardViewModelsList = new List<WLRateCardViewModel>();
        private static RateCardViewModel rateCardViewModel = new RateCardViewModel();
        private List<RateCardViewModel> rateCardViewModelList = new List<RateCardViewModel>();
        private static StandardCostCurrencyViewModel standardCostCurrencyViewModel = new StandardCostCurrencyViewModel();
        private List<StandardCostCurrencyViewModel> standardCostCurrencyViewModelList = new List<StandardCostCurrencyViewModel>();
        private static QuarterService quarter;
        private static YearService year;
        private static CurrencyService currencyService;

     [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            logger = new Mock<ILogger<RateCardController>>();
            Repository.Repository<RateCard>().DeleteRange(Repository.Repository<RateCard>().GetAll());

            rateCardController = new RateCardController(rateCardService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };

            // Authentication and Claims.
            HttpContextAccessor workflowContextAccessor = new HttpContextAccessor
            {
                HttpContext = new DefaultHttpContext() { User = User }
            };
            quarter = new QuarterService(Repository, Mapper);
          //  opportunity = new OpportunityService(Repository, Mapper, HttpContextAccessor);
            rateCardService = new RateCardService(Repository, Mapper, quarter, year, currencyService, workflowContextAccessor);
            rateCardController = new RateCardController(rateCardService, logger.Object);

            PrepareTestData();

        }

        [TestInitialize]
        public void TestInitialize()
        {
            CurrencyRateViewModel currencyRate = new CurrencyRateViewModel
            {
                CurrencyId = 1,
                YearId = 3
            };
            
            var getWLRateCard = rateCardController.GetWLRateCard(currencyRate);
            Assert.IsNotNull(getWLRateCard);

            var result = (OkObjectResult)getWLRateCard;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetWLRateCardTest()
        {
            CurrencyRateViewModel currencyRate = new CurrencyRateViewModel
            {
                CurrencyId = 1,
                YearId = 3
            };

            var getWLRateCard = rateCardController.GetWLRateCard(currencyRate);
            Assert.IsNotNull(getWLRateCard);

            var result = (OkObjectResult)getWLRateCard;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetBillRateTest()
        {
            CurrencyRateViewModel currencyRate = new CurrencyRateViewModel
            {
                CurrencyId = 3,
                YearId = 3
            };

            var getBillRate = rateCardController.GetBillRate(currencyRate);
            Assert.IsNotNull(getBillRate);

            var result = (OkObjectResult)getBillRate;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetCommentsSummaryTest()
        {
            RateCardCommentsViewModel rateCardComments = new RateCardCommentsViewModel
            {
                CurrencyId = 1,
                Year = 3
            };

            var getCommentsSummary = rateCardController.GetCommentsSummary(rateCardComments);
            Assert.IsNotNull(getCommentsSummary);

            var result = (OkObjectResult)getCommentsSummary;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }


        private static void PrepareTestData()
        {

            Repository.Repository<RateCard>().DeleteRange(Repository.Repository<RateCard>().GetAll());
            Repository.Repository<ResourceRole>().DeleteRange(Repository.Repository<ResourceRole>().GetAll());
            Repository.Repository<WorkLocation>().DeleteRange(Repository.Repository<WorkLocation>().GetAll());
            Repository.Repository<Currency>().DeleteRange(Repository.Repository<Currency>().GetAll());
            Repository.Repository<CAYear>().DeleteRange(Repository.Repository<CAYear>().GetAll());
            Repository.Repository<FxRate>().DeleteRange(Repository.Repository<FxRate>().GetAll());

            var cAYears = new List<CAYear>()
            {
                new CAYear() { YearId = 1, Year = 2018, Comments = ""},
                new CAYear() { YearId = 2, Year = 2019, Comments = ""},
                new CAYear() { YearId = 3, Year = 2020, Comments = ""},
            };
            Repository.Repository<CAYear>().AddRange(cAYears);

            var currencies = new List<Currency>()
            {
                new Currency() { CurrencyId = 1, CurrencyCode = "IND"},
                new Currency() { CurrencyId = 2, CurrencyCode = "USD"},
                new Currency() { CurrencyId = 3, CurrencyCode = "JPY"},
            };
            Repository.Repository<CAYear>().AddRange(cAYears);
        }
    }
}
