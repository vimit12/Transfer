﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;
    using OMF.Business.Interfaces;

    [TestClass]
  public  class WorkLocationAPITest : UnitTestBase
    {
        private static WorkLocationController workLocationController;
        private static WorkLocationService workLocationService;
        private static WorkLocationViewModel workLocationViewModel;
        private static Mock<ILogger<WorkLocationController>> logger;
        private List<WorkLocationViewModel> workLocationsList = new List<WorkLocationViewModel>();
        private static IQuarterService QuarterService;
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            Mock<IQuarterService> b = new Mock<IQuarterService>();

            workLocationService = new WorkLocationService(Repository, Mapper, QuarterService);
            logger = new Mock<ILogger<WorkLocationController>>();
            workLocationController = new WorkLocationController(workLocationService, logger.Object);
            Repository.Repository<WorkLocation>().DeleteRange(Repository.Repository<WorkLocation>().GetAll());

            workLocationController = new WorkLocationController(workLocationService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }


        [TestInitialize]
        public void TestInitialize()
        {
            var workLocations = workLocationController.GetAllWorkLocations();
            Assert.IsNotNull(workLocations);

            var result = (OkObjectResult)workLocations;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<WorkLocationViewModel>)response.Result;

            if (getData.Count > 0)
            {
                workLocationsList = getData;
            }
            else
            {
                var workLocation = workLocationController.AddWorkLocation(CreateWorkLocationData());
                workLocationsList.Add(workLocationViewModel);
            }

        }

        [TestCleanup]
        public void TestCleanUp()
        {
            workLocationViewModel = null;
            workLocationsList = null;
        }

        [TestMethod]
        public void GetActiveWorkLocations()
        {
            var activeWorkLocations = workLocationController.GetActiveWorkLocations();
            Assert.IsNotNull(activeWorkLocations);

            var result = (OkObjectResult)activeWorkLocations;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetAllWorkLocations()
        {
            var workLocations = workLocationController.GetAllWorkLocations();
            Assert.IsNotNull(workLocations);

            var result = (OkObjectResult)workLocations;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetWorkLocationById()
        {

            CreateWorkLocationData();
            var workLocation = workLocationController.GetWorkLocationById(workLocationViewModel.WorkLocationId);
            Assert.IsNotNull(workLocation);

            var result = (OkObjectResult)workLocation;
            Assert.AreEqual(200, result.StatusCode);
          
        }

        [TestMethod]
        public void GetCurrencyList()
        {
            var workLocations = workLocationController.GetCurrencyList();
            Assert.IsNotNull(workLocations);

            var result = (OkObjectResult)workLocations;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddWorkLocation()
        {

            var newWorkLocation = workLocationController.AddWorkLocation(CreateWorkLocationData());
            Assert.IsNotNull(newWorkLocation);

            var result = (OkObjectResult)newWorkLocation;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var workLocations = workLocationController.GetAllWorkLocations();
            Assert.IsNotNull(workLocations);

            var workLocationsResults = (OkObjectResult)workLocations;
            Assert.AreEqual(200, result.StatusCode);
            var workLocationsResponse = (ApiOkResponse)workLocationsResults.Value;
            Assert.IsNotNull(workLocationsResponse.Result);

            var workLocationList = (List<WorkLocationViewModel>)workLocationsResponse.Result;
            Assert.IsTrue(workLocationList.Any(e => e.WorkLocationName == workLocationViewModel.WorkLocationName));
            Assert.IsTrue(workLocationList.Count > 0);
        }
        [TestMethod]
        public void UpdateWorkLocation()
        {
            var workLocation = workLocationsList.FirstOrDefault();
            workLocation.WorkLocationName = workLocation.WorkLocationName + "_Test";

            var updateResult = workLocationController.UpdateWorkLocation(workLocation);
            Assert.IsNotNull(updateResult);

            var result = (OkObjectResult)updateResult;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
            Assert.IsTrue(((WorkLocationViewModel)response.Result).WorkLocationName == workLocation.WorkLocationName);

            var updatedWorkLocation = workLocationController.GetWorkLocationById(workLocation.WorkLocationId);
            Assert.IsNotNull(updatedWorkLocation);

            var updatedResult = (OkObjectResult)updatedWorkLocation;
            Assert.AreEqual(200, result.StatusCode);
            Assert.IsNotNull(response.Result);

            var updatedResponse = (ApiOkResponse)updatedResult.Value;
            Assert.IsNotNull(updatedResponse.Result);

            var updatedViewModel = (WorkLocationViewModel)updatedResponse.Result;
            Assert.IsTrue(workLocation.WorkLocationName == updatedViewModel.WorkLocationName);

        }

        [TestMethod]
        public void GetWorkLocationDeliveryModel()
        {

            CreateWorkLocationData();
            var workLocation = workLocationController.GetWorkLocationDeliveryModel(workLocationViewModel.WorkLocationId);
            Assert.IsNotNull(workLocation);

            var result = (OkObjectResult)workLocation;
            Assert.AreEqual(200, result.StatusCode);

        }

        [TestMethod]
        public void GetWorkLocationResourceMapping()
        {
            var defaultRateCard = workLocationController.GetWorkLocationResourceMapping(createDefaultRateCardInputViewModel());
            Assert.IsNotNull(defaultRateCard);

            var response = (OkObjectResult)defaultRateCard;
            Assert.AreEqual(200, response.StatusCode);

            var result = (ApiOkResponse)response.Value;
            Assert.IsNotNull(result);

            var model = (WorkLocationViewModel)result.Result;
            Assert.IsTrue(workLocationsList.First().WorkLocationId == model.WorkLocationId);
        }

        private WorkLocationViewModel CreateWorkLocationData()
        {
            int workLocationId = new Random().Next(1, randomInterval);
            workLocationViewModel = new WorkLocationViewModel
            {
                WorkLocationId = workLocationId,
                WorkLocationName = "OnShore" + workLocationId,
                IsDiscountMargin = true,
                IsIncreaseOverCostRate = true,
                DiscountPercentage = 10,
                MarginPercentage = 5,
                BaseCurrencyId = 1,
                IncreaseOverCostRate = 1,
                Comments = "Test Work Location by Uma",
                IsActive = true,
                DeliveryModelId = 1,
            };

            return workLocationViewModel;
        }

        private DefaultRateCardInputViewModel createDefaultRateCardInputViewModel()
        {
            var currencyId = Repository.Repository<WorkLocation>().GetAll().FirstOrDefault().BaseCurrencyId;
            //var yearId = Repository.Repository<CAYear>().GetAll().FirstOrDefault().YearId;
            DefaultRateCardInputViewModel model = new DefaultRateCardInputViewModel
            {
                OppourtunityBaseCurrencyId = 1,
                YearId = 1,
                Id = workLocationsList.First().WorkLocationId
            };

            return model;
        }
    }
}
