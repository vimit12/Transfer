﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class TaxRateAPITests : UnitTestBase
    {
        private static TaxRateController taxRateController;
        private static TaxRateService taxRateService;
        private static TaxRateViewModel taxRateViewModel;
        private static Mock<ILogger<TaxRateController>> logger;
        private List<TaxRateViewModel> taxRatesList = new List<TaxRateViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            taxRateService = new TaxRateService(Repository, Mapper);
            logger = new Mock<ILogger<TaxRateController>>();
            taxRateController = new TaxRateController(taxRateService, logger.Object);
            Repository.Repository<TaxRate>().DeleteRange(Repository.Repository<TaxRate>().GetAll());

            taxRateController = new TaxRateController(taxRateService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }


        [TestInitialize]
        public void TestInitialize()
        {
            var taxRates = taxRateController.GetAllTaxRates();
            Assert.IsNotNull(taxRates);

            var result = (OkObjectResult)taxRates;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<TaxRateViewModel>)response.Result;

            if (getData.Count > 0)
            {
                taxRatesList = getData;
            }
            else
            {             
                var taxRate = taxRateController.AddTaxRate(CreateTaxRateData());
                taxRatesList.Add(taxRateViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            taxRateViewModel = null;
            taxRatesList = null;
        }

        [TestMethod]
        public void GetActiveTaxRates()
        {
            var activeTaxRates = taxRateController.GetActiveTaxRates();
            Assert.IsNotNull(activeTaxRates);

            var result = (OkObjectResult)activeTaxRates;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetAllTaxRates()
        {
            var taxRates = taxRateController.GetAllTaxRates();
            Assert.IsNotNull(taxRates);

            var result = (OkObjectResult)taxRates;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetTaxRateById()
        {
            var taxRate = taxRateController.GetTaxRateById(taxRateViewModel.TaxRateId);
            Assert.IsNotNull(taxRate);

            var result = (OkObjectResult)taxRate;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddTaxRate()
        {
            
            var newTaxRate = taxRateController.AddTaxRate(CreateTaxRateData());
            Assert.IsNotNull(newTaxRate);

            var result = (OkObjectResult)newTaxRate;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var taxRates = taxRateController.GetAllTaxRates();
            Assert.IsNotNull(taxRates);

            var taxRateResults = (OkObjectResult)taxRates;
            Assert.AreEqual(200, result.StatusCode);
            var taxRateResponse = (ApiOkResponse)taxRateResults.Value;
            Assert.IsNotNull(taxRateResponse.Result);

            var taxRateList = (List<TaxRateViewModel>)taxRateResponse.Result;
            Assert.IsTrue(taxRateList.Any(e => e.TaxRateName == taxRateViewModel.TaxRateName));
            Assert.IsTrue(taxRateList.Count > 0);
        }
        [TestMethod]
        public void UpdateTaxRate()
        {
            var taxRate = taxRatesList.FirstOrDefault();
            taxRate.TaxRateName = taxRate.TaxRateName+"_Test";

            var updateResult = taxRateController.UpdateTaxRate(taxRate);
            Assert.IsNotNull(updateResult);

            var result = (OkObjectResult)updateResult;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
            Assert.IsTrue(((TaxRateViewModel)response.Result).TaxRateName == taxRate.TaxRateName);

            var updatedTaxRate = taxRateController.GetTaxRateById(taxRate.TaxRateId);
            Assert.IsNotNull(updatedTaxRate);

            var updatedResult = (OkObjectResult)updatedTaxRate;
            Assert.AreEqual(200, result.StatusCode);           
            Assert.IsNotNull(response.Result);           

            var updatedResponse = (ApiOkResponse)updatedResult.Value;
            Assert.IsNotNull(updatedResponse.Result);

            var updatedViewModel = (TaxRateViewModel)updatedResponse.Result;
            Assert.IsTrue(taxRate.TaxRateName == updatedViewModel.TaxRateName);

        }

        private TaxRateViewModel CreateTaxRateData()
        {
            int rateId = new Random().Next(1, randomInterval);
            taxRateViewModel = new TaxRateViewModel
            {
                TaxRateId = rateId,
                TaxRateName = "HCPT M0" + rateId + " - 0% Tax",
                IsActive = true,
                Comments = "Test Tax Rate by Uma"
            };

            return taxRateViewModel;
        }


    }
}