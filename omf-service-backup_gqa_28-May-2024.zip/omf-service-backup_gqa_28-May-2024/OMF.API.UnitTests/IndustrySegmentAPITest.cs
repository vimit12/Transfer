﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class IndustrySegmentAPITest : UnitTestBase
    {
        private static IndustrySegmentController industrySegmentController;
        private static IndustrySegmentService industrySegmentService;
        private static IndustrySegmentViewModel industrySegmentViewModel;
        private static Mock<ILogger<IndustrySegmentController>> logger;
        private List<IndustrySegmentViewModel> industrySegmentList = new List<IndustrySegmentViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            industrySegmentService = new IndustrySegmentService(Repository, Mapper);
            logger = new Mock<ILogger<IndustrySegmentController>>();
            industrySegmentController = new IndustrySegmentController(industrySegmentService, logger.Object);
            Repository.Repository<IndustrySegment>().DeleteRange(Repository.Repository<IndustrySegment>().GetAll());

            industrySegmentController = new IndustrySegmentController(industrySegmentService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getIndustrySegments = industrySegmentController.GetAllIndustrySegments();
            Assert.IsNotNull(getIndustrySegments);

            var result = (OkObjectResult)getIndustrySegments;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<IndustrySegmentViewModel>)response.Result;

            if (getData.Count > 0)
            {
                industrySegmentList = getData;
            }
            else
            {
                industrySegmentViewModel = new IndustrySegmentViewModel
                {
                    IndustrySegmentId = new Random().Next(1, randomInterval),
                    IndustrySegmentName = "TESTAPI",
                    IsActive = true,
                    Comments = "TestComment"
                };

                var industrySegment = industrySegmentController.AddIndustrySegment(industrySegmentViewModel);
                industrySegmentList.Add(industrySegmentViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            industrySegmentViewModel = null;
            industrySegmentList = null;
        }

        [TestMethod]
        public void GetAllIndustrySegments()
        {
            var getIndustrySegments = industrySegmentController.GetAllIndustrySegments();
            Assert.IsNotNull(getIndustrySegments);

            var result = (OkObjectResult)getIndustrySegments;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetIndustrySegmentById()
        {
            var getIndustrySegment = industrySegmentController.GetIndustrySegmentById(industrySegmentList.FirstOrDefault().IndustrySegmentId);
            Assert.IsNotNull(getIndustrySegment);

            var result = (OkObjectResult)getIndustrySegment;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddIndustrySegment()
        {
            industrySegmentViewModel = new IndustrySegmentViewModel
            {
                IndustrySegmentId = new Random().Next(1, randomInterval),
                IndustrySegmentName = "TESTAPI",
                IsActive = true,
                Comments = "TestComment"
            };

            var createdIndustrySegment = industrySegmentController.AddIndustrySegment(industrySegmentViewModel);
            Assert.IsNotNull(createdIndustrySegment);

            var result = (OkObjectResult)createdIndustrySegment;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getIndustrySegments = industrySegmentController.GetAllIndustrySegments();
            Assert.IsNotNull(getIndustrySegments);

            var getResult = (OkObjectResult)getIndustrySegments;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var industrySegmentList = (List<IndustrySegmentViewModel>)getResponse.Result;
            Assert.IsTrue(industrySegmentList.Any(e => e.IndustrySegmentName == industrySegmentViewModel.IndustrySegmentName));
        }

        [TestMethod]
        public void UpdateIndustrySegment()
        {
            var industrySegmentUpdate = industrySegmentList.FirstOrDefault();
            industrySegmentUpdate.IndustrySegmentName = "TESTAPI";

            var editIndustrySegment = industrySegmentController.UpdateIndustrySegment(industrySegmentUpdate);
            Assert.IsNotNull(editIndustrySegment);

            var result = (OkObjectResult)editIndustrySegment;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getIndustrySegment = industrySegmentController.GetIndustrySegmentById(industrySegmentUpdate.IndustrySegmentId);
            Assert.IsNotNull(getIndustrySegment);

            var getResult = (OkObjectResult)getIndustrySegment;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var industrySegment = (IndustrySegmentViewModel)getResponse.Result;
            Assert.IsTrue(industrySegmentUpdate.IndustrySegmentName == industrySegment.IndustrySegmentName);
        }


        [TestMethod]
        public void GetActiveIndustrySegments()
        {
            var getIndustrySegments = industrySegmentController.GetActiveIndustrySegments();
            Assert.IsNotNull(getIndustrySegments);

            var result = (OkObjectResult)getIndustrySegments;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}