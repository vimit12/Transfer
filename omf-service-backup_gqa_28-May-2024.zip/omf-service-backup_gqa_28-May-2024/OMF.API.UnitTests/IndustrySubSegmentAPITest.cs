﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class IndustrySubSegmentAPITest : UnitTestBase
    {
        private static IndustrySubSegmentController industrySubSegmentController;
        private static IndustrySubSegmentService industrySubSegmentService;
        private static IndustrySubSegmentViewModel industrySubSegmentViewModel;
        private static Mock<ILogger<IndustrySubSegmentController>> logger;
        private List<IndustrySubSegmentViewModel> industrySubSegmentList = new List<IndustrySubSegmentViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            industrySubSegmentService = new IndustrySubSegmentService(Repository, Mapper);
            logger = new Mock<ILogger<IndustrySubSegmentController>>();
            industrySubSegmentController = new IndustrySubSegmentController(industrySubSegmentService, logger.Object);
            Repository.Repository<IndustrySubSegment>().DeleteRange(Repository.Repository<IndustrySubSegment>().GetAll());

            industrySubSegmentController = new IndustrySubSegmentController(industrySubSegmentService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getIndustrySubSegments = industrySubSegmentController.GetAllIndustrySubSegments();
            Assert.IsNotNull(getIndustrySubSegments);

            var result = (OkObjectResult)getIndustrySubSegments;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<IndustrySubSegmentViewModel>)response.Result;

            if (getData.Count > 0)
            {
                industrySubSegmentList = getData;
            }
            else
            {
                industrySubSegmentViewModel = new IndustrySubSegmentViewModel
                {
                    IndustrySubSegmentId = new Random().Next(1, randomInterval),
                    IndustrySubSegmentName = "TESTAPI",
                    IsActive = true,
                    Comments = "TestComment"
                };

                var industrySubSegment = industrySubSegmentController.AddIndustrySubSegment(industrySubSegmentViewModel);
                industrySubSegmentList.Add(industrySubSegmentViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            industrySubSegmentViewModel = null;
            industrySubSegmentList = null;
        }

        [TestMethod]
        public void GetAllIndustrySubSegments()
        {
            var getIndustrySubSegments = industrySubSegmentController.GetAllIndustrySubSegments();
            Assert.IsNotNull(getIndustrySubSegments);

            var result = (OkObjectResult)getIndustrySubSegments;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetIndustrySubSegmentById()
        {
            var getIndustrySubSegment = industrySubSegmentController.GetIndustrySubSegmentById(industrySubSegmentList.FirstOrDefault().IndustrySubSegmentId);
            Assert.IsNotNull(getIndustrySubSegment);

            var result = (OkObjectResult)getIndustrySubSegment;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddIndustrySubSegment()
        {
            industrySubSegmentViewModel = new IndustrySubSegmentViewModel
            {
                IndustrySubSegmentId = new Random().Next(1, randomInterval),
                IndustrySubSegmentName = "TESTAPI",
                IsActive = true,
                Comments = "TestComment"
            };

            var createdIndustrySubSegment = industrySubSegmentController.AddIndustrySubSegment(industrySubSegmentViewModel);
            Assert.IsNotNull(createdIndustrySubSegment);

            var result = (OkObjectResult)createdIndustrySubSegment;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getIndustrySubSegments = industrySubSegmentController.GetAllIndustrySubSegments();
            Assert.IsNotNull(getIndustrySubSegments);

            var getResult = (OkObjectResult)getIndustrySubSegments;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var industrySubSegmentList = (List<IndustrySubSegmentViewModel>)getResponse.Result;
            Assert.IsTrue(industrySubSegmentList.Any(e => e.IndustrySubSegmentName == industrySubSegmentViewModel.IndustrySubSegmentName));
        }

        [TestMethod]
        public void UpdateIndustrySubSegment()
        {
            var industrySubSegmentUpdate = industrySubSegmentList.FirstOrDefault();
            industrySubSegmentUpdate.IndustrySubSegmentName = "TESTAPI";

            var editIndustrySubSegment = industrySubSegmentController.UpdateIndustrySubSegment(industrySubSegmentUpdate);
            Assert.IsNotNull(editIndustrySubSegment);

            var result = (OkObjectResult)editIndustrySubSegment;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getIndustrySubSegment = industrySubSegmentController.GetIndustrySubSegmentById(industrySubSegmentUpdate.IndustrySubSegmentId);
            Assert.IsNotNull(getIndustrySubSegment);

            var getResult = (OkObjectResult)getIndustrySubSegment;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var industrySubSegment = (IndustrySubSegmentViewModel)getResponse.Result;
            Assert.IsTrue(industrySubSegmentUpdate.IndustrySubSegmentName == industrySubSegment.IndustrySubSegmentName);
        }

        [TestMethod]
        public void GetActiveIndustrySubSegments()
        {
            var getIndustrySubSegments = industrySubSegmentController.GetActiveIndustrySubSegments();
            Assert.IsNotNull(getIndustrySubSegments);

            var result = (OkObjectResult)getIndustrySubSegments;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}