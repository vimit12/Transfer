﻿namespace OMF.API.UnitTests
{
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Common;
    using OMF.Business.Interfaces;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.Extensions.Options;
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Http;
    using Microsoft.CodeAnalysis.Options;
    using OMF.API.Common;
    using OMF.Data.Models;
    using Microsoft.EntityFrameworkCore.Internal;
    using System.Linq;

    [TestClass]
    public class ClientMasterControllerAPITest : UnitTestBase
    {
        private static ClientMasterController clientMasterController;
        private static ClientMasterService clientMasterService;
        private static Mock<ILogger<ClientMasterController>> logger;
        private static IOptions<OmfSettings> options;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            options = new OmfSettings() as IOptions<OmfSettings>;
            UnitTestBase baseObject = new UnitTestBase();
            HttpContextAccessor.HttpContext = new DefaultHttpContext() { User = User };
            IUserRoleService userRoleService = new UserRoleService(Repository, Mapper, HttpContextAccessor);
            IClientMasterService clientMasterService = new ClientMasterService(Repository, Mapper);
            logger = new Mock<ILogger<ClientMasterController>>();
            clientMasterController = new ClientMasterController(clientMasterService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };

        }

        [TestInitialize]
        public void TestInitialize()
        {
            Repository.Repository<ClientMaster>().DeleteRange(Repository.Repository<ClientMaster>().GetAll());
            Repository.Repository<ClientMaster>().Add(new ClientMaster
            {
                ClientMasterId = 1,
                ClientName = "Test Client",
                IsActive = true,

            });
            Repository.SaveChanges();
        }

        [TestMethod]
        public void GetAllClients()
        {
            var getClientMasters = clientMasterController.GetClientMasters();
            Assert.IsNotNull(getClientMasters);

            var response = (OkObjectResult)getClientMasters;
            Assert.IsNotNull(response);

            var result = (ApiOkResponse)response.Value;
            Assert.IsNotNull(result);

            var clientMasterList = (List<ClientMasterViewModel>)result.Result;
            Assert.IsTrue(clientMasterList.Any(x => x.ClientMasterId == 1));
        }

        [TestMethod]
        public void GetActiveCountries()
        {
            var getClientMasters = clientMasterController.GetActiveCountries();
            Assert.IsNotNull(getClientMasters);

            var response = (OkObjectResult)getClientMasters;
            Assert.IsNotNull(response);

            var result = (ApiOkResponse)response.Value;
            Assert.IsNotNull(result);

            var clientMasterList = (List<ClientMasterViewModel>)result.Result;
            Assert.IsTrue(clientMasterList.Any(x => x.ClientMasterId == 1));
        }
    }
}
