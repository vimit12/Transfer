﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class ProjectDomainAPITests : UnitTestBase
    {
        private static ProjectDomainController projectDomainController;
        private static ProjectDomainService projectDomainService;
        private static ProjectDomainViewModel projectDomainViewModel;
        private static Mock<ILogger<ProjectDomainController>> logger;
        private List<ProjectDomainViewModel> projectDomainList = new List<ProjectDomainViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            projectDomainService = new ProjectDomainService(Repository, Mapper);
            logger = new Mock<ILogger<ProjectDomainController>>();
            projectDomainController = new ProjectDomainController(projectDomainService, logger.Object);
            Repository.Repository<ProjectDomain>().DeleteRange(Repository.Repository<ProjectDomain>().GetAll());

            projectDomainController = new ProjectDomainController(projectDomainService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getProjectDomain = projectDomainController.GetAllProjectDomains();
            Assert.IsNotNull(getProjectDomain);

            var result = (OkObjectResult)getProjectDomain;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<ProjectDomainViewModel>)response.Result;

            if (getData.Count > 0)
            {
                projectDomainList = getData;
            }
            else
            {
                projectDomainViewModel = new ProjectDomainViewModel
                {
                    ProjectDomainId = new Random().Next(1, randomInterval),
                    ProjectDomainName = "Domain 1",
                    IsActive = true

                };

                var projectDomain = projectDomainController.AddProjectDomain(projectDomainViewModel);
                projectDomainList.Add(projectDomainViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            projectDomainViewModel = null;
            projectDomainList = null;
        }

        [TestMethod]
        public void GetActiveProjectDomains()
        {
            var getProjectDomain = projectDomainController.GetActiveProjectDomains();
            Assert.IsNotNull(getProjectDomain);

            var result = (OkObjectResult)getProjectDomain;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetAllProjectDomains()
        {
            var getProjectDomain = projectDomainController.GetAllProjectDomains();
            Assert.IsNotNull(getProjectDomain);

            var result = (OkObjectResult)getProjectDomain;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetProjectDomainById()
        {
            var getProjectDomain = projectDomainController.GetProjectDomainById(projectDomainList.FirstOrDefault().ProjectDomainId);
            Assert.IsNotNull(getProjectDomain);

            var result = (OkObjectResult)getProjectDomain;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddProjectDomain()
        {
            projectDomainViewModel = new ProjectDomainViewModel
            {
                ProjectDomainId = new Random().Next(1, randomInterval),
                ProjectDomainName = "COP",
                IsActive = true
            };

            var createdProjectDomain = projectDomainController.AddProjectDomain(projectDomainViewModel);
            Assert.IsNotNull(createdProjectDomain);

            var result = (OkObjectResult)createdProjectDomain;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getProjectDomain = projectDomainController.GetAllProjectDomains();
            Assert.IsNotNull(getProjectDomain);

            var getResult = (OkObjectResult)getProjectDomain;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var projectDomainList = (List<ProjectDomainViewModel>)getResponse.Result;
            Assert.IsTrue(projectDomainList.Any(e => e.ProjectDomainName == projectDomainViewModel.ProjectDomainName));
        }

        [TestMethod]
        public void UpdateProjectDomain()
        {
            var projectDomainUpdate = projectDomainList.FirstOrDefault();
            projectDomainUpdate.ProjectDomainName = "COP Practice";

            var editProjectDomain = projectDomainController.UpdateProjectDomain(projectDomainUpdate);
            Assert.IsNotNull(editProjectDomain);

            var result = (OkObjectResult)editProjectDomain;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getProjectDomain = projectDomainController.GetProjectDomainById(projectDomainUpdate.ProjectDomainId);
            Assert.IsNotNull(getProjectDomain);

            var getResult = (OkObjectResult)getProjectDomain;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var projectDomain = (ProjectDomainViewModel)getResponse.Result;
            Assert.IsTrue(projectDomainUpdate.ProjectDomainName == projectDomain.ProjectDomainName);
        }
    }
}
