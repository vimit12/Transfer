﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class WorkFlowConfigAPITest : UnitTestBase
    {
        private static WorkFlowConfigController workFlowConfigController;
        private static WorkFlowConfigService workFlowConfigService;
        private static WorkFlowConfigViewModel workFlowConfigViewModel;
        private static Mock<ILogger<WorkFlowConfigController>> Logger;
        private List<WorkFlowConfigViewModel> workFlowConfigViewModels = new List<WorkFlowConfigViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            workFlowConfigService = new WorkFlowConfigService(Repository, Mapper);
            Logger = new Mock<ILogger<WorkFlowConfigController>>();
            workFlowConfigController = new WorkFlowConfigController(workFlowConfigService, Logger.Object);

            Repository.Repository<WorkFlowTemplateMapping>().DeleteRange(Repository.Repository<WorkFlowTemplateMapping>().GetAll());
            Repository.Repository<WorkFlow>().DeleteRange(Repository.Repository<WorkFlow>().GetAll());

            workFlowConfigController = new WorkFlowConfigController(workFlowConfigService, Logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var workFlowConfigViewModel = new WorkFlowConfigViewModel
            {
                WorkFlowId = new Random().Next(1, randomInterval),
                StatusActionId = 13,
                StatusTypeId = 16,
                IsActive = true,
                Comments = "Service Test"
            };

            workFlowConfigViewModel.WorkFlowTemplateMappingList = new List<WorkFlowTemplateMappingViewModel>() { new WorkFlowTemplateMappingViewModel { WorkFlowId = workFlowConfigViewModel.WorkFlowId, TemplateId = 1 } };
            workFlowConfigController.AddWorkFlow(workFlowConfigViewModel);
            workFlowConfigViewModels.Add(workFlowConfigViewModel);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            workFlowConfigViewModel = null;
            workFlowConfigViewModels = null;
        }

        [TestMethod]
        public void GetAllWorkFlows()
        {
            var workFlows = workFlowConfigController.GetAllWorkFlows();
            Assert.IsNotNull(workFlows);

            var result = (OkObjectResult)workFlows;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddWorkFlow()
        {
            workFlowConfigViewModel = new WorkFlowConfigViewModel
            {
                WorkFlowId = new Random().Next(1, randomInterval),
                StatusActionId = 17,
                StatusTypeId = 15,
                IsActive = true,
                Comments = "Service Test"
            };

            workFlowConfigViewModel.WorkFlowTemplateMappingList = new List<WorkFlowTemplateMappingViewModel>() { new WorkFlowTemplateMappingViewModel { WorkFlowId = workFlowConfigViewModel.WorkFlowId, TemplateId = 1 } };

            var createdWorkFlow = workFlowConfigController.AddWorkFlow(workFlowConfigViewModel);
            Assert.IsNotNull(createdWorkFlow);

            var result = (OkObjectResult)createdWorkFlow;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void UpdateWorkFlow()
        {
            var workFlow = workFlowConfigViewModels.FirstOrDefault();
            workFlow.Comments = "Update Test";
            workFlow.StatusTypeId = 200;
        }
    }
}