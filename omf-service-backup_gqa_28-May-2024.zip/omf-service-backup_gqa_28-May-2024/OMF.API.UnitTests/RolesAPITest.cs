﻿namespace OMF.API.UnitTests
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Common;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using OMF.Data.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class RolesAPITest : UnitTestBase
    {
        private static RoleController RoleController;
        private static RoleService RoleService;
        private static Mock<ILogger<RoleController>> logger;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            RoleService = new RoleService(Repository, Mapper);
            logger = new Mock<ILogger<RoleController>>();
            RoleController = new RoleController(RoleService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext()
                    {
                        User = User
                    }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            prepareData();
        }

        [TestMethod]
        public void GetRoles()
        {
            var getRoles = RoleController.GetRoles();
            Assert.IsNotNull(getRoles);

            var result = (OkObjectResult)getRoles;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var viewModel = (IEnumerable<RoleViewModel>)response.Result;
            Assert.IsTrue(viewModel.Any(x => x.RoleId == 1));
        }

        [TestMethod]
        public void GetActiveRoles()
        {
            var getRoles = RoleController.GetActiveRoles();
            Assert.IsNotNull(getRoles);

            var result = (OkObjectResult)getRoles;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response);

            var viewModel = (IEnumerable<RoleViewModel>)response.Result;
            Assert.IsTrue(viewModel.Any(x => x.RoleId == 1));
        }

        private void prepareData()
        {
            var model = new Role
            {
                RoleId = 1,
                RoleName = "Test Role",
                IsActive = true,
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
            };

            Repository.Repository<Role>().DeleteRange(Repository.Repository<Role>().GetAll());
            Repository.Repository<Role>().Add(model);
            Repository.SaveChanges();
        }
    }
}
