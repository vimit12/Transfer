﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class PaymentTermApprovalTrackerAPITest : UnitTestBase
    {
        private static PaymentTermApprovalTrackerController paymentTermApprovalTrackerController;
        private static PaymentTermApprovalTrackerService paymentTermApprovalTrackerService;
        private static PaymentTermApprovalTrackerViewModel paymentTermApprovalTrackerViewModel;
        private static Mock<ILogger<PaymentTermApprovalTrackerController>> logger;
        private List<PaymentTermApprovalTrackerViewModel> paymentTermApprovalTrackerList = new List<PaymentTermApprovalTrackerViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            paymentTermApprovalTrackerService = new PaymentTermApprovalTrackerService(Repository, Mapper);
            logger = new Mock<ILogger<PaymentTermApprovalTrackerController>>();
            paymentTermApprovalTrackerController = new PaymentTermApprovalTrackerController(paymentTermApprovalTrackerService, logger.Object);
            Repository.Repository<PaymentTermApprovalTracker>().DeleteRange(Repository.Repository<PaymentTermApprovalTracker>().GetAll());
            Repository.Repository<ClientMaster>().Add(new ClientMaster
            {
                ClientMasterId = 1,
                ClientName = "Test",
                CreatedBy = "nbhat",
                CreatedDate = DateTime.Now,
                IsActive = true,
                PaymentTermId = 1,
            });

            paymentTermApprovalTrackerController = new PaymentTermApprovalTrackerController(paymentTermApprovalTrackerService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getPaymentTermApprovalTrackers = paymentTermApprovalTrackerController.GetAllPaymentTermApprovalTrackers();
            Assert.IsNotNull(getPaymentTermApprovalTrackers);

            var result = (OkObjectResult)getPaymentTermApprovalTrackers;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<PaymentTermApprovalTrackerViewModel>)response.Result;

            if (getData.Count > 0)
            {
                paymentTermApprovalTrackerList = getData;
            }
            else
            {
                paymentTermApprovalTrackerViewModel = new PaymentTermApprovalTrackerViewModel
                {
                    PaymentTermApprovalTrackerId = new Random().Next(1, randomInterval),
                    ClientMasterId = 1,
                    IsActive = true,
                    IsApproved = false
                };

                var paymentTermApprovalTracker = paymentTermApprovalTrackerController.AddPaymentTermApprovalTracker(paymentTermApprovalTrackerViewModel);
                paymentTermApprovalTrackerList.Add(paymentTermApprovalTrackerViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            paymentTermApprovalTrackerViewModel = null;
            paymentTermApprovalTrackerList = null;
        }

        [TestMethod]
        public void GetAllPaymentTermApprovalTrackers()
        {
            var getPaymentTermApprovalTrackers = paymentTermApprovalTrackerController.GetAllPaymentTermApprovalTrackers();
            Assert.IsNotNull(getPaymentTermApprovalTrackers);

            var result = (OkObjectResult)getPaymentTermApprovalTrackers;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetPaymentTermApprovalTrackerById()
        {
            var getPaymentTermApprovalTracker = paymentTermApprovalTrackerController.GetPaymentTermApprovalTrackerById(paymentTermApprovalTrackerList.FirstOrDefault().PaymentTermApprovalTrackerId);
            Assert.IsNotNull(getPaymentTermApprovalTracker);

            var result = (OkObjectResult)getPaymentTermApprovalTracker;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddPaymentTermApprovalTracker()
        {
            paymentTermApprovalTrackerViewModel = new PaymentTermApprovalTrackerViewModel
            {
                PaymentTermApprovalTrackerId = new Random().Next(1, randomInterval),
                ClientMasterId = 1,
                IsActive = true,
                IsApproved = false,
                PaymentTermId = 1
            };

            var createdPaymentTermApprovalTracker = paymentTermApprovalTrackerController.AddPaymentTermApprovalTracker(paymentTermApprovalTrackerViewModel);
            Assert.IsNotNull(createdPaymentTermApprovalTracker);

            var result = (OkObjectResult)createdPaymentTermApprovalTracker;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getPaymentTermApprovalTrackers = paymentTermApprovalTrackerController.GetAllPaymentTermApprovalTrackers();
            Assert.IsNotNull(getPaymentTermApprovalTrackers);

            var getResult = (OkObjectResult)getPaymentTermApprovalTrackers;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var paymentTermApprovalTrackerList = (List<PaymentTermApprovalTrackerViewModel>)getResponse.Result;
            Assert.IsTrue(paymentTermApprovalTrackerList.Any(e => e.ClientMasterId == paymentTermApprovalTrackerViewModel.ClientMasterId));
        }

        [TestMethod]
        public void UpdatePaymentTermApprovalTracker()
        {
            var paymentTermApprovalTrackerUpdate = paymentTermApprovalTrackerList.FirstOrDefault();
            paymentTermApprovalTrackerUpdate.ClientMasterId = 1;

            var editPaymentTermApprovalTracker = paymentTermApprovalTrackerController.UpdatePaymentTermApprovalTracker(paymentTermApprovalTrackerUpdate);
            Assert.IsNotNull(editPaymentTermApprovalTracker);

            var result = (OkObjectResult)editPaymentTermApprovalTracker;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getPaymentTermApprovalTracker = paymentTermApprovalTrackerController.GetPaymentTermApprovalTrackerById(paymentTermApprovalTrackerUpdate.PaymentTermApprovalTrackerId);
            Assert.IsNotNull(getPaymentTermApprovalTracker);

            var getResult = (OkObjectResult)getPaymentTermApprovalTracker;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var paymentTermApprovalTracker = (PaymentTermApprovalTrackerViewModel)getResponse.Result;
            Assert.IsTrue(paymentTermApprovalTrackerUpdate.ClientMasterId == paymentTermApprovalTracker.ClientMasterId);
        }
    }
}
