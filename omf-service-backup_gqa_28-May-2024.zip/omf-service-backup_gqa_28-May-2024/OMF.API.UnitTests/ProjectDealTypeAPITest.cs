﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class ProjectDealTypeAPITest : UnitTestBase
    {
        private static ProjectDealTypeController projectDealTypeController;
        private static ProjectDealTypeService projectDealTypeService;
        private static ProjectDealTypeViewModel projectDealTypeViewModel;
        private static Mock<ILogger<ProjectDealTypeController>> logger;
        private List<ProjectDealTypeViewModel> projectDealTypeList = new List<ProjectDealTypeViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            projectDealTypeService = new ProjectDealTypeService(Repository, Mapper);
            logger = new Mock<ILogger<ProjectDealTypeController>>();
            projectDealTypeController = new ProjectDealTypeController(projectDealTypeService, logger.Object);
            Repository.Repository<ProjectDealType>().DeleteRange(Repository.Repository<ProjectDealType>().GetAll());

            projectDealTypeController = new ProjectDealTypeController(projectDealTypeService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getProjectDealTypes = projectDealTypeController.GetAllProjectDealTypes();
            Assert.IsNotNull(getProjectDealTypes);

            var result = (OkObjectResult)getProjectDealTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<ProjectDealTypeViewModel>)response.Result;

            if (getData.Count > 0)
            {
                projectDealTypeList = getData;
            }
            else
            {
                projectDealTypeViewModel = new ProjectDealTypeViewModel
                {
                    ProjectDealTypeId = new Random().Next(1, randomInterval),
                    ProjectDealTypeName = "TESTAPI",
                    ProjectDomainId = new Random().Next(1, randomInterval),
                    OnShorePercentage = 22,
                    OffShorePercentage = 23,
                    IsActive = true,
                    Comments = "TestComment",
                };

                var projectDealType = projectDealTypeController.AddProjectDealType(projectDealTypeViewModel);
                projectDealTypeList.Add(projectDealTypeViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            projectDealTypeViewModel = null;
            projectDealTypeList = null;
        }

        [TestMethod]
        public void GetAllProjectDealTypes()
        {
            var getProjectDealTypes = projectDealTypeController.GetAllProjectDealTypes();
            Assert.IsNotNull(getProjectDealTypes);

            var result = (OkObjectResult)getProjectDealTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddProjectDealType()
        {
            projectDealTypeViewModel = new ProjectDealTypeViewModel
            {
                ProjectDealTypeId = new Random().Next(1, randomInterval),
                ProjectDealTypeName = "TESTAPI",
                ProjectDomainId = 1,
                OnShorePercentage = 22,
                OffShorePercentage = 23,
                IsActive = true,
                Comments = "TestComment"
            };

            var createdProjectDealType = projectDealTypeController.AddProjectDealType(projectDealTypeViewModel);
            Assert.IsNotNull(createdProjectDealType);

            var result = (OkObjectResult)createdProjectDealType;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getProjectDealTypes = projectDealTypeController.GetAllProjectDealTypes();
            Assert.IsNotNull(getProjectDealTypes);

            var getResult = (OkObjectResult)getProjectDealTypes;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var projectDealTypeList = (List<ProjectDealTypeViewModel>)getResponse.Result;
            Assert.IsTrue(projectDealTypeList.Any(e => e.ProjectDealTypeName == projectDealTypeViewModel.ProjectDealTypeName));
        }

        [TestMethod]
        public void UpdateProjectDealType()
        {
            var projectDealTypeUpdate = projectDealTypeList.FirstOrDefault();
            projectDealTypeUpdate.ProjectDealTypeName = "TESTAPI";

            var editProjectDealType = projectDealTypeController.UpdateProjectDealType(projectDealTypeUpdate);
            Assert.IsNotNull(editProjectDealType);

            var result = (OkObjectResult)editProjectDealType;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getProjectDealType = projectDealTypeController.GetContractTypeById(projectDealTypeUpdate.ProjectDealTypeId);
            Assert.IsNotNull(getProjectDealType);

            var getResult = (OkObjectResult)getProjectDealType;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var projectDealType = (ProjectDealTypeViewModel)getResponse.Result;
            Assert.IsTrue(projectDealTypeUpdate.ProjectDealTypeName == projectDealType.ProjectDealTypeName);
        }

        [TestMethod]
        public void GetActiveProjectDealTypes()
        {
            var getProjectDealTypes = projectDealTypeController.GetActiveProjectDealTypes();
            Assert.IsNotNull(getProjectDealTypes);

            var result = (OkObjectResult)getProjectDealTypes;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}
