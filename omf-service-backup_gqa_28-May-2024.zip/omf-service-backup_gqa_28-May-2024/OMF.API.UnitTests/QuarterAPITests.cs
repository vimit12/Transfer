﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class QuarterAPITests : UnitTestBase
    {
        private static QuarterController quarterController;
        private static QuarterService quarterService;
        private static Mock<ILogger<QuarterController>> logger;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            quarterService = new QuarterService(Repository, Mapper);
            logger = new Mock<ILogger<QuarterController>>();
            quarterController = new QuarterController(quarterService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
            PrepareTestData();
        }


        [TestMethod]
        public void GetAllQuarters()
        {
            var getQuarters = quarterController.GetAllQuarters();
            Assert.IsNotNull(getQuarters);

            var result = (OkObjectResult)getQuarters;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetQuarterById()
        {
            var getQuarter = quarterController.GetQuarterById(1);
            Assert.IsNotNull(getQuarter);

            var result = (OkObjectResult)getQuarter;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        private static void PrepareTestData()
        {
            Repository.Repository<Quarter>().DeleteRange(Repository.Repository<Quarter>().GetAll());
            Repository.SaveChanges();

            var quarterList = new List<Quarter>()
            {
                new Quarter() { QuarterId =1 , QuarterName = "First Quarter" },
                new Quarter() { QuarterId = 2, QuarterName = "Second Quarter" }
            };
            Repository.Repository<Quarter>().AddRange(quarterList);
            Repository.SaveChanges();
        }

        [TestMethod]
        public void GetCurrentQuarter()
        {
            var getQuarters = quarterController.GetCurrentQuarter();
            Assert.IsNotNull(getQuarters);

            var result = (OkObjectResult)getQuarters;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}
