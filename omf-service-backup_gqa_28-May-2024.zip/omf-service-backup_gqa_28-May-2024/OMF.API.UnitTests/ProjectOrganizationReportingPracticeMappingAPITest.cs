﻿
namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class ProjectOrganizationReportingPracticeMappingAPITest : UnitTestBase
    {
        private static ProjectOrganizationReportingPracticeMappingController POReportingPracticeMappingController;
        private static ProjectOrganizationReportingPracticeMappingService POReportingPracticeMappingService;
        private static ProjectOrganizationReportingPracticeMappingViewModel POReportingPracticeMappingViewModel;
        private static Mock<ILogger<ProjectOrganizationReportingPracticeMappingController>> Logger;
        private List<ProjectOrganizationReportingPracticeMappingViewModel> poReportingPracticeMappingList = new List<ProjectOrganizationReportingPracticeMappingViewModel>();

        private static ProjectOrganizationViewModel ProjectOrganizationViewModel;
        private static ReportingPracticeViewModel ReportingPracticeViewModel;

        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {

            UnitTestBase baseObject = new UnitTestBase();
            POReportingPracticeMappingService = new ProjectOrganizationReportingPracticeMappingService(Repository, Mapper);
            Logger = new Mock<ILogger<ProjectOrganizationReportingPracticeMappingController>>();
            POReportingPracticeMappingController = new ProjectOrganizationReportingPracticeMappingController(POReportingPracticeMappingService, Logger.Object);
            Repository.Repository<ProjectOrganizationReportingPracticeMapping>().DeleteRange(Repository.Repository<ProjectOrganizationReportingPracticeMapping>().GetAll());

            POReportingPracticeMappingController = new ProjectOrganizationReportingPracticeMappingController(POReportingPracticeMappingService, Logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            ProjectOrganizationViewModel = new ProjectOrganizationViewModel()
            {
                ProjectOrganizationId = 1,
                ProjectOrganizationName = "Project1"

            };

            ReportingPracticeViewModel = new ReportingPracticeViewModel()
            {
                ReportingPracticeId = 1,
                ReportingPracticeName = "RP1"

            };

            POReportingPracticeMappingViewModel = new ProjectOrganizationReportingPracticeMappingViewModel
            {
                ProjectOrganizationId = 1,
                ReportingPractices = new List<ReportingPracticeViewModel> { new ReportingPracticeViewModel { ReportingPracticeId = 1, ReportingPracticeName = "RP1" } },
                IsActive = true
            };

            var projectOrganization = POReportingPracticeMappingController.AddProjectOrganizationReportingPracticeMapping(POReportingPracticeMappingViewModel);
            poReportingPracticeMappingList.Add(POReportingPracticeMappingViewModel);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            POReportingPracticeMappingViewModel = null;
            poReportingPracticeMappingList = null;
        }

        [TestMethod]
        public void GetPOReportingPractices()
        {
            var poRPMappings = POReportingPracticeMappingController.GetAllProjectOrganizationReportingPracticeMappings();
            Assert.IsNotNull(poRPMappings);

            var result = (OkObjectResult)poRPMappings;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddPOReportingPracticeMapping()
        {
            POReportingPracticeMappingViewModel = new ProjectOrganizationReportingPracticeMappingViewModel
            {
                ProjectOrganizationId = new Random().Next(1, randomInterval),
                ReportingPractices = new List<ReportingPracticeViewModel> { new ReportingPracticeViewModel { ReportingPracticeId = 1000001, ReportingPracticeName = "RP1" } },
                IsActive = true
            };

            var createdPORP = POReportingPracticeMappingController.AddProjectOrganizationReportingPracticeMapping(POReportingPracticeMappingViewModel);
            Assert.IsNotNull(createdPORP);

            var result = (OkObjectResult)createdPORP;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getCapabilities = POReportingPracticeMappingController.GetAllProjectOrganizationReportingPracticeMappings();
            Assert.IsNotNull(getCapabilities);

            var getResult = (OkObjectResult)getCapabilities;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}
