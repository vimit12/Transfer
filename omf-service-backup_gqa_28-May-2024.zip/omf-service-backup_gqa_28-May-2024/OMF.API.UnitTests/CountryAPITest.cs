namespace OMF.API.UnitTests
{
  using System.Collections.Generic;
  using Microsoft.Extensions.Logging;
  using Microsoft.VisualStudio.TestTools.UnitTesting;
  using Moq;
  using OMF.API.Controllers;
  using OMF.Business.Models;
  using OMF.Business.Services;
  using Microsoft.AspNetCore.Http;
  using OMF.API.Common;
  using Microsoft.AspNetCore.Mvc;
  using System.Linq;
  using OMF.Data.Models;
  using System;

  [TestClass]
  public class CountryAPITests : UnitTestBase
  {
    private static CountryController countryController;
    private static CountryService countryService;
    private static CountryViewModel countryViewModel;
    private static Mock<ILogger<CountryController>> logger;
    private List<CountryViewModel> countryList = new List<CountryViewModel>();
    private int randomInterval = 100000;

    [ClassInitialize]
    public static void ClassInitialize(TestContext context)
    {
      UnitTestBase baseObject = new UnitTestBase();
      countryService = new CountryService(Repository, Mapper);
      logger = new Mock<ILogger<CountryController>>();
      countryController = new CountryController(countryService, logger.Object);
      Repository.Repository<Country>().DeleteRange(Repository.Repository<Country>().GetAll());

      countryController = new CountryController(countryService, logger.Object)
      {
        ControllerContext = new ControllerContext()
        {
          HttpContext = new DefaultHttpContext() { User = User }
        }
      };
    }

    [TestInitialize]
    public void TestInitialize()
    {
      var getCountries = countryController.GetCountries();
      Assert.IsNotNull(getCountries);

      var result = (OkObjectResult)getCountries;
      Assert.AreEqual(200, result.StatusCode);

      var response = (ApiOkResponse)result.Value;
      Assert.IsNotNull(response.Result);

      var getData = (List<CountryViewModel>)response.Result;

      if (getData.Count > 0)
      {
        countryList = getData;
      }
      else
      {
        countryViewModel = new CountryViewModel
        {
          CountryId = new Random().Next(1, randomInterval),
          CountryName = "India",
          IsActive = true,
          CurrencyId = 1,
          Comments =  "Indian INRR",
          IsTaxRegistrationNoRequired = false,
          RegionId= 1,
        };

        var country = countryController.AddCountry(countryViewModel);
        countryList.Add(countryViewModel);
      }
    }

    [TestCleanup]
    public void TestCleanUp()
    {
      countryViewModel = null;
      countryList = null;
    }

    [TestMethod]
    public void GetActiveCountries()
    {
      var getCountries = countryController.GetActiveCountries();
      Assert.IsNotNull(getCountries);

      var result = (OkObjectResult)getCountries;
      Assert.AreEqual(200, result.StatusCode);

      var response = (ApiOkResponse)result.Value;
      Assert.IsNotNull(response.Result);
    }

    [TestMethod]
    public void GetAllCountries()
    {
      var getCountries = countryController.GetCountries();
      Assert.IsNotNull(getCountries);

      var result = (OkObjectResult)getCountries;
      Assert.AreEqual(200, result.StatusCode);

      var response = (ApiOkResponse)result.Value;
      Assert.IsNotNull(response.Result);
    }

    [TestMethod]
    public void GetCountryById()
    {
      var getCountry = countryController.GetcountryById(countryList.FirstOrDefault().CountryId);
      Assert.IsNotNull(getCountry);

      var result = (OkObjectResult)getCountry;
      Assert.AreEqual(200, result.StatusCode);

      var response = (ApiOkResponse)result.Value;
      Assert.IsNotNull(response.Result);
    }

    [TestMethod]
    public void AddCountry()
    {
            countryViewModel = new CountryViewModel
            {
                CountryId = new Random().Next(1, randomInterval),
                CountryName = "India",
                IsActive = true,
                CurrencyId = 1,
                RegionId = 1
            };

      var createdCountry = countryController.AddCountry(countryViewModel);
      Assert.IsNotNull(createdCountry);

      var result = (OkObjectResult)createdCountry;
      Assert.AreEqual(200, result.StatusCode);
      var response = (ApiOkResponse)result.Value;
      Assert.IsNotNull(response.Result);

      var getCountries = countryController.GetCountries();
      Assert.IsNotNull(getCountries);

      var getResult = (OkObjectResult)getCountries;
      Assert.AreEqual(200, result.StatusCode);
      var getResponse = (ApiOkResponse)getResult.Value;
      Assert.IsNotNull(response.Result);

      var countryList = (List<CountryViewModel>)getResponse.Result;
      Assert.IsTrue(countryList.Any(e => e.CountryName == countryViewModel.CountryName));
    }

    [TestMethod]
    public void UpdateCountry()
    {
      var countryUpdate = countryList.FirstOrDefault();
      countryUpdate.CountryName = "IndiaInd";

      var editCountry = countryController.UpdateCountry(countryUpdate);
      Assert.IsNotNull(editCountry);

      var result = (OkObjectResult)editCountry;
      Assert.AreEqual(200, result.StatusCode);

      var response = (ApiOkResponse)result.Value;
      Assert.IsNotNull(response.Result);

      var getCountry = countryController.GetcountryById(countryUpdate.CountryId);
      Assert.IsNotNull(getCountry);

      var getResult = (OkObjectResult)getCountry;
      Assert.AreEqual(200, result.StatusCode);

      var getResponse = (ApiOkResponse)getResult.Value;
      Assert.IsNotNull(response.Result);

      var country = (CountryViewModel)getResponse.Result;
      Assert.IsTrue(countryUpdate.CountryName == country.CountryName);
    }
  }
}
