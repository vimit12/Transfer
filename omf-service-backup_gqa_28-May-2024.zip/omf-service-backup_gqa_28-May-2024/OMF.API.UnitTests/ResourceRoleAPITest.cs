﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class ResourceRoleAPITest : UnitTestBase
    {
        private static ResourceRoleController resourceRoleController;
        private static ResourceRoleService resourceRoleService;
        private static ResourceRoleViewModel resourceRoleViewModel;
        private static Mock<ILogger<ResourceRoleController>> logger;
        private List<ResourceRoleViewModel> resourceRoleList = new List<ResourceRoleViewModel>();
        private int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            resourceRoleService = new ResourceRoleService(Repository, Mapper);
            logger = new Mock<ILogger<ResourceRoleController>>();
            resourceRoleController = new ResourceRoleController(resourceRoleService, logger.Object);
            Repository.Repository<ResourceRole>().DeleteRange(Repository.Repository<ResourceRole>().GetAll());

            resourceRoleController = new ResourceRoleController(resourceRoleService, logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var getResourceRole = resourceRoleController.GetResourceRole();
            Assert.IsNotNull(getResourceRole);

            var result = (OkObjectResult)getResourceRole;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<ResourceRoleViewModel>)response.Result;

            if (getData.Count > 0)
            {
                resourceRoleList = getData;
            }
            else
            {
                resourceRoleViewModel = new ResourceRoleViewModel
                {
                    ResourceRoleId = new Random().Next(1, randomInterval),
                    ResourceRoleName = "Manager",
                    IsActive = true,
                };

                var country = resourceRoleController.AddResourceRole(resourceRoleViewModel);
                resourceRoleList.Add(resourceRoleViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            resourceRoleViewModel = null;
            resourceRoleList = null;
        }

        [TestMethod]
        public void GetAllResourceRole()
        {
            var getResourceRole = resourceRoleController.GetResourceRole();
            Assert.IsNotNull(getResourceRole);

            var result = (OkObjectResult)getResourceRole;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetResourceRoleById()
        {
            var getResourceRole = resourceRoleController.GetResourceRoleById(resourceRoleList.FirstOrDefault().ResourceRoleId);
            Assert.IsNotNull(getResourceRole);

            var result = (OkObjectResult)getResourceRole;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddResourceRole()
        {
            resourceRoleViewModel = new ResourceRoleViewModel
            {
                ResourceRoleId = new Random().Next(1, randomInterval),
                ResourceRoleName = "Manager",
                IsActive = true,
            };

            var createdResourceRole = resourceRoleController.AddResourceRole(resourceRoleViewModel);
            Assert.IsNotNull(createdResourceRole);

            var result = (OkObjectResult)createdResourceRole;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getResourceRole = resourceRoleController.GetResourceRole();
            Assert.IsNotNull(getResourceRole);

            var getResult = (OkObjectResult)getResourceRole;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var resourceRoleList = (List<ResourceRoleViewModel>)getResponse.Result;
            Assert.IsTrue(resourceRoleList.Any(e => e.ResourceRoleName == resourceRoleViewModel.ResourceRoleName));
        }

        [TestMethod]
        public void UpdateResourceRole()
        {
            var resourceRoleUpdate = resourceRoleList.FirstOrDefault();
            resourceRoleUpdate.ResourceRoleName = "Manager";

            var editResourceRole = resourceRoleController.UpdateResourceRole(resourceRoleUpdate);
            Assert.IsNotNull(editResourceRole);

            var result = (OkObjectResult)editResourceRole;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getResourceRole = resourceRoleController.GetResourceRoleById(resourceRoleUpdate.ResourceRoleId);
            Assert.IsNotNull(getResourceRole);

            var getResult = (OkObjectResult)getResourceRole;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var resourceRole = (ResourceRoleViewModel)getResponse.Result;
            Assert.IsTrue(resourceRoleUpdate.ResourceRoleName == resourceRole.ResourceRoleName);
        }

        [TestMethod]
        public void GetActiveResourceRole()
        {
            var getResourceRole = resourceRoleController.GetActiveResourceRole();
            Assert.IsNotNull(getResourceRole);

            var result = (OkObjectResult)getResourceRole;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }
    }
}
