﻿namespace OMF.API.UnitTests
{
    using System.Collections.Generic;
    using Microsoft.Extensions.Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using OMF.API.Controllers;
    using OMF.Business.Models;
    using OMF.Business.Services;
    using Microsoft.AspNetCore.Http;
    using OMF.API.Common;
    using Microsoft.AspNetCore.Mvc;
    using System.Linq;
    using OMF.Data.Models;
    using System;

    [TestClass]
    public class CapabilityAPITest : UnitTestBase
    {
        private static CapabilityController CapabilityController;
        private static CapabilityService CapabilityService;
        private static CapabilityViewModel CapabilityViewModel;
        private static Mock<ILogger<CapabilityController>> Logger;
        private List<CapabilityViewModel> capabilityList = new List<CapabilityViewModel>();
        private readonly int randomInterval = 100000;

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            UnitTestBase baseObject = new UnitTestBase();
            CapabilityService = new CapabilityService(Repository, Mapper);
            Logger = new Mock<ILogger<CapabilityController>>();
            CapabilityController = new CapabilityController(CapabilityService, Logger.Object);
            Repository.Repository<Capability>().DeleteRange(Repository.Repository<Capability>().GetAll());

            CapabilityController = new CapabilityController(CapabilityService, Logger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext() { User = User }
                }
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            var capabilities = CapabilityController.GetCapabilities();
            Assert.IsNotNull(capabilities);

            var result = (OkObjectResult)capabilities;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getData = (List<CapabilityViewModel>)response.Result;

            if (getData.Count > 0)
            {
                capabilityList = getData;
            }
            else
            {
                CapabilityViewModel = new CapabilityViewModel
                {
                    CapabilityId = new Random().Next(1, randomInterval),
                    CapabilityName = " Capability",
                    IsActive = true
                };

                var capability = CapabilityController.AddCapability(CapabilityViewModel);
                capabilityList.Add(CapabilityViewModel);
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            CapabilityViewModel = null;
            capabilityList = null;
        }

        [TestMethod]
        public void GetActiveCapabilities()
        {
            var getActiveCapabilities = CapabilityController.GetActiveCapabilities();
            Assert.IsNotNull(getActiveCapabilities);

            var result = (OkObjectResult)getActiveCapabilities;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetCapabilities()
        {
            var capabilities = CapabilityController.GetCapabilities();
            Assert.IsNotNull(capabilities);

            var result = (OkObjectResult)capabilities;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void GetCapabilitiesById()
        {
            var getCapability = CapabilityController.GetCapabilitiesById(capabilityList.FirstOrDefault().CapabilityId);
            Assert.IsNotNull(getCapability);

            var result = (OkObjectResult)getCapability;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);
        }

        [TestMethod]
        public void AddCapability()
        {
            CapabilityViewModel = new CapabilityViewModel
            {
                CapabilityId = new Random().Next(1, randomInterval),
                CapabilityName = " Capability",
                IsActive = true,
            };

            var createdCapability = CapabilityController.AddCapability(CapabilityViewModel);
            Assert.IsNotNull(createdCapability);

            var result = (OkObjectResult)createdCapability;
            Assert.AreEqual(200, result.StatusCode);
            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getCapabilities = CapabilityController.GetCapabilities();
            Assert.IsNotNull(getCapabilities);

            var getResult = (OkObjectResult)getCapabilities;
            Assert.AreEqual(200, result.StatusCode);
            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var CapabilityList = (List<CapabilityViewModel>)getResponse.Result;
            Assert.IsTrue(CapabilityList.Any(e => e.CapabilityName == CapabilityViewModel.CapabilityName));
        }

        [TestMethod]
        public void UpdateCapability()
        {
            var capabilityUpdate = capabilityList.FirstOrDefault();
            capabilityUpdate.CapabilityName = "Capability Update";

            var editCapability = CapabilityController.UpdateCapability(capabilityUpdate);
            Assert.IsNotNull(editCapability);

            var result = (OkObjectResult)editCapability;
            Assert.AreEqual(200, result.StatusCode);

            var response = (ApiOkResponse)result.Value;
            Assert.IsNotNull(response.Result);

            var getCapability = CapabilityController.GetCapabilitiesById(capabilityUpdate.CapabilityId);
            Assert.IsNotNull(getCapability);

            var getResult = (OkObjectResult)getCapability;
            Assert.AreEqual(200, result.StatusCode);

            var getResponse = (ApiOkResponse)getResult.Value;
            Assert.IsNotNull(response.Result);

            var Capability = (CapabilityViewModel)getResponse.Result;
            Assert.IsTrue(capabilityUpdate.CapabilityName == Capability.CapabilityName);
        }
    }
}